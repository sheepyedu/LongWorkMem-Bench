# 交付争议追溯（版本 4–9）· out/inquiry.json

只读轮次：不发送、不重发、不改库。业务日 2026-03-30 · 授权版本 9。

## 程序

    python3 project/line.py history input/questions.json out/receipts-all.json out/inquiry.json

* `input/questions.json`：80 问（4 端 × 4 个 code/day × asof 4/6/7/8/9）。
* `out/receipts-all.json`：频道 → 含归档在内的批次数组 = `input/vault/*-closing-04.json`（turn 4，已封存）
  + 线上 turn 6/8/9 批次（`out/receipts-online-10.json`，sha256 `9da59aa3…`）。
* 输出：与问题 1:1、顺序不变的数组，每项恰为 `channel, code, day, asof, due, received, pending`。
* `due` 用 `explain()`（与 `/api/when` 同一口径），即**该版本当时已知的有效政策**；
  `received` 只从 `turn <= asof` 的实际回执批次按 `(turn, receipt)` 应用得到，无历史则为 `null`；
  `pending` 就是"两者时刻不一致"（含应发而实收为空）。时刻统一写 `…Z`。
* 只读保证：`history` 以 `mode=ro` 打开记录，不写 `line_feed`、不 commit；跑两次输出逐字节相同。

## 结果

80 问 / 应发 80 / 有实收 64 / **未结 21**。未结分三族：

**① 版本 7 的撤回空档（4 格，已在 turn 8 补齐）**

| 端 | code/day | 版本 7 应发 | 当时实收 |
| --- | --- | --- | --- |
| B | Q29 2026-03-16 | 16:30Z（B-611） | 17:00Z（turn 6 的临时口径） |
| C | Q29 2026-03-16 | 15:00Z（base） | 17:00Z |
| D | Q29 2026-03-16 | 15:00Z（base） | 17:00Z |
| D | U56 2026-03-23 | 09:15Z（base） | 10:45Z（Z-87） |

W-11/W-12 生效后政策回落到下一层，而订阅方还持有旧时刻；turn 8 的补发批次把四格全部拉平（asof 8 起 `pending:false`）。
这四格是"当时确实未结、后来已结"。

**② 秋季 2026-11-02 的 N84（16 格 = 4 端 × asof 4/6/7/8）**

版本 4–8 期间政策上已排定（14:45Z，11-02 已过美国换时），但秋季四端直到 turn 9 才发布，故 `received:null`、`pending:true`；
asof 9 全部落地（A/C 14:45Z，B/D 因 A-80 为 13:30Z），不再未结。

**③ 版本 9 仍开着的 1 格**

B 端 `line-401-20260316`：应发 2026-03-16T12:50Z（A-82，rank 7 胜过 V-57 的移期），实收仍是 2026-03-15T13:45Z。
即上一轮标记、已备包未发的追溯变更（`out/fixB-B-20260302-20260323.ics`）。

## 与客户主张的对照

* 除上述 21 格，其余 59 问在各自版本上 `due == received`：客户"当时收到的时刻"与当时政策完全一致，逐笔可核。
* 争议若指向"我们收到的和你们说的不一样"，可复算的差异只有三处：版本 7 的撤回空档（已补）、秋季未发布期（已发）、
  版本 9 的 A-82（仍开）。三处的时间点、批次号（B-00003/C-00003/D-00003/D-00004、A-00003…D-00005）与回执都可在本文件与
  `out/autumn-delivery.json`、`out/receipts-all.json` 中对照。
* 本轮的答案不引用我方 `line_feed` 记账，只引用实际回执与政策内核，因此不受当年打包顺序影响；重跑结果不变。

## 变更

* `line.py history` + `history_answers` / `received_at` / `_wire` / `_open`（只读连接）；文件头补用法。
* `project/test_inquiry.py`（20 项）：列结构、顺序、UTC 形式、`pending` 定义、due 随版本、received 随 turn、归档计入、
  空值不臆测、版本 7/9 未结清单、只读与可重跑。
* 全套 19 个测试文件 339 项通过；`data/portal.sqlite` sha256 运行前后不变。
