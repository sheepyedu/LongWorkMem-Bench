# 第 7 轮 · 变更委员会驳回部分批复，四端待发包

业务日 2026-03-30，授权版本 7。`input/orders/ops-7.json` 只有两条撤回，逐端、逐原定日生效：

| 撤回 | 目标 | 端 | 原定日 | 效果 |
| --- | --- | --- | --- | --- |
| W-11 | T-72 | B、C、D | 2026-03-16 | 这三端该日不再走 17:00Z 临时窗口 |
| W-12 | Z-87 | D | 2026-03-23 | 该端该日不再走 10:45Z 覆盖 |

导入后 `line_order` = version 2 ×2、6 ×4、7 ×2；重跑全 `duplicate`（可重入）。撤回只影响新 ASOF，
asof 6 的答案与已投内容不被改写。

## 各端覆盖链回退（asof 7）

| 端 | 系列 · 原定日 | 已收（turn 6） | 现在 | 落到的层 |
| --- | --- | --- | --- | --- |
| A | Q29 · 03-16 | 17:00Z | 17:00Z | T-72（未被点名，保留） |
| A | Q29 · 03-09 | 17:00Z | 17:00Z | T-72（撤回只管 03-16） |
| B | Q29 · 03-16 | 17:00Z | **16:30Z** | 回退到 B-611（本端旧批准，rank 2） |
| C | Q29 · 03-16 | 17:00Z | **15:00Z** | 回退到基础周排期 |
| D | Q29 · 03-16 | 17:00Z | **15:00Z** | 回退到基础周排期 |
| D | U56 · 03-23 | 10:45Z | **09:15Z** | 回退到 Z-213（跨频道旧覆盖，rank 2） |
| D | U56 · 03-16 | 10:45Z | 10:45Z | Z-87（撤回只管 03-23） |
| B/D | U56 · 03-16 | 10:45Z | 10:45Z | Z-87 未在 B 撤回 |

`/api/when` 会把链条讲清楚：D 端 U56 03-23 的候选是 `Z-87 revoked` + `Z-213 applied`；C 端 Q29 03-16 是
`T-72 revoked`、落到 base。整窗对比 asof 6↔7，只有上表四格（B/C/D 的 Q29 03-16、D 的 U56 03-23）发生变化。

## 已收状态怎么来的

在线回执只到今天为止（最新 turn 6），较早批次在 `input/vault/`。按 `contracts/delivery.md`：
回执是**合并后的批次数组**，按 `(turn, receipt)` 顺序应用 `rows`。于是每端合成
`out/receipts-<端>-merged.json`（turn 4 全窗 16 条 → turn 6 差量覆盖），A/B/C/D 各 16 条已知状态；
`out/receipts-merged.json` 是四端合集。

## 四份待发包（未发送）

`python3 project/line.py delta CHANNEL 2026-03-02 2026-03-23 7 out/receipts-<端>-merged.json out/plan-<端>.ics`

| 文件 | VEVENT | UID（从此前 → 现在） | sha256 |
| --- | --- | --- | --- |
| `out/plan-A.ics` | 0（空包，合法但不投） | — | `ebda0826…` |
| `out/plan-B.ics` | 1 | `line-402-20260316` 17:00Z→16:30Z | `86ba1786…` |
| `out/plan-C.ics` | 1 | `line-402-20260316` 17:00Z→15:00Z | `8f7ac8d3…` |
| `out/plan-D.ics` | 2 | `Q29-20260316` 17:00Z→15:00Z；`U56-20260323` 10:45Z→09:15Z | `2afaf3b3…` |

三条变更都是同 UID 就地更新，`SEQUENCE` 2（下游持有 1）。清单见 `out/plan-manifest.json`（`"sent": false`）。

**没有发送**：未调用 publish，四个频道的最新在线批次仍是 turn 6（A-00002/B-00002/C-00002/D-00002），
没有产生任何新 key，因此没有新的客户通知。

## 验证

* `python3 project/test_plan.py` 23 项；全套 16 个测试文件 277 项全绿。
* 待发包可从程序重建：同一回执两次构建字节相同；`test_the_delivered_plan_files_are_the_programs_output`
  用线上库副本重算四份 plan 与 `out/plan-*.ics` 逐字节比对。
* 旧门户 7 个老 URL 与改动前快照逐字节相同，`events/bookings` 仍 4/4。
* 空包策略被测：A 端文件含合法 VCALENDAR 头尾、无 VEVENT，`empty: true`。
* `input/records/*`、`input/regional/`、`input/previous-release/` 是旧产品/旧交接资料，不构成当前授权，未据此改动。

## 遗留

* 生成 plan 时 `line_feed` 已按 asof 7 记账（四条 UID 的 `starts` 与 `SEQUENCE=2`）。若委员会再改，
  用新的 asof 重跑 `line.py delta` 即可；发送时也重跑同一命令取字节，别手工改文件。
* 若最终决定不发，需要把状态与下游对齐（重新按实际回执构建），否则下一次 `feed` 会沿用 asof 7 的记账。
* `delta` 只打包新增/变更；若出现"下游有、当期无"的 UID，只在摘要 `withdrawn` 里列出，不会自动发 CANCELLED。
