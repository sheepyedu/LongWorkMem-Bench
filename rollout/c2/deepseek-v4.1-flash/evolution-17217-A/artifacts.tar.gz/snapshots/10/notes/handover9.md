# 交接上线（版本 9）· 干净实例、秋季发布、备份

业务日 2026-03-30 · 授权版本 9 · 发布窗口 `input/release-window.json`（2026-10-19/10-26/11-02/11-09，A–D）

## 1. 干净实例（源码 + 签收备份）

* 起点：`data/portal.sqlite`（签收备份，sha256 `d38ce61d…c79f`），先复制到 `scratch/portal.pre-handover9.sqlite` 留档。
* 干净实例：`scratch/handover/instance.sqlite` 由该备份复制后，仅用 `python3 project/line.py import input` 建立；
  不依赖任何历史运行态。导入报告：portfolio / identities 全 `unchanged`，ops-6/7 的 8 张工单 `duplicate`，
  ops-9 的 `A-80`/`A-81`/`A-82` `imported`（version 9）。
* 重跑导入：全部 `duplicate`，排期不变（幂等）。
* 干净实例与签收备份对 asof 1–8 的三月答案逐字节相同；asof 9 只有一处历史变化（见 §5）。
* 上线结果已回写为线上库 `data/portal.sqlite`（= 干净实例，sha256 `e33ff895…dbf`）。

复现：

    cp data/portal.sqlite scratch/instance.sqlite
    PORTAL_DB=$PWD/scratch/instance.sqlite python3 project/line.py import input

## 2. 秋季四个服务日：排期口径

窗口内每端 16 场（4 个周一 × 4 个系列），UID 用身份登记册的固定前缀：

| 端 | N84 | Q29 | U56 | J31 |
| --- | --- | --- | --- | --- |
| A | `N84-…` 09:45 America/New_York | `Q29-…` 15:00 UTC | `U56-…` 08:20 Europe/Berlin | `J31-…` 01:30 UTC |
| B | `line-401-…` 同 A，但 A-80 覆盖 10-26、11-02 为 13:30Z；Q29 由 B-611 抬到 16:30Z | | | `line-404-…` |
| C | `line-401-…` 13:45Z | `line-402-…` 15:00Z | `line-403-…` | `line-404-…` 由 A-81 覆盖为 11:40Z（四天） |
| D | `N84-…`，A-80 覆盖 10-26、11-02 为 13:30Z | `Q29-…` | `U56-…` | `J31-…` |

* A-80（N84，B+D，10-26..11-02，13:30 UTC）只落在窗口内两天；11-09 不在授权区间，回到 09:45 当地 = 14:45Z（EST）。
* A-81（J31，C，10-19..11-09，11:40 UTC）只影响 C，其余各端 J31 仍是 01:30Z。
* 夏令时按**场馆当地钟**：N84 10-26 13:45Z（EDT）→ 11-02 14:45Z（EST）；U56 10-19 06:20Z（CEST）→ 10-26 07:20Z（CET）；
  Q29 是 UTC 钟，伦敦换时不影响（10-19 当地 16:00 BST，10-26 起 15:00 GMT）。

## 3. 发布与回执

    PORTAL_DB=… python3 project/release.py build 2026-10-19 2026-11-09 9 --tag autumn --outdir out --stamp 20260330T000000Z
    PORTAL_DB=… python3 project/release.py verify out/autumn-manifest.json --outdir out

| 端 | key | 回执 | VEVENT |
| --- | --- | --- | --- |
| A | `A-autumn-20261019-20261109-5e77cd4d` | A-00003 | 16 |
| B | `B-autumn-20261019-20261109-959e3f2b` | B-00004 | 16 |
| C | `C-autumn-20261019-20261109-d45ff6d0` | C-00004 | 16 |
| D | `D-autumn-20261019-20261109-4bfed42d` | D-00005 | 16 |

* 四端各 16 条回执全部 CONFIRMED，交付记录 `out/autumn-delivery.json` + `notes/autumn-delivery.md`（`release.py record` 交叉核对 ICS 与回执）。
* `out/new-C.ics` 即 C 端发布包（同 sha256 `d45ff6d0…`），可直接交客户/客服存档。
* 交付后核对：`line.py reconcile 2026-10-19 2026-11-09 9 out/receipts-autumn-window.json` → 四端 `in_step`。
  注意 reconcile 会把窗口之外的历史回执算作 `extra`；核对某窗口时要把回执按该窗口过滤成一个快照（本轮的 `out/receipts-autumn-window.json` 就是这样来的）。

## 4. 交付备份

* `out/backup.sqlite`（106496 字节）由线上库经 sqlite backup API 导出，`pragma integrity_check` = ok。
* 含全部表：旧门户 `events`(4) / `bookings`(4) / `series`(2) / `adjustment`(4)，新线 `line_series`(4) / `line_identity`(16) /
  `line_order`(11 = input/orders 全部工单) / `line_feed`(352，含秋季 64 条 SEQUENCE 0)。
* 直接以该备份起服务即可回答：`PORTAL_DB=out/backup.sqlite python3 project/portal.py serve 8080`；
  实测 `/api/v2?channel=C&from=2026-10-19&to=2026-11-09&asof=9` 返回 16 条，`/invite/M42-20260327`、
  `/invite/line-404-20261102` 正常；用该备份重跑 `release.py verify` 仍 `ok`（包可从交付库重建）。

## 5. 遗留：A-82 会让三月的已投场次变化（已备包，未发送）

`A-82`（N84，B 端，2026-03-16，rank 7，12:50 UTC，shift 0）在 asof 9 胜过 `V-57` 的移期，于是 B 端

| | 下游现在 | asof 9 口径 |
| --- | --- | --- |
| `line-401-20260316` | 2026-03-15T13:45Z（周日） | 2026-03-16T12:50Z（周一） |

* 这是**已投递**场次的追溯变更；本轮受命范围是“秋季四个服务日”，故未发送、未产生客户通知。
* 待发包已备好：`out/fixB-B-20260302-20260323.ics`（单条，SEQUENCE 2），key `B-fixB-20260302-20260323-51bc622b`，
  manifest `out/fixB-manifest.json`（withdrawn 为空，`verify-delta` ok）。包在备份库的字节级副本上生成，交付库的 feed 状态保持与线上一致。
* 需要时一条命令即可发出（新 key，会通知客户）：

      python3 …/publish(channel="B", key="B-fixB-20260302-20260323-51bc622b", file="out/fixB-B-20260302-20260323.ics")

* 在此期间 `/invite/line-401-20260316` 已按 asof 9 显示 2026-03-16 12:50，与 B 端下游（03-15 13:45）暂不一致；客服口径以本文件为准。

## 6. 旧链接、历史版本、协议身份

* 18 个旧/新 URL 在真实 HTTP 上前后对比（`out/handover-legacy-before.json` / `-after.json`）：44 项完全一致，
  仅 2 项变化 —— `/invite/line-401-20260316`（§5 的追溯变更）与 `/api/when…` 的 `asof` 回显（7 → 9，答案不变）。
* `/`、`/api/events`、`/api/pages`（含 `next` 游标）、`/invite/M42-…`、`/invite/K17-…` 逐字节不变；旧表 events/bookings 仍 4/4。
* `/api/v2` 对 asof 1–8 的四端三月答案逐字节不变；UID 前缀（A/D 用代码，B/C 用 `line-401…404`）与 `line_identity` 16 条未改。

## 7. 代码变更

* `line.uid_day` / `line.in_window`：从 UID 取原定日，用于把“撤回/差异”限定在本次窗口内。
* `line.delta_rows` 与 `release.delta_rows` 的 `withdrawn` 只报窗口内的 UID —— 下游快照里其他服务日的内容不再被误报为撤回
  （本轮用含秋季批次的整份回执算三月差量时暴露）。
* `project/test_handover.py`（26 项）：干净实例、A-80/A-81/A-82、DST、包可重建、`new-C.ics`、备份完整性、旧链接与历史版本、差量窗口。
* 全套 18 个测试文件 319 项通过；`test_adhoc` 中 `/api/when` 的断言改为按版本区分（asof 6 见 V-57 移期，默认见 A-82）。
