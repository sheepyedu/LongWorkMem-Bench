# 客服核对入口（只读）

## 入口

```bash
# 单场查询（HTTP，部署在同一个门户进程里）
GET /api/when?channel=B&code=Q29&day=2026-03-16&asof=4
```

返回 `{found, code, channel, day, original_day, uid, asof, zone, clock, basis, utc,
local, layer, candidates}`：

* `local` —— **场馆自己的钟点**（`zone` 是产品线登记里的场馆时区，Q29 为 `Europe/London`），
  夏令时按当天实际偏移显示（三月 GMT、四月起 BST）。
* `utc` —— 同一场次的 UTC 时刻，带偏移。
* `uid` —— 订阅端持有的稳定身份（`前缀-原定日`），客服可直接与客户日历里的 UID 比对。
* `layer` —— 这场比赛是谁定的：`{kind: base|approval, id, version, rank, shift_days}`，
  也就是"基础周排期"还是"某张批准单"。
* `candidates` —— 该场次命中的全部授权层及其状态（`applied` / `revoked` / `outranked`），
  客服可用它解释"为什么不是另一个时间"。
* `asof` 省略时取已登记的最大版本；`found: false` 表示该系列在该原定日没有场次
  （周几不符、系列不存在、或早于 2026-03-02 的基础排期起点）。

**只读**：`/api/when` 只走排期内核的读路径，不写 `line_feed`、不写回执、不投递、
不 import 任何东西；本轮实测查询前后 `data/portal.sqlite` 的 sha256 完全不变。
`/api/events`、`/api/pages`、`/api/v2`、`/`、`/invite/...` 的结果逐字节不变。

## 与已封存投递资料核对

```bash
python3 project/support.py preview input/support.json \
    --index input/vault/index.json \
    --json out/support-preview-2026-03-16.json \
    --markdown notes/support-answers-2026-03-16.md
```

* 问题清单来自 `input/support.json`（`{channel, code, day, asof}`）。
* 档案索引 `input/vault/index.json` 给出每端的封存批次文件；`support.py` 按索引读取，
  取该 UID 在归档里的 `utc/status/receipt/key`，与现在算出的场次逐条比对。
* 输出 `read_only: true` / `published: false`，并记录所查数据库的 sha256，
  便于日后复核"当时看到的是哪个库"。
* 有出入（时间不一致、状态不是 CONFIRMED、归档里没有这个 UID、该端没有归档）时，
  逐条写进 `problems` 并以退出码 2 结束 —— 预览照出，但明确提示需要升级处理。

## 本轮结果

`input/support.json` 的四问全部有场次、全部与归档一致（4/4）：

| 端 | 门店当地时间 | UTC | UID | 生效层 | 归档 |
| --- | --- | --- | --- | --- | --- |
| A | 2026-03-16 15:00 GMT | 15:00Z | `Q29-20260316` | 基础周排期 | A-00001 一致 |
| B | 2026-03-16 16:30 GMT | 16:30Z | `line-402-20260316` | 批准 B-611（v2 rank 2） | B-00001 一致 |
| C | 2026-03-16 15:00 GMT | 15:00Z | `line-402-20260316` | 基础周排期 | C-00001 一致 |
| D | 2026-03-16 15:00 GMT | 15:00Z | `Q29-20260316` | 基础周排期 | D-00001 一致 |

即：伦敦门店在 2026-03-16 应看到 **15:00（GMT）**；只有 B 端是 **16:30（GMT）**，
因为 B-611 只作用于 B 频道。四端归档投递与现算结果一致。

## 验证

* 测试 **195 例全绿**（新增 `project/test_support.py` 26 例：场馆时区/夏令时、
  asof 分层、撤回与被压制层的解释、无场次、`/api/when` 形状与 400、真实 HTTP、
  只读性（库 sha 与 `line_feed` 不变）、预览与归档一致/不一致/缺 UID/缺档案、CLI 退出码）。
* 旧路由逐字节不变（`/api/events`、`/api/pages`、`/`、`/invite/`、`/api/v2`）。
* 本轮**没有调用 `publish`**，四端在线回执仍为空，未通知任何客户。

## 遗留

* `/api/when` 只答"某一原定日的单场"。若要按 UID 反查（客户只报 UID），
  可用 `/invite/<uid>?tz=Europe/London`，或按 `uid` 末 8 位推出原定日再查 `/api/when`。
* 归档核对按 UID 匹配；若某场在封存之后又改过时间，预览会以"不一致"报出并退出 2，
  这时应确认是否需要新批次，而不是改档案。
