# 三月首发（release 3，业务日 2026-03-30）：四端发布包 + 交付记录

## 发布窗口的选择

"三月四个服务日"取三月里业务日（2026-03-30）之前的四个周一：
**2026-03-02 / 03-09 / 03-16 / 03-23**。窗口写作 `2026-03-02 .. 2026-03-23`，
按原定日含端点，正好四个服务日（03-30 当天不在首发里；窗口可改，见下面的重建命令）。

授权层取 `asof=3`（当前发布版本），即包含 `ops-2.json` 的 B-611（Q29/频道 B 改 16:30）
与 Z-213（U56/频道 C、D 在 03-09..03-23 改 09:15）。

## 发布包可由程序重建

```bash
python3 project/line.py    import input                    # 需要时先导入（可重入）
python3 project/release.py build 2026-03-02 2026-03-23 3 --tag first --outdir out
python3 project/release.py verify out/first-manifest.json  # 逐字节复核
```

`build` 每端渲染一份全量 ICS，并写 `out/first-manifest.json`：
端、key、文件名、sha256、VEVENT 数、DTSTAMP、UID 清单。
key 是**内容寻址**的（`A-first-20260302-20260323-8cc95bf0`），同内容必得同 key，
不同内容不可能复用已发出的 key；因此在同一数据库上重跑 `build` 得到逐字节相同的包
（本轮实测四端 sha 稳定，`line_feed` 不增长、`SEQUENCE` 保持 0）。

`verify` 做两件事：核对磁盘文件与其 sha256，再从数据库重新渲染并比字节，
另外校验 key 是否仍等于内容摘要。数据库漂移、文件被改、key 被复用都会报 `problems` 并退出 2。

## 实际投递（已发布）

| 端 | key | 文件 | sha256（前 12） | 回执 |
| --- | --- | --- | --- | --- |
| A | `A-first-20260302-20260323-8cc95bf0` | `out/first-A-20260302-20260323.ics` | `8cc95bf08f8e…` | `A-00001` |
| B | `B-first-20260302-20260323-6021bc6b` | `out/first-B-20260302-20260323.ics` | `6021bc6bf965…` | `B-00001` |
| C | `C-first-20260302-20260323-c3b5de37` | `out/first-C-20260302-20260323.ics` | `c3b5de37990c…` | `C-00001` |
| D | `D-first-20260302-20260323-a223e03c` | `out/first-D-20260302-20260323.ics` | `a223e03c65c1…` | `D-00001` |

每端 16 个 VEVENT（4 系列 × 4 服务日），全部 `STATUS:CONFIRMED`、`SEQUENCE:0`。
`A` 端与 `D` 端用系列旧名（`N84-20260302`…），`B` 端与 `C` 端用上线单编号
（`line-401-20260302`…），同一场次两端各有稳定且互不相撞的身份。

重试用同 key 已验证：A 端第二次 `publish` 返回 `already_received: true`，无副作用、无二次通知。

## 客服可引用的交付记录

* `notes/delivery-record-march-first.md` —— 人读表格：每端回执、key、文件、sha256，
  以及 64 行 `UID / 系列 / UTC / 场馆当地 / 状态`。客服按 UID 或当地时刻直接引用。
* `out/delivery-record-march-first.json` —— 同内容的机器可读版。
* `out/receipts-first.json` —— 投递服务对四个批次的原始回执（`turn/key/receipt/rows`）。

三份都由 `release.py record` 生成，且**先交叉核对再落盘**：

```bash
python3 project/release.py record out/first-manifest.json out/receipts-first.json \
    --json out/delivery-record-march-first.json \
    --markdown notes/delivery-record-march-first.md
```

核对项：回执行数与包内 VEVENT 数一致、UID 集合一致、每行 `utc` 等于包内该 UID 的
`DTSTART`、状态全为 `CONFIRMED`。任何一项不符即列出并退出 2 ——
记录不会与发出去的东西悄悄不一致。本轮结果 `problems: 0`、64/64 CONFIRMED。

## 验证

* 测试 **169 例全绿**：portal 11、migrate 14、prepare 8、adjust 15、ch64 10、recover 16、
  backup 10、q2 10、pages 12、line 20、v2 31、feed 13、release 22。
* `release.py verify out/first-manifest.json` → `ok: true, problems: 0`。
* 内容抽查：A 端 N84 在 03-02 为 14:45Z（EST），03-09 起 13:45Z（EDT，美国夏令时 3/8 起）；
  C 端 U56 在 03-02 为 07:20Z（08:20 CET），03-09..03-23 为 09:15Z（Z-213）；
  A 端 Q29 全窗 15:00Z（B-611 只作用于频道 B，B 端才是 16:30Z）。
* **从零重建**：把 `line_feed` 清空后重新 `build`，四端重新生成的 ICS 与已发布的
  `out/first-*.ics` 逐字节相同（sha 全部一致），说明发布包不依赖"之前发过什么"，
  只依赖数据库授权层 + 窗口 + DTSTAMP。
* `data/portal.sqlite` 未因本轮改动（sha `94b01e34…`）；`line_feed` 每端 72 行、`SEQUENCE` 全 0。

## 遗留

* 本轮只发首发四日；`out/feed-{A,B,C,D}-20260302-20260629.ics`（18 个周一）仍**未发布**，
  要与不要都可用同一 `release.py build` 换窗口重出，key 会随内容变化。
* `line_feed` 不表达"撤场"：某场若要从订阅端移除，需另发同 UID 的 `STATUS:CANCELLED`，
  契约未要求，本轮未做。
* `data/receipts-{A,B}.json` 是更早一轮的本地回执镜像（turn 4–8，与当前在线回执无关），
  本轮未覆盖；当前四个批次的原始回执在 `out/receipts-first.json`。
* `out/backup.sqlite` 仍是旧门户早期的签收快照，不含 `line_*` 表。
