# 第 8 轮 · 队列中断恢复（版本 8 = 恢复轮，口径仍是 asof 7）

业务日 2026-03-30。`input/version.txt` 为 8，但没有新批复文件：本轮只做恢复与补齐，不引入新口径。
`input/interruption.json` 报两项超时，都是单项批次：

| 端 | 原 key | 单项 | 恢复前线上 | 结论 |
| --- | --- | --- | --- | --- |
| C | `C-resume-08` | `line-402-20260316` 15:00Z | **已收**（回执 C-00003，turn 8） | 超时≠失败，**不补发** |
| D | `D-resume-08` | `Q29-20260316` 15:00Z | 未收（D 端止于 turn 6） | 按**原 key** 补发该单项 |

判断依据只取真实回执：`receipts(A|B|C|D)` 合并 `input/vault/` 归档后按 `(turn, receipt)` 应用。

## 恢复动作

| 端 | 回执 | key | 内容 | 说明 |
| --- | --- | --- | --- | --- |
| B | B-00003 | `B-remend8-20260302-20260323-86ba1786` | `line-402-20260316` 17:00Z→16:30Z | 第 7 轮 B 端差量从未发出，另组新批次 |
| D | D-00003 | `D-resume-08` | `Q29-20260316` 17:00Z→15:00Z | 原 key 同语义重试 |
| D | D-00004 | `D-remend8-20260302-20260323-7d464e4f` | `U56-20260323` 10:45Z→09:15Z | 同日其余差量，另组批次 |

文件：`out/resume8-B-line-402-20260316.ics`、`out/resume8-D-Q29-20260316.ics`、`out/resume8-D-U56-20260323.ics`，
均 `SEQUENCE:2`（下游持有 1），`STATUS:CONFIRMED`，DTSTAMP `20260330T000000Z`。
通知口径：**新 key 2 个**（B、D 的 remend8）+ **原 key 重试 1 个**（`D-resume-08`，不构成新通知）；
C 端一项已在线上，没有重发，因此没有第二次通知。

## 可重跑的差量入口

* `line.py delta CHANNEL FROM TO ASOF RECEIPTS_JSON OUTPUT [--only UID,...]`
  回执按 `(turn, receipt)` 应用；只输出新项或与已应用状态不同的事件；`--only` 用来把单项补发与"其他差量"拆批。
* `line.py reconcile FROM TO ASOF RECEIPTS... [--json OUT]`：**只读**核对，逐端给出 `pending / missing / extra`，
  一致时退出码 0、否则 1；不碰 `line_feed`，可以反复跑。
* 回执文件可以是单端合并数组，也可以是 `{channel: [batches]}` 或按文件名识别的 `receipts-<端>-*.json`。

留档：`out/receipts-<端>-merged-turn6.json`（第 7 轮看的样子）、`out/receipts-<端>-merged-before8.json`
（恢复前，含 C 的 turn 8）、`out/receipts-<端>-merged.json`（恢复后）、`out/receipts-online-08[-after].json`
（两次真实在线回执快照）。

## 核对（asof 7，2026-03-02 .. 2026-03-23，16 场/端）

`python3 project/line.py reconcile 2026-03-02 2026-03-23 7 out/receipts-merged.json --json out/reconcile-08.json`

| 端 | 恢复前 | 待发 | 恢复后 |
| --- | --- | --- | --- |
| A | 一致 | — | 一致 |
| B | 缺件 | `line-402-20260316` | 一致 |
| C | 一致（超时但已收） | — | 一致 |
| D | 缺件 | `Q29-20260316`、`U56-20260323` | 一致 |

恢复后再跑一次 `delta` 四端：全部空包（`scratch/rerun8/plan-*.ics`），即再跑不会重复通知。
`out/reconcile-before-8.json` 与 `out/reconcile-08.json` 是核对前后两份报告；交付记录见
`out/resume8-delivery.json` 与 `notes/resume8-delivery.md`。

## 验证

* 新增 `project/test_resume.py` 16 项（超时判定、原 key 重试、拆批、只读核对、空包重跑、在线 CONFIRMED）；
  全套 17 个测试文件 **293 项全绿**。
* 恢复包可由程序重建：用恢复前的回执重算三份包与已投文件逐字节相同。
* 核对只读：调用前后库文件 sha256 与 `line_feed` 完全不变。
* 旧门户 7 个老 URL 与改动前逐字节相同；本轮库字节未变（`d38ce61d…`）。
* `input/records/*`、`input/regional/`、`input/previous-release/` 仍是旧资料，未据此改动。

## 遗留

* `out/plan-*.ics` 保留第 7 轮"待发"原样以便审计，已不作为待发件；实际待发/已发以 `out/resume8-*` 与回执为准。
* `D-resume-08` 若日后在传输侧"迟到重放"，因同 key 同语义，订阅端只会更新同一条，不会增生。
* 若还有别的端日后报超时，先跑 `reconcile` 看真实收件，再决定原 key 补发还是新批次。
