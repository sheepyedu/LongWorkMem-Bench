# 委托：接入合作方新组合 + 排期内核（业务日 2026-03-30，发布版本 2）

范围：新产品线独立于旧试点。新增排期内核与可重入导入；旧门户/旧表/旧路由保持不变。
未生成或投递任何 ICS（本轮是排期查询内核，不是分发轮次）。

## 1. 交付
- `project/line.py`：新排期内核。
  - `python3 project/line.py import INPUT_DIR`：增量导入 `INPUT_DIR/portfolio.json` 与
    `INPUT_DIR/orders/*.json`（每份含 `version,rows`），写 `PORTAL_DB`（默认 `data/portal.sqlite`）。
  - `python3 project/line.py query CHANNEL FROM TO ASOF`：输出 JSON 数组，每行 `code,day,utc`。
- `project/test_line.py`：**20 项**回归。
- 实际导入 `data/portal.sqlite`：`line_series` 4 行、`line_order` 2 行（可重复执行）。
- `out/line-schedule-2026-03-30.json`：业务日 2026-03-30、ASOF=2、A/B/C/D 的只读查询快照（非投递件）。
- 备份：`scratch/portal.pre-line.sqlite`（导入前，sha256 `5c3c65ac…`）。

## 2. 本轮来件
- `input/portfolio.json`：N84（wall 09:45 America/New_York）、Q29（utc 15:00 Europe/London）、
  U56（wall 08:20 Europe/Berlin）、J31（utc 01:30 Australia/Sydney），weekday=0（周一），sid line-401..404。
- `input/orders/ops-2.json`（version 2）：
  - `B-611`：Q29，频道 B，2026-01-01..2026-12-31，rank 2，16:30 UTC，shift_days 0。
  - `Z-213`：U56，频道 C、D，2026-03-09..2026-03-23，rank 2，09:15 UTC，shift_days 0。
- `input/version.txt` = 2（当前发布版本）；`input/clock.txt` = 2026-03-30（周一）。
- `input/regional/*`（state=expired/closed）与旧 `records/*` 属旧产品/旧试点，**未导入**。

## 3. 语义实现（按 contracts/engine.md）
- **基础周排期**：每个系列的 `weekday`（本轮均为周一），自 **2026-03-02** 起，无截止。
  `basis=wall` 用场馆当地钟点（DST 自动，fold=0）；`basis=utc` 用 UTC 钟点。
- **查询区间**：`FROM..TO` 落在**原始周一服务日**上，含端点；早于 2026-03-02 的部分不产生场次。
- **已知版本**：只用 `version <= ASOF` 的已登记授权（批准与撤回都受此过滤），因此旧 ASOF 不被追溯改写。
- **普通批准**：按 code / 频道 / 原定日 命中其 `[start,end]` 窗口；在命中者中取最大
  `(rank, version, id)`。
- **撤回**：按 `target`（被撤批准 id）+ 频道 + 原定日窗口排除该批准，然后回退到**剩余有效层**
  （继续按 `(rank,version,id)` 取次高者）；全部被撤则回到基础排期。无窗口的撤回视为撤整条批准。
- **shift_days**：先移原定日（`day = 原定日 + shift_days`），再按 clock/basis 定时刻。
  因此输出 `day` 是**移动后的实际服务日**；`FROM..TO` 仍按**原始周一**筛选。
- **输出**：`day` 为 `YYYY-MM-DD`；`utc` 为带时区的 UTC ISO8601（`…+00:00`，符合 desk.md
  “所有时间按 ISO8601 明示时区”）。数组按「业务日、再 code」升序。
- **可重入导入**：`id` 不可变，已登记则不再登记；批次可乱序、可重送（重复为 `duplicate`）；
  同一 id 以不同内容重送直接报错拒绝（不静默覆盖）。`version` 取文件级，行内 `version` 可覆盖；
  `portfolio.json` 支持裸数组或 `{rows:[...]}`。

## 4. 验证
- **全套 126 项测试全过**：test_portal 11、test_migrate 14、test_prepare 8、test_adjust 15、
  test_ch64 10、test_recover 16、test_backup 10、test_q2 10、test_pages 12、**test_line 20**。
- test_line 覆盖：真实来件导入/重复导入、乱序批次等价、id 冲突拒绝、未知时区/依据拒绝、
  行级 version 覆盖、基础周一与 2026-03-02 起点、端点含入、无周一区间为空、
  wall/utc 跨夏令时（N84 14:45Z→13:45Z；U56 07:20Z→06:20Z）、频道+ASOF 门槛（B-611/Z-213）、
  (rank,version,id) 优先级与 id 平手、撤回落层、按频道/按日限定、无窗口撤整条、撤未知目标无副作用、
  shift_days 的 wall/utc 两种口径与“窗口按原定周一匹配”、CLI 端到端。
- **旧门户未变**：对导入前后 7 个 URL（`/api/events` 两频道与区间、`/api/pages`、`/`、两个 `/invite`）
  逐字节相同；events 4 / bookings 4 / series 2 / adjustment 4 行原样；真实环回进程照常作答。
- 当前业务日 2026-03-30（ASOF=2）：A/C/D 为合同口径（N84 13:45Z、Q29 15:00Z、U56 06:20Z、J31 01:30Z），
  B 频道 Q29 因 B-611 为 **16:30Z**；Z-213 仅在 03-09..03-23 把 C/D 的 U56 提到 09:15Z（03-30 已到期回落）。
- 幂等：真库 `import` 第二次全 `unchanged`/`duplicate`，行数不变。

## 5. 遗留 / 注意
- 本轮来件没有撤回行；撤回模型与回退已实现并由 test_line 用合成批次覆盖。约定撤回行字段：
  `id`、`target`（被撤批准 id）、`channels`，窗口用 `start`/`end` 或单日 `day`/`original_day`/`date`（缺省=撤整条）。
  若后续签批使用别的字段名，需在 `normalise_order` 内加别名。
- `ASOF` 不做“≤发布版本”的硬上限：只按 `version<=ASOF` 过滤；`import` 报告会回显 `release_version`（当前 2）。
  发布版本号仍由 `input/version.txt` 提供，未改动。
- `day` 在 `shift_days≠0` 时是移动后的实际服务日，`FROM..TO` 仍按原始周一筛选——这是对
  “shift_days 先移原定日再定时刻 / 按原始周一服务日含端点”的实现选择，已在 test_line 固化。
- 旧交接备份 `out/backup.sqlite` 是加 line 表之前的快照（旧四表逐行仍与生产库一致）；
  若要连新产品线一起交接，用 `python3 project/backup.py out/backup.sqlite` 重新生成即可。
- 新产品线的 `portfolio` 无版本号：改系列定义会追溯影响所有 ASOF；如需版本化组合，需要新契约。
- 未调用 publish、无新回执；本轮不涉及订阅端分发。

## Final review pass (round 2 close-out)

Read-through of `project/line.py` end to end; one cosmetic fix only (dropped an
unused `time` import from the datetime line; no behaviour change, module still
compiles and all 20 `test_line` cases pass).

Re-verified after the edit:

* 126/126 tests green (`test_portal` 11, `test_migrate` 14, `test_prepare` 8,
  `test_adjust` 15, `test_ch64` 10, `test_recover` 16, `test_backup` 10,
  `test_q2` 10, `test_pages` 12, `test_line` 20).
* `data/portal.sqlite` untouched by the test run: sha256
  `d0c2e63cd29f807f…`, tables events 4 / bookings 4 / series 2 / adjustment 4 /
  line_series 4 / line_order 2. Pre-import snapshot still
  `scratch/portal.pre-line.sqlite` (`5c3c65ac…`).
* Old portal is byte-identical to the pre-import snapshot over 9 URLs
  (`/api/events` A/B/D short and full-year, `/api/pages` two windows, `/`, and
  `/invite/M42`, `/invite/M42-20260313`), checked through the real loopback
  server as well as `portal.py request`.
* Engine spot checks against the live DB: A base (J31 01:30Z, N84 13:45Z =
  09:45 EDT, Q29 15:00Z, U56 06:20Z = 08:20 CEST); B picks B-611 → Q29 16:30Z;
  C for 03-09..03-23 picks Z-213 → U56 09:15Z, D at asof 1 falls back to the
  base wall clock (U56 07:20Z = 08:20 CET).

Known leftovers, unchanged from above: `out/backup.sqlite` is the earlier
legacy-portal snapshot and deliberately does **not** carry the `line_*` tables
(a fresh one can be produced with `python3 project/backup.py out/backup.sqlite`
if a signed post-import snapshot is ever wanted); no ICS/publish this round,
since the launch order asked for registration plus query, not for a calendar
delivery.

## 第 6 轮追加

* `line.py preview REQUEST_JSON OUTPUT`：只读批量问答，1:1 回填请求键 + `local`（Europe/London，分钟精度）。
  每条请求自带的 `asof` 优先于批次默认值，所以新批复落地后旧问题仍按旧口径回答。
* 差量发布在 `release.py`：`delta START END ASOF --downstream input/vault/index.json --tag TAG`
  先读下游（归档索引或回执转储，同 UID 后者覆盖前者），再用 `feed_rows` 取当期行，只把 utc 与下游不同者
  写进包；`verify-delta` 复核字节、UID 集合、重渲染与"下游确实没有这条新口径"。
* 时间比较走 `release.same_instant`：`2026-03-16T15:00:00` 与 `...Z` 是同一瞬间，不能当成差量。

## 第 7 轮追加

* `line.py delta CHANNEL FROM TO ASOF RECEIPTS_JSON OUTPUT`（`contracts/delivery.md`）：回执按 `(turn, receipt)`
  排序后逐批应用 `rows`，得到订阅方真实持有状态；只输出新项或 utc/status 与已应用状态不同的事件。
  空包照写（合法），是否投递由人决定。时间比较用 `line.same_instant`，`…T15:00:00` 与 `…Z` 视为同一瞬间。
* 回执文件可以是单端合并数组，也可以是 `{channel: [batches]}`；后者必须指定端。
* 摘要里带 `applied`（应用了哪些批次）、`received`（已知 UID 数）、`sequence`（每条从此前到现在的变化）、
  `withdrawn`（下游有、当期无的 UID，仅报告不打包）。

## 第 8 轮追加

* `line.py delta ... --only UID[,UID]`：按 UID 收窄一个批次，用于"单项补发"与"其余差量另组批次"分开投；
  收窄只影响打包，不影响 `line_feed` 记账。
* `line.py reconcile FROM TO ASOF RECEIPTS... [--json OUT]`：只读核对，逐端 `pending / missing / extra`；
  用 `schedule()`（不写 `line_feed`），可反复跑，在投递前后都能当"到底齐没齐"的判据，退出码 0/1。
* `load_receipts_files` 接受多份回执（合并数组、`{channel: [batches]}`、`receipts-<端>-*.json` 按文件名识别端），
  同一端多份按 `(turn, receipt)` 合并。

## 第 9 轮追加

* `line.uid_day(uid)` / `line.in_window(uid, start, end)`：从稳定 UID（`前缀-原定日YYYYMMDD`）取原定日，
  判断某条是否落在本次窗口内；原定日不可解析时按“在窗口内”处理，宁可多报也不静默丢。
* `line.delta_rows` / `release.delta_rows` 的 `withdrawn` 现在只报**窗口内**的 UID：下游快照往往覆盖多期
  （如整份回执里既有三月也有秋季），算某窗口的差量时，窗口外那些已投项不是“撤回”，不该出现在报告里。
  不改变任何已发出的包（历次差量的快照本来就与窗口同期）。
* 核对某窗口时，回执要先按窗口过滤成快照（本轮 `out/receipts-autumn-window.json`）；否则 `reconcile` 会把
  窗口外的历史回执算成 `extra`。`schedule()` 仍然只读，核对不动 `line_feed`。
* 交接验证套路：签收备份 → 复制成干净实例 → `line.py import input`（应全 `duplicate`/`unchanged` 或仅本轮新单 `imported`）
  → 与备份比 asof 1..N-1 的历史答案逐字节相等 → 只在最新版本上出现预期变化。

## 第 10 轮追加

* `line.py history QUESTIONS_JSON RECEIPTS_JSON OUTPUT`（`contracts/inquiry.md`）：逐问给 `due / received / pending`。
  `due` 走 `explain()`（与 `/api/when` 同一政策口径，按问题自带的 `asof`）；`received` 只应用 `turn <= asof` 的实际回执
  （含 `input/vault` 归档），无历史给 `null`；`pending = not same_instant(due, received)`，两边都空则不算未结。
  时刻统一按线上写法 `…Z`。`received_at()` 对无法证明 turn 的批次宁可不计入。
* 只读：`history` 用 `file:…?mode=ro` 打开记录（`_open`），不走 `ensure_schema`，不写 `line_feed`，可反复跑且输出逐字节一致。
