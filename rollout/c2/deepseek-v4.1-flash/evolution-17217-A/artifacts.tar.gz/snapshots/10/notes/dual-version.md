# 双版本上线（第 3 轮，release 3，业务日 2026-03-30）

契约：`input/contracts/interfaces.md`。目标是把旧端与新端接到同一份身份登记册上，
让同一场次在两端有稳定的身份，并把 HTTP v2 与 ICS 生成器接通，同时不重写旧 UID 与报名。

## 交付

| 文件 | 内容 |
|---|---|
| `project/line.py` | `import` 现同时迁移 `identities.json` 到 `line_identity`；新增 `schedule()`（带 uid）、`v2_rows()`、`feed_rows()`、`feed()` 与 `feed` 子命令。 |
| `project/portal.py` | 新增 `GET /api/v2`（`v2_json` / `v2_by_uid`），`/invite/<新 UID>` 回退解析；坏参数返回 400；V1 全部路由不变。 |
| `project/calendar_io.py` | 新增 `encode_feed()`（UID+DTSTAMP+DTSTART+SEQUENCE+STATUS:CONFIRMED）；`encode()` 一字未改。 |
| `project/test_v2.py` | 31 例：身份迁移、稳定 UID、/api/v2 语义、400/404、真实 HTTP、旧库不受影响、邀请回退。 |
| `project/test_feed.py` | 13 例：全量 VEVENT、CONFIRMED、同 UID 更新（SEQUENCE+1）、重跑逐字节一致、CLI。 |
| `data/portal.sqlite` | 已迁移：`line_identity` 16 行；`line_series` 4、`line_order` 2、`line_feed` 视发布而定。 |
| `out/feed-{A,B,C,D}-20260302-20260629.ics` | 四频道全量订阅源，asof=3，每频道 72 场（18 个周一 × 4 系列）。 |
| `out/v2-2026-03-30.json` | 业务日 2026-03-30 四频道 `/api/v2` 只读快照。 |
| `scratch/portal.pre-v2.sqlite` | 本轮迁移前快照，用于"旧接口逐字节不变"的比对。 |

## 身份登记册

* `identities.json` 结构是 `{code: {channel: prefix}}`（也接受 `[{code,channel,prefix}]`）。
* 迁移进 `line_identity(code, channel, prefix, imported)`，`import` 每次重跑都执行：
  同值 `unchanged`，新值 `imported`，改值 `updated`；文件缺失则整段跳过（登记册可选）。
* wire 身份：`UID = 前缀-原定日YYYYMMDD`，**原定日**是移位前的周一。
  - 频道 A/D 用系列自身的旧名（`N84-20260330`），频道 B/C 用上线单的 `line-401`…；
    两端因此对同一场次各有稳定且可复算的名字，且不会与旧试点 UID 相撞。
  - 未登记的 (code, channel) 回退到 `portfolio.json` 的 `sid`，再回退到 `code`。
* 稳定性的关键：`shift_days` 只改 `day`/`utc`，UID 仍取原定日。所以"周一改周二"
  在订阅端是同一条 VEVENT 的更新，不是新增。

## HTTP v2

`GET /api/v2?channel=&from=&to=&asof=` → `[{code, day, utc, uid}]`，
按原定日排序（同日按 code），`asof` 缺省取已登记的最大 version（当前 3）。
非整数/负 `asof`、非法频道 → 400；未知路径仍 404；`asof` 越小看到的是越早的授权层，
同一 UID 的 `utc` 会变，身份不变。

请求路径只读数据库：身份表已迁移，`/api/v2` 与 `/invite/` 都不碰 `input/`
（`test_service_does_not_read_input` 把 `input/` 下的 `open()` 全部拦死仍然通过）。

`/invite/<uid>`：旧 UID 走原来的 `resolve_occurrence()`；若旧路径查不到而 UID 属于新线，
用 `v2_by_uid()` 按原定日回查四频道并渲染同一 HTML 形状。旧 UID 的结果逐字节不变。

## ICS 生成器

`python3 project/line.py feed CHANNEL FROM TO ASOF OUTPUT`

* 全量 VEVENT，`STATUS:CONFIRMED`，一条 UID 一条 VEVENT；窗口按原定日含端点。
* `SEQUENCE` 记在 `line_feed(uid, channel, starts, sequence, stamp)`：
  首见 0；`DTSTART` 未变则原样（重跑逐字节一致）；`DTSTART` 变了则 +1 并换 `DTSTAMP`。
  同一 UID 因此只更新不增生（实测：改钟点后 12 场仍是 12 场，目标行 SEQUENCE 0→1）。
* `DTSTAMP` 取当前业务日（`input/clock.txt` 的日期）零点 UTC，保证同轮可复跑；
  也可用 `feed(..., stamp=...)` 显式指定。
* 同一份 feed 内 UID 重复直接报错（例如两系列共用前缀）。

## 验证

* 测试 **147 例全绿**：portal 11、migrate 14、prepare 8、adjust 15、ch64 10、recover 16、
  backup 10、q2 10、pages 12、line 20、v2 31、feed 13。
* 旧端零回归：10 条旧 URL（`/api/events` 三窗口、`/api/pages` 两窗口、`/`、
  `/invite/M42`、`/invite/M42-20260313`、`/invite/K17-20260306`、`/api/events?channel=D`）
  与迁移前快照逐字节相同；`events/bookings/series/adjustment` 四张表逐行相同，
  旧 UID 与报名摘要 `d84b0b7238ac7418` 前后一致。
* 真实 HTTP：`/api/v2` 200、坏 `asof` 400、未知路径 404、`/api/events`、`/api/pages`、
  `/invite/<新 UID>?tz=` 均正常。
* 订阅源可复跑：四份 feed 重新生成后 sha256 完全一致
  （A `2500c241…`、B `a81f8a7f…`、C `85a159bb…`、D `4f063a4b…`）。
* `data/portal.sqlite` 迁移后：`line_identity` 16、`line_series` 4、`line_order` 2，旧表未动。

## 遗留

* **未发布**：四份 feed 只落在 `out/`，没有调用 `publish()`。接口契约要求"接通"生成器，
  而每个新 key 都会通知客户，所以留待明确的投递指令；要发时按频道给 key 即可
  （例如 `feed-A-20260302-20260629`），同键同语义重试安全。
* `line_feed` 只记录已发出的场次，不处理"某场从窗口里消失"（如需撤场应另发
  `STATUS:CANCELLED` 的同 UID 事件，契约未要求，本轮未做）。
* `out/backup.sqlite` 仍是更早的旧门户签收快照，不含 `line_*` 表；需要新快照可
  `python3 project/backup.py out/backup.sqlite`（属新交付，需你确认）。
* 变更前缀会把该 (code, channel) 之后的 wire UID 整体换名（登记册即权威）；
  若已发过订阅，改前缀等于换身份，投递前请确认。
