"""New product line schedule core (independent of the pilot portal).

    python3 project/line.py import INPUT_DIR
    python3 project/line.py query CHANNEL FROM TO ASOF

`import` incrementally registers the series catalogue (INPUT_DIR/portfolio.json)
and every authorisation batch under INPUT_DIR/orders/*.json ({version, rows})
into PORTAL_DB.  Batches may arrive out of order or be re-sent; an order `id`
is immutable and registered exactly once.

The same `import` also migrates the identity registry (INPUT_DIR/identities.json:
code -> channel -> wire prefix), which is what gives one session the same stable
identity on the old and the new side:  UID = prefix-原定日YYYYMMDD, i.e. built
from the *original* Monday, so a shift_days move keeps the UID and updates the
entry instead of adding one.

`query` prints a JSON array of {code, day, utc} for one channel over the
original Monday service days FROM..TO (endpoints included), using only
authorisations whose version <= ASOF:

* a normal approval matches by code/channel/original-day and the highest
  (rank, version, id) wins;
* a revocation removes its `target` approval for a channel and original day,
  and the next remaining valid layer applies (base if nothing remains);
* without an approval the base weekly schedule is used, starting 2026-03-02.

`feed CHANNEL FROM TO ASOF OUTPUT` writes the full VEVENT set (STATUS:CONFIRMED)
for that window, one VEVENT per UID.  A UID that already went out is updated in
place -- same UID, bumped SEQUENCE -- never duplicated, and an unchanged feed is
byte-identical when re-run.

Everything that serves requests reads the database only: the identity registry
is migrated into `line_identity`, so nothing at serve time touches input/.

The old portal's tables and routes are untouched: this module only owns the
`line_*` tables in the same PORTAL_DB, and no migration rewrites an old UID
(`M42-20260327`) or an existing booking.
"""
import argparse
import glob
import json
import os
import sqlite3
import sys
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import calendar_io

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLOCK = os.path.join(ROOT, "input", "clock.txt")
VERSION = os.path.join(ROOT, "input", "version.txt")

BASE_START = date(2026, 3, 2)          # first Monday of the base weekly schedule
KIND_APPROVAL = "approval"
KIND_REVOKE = "revoke"
BASES = {"utc", "wall"}
REVOKE_WORDS = {"revoke", "revocation", "cancel", "cancelled", "撤回", "撤销"}

SERIES_COLUMNS = ("code", "sid", "zone", "clock", "basis", "weekday")
ORDER_COLUMNS = ("id", "version", "kind", "code", "channels", "start_day", "end_day",
                 "rank", "clock", "basis", "shift_days", "target")
IDENTITY_COLUMNS = ("code", "channel", "prefix")
FEED_COLUMNS = ("uid", "channel", "starts", "sequence", "stamp")
STATUS_CONFIRMED = "CONFIRMED"
FALLBACK_STAMP = "19700101T000000Z"    # only when no business day is on file
CHANNEL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


# --------------------------------------------------------------------------- #
# storage
# --------------------------------------------------------------------------- #
def ensure_schema(db):
    """Create the new line tables; never touches the portal's own tables."""
    db.execute("""create table if not exists line_series(
        code text primary key, sid text, zone text not null, clock text not null,
        basis text not null, weekday integer not null, imported text)""")
    db.execute("""create table if not exists line_order(
        id text primary key, version integer not null, kind text not null,
        code text, channels text, start_day text, end_day text,
        rank integer not null default 0, clock text, basis text,
        shift_days integer not null default 0, target text, imported text)""")
    db.execute("""create table if not exists line_identity(
        code text not null, channel text not null, prefix text not null,
        imported text, primary key(code, channel))""")
    db.execute("""create table if not exists line_feed(
        uid text not null, channel text not null, starts text not null,
        sequence integer not null default 0, stamp text not null,
        primary key(uid, channel))""")
    return db


def business_day():
    try:
        with open(CLOCK, encoding="utf-8") as handle:
            return handle.read().strip()
    except OSError:
        return ""


def release_version():
    """The deployed release number (input/version.txt), for reporting only."""
    try:
        with open(VERSION, encoding="utf-8") as handle:
            return int(handle.read().strip())
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------------- #
# parsing helpers
# --------------------------------------------------------------------------- #
def as_day(value):
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value).strip())
    except ValueError:
        raise ValueError(f"not a service day: {value!r}")


def parse_clock(value):
    if value is None:
        raise ValueError("missing clock")
    text = str(value).strip()
    for pattern in ("%H:%M:%S", "%H:%M"):
        try:
            return datetime.strptime(text, pattern).time()
        except ValueError:
            continue
    raise ValueError(f"not a clock time: {value!r}")


def channel_set(value):
    """`CD` / `C,D` / ['C','D'] -> {'C','D'}; None/empty -> None (all channels)."""
    if value is None or value == "":
        return None
    if isinstance(value, (list, tuple, set)):
        text = "".join(str(item) for item in value)
    else:
        text = str(value)
    letters = {char for char in text.upper() if char in CHANNEL_ALPHABET}
    return letters or None


def channel_in(channels, channel):
    if not channels:                        # authorisation covers every channel
        return True
    text = channels if isinstance(channels, str) else "".join(channels)
    return str(channel).upper() in text.upper()


def normalise_series(entry):
    code = str(entry.get("code", "")).strip()
    if not code:
        raise ValueError(f"portfolio entry without code: {entry!r}")
    zone = str(entry.get("zone", "")).strip()
    try:
        ZoneInfo(zone)                                # unknown zone fails loudly
    except (ZoneInfoNotFoundError, ValueError) as problem:
        raise ValueError(f"{code}: unknown zone {entry.get('zone')!r}") from problem
    basis = str(entry.get("basis", "wall")).strip().lower()
    if basis not in BASES:
        raise ValueError(f"{code}: unknown basis {entry.get('basis')!r}")
    clock = str(entry.get("clock", "")).strip()
    parse_clock(clock)
    weekday = int(entry.get("weekday", 0))
    if not 0 <= weekday <= 6:
        raise ValueError(f"{code}: weekday out of range: {weekday}")
    return dict(code=code, sid=entry.get("sid"), zone=zone, clock=clock,
                basis=basis, weekday=weekday)


def _window(row):
    """Original-service-day window from start/end, a single day, or nothing."""
    single = row.get("day", row.get("original_day", row.get("date")))
    start = row.get("start", row.get("from", single))
    end = row.get("end", row.get("to", single))
    return as_day(start), as_day(end)


def normalise_order(row, version):
    oid = str(row.get("id", "")).strip()
    if not oid:
        raise ValueError(f"order row without an immutable id: {row!r}")
    target = row.get("target")
    target = str(target).strip() if target not in (None, "") else None
    word = str(row.get("kind", "")).strip().lower()
    kind = KIND_REVOKE if (target or word in REVOKE_WORDS) else KIND_APPROVAL
    if kind == KIND_REVOKE and not target:
        raise ValueError(f"{oid}: a revocation must name a target")
    code = row.get("code")
    code = str(code).strip() if code not in (None, "") else None
    if kind == KIND_APPROVAL and not code:
        raise ValueError(f"{oid}: an approval must name a code")
    start_day, end_day = _window(row)
    clock = row.get("clock")
    if clock not in (None, ""):
        parse_clock(clock)
        clock = str(clock).strip()
    else:
        clock = None
    basis = row.get("basis")
    if basis not in (None, ""):
        basis = str(basis).strip().lower()
        if basis not in BASES:
            raise ValueError(f"{oid}: unknown basis {row.get('basis')!r}")
    else:
        basis = None
    scoped = channel_set(row.get("channels"))
    channels = "".join(sorted(scoped)) if scoped else None
    return dict(id=oid, version=int(version), kind=kind, code=code,
                channels=channels,
                start_day=start_day.isoformat() if start_day else None,
                end_day=end_day.isoformat() if end_day else None,
                rank=int(row.get("rank") or 0), clock=clock, basis=basis,
                shift_days=int(row.get("shift_days") or 0), target=target)


# --------------------------------------------------------------------------- #
# identity registry
# --------------------------------------------------------------------------- #
def _identities_path(input_dir):
    for candidate in (os.path.join(input_dir, "identities.json"),
                      os.path.join(os.path.dirname(os.path.abspath(input_dir)), "identities.json")):
        if os.path.exists(candidate):
            return candidate
    return None


def normalise_identity(code, channel, prefix):
    code = str(code).strip()
    channel = str(channel).strip().upper()
    prefix = str(prefix).strip()
    if not code or not channel or not prefix:
        raise ValueError(f"identity needs code, channel and prefix: {code!r}/{channel!r}/{prefix!r}")
    if len(channel) != 1 or channel not in CHANNEL_ALPHABET:
        raise ValueError(f"{code}: not a channel: {channel!r}")
    return dict(code=code, channel=channel, prefix=prefix)


def import_identities(db, input_dir, stamp=None):
    """Register the code/channel -> wire prefix table; -> list of per-entry actions."""
    path = _identities_path(input_dir)
    if path is None:
        return []                                  # registry is optional for an import
    stamp = stamp if stamp is not None else business_day()
    with open(path, encoding="utf-8") as handle:
        registry = json.load(handle)
    if isinstance(registry, dict) and isinstance(registry.get("rows"), list):
        registry = registry["rows"]
    entries = []
    if isinstance(registry, list):                 # [{code, channel, prefix}, ...]
        entries = [(row.get("code"), row.get("channel"), row.get("prefix")) for row in registry]
    elif isinstance(registry, dict):               # {code: {channel: prefix}}
        for code in sorted(registry):
            channels = registry[code]
            if not isinstance(channels, dict):
                raise ValueError(f"{code}: identity entry must map channel -> prefix")
            entries.extend((code, channel, channels[channel]) for channel in sorted(channels))
    else:
        raise ValueError("identities.json must be {code: {channel: prefix}} or a list of rows")

    actions = []
    for code, channel, prefix in entries:
        wanted = normalise_identity(code, channel, prefix)
        current = db.execute("select prefix from line_identity where code=? and channel=?",
                             (wanted["code"], wanted["channel"])).fetchone()
        if current is None:
            db.execute("insert into line_identity(code,channel,prefix,imported) values(?,?,?,?)",
                       (wanted["code"], wanted["channel"], wanted["prefix"], stamp))
            action = "imported"
        elif current[0] == wanted["prefix"]:
            action = "unchanged"
        else:
            db.execute("update line_identity set prefix=? where code=? and channel=?",
                       (wanted["prefix"], wanted["code"], wanted["channel"]))
            action = "updated"
        actions.append(dict(code=wanted["code"], channel=wanted["channel"],
                            prefix=wanted["prefix"], action=action))
    return actions


def prefix_for(db, code, channel):
    """Wire prefix for code/channel; falls back to the series id, then the code."""
    try:
        row = db.execute("select prefix from line_identity where code=? and channel=?",
                         (code, str(channel).strip().upper())).fetchone()
    except sqlite3.OperationalError:               # never imported
        row = None
    if row and row[0]:
        return row[0]
    try:
        row = db.execute("select sid from line_series where code=?", (code,)).fetchone()
    except sqlite3.OperationalError:
        row = None
    return (row[0] if row and row[0] else code)


def uid_for(prefix, original_day):
    """UID = prefix-YYYYMMDD, built from the *original* service day (never the shift)."""
    if isinstance(original_day, str):
        original_day = date.fromisoformat(original_day)
    return f"{prefix}-{original_day.strftime('%Y%m%d')}"


# --------------------------------------------------------------------------- #
# import
# --------------------------------------------------------------------------- #
def _portfolio_path(input_dir):
    for candidate in (os.path.join(input_dir, "portfolio.json"),
                      os.path.join(os.path.dirname(os.path.abspath(input_dir)), "portfolio.json")):
        if os.path.exists(candidate):
            return candidate
    raise ValueError(f"no portfolio.json in {input_dir}")


def _order_files(input_dir):
    orders_dir = os.path.join(input_dir, "orders")
    if os.path.isdir(orders_dir):
        files = glob.glob(os.path.join(orders_dir, "*.json")) + glob.glob(os.path.join(orders_dir, "*.JSON"))
        return sorted(files), orders_dir
    # a bare orders directory was handed over instead of its parent
    if os.path.isdir(input_dir):
        return sorted(path for path in glob.glob(os.path.join(input_dir, "*.json"))
                      if os.path.basename(path) != "portfolio.json"), input_dir
    return [], orders_dir


def _same(current, wanted, columns):
    return all(current[column] == wanted[column] for column in columns)


def import_dir(db, input_dir, stamp=None):
    """Incrementally register portfolio + order batches; -> report dict."""
    ensure_schema(db)
    stamp = stamp if stamp is not None else business_day()
    report = {"portfolio": [], "identities": [], "orders": []}
    try:
        with open(_portfolio_path(input_dir), encoding="utf-8") as handle:
            entries = json.load(handle)
        if isinstance(entries, dict) and isinstance(entries.get("rows"), list):
            entries = entries["rows"]
        if not isinstance(entries, list):
            raise ValueError("portfolio.json must be a JSON list (or {rows: [...]})")
        for entry in entries:
            wanted = normalise_series(entry)
            current = db.execute("select " + ",".join(SERIES_COLUMNS)
                                 + " from line_series where code=?", (wanted["code"],)).fetchone()
            if current is None:
                db.execute("insert into line_series(" + ",".join(SERIES_COLUMNS) + ",imported) values("
                           + ",".join("?" * (len(SERIES_COLUMNS) + 1)) + ")",
                           tuple(wanted[column] for column in SERIES_COLUMNS) + (stamp,))
                action = "imported"
            elif _same(dict(zip(SERIES_COLUMNS, current)), wanted, SERIES_COLUMNS):
                action = "unchanged"
            else:
                db.execute("update line_series set sid=?,zone=?,clock=?,basis=?,weekday=? where code=?",
                           (wanted["sid"], wanted["zone"], wanted["clock"],
                            wanted["basis"], wanted["weekday"], wanted["code"]))
                action = "updated"
            report["portfolio"].append(dict(code=wanted["code"], action=action))

        report["identities"] = import_identities(db, input_dir, stamp)

        files, _ = _order_files(input_dir)
        seen_here = set()
        for path in files:
            with open(path, encoding="utf-8") as handle:
                batch = json.load(handle)
            if not isinstance(batch, dict) or "version" not in batch or "rows" not in batch:
                raise ValueError(f"{path}: an order file needs version and rows")
            version = int(batch["version"])
            if not isinstance(batch["rows"], list):
                raise ValueError(f"{path}: rows must be a list")
            for row in batch["rows"]:
                row_version = int(row.get("version", version))
                wanted = normalise_order(row, row_version)
                current = db.execute("select " + ",".join(ORDER_COLUMNS)
                                     + " from line_order where id=?", (wanted["id"],)).fetchone()
                if current is not None:
                    if not _same(dict(zip(ORDER_COLUMNS, current)), wanted, ORDER_COLUMNS):
                        raise ValueError(f'{wanted["id"]}: immutable id re-sent with different content')
                    action = "duplicate"
                elif wanted["id"] in seen_here:
                    action = "duplicate"
                else:
                    db.execute("insert into line_order(" + ",".join(ORDER_COLUMNS) + ",imported) values("
                               + ",".join("?" * (len(ORDER_COLUMNS) + 1)) + ")",
                               tuple(wanted[column] for column in ORDER_COLUMNS) + (stamp,))
                    action = "imported"
                seen_here.add(wanted["id"])
                report["orders"].append(dict(id=wanted["id"], version=wanted["version"],
                                             code=wanted["code"], kind=wanted["kind"],
                                             action=action))
        db.commit()
    except Exception:
        db.rollback()
        raise
    return report


# --------------------------------------------------------------------------- #
# query
# --------------------------------------------------------------------------- #
def _series(db):
    return [dict(zip(SERIES_COLUMNS, row)) for row in
            db.execute("select " + ",".join(SERIES_COLUMNS) + " from line_series order by code")]


def _orders(db):
    return [dict(zip(ORDER_COLUMNS, row)) for row in
            db.execute("select " + ",".join(ORDER_COLUMNS) + " from line_order order by id")]


def _approved(order, day):
    if order["start_day"] and day < date.fromisoformat(order["start_day"]):
        return False
    if order["end_day"] and day > date.fromisoformat(order["end_day"]):
        return False
    return True


def _revoked(approval, day, channel, revokes):
    for revoke in revokes:
        if revoke["target"] != approval["id"]:
            continue
        if not channel_in(revoke["channels"], channel):
            continue
        if revoke["start_day"] and day < date.fromisoformat(revoke["start_day"]):
            continue
        if revoke["end_day"] and day > date.fromisoformat(revoke["end_day"]):
            continue
        return True
    return False


def to_utc(day, clock, basis, zone):
    """A service day plus a clock -> an aware UTC instant."""
    moment = parse_clock(clock)
    if basis == "utc":
        return datetime.combine(day, moment, tzinfo=timezone.utc)
    if basis == "wall":
        return datetime.combine(day, moment, tzinfo=ZoneInfo(zone)).astimezone(timezone.utc)
    raise ValueError(f"unknown basis {basis!r}")


def _first_day(start, weekday):
    """First `weekday` on or after max(start, BASE_START)."""
    floor = start if start > BASE_START else BASE_START
    return floor + timedelta(days=(weekday - floor.weekday()) % 7)


def schedule(db, channel, start, end, asof):
    """-> [{code, day, utc, uid}] for a channel over original Monday service days.

    `day` is the service day after any shift_days move; the UID is built from the
    original Monday, so moving a session keeps its identity.
    """
    channel = str(channel).strip().upper()
    if len(channel) != 1 or channel not in CHANNEL_ALPHABET:
        raise ValueError(f"not a channel: {channel!r}")
    start, end, asof = as_day(start), as_day(end), int(asof)
    if start is None or end is None or start > end:
        return []
    try:
        series = _series(db)
        registered = _orders(db)
    except sqlite3.OperationalError:          # database never imported
        return []
    prefixes = {item["code"]: prefix_for(db, item["code"], channel) for item in series}
    approvals = [order for order in registered
                 if order["kind"] == KIND_APPROVAL and order["version"] <= asof]
    revokes = [order for order in registered
               if order["kind"] == KIND_REVOKE and order["version"] <= asof]

    rows = []
    for item in series:
        day = _first_day(start, item["weekday"])
        while day <= end:
            candidates = [order for order in approvals
                          if order["code"] == item["code"]
                          and channel_in(order["channels"], channel)
                          and _approved(order, day)]
            candidates.sort(key=lambda order: (order["rank"], order["version"], order["id"]),
                            reverse=True)
            chosen = next((order for order in candidates
                           if not _revoked(order, day, channel, revokes)), None)
            if chosen is not None:
                service_day = day + timedelta(days=chosen["shift_days"])
                clock = chosen["clock"] or item["clock"]
                basis = chosen["basis"] or item["basis"]
            else:
                service_day = day
                clock, basis = item["clock"], item["basis"]
            moment = to_utc(service_day, clock, basis, item["zone"])
            rows.append((day, item["code"],
                         dict(code=item["code"], day=service_day.isoformat(),
                              utc=moment.astimezone(timezone.utc).isoformat(),
                              uid=uid_for(prefixes[item["code"]], day))))
            day += timedelta(days=7)
    rows.sort(key=lambda entry: (entry[0], entry[1]))   # business day, then code
    return [row for _, _, row in rows]


def query(db, channel, start, end, asof):
    """-> [{code, day, utc}] the engine contract's shape (no wire identity)."""
    return [dict(code=row["code"], day=row["day"], utc=row["utc"])
            for row in schedule(db, channel, start, end, asof)]


def latest_version(db):
    """Highest registered authorisation version, i.e. "everything known now"."""
    try:
        row = db.execute("select max(version) from line_order").fetchone()
    except sqlite3.OperationalError:
        return 0
    return int(row[0]) if row and row[0] is not None else 0


def v2_rows(db, channel, start, end, asof=None):
    """Rows for GET /api/v2: [{code, day, utc, uid}]; asof defaults to latest."""
    if asof is None or str(asof).strip() == "":
        asof = latest_version(db)
    try:
        resolved = int(str(asof).strip())
    except (TypeError, ValueError):
        raise ValueError(f"asof must be an integer version, got {asof!r}")
    if resolved < 0:
        raise ValueError(f"asof must not be negative, got {resolved}")
    return schedule(db, channel, start, end, resolved)


# --------------------------------------------------------------------------- #
# ICS feed
# --------------------------------------------------------------------------- #
def feed_stamp():
    """Deterministic DTSTAMP for a round: the business day from input/clock.txt."""
    day = as_day(business_day())
    return day.strftime("%Y%m%dT000000Z") if day else FALLBACK_STAMP


def feed_rows(db, channel, start, end, asof, stamp=None):
    """Rows plus the SEQUENCE/DTSTAMP each UID is published with.

    A UID already on the wire keeps its sequence while its DTSTART is unchanged
    (so a re-run is byte-identical); a changed DTSTART bumps SEQUENCE, so the
    subscriber updates the existing entry instead of gaining a second one.
    """
    ensure_schema(db)
    channel = str(channel).strip().upper()
    stamp = stamp or feed_stamp()
    known = {}
    for uid, starts, sequence, previous in db.execute(
            "select uid,starts,sequence,stamp from line_feed where channel=?", (channel,)):
        known[uid] = (starts, sequence, previous)
    out, seen = [], set()
    for row in schedule(db, channel, start, end, asof):
        uid = row["uid"]
        if uid in seen:
            raise ValueError(f"{uid}: two sessions share one UID in this feed")
        seen.add(uid)
        if uid not in known:
            sequence, entry_stamp = 0, stamp
            db.execute("insert into line_feed(uid,channel,starts,sequence,stamp) values(?,?,?,?,?)",
                       (uid, channel, row["utc"], sequence, entry_stamp))
        else:
            starts, sequence, previous = known[uid]
            if starts == row["utc"]:
                entry_stamp = previous                 # unchanged: keep the file stable
            else:
                sequence, entry_stamp = sequence + 1, stamp
                db.execute("update line_feed set starts=?,sequence=?,stamp=? where uid=? and channel=?",
                           (row["utc"], sequence, entry_stamp, uid, channel))
        out.append(dict(uid=uid, utc=row["utc"], code=row["code"], day=row["day"],
                        status=STATUS_CONFIRMED, sequence=sequence, stamp=entry_stamp))
    return out


def feed(db, channel, start, end, asof, output, stamp=None):
    """Write the full VEVENT set for a channel to OUTPUT; -> summary dict."""
    rows = feed_rows(db, channel, start, end, asof, stamp=stamp)
    text = calendar_io.encode_feed(rows)
    folder = os.path.dirname(os.path.abspath(output))
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(output, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)
    db.commit()
    return dict(channel=str(channel).strip().upper(), events=len(rows),
                output=output, asof=int(asof),
                updated=sum(1 for row in rows if row["sequence"]),
                first_uid=rows[0]["uid"] if rows else None)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main(argv=None):
    parser = argparse.ArgumentParser(prog="line.py")
    sub = parser.add_subparsers(dest="action", required=True)
    importer = sub.add_parser("import")
    importer.add_argument("input_dir")
    asker = sub.add_parser("query")
    asker.add_argument("channel")
    asker.add_argument("start")
    asker.add_argument("end")
    asker.add_argument("asof", type=int)
    feeder = sub.add_parser("feed")
    feeder.add_argument("channel")
    feeder.add_argument("start")
    feeder.add_argument("end")
    feeder.add_argument("asof", type=int)
    feeder.add_argument("output")
    args = parser.parse_args(argv)

    db = ensure_schema(sqlite3.connect(os.getenv("PORTAL_DB", "data/portal.sqlite")))
    try:
        if args.action == "import":
            report = import_dir(db, args.input_dir)
            report["release_version"] = release_version()
            print(json.dumps(report, ensure_ascii=False))
            return 0
        if args.action == "feed":
            summary = feed(db, args.channel, args.start, args.end, args.asof, args.output)
            print(json.dumps(summary, ensure_ascii=False))
            return 0
        rows = query(db, args.channel, args.start, args.end, args.asof)
        print(json.dumps(rows, ensure_ascii=False))
        return 0
    except (ValueError, OSError, json.JSONDecodeError, sqlite3.Error) as problem:
        print(f"line.py {args.action} failed: {problem}", file=sys.stderr)
        return 2
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
