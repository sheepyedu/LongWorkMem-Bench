"""Deployed v1 application. Run python3 project/portal.py serve [port].

Local-date fix (Tokyo overnight reports):
labels take date *and* time from one instant converted into the requested zone
(the HTML used to glue the UTC date onto the local time, so occurrences whose
local wall clock falls on the previous UTC day showed one day early).

Pilot intake (migrate):
`python3 project/portal.py migrate [INTAKE] [RECORDS]` imports the series listed
in intake.json, resolving each entry's approval ticket from the records library
and repeating it weekly with no end date.  Occurrences are expanded per
requested range, not materialised, and are keyed by the stable VEVENT UID
`CODE-原定日`, so invite links and bookings survive.  Re-running is a no-op; a
later intake with new ticket numbers is imported incrementally and earlier
series are kept.

Dual-version launch (V2):
`GET /api/v2?channel=&from=&to=&asof=` serves the new product line next to the
pilot API: `[{code, day, utc, uid}]` for the original Monday service days in the
range, using only authorisations with version <= asof (default: the latest
registered).  The UID comes from the migrated identity registry
(`prefix-原定日`) and is stable across reschedules, so the old and the new side
name one session the same way, and a feed update lands on the existing entry.
/api/v2 reads the database only -- nothing in the request path touches input/
-- and every V1 route below keeps its shape.

Long ranges and paging (V1 compatibility):
occurrence expansion has no silent per-series cap -- a long range yields every
occurrence.  `GET /api/pages?channel=&from=&to=&offset=&limit=` pages the same
UID-sorted rows as `/api/events` (legacy items included) and answers
`{items:[...], next: offset|null}`, so a caller can walk a range larger than a
single response without losing or duplicating a UID.  `/api/events` and
`/invite/...` keep their existing shapes.
"""
import argparse
from datetime import date, datetime, timedelta, timezone
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import re
import sqlite3
import sys
from urllib.parse import parse_qs, urlsplit
from zoneinfo import ZoneInfo

INTAKE = "input/intake.json"
RECORDS = "input/records"
CLOCK = "input/clock.txt"
INCIDENT = "input/incident.json"   # urgent corrections the duty desk recorded

RULE_LOCAL = "venue_local_clock"   # keep the first occurrence's venue local clock
RULE_UTC = "utc_clock"            # keep the first occurrence's UTC clock
# Historical per-series cap.  Expansion is now unbounded inside the requested
# range (see occurrences()); responses that must stay small page via /api/pages.
MAX_OCCURRENCES = 1000
TICKET = re.compile(r"\b[A-Z]{2,}-\d{2,}\b")          # a reference inside ticket text, e.g. CH-53
TICKET_NAME = re.compile(r"[A-Z]{2,}-\d{2,}")           # a ticket file name, e.g. CH-51.txt

SERIES_COLUMNS = ("code", "ord", "anchor", "zone", "rule", "weekday", "clock", "channel")
ADJUSTMENT_COLUMNS = ("id", "ticket", "code", "kind", "from_day", "to_day", "days", "minutes", "basis",
                      "channel", "target")
KIND_MOVE = "move"          # 单场改期: one occurrence changes day
KIND_SHIFT = "shift"        # 临时窗口: occurrences inside a window shift, 到期恢复
KIND_REVOKE = "revoke"      # 撤销: one ticket stops applying, on one channel / day
RULE_ORIGINAL = "original_contract"   # 恢复原合同时间
REVOKE_WORD = re.compile(r"(撤销|撤回)")
NUMERALS = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
MOVE_WORD = re.compile(r"(提前|推迟|延后)([0-9一二三四五六七八九十两]+)(日|天|小时)")
DAY_WORD = re.compile(r"(?:(\d{1,2})月)?\s*(\d{1,2})日")     # "3月13日、20日" shares one month


# --------------------------------------------------------------------------- #
# storage
# --------------------------------------------------------------------------- #
def ensure_schema(db):
    db.execute("create table if not exists events(uid text primary key, starts text not null)")
    db.execute("create table if not exists bookings(id text primary key, uid text not null)")
    db.execute("""create table if not exists series(
        code text primary key, ord text not null, anchor text not null,
        zone text not null, rule text not null, weekday integer not null,
        clock text not null, channel text, imported text)""")
    db.execute("""create table if not exists adjustment(
        id text primary key, ticket text not null, code text not null, kind text not null,
        from_day text not null, to_day text not null, days integer not null default 0,
        minutes integer not null default 0, basis text not null, channel text, target text,
        imported text)""")
    present = {row[1] for row in db.execute("pragma table_info(adjustment)")}
    for column in ("channel", "target"):        # databases created before CH-64
        if column not in present:
            db.execute(f"alter table adjustment add column {column} text")
    return db


def as_utc(stamp):
    """Stored timestamps are UTC; tolerate a naive value by reading it as UTC."""
    moment = datetime.fromisoformat(stamp)
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone(timezone.utc)


def as_date(value):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def stamp(moment):
    return moment.strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------- #
# schedules
# --------------------------------------------------------------------------- #
def revoked(rule, day, revokes):
    """True when a later ticket withdrew this rule for that day (CH-64)."""
    return any(revoke["target"] == rule["ticket"]
               and as_date(revoke["from_day"]) <= day <= as_date(revoke["to_day"])
               for revoke in revokes)


def apply_adjustments(moment, day, zone, rules, revokes=()):
    """Shift/reschedule one occurrence; the UID keeps its 原定日 either way."""
    for rule in rules:
        if not (as_date(rule["from_day"]) <= day <= as_date(rule["to_day"])):
            continue
        if revoked(rule, day, revokes):
            continue
        if rule["basis"] == RULE_UTC:                    # 按通常 UTC 时刻
            delta = timedelta(days=rule["days"]) if rule["kind"] == KIND_MOVE else timedelta(minutes=rule["minutes"])
            moment = moment + delta
        else:                                            # 仍用场馆惯用钟点: keep the wall clock
            local = moment.astimezone(zone)
            if rule["kind"] == KIND_MOVE:
                new_day = local.date() + timedelta(days=rule["days"])
                moment = datetime.combine(new_day, local.time().replace(tzinfo=None), tzinfo=zone).astimezone(timezone.utc)
            else:
                shifted = datetime.combine(local.date(), local.time().replace(tzinfo=None)) + timedelta(minutes=rule["minutes"])
                moment = shifted.replace(tzinfo=zone).astimezone(timezone.utc)
    return moment


def occurrences(series, start=None, end=None, limit=None, rules=(), revokes=()):
    """Weekly occurrences of one series inside [start, end] on its UID day.

    `limit=None` (the default) expands the *whole* requested range: there is no
    silent per-series cap, so a long range yields every occurrence instead of
    being truncated at MAX_OCCURRENCES.  Responses that must stay bounded go
    through /api/pages; pass an explicit `limit` only for a single-row probe
    (as the migration does with limit=1).
    """
    if limit is None and end is None:
        raise ValueError("occurrence expansion needs an end date or an explicit limit")
    zone = ZoneInfo(series["zone"])
    anchor = as_utc(series["anchor"])
    if series["rule"] == RULE_UTC:
        clock = anchor.time().replace(tzinfo=None)
        first = anchor
    else:                                   # venue local clock: UTC drifts with DST
        local = anchor.astimezone(zone)
        clock = local.time().replace(tzinfo=None)
        first = datetime.combine(local.date(), clock, tzinfo=zone)
    base_day = first.date() if series["rule"] == RULE_UTC else first.astimezone(zone).date()
    step = timedelta(days=7)
    k = 0
    if start and start > base_day:
        k = max(0, -(-(start - base_day).days // 7))
    out = []
    while limit is None or len(out) < limit:
        try:
            if series["rule"] == RULE_UTC:
                moment, day = first + step * k, base_day + step * k
            else:
                day = base_day + step * k
                moment = datetime.combine(day, clock, tzinfo=zone).astimezone(timezone.utc)
        except (OverflowError, ValueError):     # UID/range outside the calendar
            break
        if end and day > end:
            break
        out.append(dict(uid=f'{series["code"]}-{day:%Y%m%d}',
                        utc=stamp(apply_adjustments(moment, day, zone, rules, revokes)), status="CONFIRMED"))
        k += 1
    return out


def adjustments(db, code=None, channel=None):
    """Adjustments in force for a channel; a row without a channel hits both."""
    sql = "select " + ",".join(ADJUSTMENT_COLUMNS) + " from adjustment where 1=1"
    args = []
    if code is not None:
        sql += " and code=?"
        args.append(code)
    if channel is not None:
        sql += " and (channel is null or channel=?)"
        args.append(channel)
    try:
        rows = db.execute(sql + " order by id", args).fetchall()
    except sqlite3.OperationalError:        # database never migrated
        return []
    return [dict(zip(ADJUSTMENT_COLUMNS, row)) for row in rows]


def rules_by_code(db, channel=None):
    """-> ({code: [move/shift rules]}, {code: [revocations]}) for one channel."""
    active, revokes = {}, {}
    for row in adjustments(db, channel=channel):
        bucket = revokes if row["kind"] == KIND_REVOKE else active
        bucket.setdefault(row["code"], []).append(row)
    return active, revokes


def series_rows(db, start=None, end=None, channel=None):
    """Pilot occurrences in range; a series without a channel belongs to both."""
    sql = "select " + ",".join(SERIES_COLUMNS) + " from series"
    args = ()
    if channel is not None:
        sql += " where channel is null or channel=?"
        args = (channel,)
    try:
        rows = db.execute(sql + " order by code", args).fetchall()
    except sqlite3.OperationalError:        # database never migrated
        return []
    active, revokes = rules_by_code(db, channel)
    found = []
    for row in rows:
        series = dict(zip(SERIES_COLUMNS, row))
        code = series["code"]
        found.extend(occurrences(series, start, end,
                                 rules=active.get(code, ()), revokes=revokes.get(code, ())))
    return found


def uid_day(uid):
    """The 原定日 encoded in a UID such as K17-20260306."""
    _, _, tail = uid.rpartition("-")
    if len(tail) != 8 or not tail.isdigit():
        return None
    return as_date(f"{tail[:4]}-{tail[4:6]}-{tail[6:]}")


def resolve_occurrence(db, uid, channel=None):
    """Single pilot occurrence addressed by its UID, if that UID is real."""
    code, day = uid.rpartition("-")[0], uid_day(uid)
    if not code or day is None:
        return None
    for row in occurrences_around(db, code, day, channel):
        if row["uid"] == uid:
            return row
    return None


def occurrences_around(db, code, day, channel=None):
    try:
        row = db.execute("select " + ",".join(SERIES_COLUMNS) + " from series where code=?", (code,)).fetchone()
    except sqlite3.OperationalError:
        return []
    if not row:
        return []
    series = dict(zip(SERIES_COLUMNS, row))
    active, revokes = rules_by_code(db, channel)
    name = series["code"]
    return occurrences(series, day, day, rules=active.get(name, ()), revokes=revokes.get(name, ()))


# --------------------------------------------------------------------------- #
# approvals
# --------------------------------------------------------------------------- #
def rule_from_text(text):
    if "UTC" in text.upper():
        return RULE_UTC
    if "当地" in text or "本地" in text:
        return RULE_LOCAL
    return None


def approval_rule(records, order, seen=()):
    """Scheduling rule of an approval ticket; a ticket may point at another one."""
    path = os.path.join(records, order + ".txt")
    if not os.path.exists(path):
        raise ValueError(f"approval for {order} not found: {path}")
    with open(path, encoding="utf-8") as handle:
        text = handle.read()
    rule = rule_from_text(text)
    if rule:
        return rule, order
    for reference in TICKET.findall(text):
        if reference != order and reference not in seen:
            return approval_rule(records, reference, seen + (order,))
    raise ValueError(f"cannot read a scheduling rule from {path}: {text.strip()!r}")


def channels_of(text):
    """A、B 均生效 -> both channels (None); 对 B 的 -> 'B'."""
    named = set(re.findall(r"(?<![A-Za-z0-9])([AB])(?![A-Za-z0-9])", text))
    if named == {"A", "B"} or not named:
        return None
    return named.pop()


def count_of(token):
    """Chinese or arabic count: 两/2, 十二/12 ..."""
    if token.isdigit():
        return int(token)
    if "十" in token:
        tens, _, ones = token.partition("十")
        return (NUMERALS.get(tens, 1) if tens else 1) * 10 + (NUMERALS.get(ones, 0) if ones else 0)
    if token in NUMERALS:
        return NUMERALS[token]
    raise ValueError(f"cannot read the count {token!r}")


def listed_days(text, year):
    """Days written as 3月13日、20日 (a shared month may be omitted)."""
    days, month = set(), None
    for written_month, written_day in DAY_WORD.findall(text):
        if written_month:
            month = int(written_month)
        if month is None:
            raise ValueError(f"ticket day without a month: {text.strip()!r}")
        try:
            days.add(date(year, month, int(written_day)))
        except ValueError:
            raise ValueError(f"ticket has an impossible date: {text.strip()!r}")
    if not days:
        raise ValueError(f"ticket names no 原定 day: {text.strip()!r}")
    return sorted(days)


def parse_revocation(text, series_by_code, known):
    """A ticket that withdraws another one, possibly for one channel only (CH-64)."""
    if not REVOKE_WORD.search(text):
        return None
    target = next(iter(TICKET.findall(text)), None)
    if target is None:
        raise ValueError(f"撤销 ticket names no ticket to withdraw: {text.strip()!r}")
    codes = {row["code"] for row in known if row["ticket"] == target}
    if len(codes) != 1:
        raise ValueError(f"cannot tell what {target} schedules (found {sorted(codes) or 'nothing'})")
    code = codes.pop()
    days_listed = listed_days(text, as_utc(series_by_code[code]["anchor"]).year)
    if len(days_listed) != 1:
        raise ValueError(f"撤销 ticket names several days, needs a human: {text.strip()!r}")
    windows = [row for row in known if row["ticket"] == target and row["kind"] != KIND_REVOKE]
    if not any(as_date(row["from_day"]) <= days_listed[0] <= as_date(row["to_day"]) for row in windows):
        raise ValueError(f"{target} does not cover {days_listed[0]} ({text.strip()!r})")
    return dict(code=code, kind=KIND_REVOKE, from_day=days_listed[0].isoformat(),
                to_day=days_listed[0].isoformat(), days=0, minutes=0,
                basis=RULE_ORIGINAL, channel=channels_of(text), target=target)


def parse_adjustment(text, series_by_code):
    """Read one 改期 / 临时窗口 ticket; None when the text is not one."""
    if "原定" not in text:
        return None
    code = next((c for c in sorted(series_by_code, key=len, reverse=True)
                 if re.search(rf"(?<![A-Za-z0-9]){re.escape(c)}(?![0-9])", text)), None)
    if code is None:
        raise ValueError(f"ticket names no known series: {text.strip()!r}")
    series = series_by_code[code]
    found = MOVE_WORD.search(text)
    if not found:
        raise ValueError(f"ticket has 原定 days but no 提前/推迟 amount: {text.strip()!r}")
    verb, amount, unit = found.group(1), count_of(found.group(2)), found.group(3)
    sign = -1 if verb == "提前" else 1
    if unit in ("日", "天"):
        kind, days, minutes = KIND_MOVE, sign * amount, 0
    else:
        kind, days, minutes = KIND_SHIFT, 0, sign * amount * 60
    if "场馆" in text:
        basis = RULE_LOCAL                       # 仍用场馆惯用钟点
    elif "UTC" in text.upper():
        basis = RULE_UTC                         # 按通常 UTC 时刻
    else:
        raise ValueError(f"ticket does not say which clock to keep: {text.strip()!r}")
    days_listed = listed_days(text, as_utc(series["anchor"]).year)
    if not days_listed:
        raise ValueError(f"ticket names no 原定 day: {text.strip()!r}")
    if kind == KIND_MOVE and len(days_listed) != 1:
        raise ValueError(f"单场改期 ticket lists several days, needs a human: {text.strip()!r}")
    return dict(code=code, kind=kind, from_day=days_listed[0].isoformat(),
                to_day=days_listed[-1].isoformat(), days=days, minutes=minutes, basis=basis,
                channel=channels_of(text), target=None)


def check_adjustment(series, parsed):
    """The ticket must address real occurrences, and a window must not sweep extras in."""
    start, end = as_date(parsed["from_day"]), as_date(parsed["to_day"])
    hit = occurrences(series, start, end)
    wanted = {f'{parsed["code"]}-{start:%Y%m%d}'}
    if parsed["kind"] == KIND_SHIFT:
        wanted = {row["uid"] for row in hit}
    elif len(hit) != 1:
        raise ValueError(f'{parsed["code"]} has no single occurrence on {start}')
    if not wanted or not any(row["uid"] in wanted for row in hit):
        raise ValueError(f'{parsed["code"]} has no scheduled occurrence in {start}..{end}')
    if parsed["kind"] == KIND_SHIFT:
        listed = {f'{parsed["code"]}-{as_date(parsed["from_day"]):%Y%m%d}',
                  f'{parsed["code"]}-{as_date(parsed["to_day"]):%Y%m%d}'}
        if wanted != listed:
            raise ValueError(f'temporary window would also move '
                             f'{sorted(wanted - listed)}, needs a human')
    return wanted


# --------------------------------------------------------------------------- #
# migration
# --------------------------------------------------------------------------- #
def migrate(db, intake=INTAKE, records=RECORDS):
    """Incremental, repeatable import of the pilot series in intake.json."""
    ensure_schema(db)
    if not os.path.exists(intake):
        print(f"no intake at {intake}; nothing to import")
        return []
    with open(intake, encoding="utf-8") as handle:
        entries = json.load(handle)
    business_day = ""
    if os.path.exists(CLOCK):
        with open(CLOCK, encoding="utf-8") as handle:
            business_day = handle.read().strip()
    report = []
    for entry in entries:
        code, order, zone_name = entry["code"], entry["order"], entry["zone"]
        anchor = as_utc(entry["anchor"])
        zone = ZoneInfo(zone_name)                     # unknown zone fails loudly
        rule, source = approval_rule(records, order)
        local = anchor.astimezone(zone)
        # the reference calendar of the rule: UTC clock -> UTC days, venue clock -> venue days
        reference, clock = (anchor, anchor.strftime("%H:%M")) if rule == RULE_UTC else (local, local.strftime("%H:%M"))
        wanted = dict(code=code, ord=order, anchor=stamp(anchor), zone=zone_name, rule=rule,
                      weekday=reference.weekday(), clock=clock, channel=entry.get("channel"))
        current = db.execute("select " + ",".join(SERIES_COLUMNS) + " from series where code=?", (code,)).fetchone()
        if current is None:
            db.execute("insert into series(" + ",".join(SERIES_COLUMNS) + ",imported) values("
                       + ",".join("?" * (len(SERIES_COLUMNS) + 1)) + ")",
                       tuple(wanted[c] for c in SERIES_COLUMNS) + (business_day,))
            action = "imported"
        elif dict(zip(SERIES_COLUMNS, current)) == wanted:
            action = "unchanged"
        else:
            db.execute("update series set ord=?,anchor=?,zone=?,rule=?,weekday=?,clock=?,channel=? where code=?",
                       (wanted["ord"], wanted["anchor"], wanted["zone"], wanted["rule"],
                        wanted["weekday"], wanted["clock"], wanted["channel"], code))
            action = "updated"
        first = occurrences(wanted, limit=1)[0]
        before = db.execute("select starts from events where uid=?", (first["uid"],)).fetchone()
        merged = "kept"
        if before is None:
            db.execute("insert into events(uid, starts) values(?,?)", (first["uid"], first["utc"]))
            merged = "inserted"
        elif before[0] != first["utc"]:
            db.execute("update events set starts=? where uid=?", (first["utc"], first["uid"]))
            merged = "rescheduled"
        report.append(dict(code=code, order=order, source=source, rule=rule, zone=zone_name,
                           weekday=reference.weekday(), first=first["uid"], utc=first["utc"],
                           series=action, event=merged))
        print(f'{code:>5} {order} rule={rule} via={source} zone={zone_name} '
              f'weekday={reference.strftime("%a")} first={first["uid"]}@{first["utc"]} '
              f'series={action} event={merged}')
    import_adjustments(db, records, business_day)
    incident_adjustments(db, os.getenv("INCIDENT", INCIDENT), business_day)
    db.commit()
    return report


def import_adjustments(db, records, business_day=""):
    """Every ticket in the records library that reschedules occurrences."""
    series_by_code = {row[0]: dict(zip(SERIES_COLUMNS, row))
                      for row in db.execute("select " + ",".join(SERIES_COLUMNS) + " from series")}
    imported = []
    for name in sorted(os.listdir(records)) if os.path.isdir(records) else []:
        ticket, extension = os.path.splitext(name)
        if extension != ".txt" or not TICKET_NAME.fullmatch(ticket):
            continue
        with open(os.path.join(records, name), encoding="utf-8") as handle:
            text = handle.read()
        known = adjustments(db)
        parsed = parse_revocation(text, series_by_code, known) if REVOKE_WORD.search(text) else None
        if parsed is None:
            parsed = parse_adjustment(text, series_by_code)
        if parsed is None:
            continue
        check_adjustment(series_by_code[parsed["code"]], parsed)
        wanted, action = store_adjustment(db, ticket, parsed, business_day)
        imported.append(wanted)
        scope = parsed["channel"] or "A+B"
        tail = f' target={parsed["target"]}' if parsed["target"] else ""
        print(f'{ticket} {parsed["code"]} {parsed["kind"]} {parsed["from_day"]}..{parsed["to_day"]} '
              f'days={parsed["days"]:+d} minutes={parsed["minutes"]:+d} basis={parsed["basis"]} '
              f'channel={scope}{tail} adjustment={action}')
    return imported


def store_adjustment(db, ticket, parsed, business_day=""):
    """Insert or update one adjustment; the id is stable, so re-runs are no-ops."""
    key = f'{ticket}:{parsed["code"]}:{parsed["kind"]}:{parsed["from_day"]}'
    if parsed["channel"]:
        key += f':{parsed["channel"]}'
    wanted = dict(parsed, id=key, ticket=ticket)
    current = db.execute("select " + ",".join(ADJUSTMENT_COLUMNS) + " from adjustment where id=?", (key,)).fetchone()
    if current is None:
        db.execute("insert into adjustment(" + ",".join(ADJUSTMENT_COLUMNS) + ",imported) values("
                   + ",".join("?" * (len(ADJUSTMENT_COLUMNS) + 1)) + ")",
                   tuple(wanted[c] for c in ADJUSTMENT_COLUMNS) + (business_day,))
        return wanted, "imported"
    if dict(zip(ADJUSTMENT_COLUMNS, current)) == wanted:
        return wanted, "unchanged"
    db.execute("update adjustment set ticket=?,code=?,kind=?,from_day=?,to_day=?,days=?,minutes=?,basis=?,channel=?,target=? where id=?",
               (wanted["ticket"], wanted["code"], wanted["kind"], wanted["from_day"],
                wanted["to_day"], wanted["days"], wanted["minutes"], wanted["basis"],
                wanted["channel"], wanted["target"], key))
    return wanted, "updated"


# --------------------------------------------------------------------------- #
# urgent corrections (duty desk incident)
# --------------------------------------------------------------------------- #
def incident_ticket(entries):
    """Origin of the per-channel keys: urgent-0327-A / urgent-0327-B -> urgent-0327."""
    names = set()
    for channel, entry in entries.items():
        key = entry.get("key") or ""
        tail = f"-{channel}"
        names.add(key[:-len(tail)] if key.endswith(tail) else key)
    if len(names) != 1 or not next(iter(names)):
        raise ValueError(f"incident keys do not share one ticket name: {sorted(names)}")
    return names.pop()


def correction_of(series, base, moment):
    """A corrected UTC time read in the series' own clock -> (kind, days, minutes, basis)."""
    delta = moment - base
    if not delta:
        raise ValueError(f"incident repeats the contract time {stamp(moment)}; nothing to record")
    if series["rule"] == RULE_UTC:
        basis = RULE_UTC                       # 按通常 UTC 时刻
    else:                                      # 场馆钟点: the wall clock must move as far
        zone = ZoneInfo(series["zone"])
        wall = (moment.astimezone(zone).replace(tzinfo=None)
                - base.astimezone(zone).replace(tzinfo=None))
        if wall != delta:
            raise ValueError(f"correction {delta} crosses a clock change; needs a human")
        basis = RULE_LOCAL
    seconds = delta.total_seconds()
    if seconds % 86400 == 0:
        return KIND_MOVE, int(seconds // 86400), 0, basis
    if seconds % 60 == 0:
        return KIND_SHIFT, 0, int(seconds // 60), basis
    raise ValueError(f"correction of {delta} is not a whole number of minutes")


def incident_adjustments(db, incident=INCIDENT, business_day=""):
    """Record the urgent corrections in `adjustment`, so every reader agrees.

    The portal list, the invite page and the delta preparation all take the
    schedule from `adjustment`.  A correction that only reached one channel
    before the desk was cut off has to live here too, otherwise the next delta
    would push the subscribers back to the contract time.
    """
    if not incident or not os.path.exists(incident):
        return []
    with open(incident, encoding="utf-8") as handle:
        entries = json.load(handle)
    if not entries:
        return []
    ticket = incident_ticket(entries)
    series_by_code = {row[0]: dict(zip(SERIES_COLUMNS, row))
                      for row in db.execute("select " + ",".join(SERIES_COLUMNS) + " from series")}
    groups = {}
    for channel, entry in entries.items():
        if channel not in ("A", "B"):
            raise ValueError(f"incident names an unknown channel {channel!r}")
        groups.setdefault((entry["uid"], stamp(as_utc(entry["utc"])), entry["status"]), set()).add(channel)
    imported = []
    for (uid, moment, status), channels in sorted(groups.items()):
        code, day = uid.rpartition("-")[0], uid_day(uid)
        if not code or day is None:
            raise ValueError(f"incident names a malformed occurrence {uid!r}")
        if code not in series_by_code:          # a deployment that does not carry that series
            print(f"{ticket} {code} skipped: no {code} series in this database ({uid})")
            continue
        series = series_by_code[code]
        base = next((row for row in occurrences(series, day, day) if row["uid"] == uid), None)
        if base is None:
            raise ValueError(f"{code} has no occurrence on {day}")
        kind, days, minutes, basis = correction_of(series, as_utc(base["utc"]), as_utc(moment))
        scope = None if channels == {"A", "B"} else sorted(channels)[0]
        parsed = dict(code=code, kind=kind, from_day=day.isoformat(), to_day=day.isoformat(),
                      days=days, minutes=minutes, basis=basis, channel=scope, target=None)
        check_adjustment(series, parsed)
        wanted, action = store_adjustment(db, ticket, parsed, business_day)
        for channel in sorted(channels):        # the stored rule must reproduce the incident
            got = next(row for row in occurrences_around(db, code, day, channel) if row["uid"] == uid)
            if got["utc"] != moment or got["status"] != status:
                raise ValueError(f"{ticket} gives {uid} {got['utc']} on {channel}, "
                                 f"incident says {moment}")
        imported.append(wanted)
        print(f'{ticket} {code} {kind} {parsed["from_day"]}..{parsed["to_day"]} '
              f'days={days:+d} minutes={minutes:+d} basis={basis} '
              f'channel={scope or "A+B"} {uid}@{moment} adjustment={action}')
    return imported


# --------------------------------------------------------------------------- #
# http surface
# --------------------------------------------------------------------------- #
def events(db, start, end, channel, expand=False):
    rows = db.execute("select uid, starts from events order by uid")
    found = [dict(uid=u, utc=s, status="CONFIRMED") for u,s in rows if start <= s[:10] <= end]
    if expand:
        known = {uid for uid,_ in db.execute("select uid, starts from events")}
        for row in series_rows(db, as_date(start), as_date(end), channel):
            if row["uid"] not in known:
                found.append(row)
                known.add(row["uid"])
        found.sort(key=lambda r: r["uid"])
    return found


def local_label(utc, zone):
    """Wall-clock label in `zone`; date and time come from one instant."""
    local = as_utc(utc).astimezone(ZoneInfo(zone))
    return local.strftime("%Y-%m-%d %H:%M")


def _count(raw, default):
    """Lenient integer query parameter; `default` when absent or malformed."""
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


def page_slice(rows, offset_raw=None, limit_raw=None):
    """One page of already-sorted rows -> {"items": [...], "next": int|None}.

    `rows` is the complete, UID-sorted result set for the requested channel and
    service-day range — built exactly the way /api/events builds it, legacy
    occurrences included and with no per-series cap.  `next` is the offset to
    ask for on the following page, or None once the set is exhausted.  Paging
    through every page therefore reconstructs /api/events with no duplicate or
    missing UID, and the same request always returns the same page.
    """
    total = len(rows)
    offset = _count(offset_raw, 0)
    if offset < 0:
        offset = 0
    limit = _count(limit_raw, None)
    if limit is None or limit <= 0:        # no usable page size -> whole remainder
        limit = total
    if offset > total:
        offset = total
    window = rows[offset:offset + limit]
    following = offset + len(window)
    return dict(items=window, next=(following if following < total else None))


def v2_json(db, query):
    """Rows behind /api/v2; the line tables are the only thing consulted."""
    import line                      # same directory; imported lazily so V1 stands alone
    return json.dumps(line.v2_rows(db, query.get("channel", "A"),
                                   query.get("from"), query.get("to"), query.get("asof")))


def v2_by_uid(db, uid):
    """A new-line session addressed by its stable UID, for dual-version invite links.

    Pilot UIDs are resolved by resolve_occurrence() as before; this is only the
    fallback for a UID that belongs to the new line (`prefix-原定日`).
    """
    day = uid_day(uid)
    if day is None:
        return None
    import line
    asof = line.latest_version(db)
    for channel in ("A", "B", "C", "D"):
        for row in line.schedule(db, channel, day.isoformat(), day.isoformat(), asof):
            if row["uid"] == uid:
                return row
    return None


def route(db, url):
    parts = urlsplit(url)
    query = {k:v[0] for k,v in parse_qs(parts.query).items()}
    if parts.path == "/api/v2":        # new product line, stable wire identity
        return "application/json", v2_json(db, query)
    start, end = query.get("from","1900"), query.get("to","2100")
    from_day, to_day = as_date(start), as_date(end)
    bounded = from_day is not None and to_day is not None and from_day <= to_day
    rows = events(db, start, end, query.get("channel","A"), expand=bounded)
    if parts.path == "/api/events":
        return "application/json", json.dumps(rows)
    if parts.path == "/api/pages":       # paging view over the same rows as /api/events
        return "application/json", json.dumps(
            page_slice(rows, query.get("offset"), query.get("limit")))
    if parts.path.startswith("/invite/"):
        uid = parts.path.split("/")[-1]
        rows = [r for r in rows if r["uid"] == uid]
        if not rows:
            row = resolve_occurrence(db, uid, query.get("channel", "A"))
            if row and (not bounded or from_day <= uid_day(uid) <= to_day):
                rows = [row]
            elif not bounded or from_day <= uid_day(uid) <= to_day:
                row = v2_by_uid(db, uid)        # a new-line session named by its stable UID
                if row:
                    rows = [row]
    elif parts.path != "/":
        raise KeyError("unknown route")
    zone = query.get("tz","UTC")
    return "text/html", "<main>" + "".join(
        f'<article data-uid="{escape(r["uid"])}">{escape(local_label(r["utc"],zone),quote=False)}</article>' for r in rows
    ) + "</main>"


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action", choices=["serve","request","migrate"])
    p.add_argument("value", nargs="?")
    p.add_argument("rest", nargs="*")
    args=p.parse_args()
    db=ensure_schema(sqlite3.connect(os.getenv("PORTAL_DB","data/portal.sqlite")))
    if args.action == "migrate":
        migrate(db, args.value or INTAKE, (args.rest or [RECORDS])[0])
    elif args.action == "request":
        try:
            print(route(db,args.value)[1])
        except ValueError as problem:      # e.g. a malformed asof on /api/v2
            print(problem, file=sys.stderr)
            return 2
    else:
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                try:
                    mime, text = route(db,self.path)
                    status = 200
                except KeyError:
                    mime,text = "text/plain","missing"
                    status = 404
                except ValueError as problem:      # bad asof / channel on /api/v2
                    mime,text = "text/plain",str(problem)
                    status = 400
                self.send_response(status)
                self.send_header("Content-Type",mime+"; charset=utf-8")
                self.end_headers()
                self.wfile.write(text.encode())
        HTTPServer(("127.0.0.1",int(args.value or 8090)),Handler).serve_forever()


if __name__ == "__main__":
    main()
