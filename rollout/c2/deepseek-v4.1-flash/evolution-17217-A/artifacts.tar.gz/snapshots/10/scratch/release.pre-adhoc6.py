"""Rebuildable release packages for the new product line.

    python3 project/release.py build  START END ASOF [--tag first] [--outdir out]
    python3 project/release.py verify MANIFEST [--outdir out]
    python3 project/release.py record MANIFEST RECEIPTS [--json PATH] [--markdown PATH]

`build` renders one ICS per channel (A/B/C/D) from the schedule core and writes a
manifest that pins the package: for every channel its dedupe key, file name,
sha256, event count and stamp.  The key is content addressed
(`A-first-20260302-20260323-1f4c9ab2`), so the same bytes always get the same key
and different bytes can never be published under a key that is already out.

`verify` proves the package is reproducible: it checks the files on disk against
the manifest, then re-renders the package from the database and compares bytes.

Nothing here talks to the delivery service; `publish(channel, key, file)` is a
separate, deliberate step.

`record` turns the service's own receipts into the delivery record the support
desk quotes from: it matches each channel's receipt to the manifest key and
cross-checks it against the published file (same UID set, same instants,
CONFIRMED), so a record can never quietly disagree with what went out.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import sqlite3
import sys
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import line

CHANNELS = ("A", "B", "C", "D")
DEFAULT_TAG = "first"


# --------------------------------------------------------------------------- #
# rendering
# --------------------------------------------------------------------------- #
def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def key_for(channel, tag, start, end, sha):
    """Dedupe key: channel + tag + window + content digest (content addressed)."""
    return f"{channel}-{tag}-{start:%Y%m%d}-{end:%Y%m%d}-{sha[:8]}"


def render(db, channel, start, end, asof, stamp=None):
    """-> (ics text, rows) for one channel; updates the per-UID feed state."""
    rows = line.feed_rows(db, channel, start, end, asof, stamp=stamp)
    return calendar_io.encode_feed(rows), rows


def build(db, channel, start, end, asof, outdir, tag=DEFAULT_TAG, stamp=None):
    """Write one channel's release file; -> manifest entry."""
    start, end = line.as_day(start), line.as_day(end)
    text, rows = render(db, channel, start, end, asof, stamp=stamp)
    name = f"{tag}-{channel}-{start:%Y%m%d}-{end:%Y%m%d}.ics"
    path = os.path.join(outdir, name)
    os.makedirs(outdir, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)
    sha = digest(text)
    db.commit()
    return dict(channel=channel, key=key_for(channel, tag, start, end, sha),
                file=name, sha256=sha, events=len(rows),
                first_uid=rows[0]["uid"] if rows else None,
                last_uid=rows[-1]["uid"] if rows else None,
                uids=[row["uid"] for row in rows])


def build_all(db, start, end, asof, outdir, tag=DEFAULT_TAG, stamp=None):
    """Build every channel and write the manifest; -> manifest dict."""
    try:
        registered = db.execute("select count(*) from line_series").fetchone()[0]
    except sqlite3.OperationalError:
        registered = 0
    if not registered:
        raise ValueError("no series registered; run `line.py import INPUT_DIR` first")
    start, end = line.as_day(start), line.as_day(end)
    stamp = stamp or line.feed_stamp()
    channels = [build(db, channel, start, end, asof, outdir, tag=tag, stamp=stamp)
                for channel in CHANNELS]
    manifest = dict(tag=tag, start=start.isoformat(), end=end.isoformat(),
                    asof=int(asof), stamp=stamp, channels=channels)
    write_manifest(manifest, outdir)
    return manifest


def manifest_path(outdir, tag=DEFAULT_TAG):
    return os.path.join(outdir, f"{tag}-manifest.json")


def write_manifest(manifest, outdir):
    text = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    with open(manifest_path(outdir, manifest["tag"]), "w", encoding="utf-8") as handle:
        handle.write(text)
    return digest(text)


def load_manifest(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


# --------------------------------------------------------------------------- #
# verification
# --------------------------------------------------------------------------- #
def verify(db, path, outdir=None):
    """Check the package on disk and re-render it; -> list of problems."""
    manifest = load_manifest(path)
    outdir = outdir or os.path.dirname(os.path.abspath(path))
    problems = []
    for entry in manifest["channels"]:
        target = os.path.join(outdir, entry["file"])
        if not os.path.exists(target):
            problems.append(f"{entry['channel']}: missing file {entry['file']}")
            continue
        with open(target, encoding="utf-8", newline="") as handle:
            on_disk = handle.read()
        if digest(on_disk) != entry["sha256"]:
            problems.append(f"{entry['channel']}: {entry['file']} does not match its sha256")
        rebuilt, rows = render(db, entry["channel"], manifest["start"], manifest["end"],
                               manifest["asof"], stamp=manifest["stamp"])
        if digest(rebuilt) != entry["sha256"]:
            problems.append(f"{entry['channel']}: rebuild from the database differs")
        elif [row["uid"] for row in rows] != entry["uids"]:
            problems.append(f"{entry['channel']}: rebuild has a different UID set")
        expected_key = key_for(entry["channel"], manifest["tag"],
                               line.as_day(manifest["start"]), line.as_day(manifest["end"]),
                               entry["sha256"])
        if expected_key != entry["key"]:
            problems.append(f"{entry['channel']}: key {entry['key']} is not {expected_key}")
    db.commit()
    return problems


# --------------------------------------------------------------------------- #
# delivery record
# --------------------------------------------------------------------------- #
def ics_starts(text):
    """{UID: DTSTART} from an ICS body."""
    out, uid = {}, None
    for raw in text.replace("\r\n", "\n").split("\n"):
        name, _, value = raw.partition(":")
        if raw == "BEGIN:VEVENT":
            uid = None
        elif name == "UID":
            uid = value
        elif name == "DTSTART" and uid:
            out[uid] = value
        elif raw == "END:VEVENT":
            uid = None
    return out


def stamp_of(utc):
    """ISO8601 instant -> the ICS basic format used in DTSTART."""
    return datetime.fromisoformat(utc.replace("Z", "+00:00")).astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def local_label(utc, zone):
    moment = datetime.fromisoformat(utc.replace("Z", "+00:00")).astimezone(ZoneInfo(zone))
    return moment.strftime("%Y-%m-%d %H:%M %Z")


def code_of(db, channel, uid):
    """The series code behind a wire UID (prefix lookup, per channel)."""
    prefix = uid.rpartition("-")[0]
    for row in db.execute("select code from line_series order by code"):
        if line.prefix_for(db, row[0], channel) == prefix:
            return row[0]
    return None


def zone_of(db, code):
    row = db.execute("select zone from line_series where code=?", (code,)).fetchone()
    return row[0] if row else "UTC"


def receipt_for(receipts, channel, key):
    for batch in receipts.get(channel, []):
        if batch.get("key") == key:
            return batch
    return None


def record(db, manifest_path, receipts_path, json_path=None, markdown_path=None, outdir=None):
    """Build the support-facing delivery record; -> (record dict, problems list)."""
    manifest = load_manifest(manifest_path)
    outdir = outdir or os.path.dirname(os.path.abspath(manifest_path))
    with open(receipts_path, encoding="utf-8") as handle:
        receipts = json.load(handle)

    problems, batches, deliveries = [], [], []
    for entry in manifest["channels"]:
        channel = entry["channel"]
        batch = receipt_for(receipts, channel, entry["key"])
        if batch is None:
            problems.append(f"{channel}: no receipt for key {entry['key']}")
            batches.append(dict(channel=channel, key=entry["key"], file=entry["file"],
                                sha256=entry["sha256"], events=entry["events"],
                                receipt=None, turn=None, receipt_rows=0))
            continue
        rows = batch.get("rows") or {}
        with open(os.path.join(outdir, entry["file"]), encoding="utf-8", newline="") as handle:
            published = ics_starts(handle.read())
        if len(rows) != entry["events"]:
            problems.append(f"{channel}: receipt has {len(rows)} rows, package has {entry['events']}")
        if sorted(rows) != sorted(entry["uids"]):
            problems.append(f"{channel}: receipt UID set differs from the package")
        for uid, row in sorted(rows.items()):
            if row.get("status") != "CONFIRMED":
                problems.append(f"{channel}: {uid} is {row.get('status')!r} on the service")
            if published.get(uid) != stamp_of(row["utc"]):
                problems.append(f"{channel}: {uid} is {row['utc']} on the service, "
                                f"{published.get(uid)} in {entry['file']}")
            code = code_of(db, channel, uid)
            deliveries.append(dict(channel=channel, uid=uid, code=code, utc=row["utc"],
                                   status=row["status"],
                                   local=local_label(row["utc"], zone_of(db, code) if code else "UTC")))
        batches.append(dict(channel=channel, key=entry["key"], file=entry["file"],
                            sha256=entry["sha256"], events=entry["events"],
                            receipt=batch.get("receipt"), turn=batch.get("turn"),
                            receipt_rows=len(rows)))

    result = dict(tag=manifest["tag"], start=manifest["start"], end=manifest["end"],
                  asof=manifest["asof"], stamp=manifest["stamp"],
                  manifest=os.path.basename(manifest_path), batches=batches,
                  deliveries=deliveries,
                  totals=dict(channels=len({row["channel"] for row in deliveries}),
                              deliveries=len(deliveries),
                              confirmed=sum(1 for row in deliveries if row["status"] == "CONFIRMED")))
    if json_path:
        os.makedirs(os.path.dirname(os.path.abspath(json_path)), exist_ok=True)
        with open(json_path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    if markdown_path:
        os.makedirs(os.path.dirname(os.path.abspath(markdown_path)), exist_ok=True)
        with open(markdown_path, "w", encoding="utf-8") as handle:
            handle.write(render_markdown(result))
    db.commit()
    return result, problems


def render_markdown(result):
    """A support desk can quote this as-is."""
    lines = [f"# 交付记录 · {result['tag']}（客服引用）", "",
             f"* 服务窗口（原定日，含端点）：{result['start']} .. {result['end']}",
             f"* 授权版本 ASOF：{result['asof']}",
             f"* 发布包：`{result['manifest']}`（`python3 project/release.py build "
             f"{result['start']} {result['end']} {result['asof']} --tag {result['tag']}` 可重建）",
             f"* DTSTAMP：{result['stamp']}",
             f"* 共 {result['totals']['channels']} 端 / {result['totals']['deliveries']} 条投递 / "
             f"{result['totals']['confirmed']} 条 CONFIRMED",
             "", "## 批次与回执", "",
             "| 端 | 回执 | key | 文件 | sha256 | VEVENT |", "| --- | --- | --- | --- | --- | --- |"]
    for entry in result["batches"]:
        lines.append(f"| {entry['channel']} | {entry.get('receipt', '—')} | `{entry['key']}` | "
                     f"`{entry['file']}` | `{entry['sha256'][:12]}…` | {entry['events']} |")
    for channel in CHANNELS:
        rows = [row for row in result["deliveries"] if row["channel"] == channel]
        if not rows:
            continue
        lines.extend(["", f"## {channel} 端（{len(rows)} 场）", "",
                      "| UID | 系列 | UTC | 场馆当地 | 状态 |", "| --- | --- | --- | --- | --- |"])
        for row in rows:
            lines.append(f"| `{row['uid']}` | {row['code']} | {row['utc']} | {row['local']} | {row['status']} |")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main(argv=None):
    parser = argparse.ArgumentParser(prog="release.py")
    sub = parser.add_subparsers(dest="action", required=True)
    builder = sub.add_parser("build")
    builder.add_argument("start")
    builder.add_argument("end")
    builder.add_argument("asof", type=int)
    builder.add_argument("--tag", default=DEFAULT_TAG)
    builder.add_argument("--outdir", default="out")
    builder.add_argument("--stamp", default=None)
    checker = sub.add_parser("verify")
    checker.add_argument("manifest")
    checker.add_argument("--outdir", default=None)
    recorder = sub.add_parser("record")
    recorder.add_argument("manifest")
    recorder.add_argument("receipts")
    recorder.add_argument("--json", dest="json_path", default=None)
    recorder.add_argument("--markdown", dest="markdown_path", default=None)
    recorder.add_argument("--outdir", default=None)
    args = parser.parse_args(argv)

    db = line.ensure_schema(sqlite3.connect(os.getenv("PORTAL_DB", "data/portal.sqlite")))
    try:
        if args.action == "build":
            manifest = build_all(db, args.start, args.end, args.asof, args.outdir,
                                 tag=args.tag, stamp=args.stamp)
            print(json.dumps(manifest, ensure_ascii=False))
            return 0
        if args.action == "record":
            result, problems = record(db, args.manifest, args.receipts,
                                      json_path=args.json_path,
                                      markdown_path=args.markdown_path,
                                      outdir=args.outdir)
            for problem in problems:
                print(problem, file=sys.stderr)
            print(json.dumps(dict(batches=len(result["batches"]),
                                  deliveries=result["totals"]["deliveries"],
                                  confirmed=result["totals"]["confirmed"],
                                  problems=len(problems)), ensure_ascii=False))
            return 0 if not problems else 2
        problems = verify(db, args.manifest, args.outdir)
        for problem in problems:
            print(problem, file=sys.stderr)
        print(json.dumps(dict(manifest=args.manifest, ok=not problems,
                              problems=len(problems)), ensure_ascii=False))
        return 0 if not problems else 2
    except (ValueError, OSError, json.JSONDecodeError, sqlite3.Error) as problem:
        print(f"release.py {args.action} failed: {problem}", file=sys.stderr)
        return 2
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
