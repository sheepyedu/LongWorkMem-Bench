"""Compare every legacy answer before/after the handover on the real HTTP server."""
import json, os, socket, subprocess, sys, time, urllib.request, urllib.error

URLS = ["/", "/api/events", "/api/pages?limit=100", "/api/pages?limit=2",
        "/invite/M42-20260327", "/invite/M42-20260306", "/invite/M42-20260313",
        "/invite/K17-20260306", "/invite/line-401-20260316", "/invite/line-404-20260309",
        "/invite/N84-20260316",
        "/api/when?channel=B&code=Q29&day=2026-03-16&asof=4",
        "/api/when?channel=C&code=U56&day=2026-03-16"]
for asof in range(1, 9):
    URLS.append(f"/api/v2?channel=A&from=2026-03-02&to=2026-03-23&asof={asof}")
    URLS.append(f"/api/v2?channel=B&from=2026-03-02&to=2026-03-23&asof={asof}")
    URLS.append(f"/api/v2?channel=C&from=2026-03-02&to=2026-03-23&asof={asof}")
    URLS.append(f"/api/v2?channel=D&from=2026-03-02&to=2026-03-23&asof={asof}")
URLS.append("/api/v2?channel=A&from=2026-10-19&to=2026-11-09&asof=9")

def fetch_all(db):
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]
    env = dict(os.environ, PORTAL_DB=os.path.abspath(db))
    proc = subprocess.Popen([sys.executable, "project/portal.py", "serve", str(port)],
                            stderr=subprocess.DEVNULL, env=env)
    out = {}
    try:
        for _ in range(120):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2).read(); break
            except urllib.error.URLError:
                if proc.poll() is not None: raise
                time.sleep(.05)
        for url in URLS:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}{url}", timeout=5) as r:
                    out[url] = (r.status, r.read().decode())
            except urllib.error.HTTPError as err:
                out[url] = (err.code, err.read().decode())
    finally:
        proc.terminate(); proc.wait()
    return out

before = fetch_all("scratch/portal.pre-handover9.verify.sqlite")
after = fetch_all("data/portal.sqlite")
same = [u for u in URLS if before[u] == after[u]]
diff = [u for u in URLS if before[u] != after[u]]
print(f"same={len(same)} diff={len(diff)}")
for u in diff:
    print("DIFF", u, before[u][0], after[u][0])
    if u.startswith("/api/v2") and "asof=9" not in u:
        b = json.loads(before[u][1]); a = json.loads(after[u][1])
        for x, y in zip(b, a):
            if x != y: print("   before", x); print("   after ", y)
json.dump({u: after[u][1] for u in URLS}, open("out/handover-legacy-after.json", "w"), indent=1)
json.dump({u: before[u][1] for u in URLS}, open("out/handover-legacy-before.json", "w"), indent=1)
