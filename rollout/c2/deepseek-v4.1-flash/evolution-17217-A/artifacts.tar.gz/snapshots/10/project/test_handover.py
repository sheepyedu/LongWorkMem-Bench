"""Handover launch: clean instance from source + backup, autumn release, backup.

Run: python3 project/test_handover.py

A handover is only clean if it proves four things at once: a fresh instance built
from the source tree and the signed database backup answers exactly like the
delivered one; the autumn extra orders land on the four service days the release
window names, per channel, with DST-correct wall clocks; the packages are
rebuildable byte for byte and their keys are the ones in the delivery record; and
nothing old breaks -- legacy links, historical ASOF answers and wire identities
stay valid.

The one change the new version makes to the past (A-82 moves B's 2026-03-16
session) is deliberately *not* delivered here: it is prepared as a single-event
package and reported, so no customer is notified without an instruction.
"""
import json
import os
import sqlite3
import sys
import tempfile
import unittest

import line
import portal
import release

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
OUT = os.path.join(ROOT, "out")
BACKUP = os.path.join(OUT, "backup.sqlite")
STAMP = "20260330T000000Z"
AUTUMN_START, AUTUMN_END, AUTUMN_ASOF = "2026-10-19", "2026-11-09", 9
MARCH_START, MARCH_END = "2026-03-02", "2026-03-23"
DAYS = ("20261019", "20261026", "20261102", "20261109")
CHANNELS = ("A", "B", "C", "D")
PREFIX = {("A", "N84"): "N84", ("A", "Q29"): "Q29", ("A", "U56"): "U56", ("A", "J31"): "J31",
          ("B", "N84"): "line-401", ("B", "Q29"): "line-402", ("B", "U56"): "line-403",
          ("B", "J31"): "line-404",
          ("C", "N84"): "line-401", ("C", "Q29"): "line-402", ("C", "U56"): "line-403",
          ("C", "J31"): "line-404",
          ("D", "N84"): "N84", ("D", "Q29"): "Q29", ("D", "U56"): "U56", ("D", "J31"): "J31"}
# Wall clocks per code and day; N84 and U56 cross the DST switch between 10-26
# and 11-02, J31 enters AEDT, Q29 leaves BST -- the UTC instants must follow.
BASE = {"J31": ["01:30"] * 4,
        "N84": ["13:45", "13:45", "14:45", "14:45"],
        "Q29": ["15:00"] * 4,
        "U56": ["06:20", "07:20", "07:20", "07:20"]}
OVERRIDE = {"B": {"N84": ["13:45", "13:30", "13:30", "14:45"],   # A-80, B+D only
                  "Q29": ["16:30"] * 4},                          # B-611
            "D": {"N84": ["13:45", "13:30", "13:30", "14:45"]},   # A-80
            "C": {"J31": ["11:40"] * 4}}                          # A-81, C only


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def expected(channel):
    """-> {uid: 'YYYY-MM-DDTHH:MM:SS'} the autumn four service days must hold."""
    table = dict(BASE)
    table.update(OVERRIDE.get(channel, {}))
    out = {}
    for code, times in table.items():
        for day, clock in zip(DAYS, times):
            out[f"{PREFIX[(channel, code)]}-{day}"] = f"{day[:4]}-{day[4:6]}-{day[6:]}T{clock}:00"
    return out


def fresh_db():
    """A clean instance: an empty database filled from input/ only."""
    db = line.ensure_schema(sqlite3.connect(":memory:"))
    line.import_dir(db, INPUT)
    return db


def open_backup():
    """The delivered backup, opened read only so a test cannot disturb it."""
    return sqlite3.connect(f"file:{BACKUP}?mode=ro", uri=True)


def plain(utc):
    """The engine may spell UTC as +00:00; packages spell it Z."""
    return (utc or "").replace("+00:00", "").replace("Z", "")


def utc_map(db, channel, start, end, asof):
    return {row["uid"]: plain(row["utc"]) for row in line.schedule(db, channel, start, end, asof)}


def read(path):
    """Read verbatim: packages are compared byte for byte, CRLF included."""
    with open(path, encoding="utf-8", newline="") as handle:
        return handle.read()


def load(path):
    return json.loads(read(path))


def order_ids():
    """Every order id the source material has sent so far."""
    ids = set()
    folder = os.path.join(INPUT, "orders")
    for name in sorted(os.listdir(folder)):
        if not name.endswith(".json"):
            continue
        batch = load(os.path.join(folder, name))
        rows = batch
        if isinstance(batch, dict):
            rows = batch.get("rows") or batch.get("orders") or []
        for row in rows:
            ids.add(row["id"])
    return ids


# --------------------------------------------------------------------------- #
# a clean instance from source + signed backup
# --------------------------------------------------------------------------- #
class CleanInstance(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()

    def test_a_clean_instance_serves_the_autumn_window(self):
        for channel in CHANNELS:
            self.assertEqual(utc_map(self.db, channel, AUTUMN_START, AUTUMN_END, AUTUMN_ASOF),
                             expected(channel), channel)

    def test_four_service_days_and_no_others(self):
        days = {row["day"] for row in line.schedule(self.db, "A", AUTUMN_START, AUTUMN_END, AUTUMN_ASOF)}
        self.assertEqual(days, {"2026-10-19", "2026-10-26", "2026-11-02", "2026-11-09"})
        for channel in CHANNELS:
            self.assertEqual(len(line.schedule(self.db, channel, AUTUMN_START, AUTUMN_END, AUTUMN_ASOF)),
                             16, channel)

    def test_a80_moves_only_b_and_d_and_only_inside_its_window(self):
        for channel in CHANNELS:
            rows = utc_map(self.db, channel, AUTUMN_START, AUTUMN_END, AUTUMN_ASOF)
            for day in DAYS:
                uid = f"{PREFIX[(channel, 'N84')]}-{day}"
                inside = day in ("20261026", "20261102")
                self.assertEqual(rows[uid].endswith("13:30:00"), inside and channel in "BD",
                                 (channel, uid, rows[uid]))

    def test_a81_moves_only_c(self):
        for channel in CHANNELS:
            rows = utc_map(self.db, channel, AUTUMN_START, AUTUMN_END, AUTUMN_ASOF)
            for day in DAYS:
                uid = f"{PREFIX[(channel, 'J31')]}-{day}"
                self.assertEqual(rows[uid].endswith("11:40:00"), channel == "C", (channel, uid))

    def test_wall_clocks_hold_across_the_dst_switch(self):
        autumn = utc_map(self.db, "A", AUTUMN_START, AUTUMN_END, AUTUMN_ASOF)
        # N84 09:45 New York: EDT until 11-01, EST after.
        self.assertEqual(autumn["N84-20261026"], "2026-10-26T13:45:00")
        self.assertEqual(autumn["N84-20261102"], "2026-11-02T14:45:00")
        # U56 08:20 Berlin: CEST until 10-25, CET after.
        self.assertEqual(autumn["U56-20261019"], "2026-10-19T06:20:00")
        self.assertEqual(autumn["U56-20261026"], "2026-10-26T07:20:00")
        # Q29 15:00 UTC is a UTC clock: unchanged by the London switch.
        self.assertEqual(autumn["Q29-20261019"], "2026-10-19T15:00:00")
        self.assertEqual(autumn["Q29-20261102"], "2026-11-02T15:00:00")

    def test_the_import_is_idempotent(self):
        before = {channel: utc_map(self.db, channel, MARCH_START, "2026-11-09", 9) for channel in CHANNELS}
        report = line.import_dir(self.db, INPUT)
        self.assertTrue(report["orders"], "a re-import should still report every batch")
        self.assertEqual({row["action"] for row in report["orders"]}, {"duplicate"})
        after = {channel: utc_map(self.db, channel, MARCH_START, "2026-11-09", 9) for channel in CHANNELS}
        self.assertEqual(before, after)

    def test_version_nine_is_the_latest_authorisation(self):
        self.assertEqual(line.latest_version(self.db), 9)


# --------------------------------------------------------------------------- #
# the retroactive order must not rewrite history
# --------------------------------------------------------------------------- #
class Retroactive(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()

    def test_a82_applies_to_b_at_the_current_version(self):
        rows = utc_map(self.db, "B", "2026-03-16", "2026-03-16", 9)
        self.assertEqual(rows["line-401-20260316"], "2026-03-16T12:50:00")

    def test_historical_versions_still_answer_the_old_way(self):
        # asof 1..5 the base approval holds; the turn-6 window moved it to 03-15;
        # only version 9 (A-82) puts it back on 03-16 with a new clock.
        for asof, utc in ((1, "2026-03-16T13:45:00"), (5, "2026-03-16T13:45:00"),
                          (6, "2026-03-15T13:45:00"), (8, "2026-03-15T13:45:00")):
            rows = utc_map(self.db, "B", "2026-03-16", "2026-03-16", asof)
            self.assertEqual(rows["line-401-20260316"], utc, asof)

    def test_a82_touches_no_other_channel(self):
        backup = open_backup()
        try:
            for channel in ("A", "C", "D"):
                self.assertEqual(utc_map(self.db, channel, MARCH_START, MARCH_END, 9),
                                 utc_map(backup, channel, MARCH_START, MARCH_END, 8), channel)
        finally:
            backup.close()

    def test_the_clean_instance_reproduces_every_old_answer(self):
        backup = open_backup()
        try:
            for asof in range(1, 9):
                for channel in CHANNELS:
                    self.assertEqual(utc_map(self.db, channel, MARCH_START, MARCH_END, asof),
                                     utc_map(backup, channel, MARCH_START, MARCH_END, asof),
                                     (channel, asof))
        finally:
            backup.close()


# --------------------------------------------------------------------------- #
# the delivered packages
# --------------------------------------------------------------------------- #
class Packages(unittest.TestCase):
    def setUp(self):
        self.manifest = load(os.path.join(OUT, "autumn-manifest.json"))

    def test_the_manifest_pins_four_sixteen_event_packages(self):
        self.assertEqual(self.manifest["tag"], "autumn")
        self.assertEqual(self.manifest["asof"], AUTUMN_ASOF)
        self.assertEqual(self.manifest["stamp"], STAMP)
        self.assertEqual([entry["channel"] for entry in self.manifest["channels"]], list(CHANNELS))
        for entry in self.manifest["channels"]:
            self.assertEqual(entry["events"], 16)
            text = read(os.path.join(OUT, entry["file"]))
            self.assertEqual(text.count("BEGIN:VEVENT"), 16)
            self.assertEqual(sorted(entry["uids"]), sorted(expected(entry["channel"])))

    def test_every_package_verifies(self):
        self.assertEqual(release.verify(fresh_db(), os.path.join(OUT, "autumn-manifest.json"),
                                        outdir=OUT), [])

    def test_packages_rebuild_byte_for_byte_from_source(self):
        folder = tempfile.mkdtemp()
        try:
            rebuilt = release.build_all(fresh_db(), AUTUMN_START, AUTUMN_END, AUTUMN_ASOF,
                                        folder, tag="autumn", stamp=STAMP)
        finally:
            pass
        by_channel = {entry["channel"]: entry for entry in rebuilt["channels"]}
        for entry in self.manifest["channels"]:
            channel = entry["channel"]
            self.assertEqual(by_channel[channel]["sha256"], entry["sha256"], channel)
            self.assertEqual(by_channel[channel]["key"], entry["key"], channel)
            self.assertEqual(read(os.path.join(folder, entry["file"])),
                             read(os.path.join(OUT, entry["file"])), channel)

    def test_new_c_is_the_c_package(self):
        text = read(os.path.join(OUT, "new-C.ics"))
        self.assertEqual(text, read(os.path.join(OUT, "autumn-C-20261019-20261109.ics")))
        self.assertEqual(text.count("BEGIN:VEVENT"), 16)
        rows = utc_map(fresh_db(), "C", AUTUMN_START, AUTUMN_END, AUTUMN_ASOF)
        for uid, utc in rows.items():
            wire = utc.replace("-", "").replace(":", "")
            self.assertIn(f"UID:{uid}\r\nDTSTAMP:{STAMP}\r\nDTSTART:{wire}", text, uid)

    def test_the_delivery_record_matches_what_went_out(self):
        record = load(os.path.join(OUT, "autumn-delivery.json"))
        self.assertEqual(record["kind"], "release")
        self.assertEqual(record["totals"]["deliveries"], 64)
        self.assertEqual(record["totals"]["confirmed"], 64)
        receipts = load(os.path.join(OUT, "receipts-autumn.json"))
        for entry in record["batches"]:
            batches = [batch for batch in receipts[entry["channel"]] if batch["key"] == entry["key"]]
            self.assertEqual(len(batches), 1, entry["channel"])
            self.assertEqual(batches[0]["receipt"], entry["receipt"])
            self.assertEqual(len(batches[0]["rows"]), 16)

    def test_the_autumn_window_is_in_step_on_every_channel(self):
        report = line.reconcile(fresh_db(), AUTUMN_START, AUTUMN_END, AUTUMN_ASOF,
                                [os.path.join(OUT, "receipts-autumn-window.json")])
        self.assertTrue(report["in_step"], report)

    def test_the_undelivered_march_fix_is_one_event_and_not_in_any_batch(self):
        fix = load(os.path.join(OUT, "fixB-manifest.json"))
        self.assertEqual(len(fix["channels"]), 1)
        entry = fix["channels"][0]
        self.assertEqual(entry["channel"], "B")
        self.assertEqual(entry["uids"], ["line-401-20260316"])
        self.assertEqual(entry["previous"], {"line-401-20260316": "2026-03-15T13:45:00Z"})
        self.assertEqual(fix["withdrawn"], [])
        published = {batch["key"] for batches in load(os.path.join(OUT, "receipts-autumn.json")).values()
                     for batch in batches}
        self.assertNotIn(entry["key"], published)
        self.assertNotIn(entry["key"], {row["key"] for row in self.manifest["channels"]})


# --------------------------------------------------------------------------- #
# the delivered backup
# --------------------------------------------------------------------------- #
class Backup(unittest.TestCase):
    def setUp(self):
        self.assertTrue(os.path.exists(BACKUP), BACKUP)
        self.db = open_backup()

    def tearDown(self):
        self.db.close()

    def test_the_backup_is_sound_and_complete(self):
        self.assertEqual(self.db.execute("pragma integrity_check").fetchone()[0], "ok")
        tables = {row[0] for row in self.db.execute("select name from sqlite_master where type='table'")}
        self.assertEqual(tables, {"adjustment", "bookings", "events", "series",
                                  "line_series", "line_order", "line_identity", "line_feed"})
        counts = {name: self.db.execute(f'select count(*) from "{name}"').fetchone()[0] for name in tables}
        self.assertEqual(counts["events"], 4)      # legacy registrations untouched
        self.assertEqual(counts["bookings"], 4)
        self.assertEqual(counts["series"], 2)
        self.assertEqual(counts["adjustment"], 4)
        self.assertEqual(counts["line_series"], 4)
        self.assertEqual(counts["line_identity"], 16)
        ids = {row[0] for row in self.db.execute("select id from line_order")}
        self.assertEqual(ids, order_ids())

    def test_the_backup_answers_like_a_clean_instance(self):
        fresh = fresh_db()
        for channel in CHANNELS:
            self.assertEqual(utc_map(self.db, channel, AUTUMN_START, AUTUMN_END, AUTUMN_ASOF),
                             expected(channel), channel)
            self.assertEqual(utc_map(self.db, channel, MARCH_START, MARCH_END, AUTUMN_ASOF),
                             utc_map(fresh, channel, MARCH_START, MARCH_END, AUTUMN_ASOF), channel)

    def test_the_backup_serves_the_new_and_the_old_product(self):
        kind, body = portal.route(self.db, "/api/v2?channel=C&from=2026-10-19&to=2026-11-09&asof=9")
        self.assertEqual(kind, "application/json")
        self.assertEqual(len(json.loads(body)), 16)
        kind, body = portal.route(self.db, "/api/events")
        self.assertEqual(kind, "application/json")
        self.assertEqual(len(json.loads(body)), 4)
        kind, body = portal.route(self.db, "/api/pages?limit=2")
        self.assertEqual(kind, "application/json")
        page = json.loads(body)
        self.assertEqual(len(page["items"]), 2)
        self.assertEqual(page["next"], 2)

    def test_old_links_still_resolve_identically(self):
        kind, body = portal.route(self.db, "/invite/M42-20260327")
        self.assertEqual(kind, "text/html")
        self.assertIn('data-uid="M42-20260327"', body)
        kind, body = portal.route(self.db, "/invite/K17-20260306")
        self.assertEqual(kind, "text/html")
        self.assertIn('data-uid="K17-20260306"', body)
        # A wire identity from the new line resolves on the same route; its time
        # follows the current version (A-82), its identity does not move.
        kind, body = portal.route(self.db, "/invite/line-401-20260316")
        self.assertEqual(kind, "text/html")
        self.assertIn('data-uid="line-401-20260316"', body)
        self.assertIn("2026-03-16 12:50", body)

    def test_historical_versions_are_byte_identical_to_before_the_handover(self):
        before = load(os.path.join(OUT, "handover-legacy-before.json"))
        after = load(os.path.join(OUT, "handover-legacy-after.json"))
        moved = {"/invite/line-401-20260316",
                 "/api/when?channel=C&code=U56&day=2026-03-16"}  # asof echo only
        for url, body in before.items():
            if url in moved:
                continue
            self.assertEqual(after[url], body, url)
        self.assertNotEqual(after["/invite/line-401-20260316"], before["/invite/line-401-20260316"])


# --------------------------------------------------------------------------- #
# delta discipline
# --------------------------------------------------------------------------- #
class DeltaWindow(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        self.delivered = release.downstream_state(os.path.join(OUT, "receipts-B-full.json"))[0]["B"]

    def test_a_march_delta_ignores_autumn_service_days(self):
        changed, withdrawn = release.delta_rows(self.db, "B", line.as_day(MARCH_START),
                                               line.as_day(MARCH_END), 9, self.delivered)
        self.assertEqual([row["uid"] for row in changed], ["line-401-20260316"])
        self.assertEqual(withdrawn, [])

    def test_the_core_agrees_on_the_same_window(self):
        received = {uid: {"uid": uid, "utc": utc, "status": line.STATUS_CONFIRMED}
                    for uid, utc in self.delivered.items()}
        changed, withdrawn = line.delta_rows(self.db, "B", line.as_day(MARCH_START),
                                            line.as_day(MARCH_END), 9, received)
        self.assertEqual([row["uid"] for row in changed], ["line-401-20260316"])
        self.assertEqual(withdrawn, [])

    def test_an_autumn_delta_against_the_real_receipts_is_empty(self):
        grand = tempfile.mkdtemp()
        manifest = release.build_delta(self.db, AUTUMN_START, AUTUMN_END, AUTUMN_ASOF, grand,
                                       [os.path.join(OUT, "receipts-autumn.json")],
                                       tag="recheck", channels=CHANNELS, stamp=STAMP)
        self.assertEqual(manifest["channels"], [])
        self.assertEqual(manifest["withdrawn"], [])
        self.assertEqual(len(manifest["skipped"]), 4)


if __name__ == "__main__":
    sys.exit(unittest.main(verbosity=2))
