"""Version 7: the board revokes part of version 6, and the pending packages.

Run: python3 project/test_plan.py

input/orders/ops-7.json withdraws two approvals, per channel and per original
day, so each channel walks its own override chain back:

* W-11 drops T-72 on B, C and D for 2026-03-16 only -- B falls back to B-611
  (16:30 UTC), C and D fall back to the base clock, A keeps 17:00, and
  2026-03-09 keeps 17:00 everywhere;
* W-12 drops Z-87 on D for 2026-03-23 only -- D falls back to Z-213 (09:15 UTC),
  2026-03-16 keeps 10:45.

The pending package (`line.py delta`) is measured against the merged receipts the
subscriber already holds, applied in (turn, receipt) order: nothing else may be
in it, an empty package is legal, and nothing is sent here.
"""
import json
import os
import shutil
import sqlite3
import tempfile
import unittest

import line
import portal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
LIVE = os.path.join(ROOT, "data", "portal.sqlite")
OUT = os.path.join(ROOT, "out")
STAMP = "20260330T000000Z"
START, END = "2026-03-02", "2026-03-23"
ASOF, BEFORE = 7, 6
DAYS = ("2026-03-02", "2026-03-09", "2026-03-16", "2026-03-23")

# What each channel really holds: turn 4 (full window) then turn 6 (the delta).
RECEIVED = {
    "A": ({"J31-20260309": "2026-03-09T07:10:00Z", "Q29-20260309": "2026-03-09T17:00:00Z",
           "N84-20260316": "2026-03-15T13:45:00Z", "Q29-20260316": "2026-03-16T17:00:00Z"}, 16),
    "B": ({"line-402-20260309": "2026-03-09T17:00:00Z",
           "line-401-20260316": "2026-03-15T13:45:00Z",
           "line-402-20260316": "2026-03-16T17:00:00Z",
           "line-403-20260316": "2026-03-16T10:45:00Z",
           "line-403-20260323": "2026-03-23T10:45:00Z"}, 16),
    "C": ({"line-404-20260309": "2026-03-09T07:10:00Z",
           "line-402-20260309": "2026-03-09T17:00:00Z",
           "line-401-20260316": "2026-03-15T13:45:00Z",
           "line-402-20260316": "2026-03-16T17:00:00Z"}, 16),
    "D": ({"Q29-20260309": "2026-03-09T17:00:00Z", "N84-20260316": "2026-03-15T13:45:00Z",
           "Q29-20260316": "2026-03-16T17:00:00Z", "U56-20260316": "2026-03-16T10:45:00Z",
           "U56-20260323": "2026-03-23T10:45:00Z"}, 16),
}
# (uid, was, now) per channel: the pending package, nothing else.
PENDING = {
    "A": [],
    "B": [("line-402-20260316", "2026-03-16T17:00:00Z", "2026-03-16T16:30:00Z")],
    "C": [("line-402-20260316", "2026-03-16T17:00:00Z", "2026-03-16T15:00:00Z")],
    "D": [("Q29-20260316", "2026-03-16T17:00:00Z", "2026-03-16T15:00:00Z"),
          ("U56-20260323", "2026-03-23T10:45:00Z", "2026-03-23T09:15:00Z")],
}


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def fresh():
    db = line.ensure_schema(sqlite3.connect(":memory:"))
    line.import_dir(db, INPUT)
    return db


def live_copy():
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(LIVE, path)
    return line.ensure_schema(sqlite3.connect(path))


def receipts_for(channel):
    """The merged receipts as they stood when version 7 was planned (turn 4 + turn 6).

    `receipts-<channel>-merged-turn6.json` is that frozen state; the live files
    (`receipts-<channel>-merged.json`) have since grown the turn-8 recovery batches.
    """
    with open(os.path.join(OUT, f"receipts-{channel}-merged-turn6.json"), encoding="utf-8") as handle:
        return json.load(handle)


def receipts_file(channel, batches=None):
    folder = tempfile.mkdtemp()
    path = os.path.join(folder, f"receipts-{channel}.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(receipts_for(channel) if batches is None else batches, handle)
    return path


def rows_of(db, channel, asof=ASOF):
    """{(code, service day): utc} for one channel over the whole March window."""
    return {(row["code"], row["day"]): row["utc"]
            for row in line.schedule(db, channel, START, END, asof)}


def read(path):
    with open(path, encoding="utf-8", newline="") as handle:
        return handle.read()


def events(text):
    out, row = [], None
    for raw in text.replace("\r\n", "\n").split("\n"):
        name, _, value = raw.partition(":")
        if raw == "BEGIN:VEVENT":
            row = {}
        elif raw == "END:VEVENT":
            out.append(row)
            row = None
        elif row is not None:
            row[name] = value
    return out


# --------------------------------------------------------------------------- #
# the revocation file
# --------------------------------------------------------------------------- #
class RevocationImported(unittest.TestCase):
    def test_both_withdrawals_are_registered_once(self):
        db = fresh()
        rows = db.execute("select id, version, kind, target, channels, start_day, end_day "
                          "from line_order where version=?", (ASOF,)).fetchall()
        self.assertEqual(rows, [("W-11", 7, "revoke", "T-72", "BCD", "2026-03-16", "2026-03-16"),
                                ("W-12", 7, "revoke", "Z-87", "D", "2026-03-23", "2026-03-23")])

    def test_a_withdrawal_does_not_rewrite_what_was_already_published(self):
        db = fresh()
        self.assertEqual(rows_of(db, "B", BEFORE)[("Q29", "2026-03-16")],
                         "2026-03-16T17:00:00+00:00")
        self.assertEqual(rows_of(db, "D", BEFORE)[("U56", "2026-03-23")],
                         "2026-03-23T10:45:00+00:00")
        # before version 6 the window did not exist at all, so B-611 still speaks
        self.assertEqual(rows_of(db, "B", 5)[("Q29", "2026-03-16")],
                         "2026-03-16T16:30:00+00:00")


# --------------------------------------------------------------------------- #
# each channel walks its own chain back
# --------------------------------------------------------------------------- #
class OverrideChain(unittest.TestCase):
    def test_b_falls_back_to_its_own_older_approval(self):
        answer = line.explain(fresh(), "B", "Q29", "2026-03-16", ASOF)
        self.assertEqual((answer["utc"], answer["layer"]["id"]),
                         ("2026-03-16T16:30:00+00:00", "B-611"))
        self.assertEqual([item["status"] for item in answer["candidates"]],
                         ["revoked", "applied"])

    def test_c_and_d_fall_back_to_the_base_clock(self):
        db = fresh()
        self.assertEqual(rows_of(db, "C")[("Q29", "2026-03-16")],
                         "2026-03-16T15:00:00+00:00")
        self.assertEqual(rows_of(db, "D")[("Q29", "2026-03-16")],
                         "2026-03-16T15:00:00+00:00")
        self.assertEqual(line.explain(db, "C", "Q29", "2026-03-16", ASOF)["layer"]["kind"], "base")

    def test_d_falls_back_to_the_older_cross_channel_override(self):
        answer = line.explain(fresh(), "D", "U56", "2026-03-23", ASOF)
        self.assertEqual((answer["utc"], answer["layer"]["id"]),
                         ("2026-03-23T09:15:00+00:00", "Z-213"))
        self.assertEqual([item["status"] for item in answer["candidates"]],
                         ["revoked", "applied"])

    def test_the_channel_not_named_keeps_the_window(self):
        answer = line.explain(fresh(), "A", "Q29", "2026-03-16", ASOF)
        self.assertEqual((answer["utc"], answer["layer"]["id"]),
                         ("2026-03-16T17:00:00+00:00", "T-72"))

    def test_the_day_not_named_keeps_the_window_and_the_override(self):
        db = fresh()
        for channel in "ABCD":
            self.assertEqual(rows_of(db, channel)[("Q29", "2026-03-09")],
                             "2026-03-09T17:00:00+00:00", channel)
        self.assertEqual(rows_of(db, "D")[("U56", "2026-03-16")],
                         "2026-03-16T10:45:00+00:00")
        self.assertEqual(rows_of(db, "B")[("U56", "2026-03-16")],
                         "2026-03-16T10:45:00+00:00")

    def test_only_the_two_withdrawn_cells_move(self):
        db = fresh()
        expected = {"A": set(),
                    "B": {("Q29", "2026-03-16")},
                    "C": {("Q29", "2026-03-16")},
                    "D": {("Q29", "2026-03-16"), ("U56", "2026-03-23")}}
        for channel in "ABCD":
            before, after = rows_of(db, channel, BEFORE), rows_of(db, channel, ASOF)
            self.assertEqual(set(before), set(after), channel)
            self.assertEqual({key for key in after if after[key] != before[key]},
                             expected[channel], channel)
        self.assertEqual(rows_of(db, "A")[("N84", "2026-03-15")],
                         "2026-03-15T13:45:00+00:00")


# --------------------------------------------------------------------------- #
# the receipts the package is measured against
# --------------------------------------------------------------------------- #
class ReceiptState(unittest.TestCase):
    def test_batches_are_applied_in_turn_then_receipt_order(self):
        batches = [
            dict(turn=6, receipt="X-00002", rows={"u": dict(uid="u", utc="2026-03-16T17:00:00Z")}),
            dict(turn=4, receipt="X-00001", rows={"u": dict(uid="u", utc="2026-03-16T15:00:00Z")}),
        ]
        state, applied = line.apply_receipts(batches)
        self.assertEqual(state["u"]["utc"], "2026-03-16T17:00:00Z")
        self.assertEqual([row["receipt"] for row in applied], ["X-00001", "X-00002"])

    def test_the_merge_order_does_not_depend_on_the_file_order(self):
        first = line.apply_receipts(receipts_for("D"))[0]
        second = line.apply_receipts(list(reversed(receipts_for("D"))))[0]
        self.assertEqual(first, second)

    def test_the_merged_receipts_hold_what_was_really_delivered(self):
        for channel in "ABCD":
            state, applied = line.apply_receipts(receipts_for(channel))
            self.assertEqual(len(state), RECEIVED[channel][1], channel)
            self.assertEqual([row["turn"] for row in applied], [4, 6], channel)
            for uid, utc in RECEIVED[channel][0].items():
                self.assertEqual(line._instant(state[uid]["utc"]), line._instant(utc), uid)

    def test_a_channel_can_be_picked_out_of_a_multi_channel_file(self):
        path = os.path.join(OUT, "receipts-merged-turn6.json")
        with open(path, encoding="utf-8") as handle:
            everything = json.load(handle)
        self.assertEqual(line.load_receipts(path, "C")[0],
                         line.apply_receipts(everything["C"])[0])
        with self.assertRaises(ValueError):
            line.load_receipts(path)
        with self.assertRaises(ValueError):
            line.load_receipts(path, "Z")


# --------------------------------------------------------------------------- #
# the pending package
# --------------------------------------------------------------------------- #
class PendingPackage(unittest.TestCase):
    def test_each_channel_gets_exactly_its_own_delta(self):
        db = fresh()
        for channel in "ABCD":
            target = os.path.join(tempfile.mkdtemp(), f"plan-{channel}.ics")
            summary = line.delta(db, channel, START, END, ASOF,
                                 receipts_file(channel), target, stamp=STAMP)
            got = [(event["UID"], event["DTSTART"]) for event in events(read(target))]
            self.assertEqual(got, [(uid, now.replace("-", "").replace(":", ""))
                                   for uid, _, now in PENDING[channel]], channel)
            self.assertEqual(summary["events"], len(PENDING[channel]), channel)
            self.assertEqual(summary["empty"], not PENDING[channel], channel)

    def test_an_empty_package_is_written_and_stays_valid(self):
        db = fresh()
        target = os.path.join(tempfile.mkdtemp(), "plan-A.ics")
        summary = line.delta(db, "A", START, END, ASOF, receipts_file("A"), target, stamp=STAMP)
        self.assertTrue(summary["empty"])
        text = read(target)
        self.assertEqual(events(text), [])
        self.assertTrue(text.startswith("BEGIN:VCALENDAR"))
        self.assertTrue(text.rstrip().endswith("END:VCALENDAR"))

    def test_a_changed_event_bumps_the_sequence_of_the_same_uid(self):
        db = fresh()
        line.feed_rows(db, "D", START, END, 3, stamp="20260323T000000Z")   # what turn 4 sent
        line.feed_rows(db, "D", START, END, BEFORE, stamp=STAMP)          # what turn 6 sent
        target = os.path.join(tempfile.mkdtemp(), "plan-D.ics")
        line.delta(db, "D", START, END, ASOF, receipts_file("D"), target, stamp=STAMP)
        rows = {event["UID"]: event for event in events(read(target))}
        self.assertEqual(set(rows), {"Q29-20260316", "U56-20260323"})
        for event in rows.values():
            self.assertEqual(event["SEQUENCE"], "2")
            self.assertEqual(event["STATUS"], "CONFIRMED")

    def test_a_subscriber_already_in_step_gets_nothing(self):
        db = fresh()
        folder = tempfile.mkdtemp()
        first = os.path.join(folder, "one.ics")
        line.delta(db, "B", START, END, ASOF, receipts_file("B"), first, stamp=STAMP)
        # Feed the pending package back in as a receipt: nothing may be left over.
        batches = receipts_for("B") + [dict(turn=7, receipt="B-00003",
                                            rows={"line-402-20260316": dict(
                                                uid="line-402-20260316",
                                                utc="2026-03-16T16:30:00Z")})]
        second = os.path.join(folder, "two.ics")
        summary = line.delta(db, "B", START, END, ASOF,
                             receipts_file("B", batches), second, stamp=STAMP)
        self.assertTrue(summary["empty"], summary)
        self.assertEqual(events(read(second)), [])

    def test_the_same_instant_written_differently_is_not_a_delta(self):
        db = fresh()
        batches = receipts_for("B")
        for row in batches[1]["rows"].values():
            row["utc"] = row["utc"].replace("Z", "+00:00")
        batches[1]["rows"]["line-402-20260316"]["utc"] = "2026-03-16T16:30:00+00:00"
        summary = line.delta(db, "B", START, END, ASOF, receipts_file("B", batches),
                             os.path.join(tempfile.mkdtemp(), "plan-B.ics"), stamp=STAMP)
        self.assertTrue(summary["empty"])

    def test_a_received_event_that_is_gone_is_reported_but_not_packaged(self):
        db = fresh()
        batches = receipts_for("C")
        batches[1]["rows"]["GONE-20260316"] = dict(uid="GONE-20260316",
                                                   utc="2026-03-16T08:00:00Z",
                                                   status="CONFIRMED")
        summary = line.delta(db, "C", START, END, ASOF, receipts_file("C", batches),
                             os.path.join(tempfile.mkdtemp(), "plan-C.ics"), stamp=STAMP)
        self.assertEqual([row["uid"] for row in summary["withdrawn"]], ["GONE-20260316"])
        self.assertEqual(summary["uids"], ["line-402-20260316"])

    def test_the_pending_package_rebuilds_byte_for_byte(self):
        db = fresh()
        folder = tempfile.mkdtemp()
        first = os.path.join(folder, "one.ics")
        second = os.path.join(folder, "two.ics")
        line.delta(db, "D", START, END, ASOF, receipts_file("D"), first, stamp=STAMP)
        line.delta(db, "D", START, END, ASOF, receipts_file("D"), second, stamp=STAMP)
        self.assertEqual(read(first), read(second))

    def test_the_delivered_plan_files_are_the_programs_output(self):
        db = live_copy()
        for channel in "ABCD":
            target = os.path.join(tempfile.mkdtemp(), f"plan-{channel}.ics")
            line.delta(db, channel, START, END, ASOF, receipts_file(channel), target, stamp=STAMP)
            self.assertEqual(read(target), read(os.path.join(OUT, f"plan-{channel}.ics")), channel)


# --------------------------------------------------------------------------- #
# the portal shows the withdrawn chain too
# --------------------------------------------------------------------------- #
class PortalReflects(unittest.TestCase):
    def test_v2_defaults_to_the_revoked_schedule(self):
        db = live_copy()
        rows = json.loads(portal.v2_json(db, dict(channel="D", **{"from": "2026-03-16", "to": "2026-03-23"})))
        self.assertEqual([(row["code"], row["day"], row["utc"]) for row in rows
                          if row["code"] in ("Q29", "U56")],
                         [("Q29", "2026-03-16", "2026-03-16T15:00:00+00:00"),
                          ("U56", "2026-03-16", "2026-03-16T10:45:00+00:00"),
                          ("Q29", "2026-03-23", "2026-03-23T15:00:00+00:00"),
                          ("U56", "2026-03-23", "2026-03-23T09:15:00+00:00")])

    def test_when_explains_the_fallback(self):
        db = live_copy()
        answer = json.loads(portal.when_json(db, dict(channel="C", code="Q29", day="2026-03-16")))
        self.assertEqual((answer["utc"], answer["layer"]["kind"]),
                         ("2026-03-16T15:00:00+00:00", "base"))
        self.assertEqual([item["status"] for item in answer["candidates"]], ["revoked"])

    def test_the_old_portal_is_still_untouched(self):
        db = live_copy()
        self.assertEqual(db.execute("select count(*) from events").fetchone()[0], 4)
        self.assertEqual(db.execute("select count(*) from bookings").fetchone()[0], 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
