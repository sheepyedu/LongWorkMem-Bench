"""Version 8: the queue broke off, two single-item batches timed out, recover.

Run: python3 project/test_resume.py

`input/interruption.json` says C and D each had one item attempted under the key
`<channel>-resume-08` and the transport timed out.  A timeout is not an outcome:
the only way to decide is to read the real receipts.  Here C's batch did land
(receipt C-00003) while D's did not, so C is left alone and D's item is retried
under its original key -- same key, same semantics, no second notification --
while the remaining deltas (B, and D's other item) go out as new batches.

Everything after that must be re-runnable: a reconciliation that only reads, and
a delta entry that yields empty packages once the channels are in step.
"""
import hashlib
import json
import os
import shutil
import sqlite3
import tempfile
import unittest

import line

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
LIVE = os.path.join(ROOT, "data", "portal.sqlite")
OUT = os.path.join(ROOT, "out")
STAMP = "20260330T000000Z"
START, END, ASOF = "2026-03-02", "2026-03-23", 7

BEFORE = {channel: os.path.join(OUT, f"receipts-{channel}-merged-before8.json") for channel in "ABCD"}
AFTER = {channel: os.path.join(OUT, f"receipts-{channel}-merged.json") for channel in "ABCD"}
MERGED_BEFORE = os.path.join(OUT, "receipts-merged-before8.json")
MERGED_AFTER = os.path.join(OUT, "receipts-merged.json")

# What the receipts said before recovery, per channel.
BEFORE_PENDING = {
    "A": [],
    "B": ["line-402-20260316"],
    "C": [],
    "D": ["Q29-20260316", "U56-20260323"],
}
# The recovery packages, and the receipts each one really got.
RECOVERY = [
    ("B", "resume8-B-line-402-20260316.ics", "B-remend8-20260302-20260323-86ba1786", "B-00003",
     ["line-402-20260316"]),
    ("D", "resume8-D-Q29-20260316.ics", "D-resume-08", "D-00003", ["Q29-20260316"]),
    ("D", "resume8-D-U56-20260323.ics", "D-remend8-20260302-20260323-7d464e4f", "D-00004",
     ["U56-20260323"]),
]


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def live_copy():
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(LIVE, path)
    return path, line.ensure_schema(sqlite3.connect(path))


def read(path):
    with open(path, encoding="utf-8", newline="") as handle:
        return handle.read()


def outdir():
    return tempfile.mkdtemp()


def events(text):
    out, row = [], None
    for raw in text.replace("\r\n", "\n").split("\n"):
        name, _, value = raw.partition(":")
        if raw == "BEGIN:VEVENT":
            row = {}
        elif raw == "END:VEVENT":
            out.append(row)
            row = None
        elif row is not None:
            row[name] = value
    return out


def receipts_copy(source, channel, mutate=None):
    """One channel's batches out of a merged receipts file, optionally edited."""
    with open(source, encoding="utf-8") as handle:
        data = json.load(handle)
    batches = data[channel]
    if mutate:
        mutate(batches)
    path = os.path.join(outdir(), f"receipts-{channel}.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump({channel: batches}, handle)
    return path


# --------------------------------------------------------------------------- #
# the triage: what the real receipts say
# --------------------------------------------------------------------------- #
class Interruption(unittest.TestCase):
    def test_a_timeout_does_not_mean_it_failed(self):
        state, _ = line.apply_receipts(json.load(open(os.path.join(OUT, "receipts-online-08.json")))["C"])
        self.assertEqual(line._instant(state["line-402-20260316"]["utc"]),
                         line._instant("2026-03-16T15:00:00Z"))

    def test_the_channel_whose_batch_landed_needs_nothing(self):
        db = live_copy()[1]
        report = line.reconcile(db, START, END, ASOF, [MERGED_BEFORE])
        verdict = {row["channel"]: (row["in_step"], [item["uid"] for item in row["pending"]])
                   for row in report["channels"]}
        self.assertEqual(verdict["C"], (True, []))
        self.assertEqual(verdict["A"], (True, []))

    def test_the_channel_whose_batch_was_lost_still_owes_it(self):
        db = live_copy()[1]
        report = line.reconcile(db, START, END, ASOF, [MERGED_BEFORE])
        verdict = {row["channel"]: [item["uid"] for item in row["pending"]]
                   for row in report["channels"]}
        self.assertEqual(verdict["B"], BEFORE_PENDING["B"])
        self.assertEqual(verdict["D"], BEFORE_PENDING["D"])

    def test_the_retried_item_carries_its_original_key(self):
        record = json.load(open(os.path.join(OUT, "resume8-delivery.json")))
        keys = {(row["channel"], row["uid"]): row for row in record["interruption"]}
        self.assertFalse(keys[("D", "Q29-20260316")]["landed_before"])
        self.assertEqual(keys[("D", "Q29-20260316")]["key"], "D-resume-08")
        self.assertTrue(keys[("C", "line-402-20260316")]["landed_before"])
        self.assertEqual(record["notifications"]["retried_keys"], ["D-resume-08"])
        self.assertNotIn("D-resume-08", record["notifications"]["new_keys"])


# --------------------------------------------------------------------------- #
# reconciliation is read-only and re-runnable
# --------------------------------------------------------------------------- #
class Reconciliation(unittest.TestCase):
    def test_reconciliation_does_not_touch_the_database(self):
        path, db = live_copy()
        before = hashlib.sha256(open(path, "rb").read()).hexdigest()
        feed = db.execute("select count(*), sum(sequence) from line_feed").fetchone()
        line.reconcile(db, START, END, ASOF, [MERGED_BEFORE])
        line.reconcile(db, START, END, ASOF, [MERGED_AFTER])
        self.assertEqual(hashlib.sha256(open(path, "rb").read()).hexdigest(), before)
        self.assertEqual(db.execute("select count(*), sum(sequence) from line_feed").fetchone(), feed)

    def test_two_files_for_one_channel_are_merged(self):
        db = live_copy()[1]
        report = line.reconcile(db, START, END, ASOF, [BEFORE["B"], AFTER["B"]])
        channel = [row for row in report["channels"] if row["channel"] == "B"][0]
        self.assertTrue(channel["in_step"])

    def test_a_missing_session_is_reported(self):
        db = live_copy()[1]
        # a session that turn 4 sent and no later batch touched
        path = receipts_copy(MERGED_AFTER, "B",
                             lambda batches: batches[0]["rows"].pop("line-404-20260302"))
        report = line.reconcile(db, START, END, ASOF, [path])
        channel = [row for row in report["channels"] if row["channel"] == "B"][0]
        self.assertEqual([item["uid"] for item in channel["missing"]], ["line-404-20260302"])
        self.assertFalse(channel["in_step"])

    def test_a_uid_the_schedule_no_longer_has_is_reported(self):
        db = live_copy()[1]

        def extra(batches):
            batches[-1]["rows"]["GONE-20260316"] = dict(uid="GONE-20260316",
                                                        utc="2026-03-16T08:00:00Z",
                                                        status="CONFIRMED")

        path = receipts_copy(MERGED_AFTER, "D", extra)
        report = line.reconcile(db, START, END, ASOF, [path])
        channel = [row for row in report["channels"] if row["channel"] == "D"][0]
        self.assertEqual([item["uid"] for item in channel["extra"]], ["GONE-20260316"])
        self.assertFalse(report["in_step"])

    def test_the_channel_can_be_read_from_a_file_name(self):
        self.assertEqual(line.channel_of("receipts-C-merged.json"), "C")
        self.assertEqual(line.channel_of("/tmp/receipts-D.json"), "D")
        self.assertIsNone(line.channel_of("all-at-once.json"))

    def test_every_channel_is_in_step_after_the_recovery(self):
        db = live_copy()[1]
        report = line.reconcile(db, START, END, ASOF, [MERGED_AFTER])
        self.assertTrue(report["in_step"], report)
        for row in report["channels"]:
            self.assertEqual((row["scheduled"], row["received"]), (16, 16), row["channel"])


# --------------------------------------------------------------------------- #
# the delta entry is re-runnable
# --------------------------------------------------------------------------- #
class DeltaEntry(unittest.TestCase):
    def test_the_recovery_packages_rebuild_from_the_program(self):
        db = live_copy()[1]
        for channel, name, _key, _receipt, uids in RECOVERY:
            target = os.path.join(outdir(), name)
            summary = line.delta(db, channel, START, END, ASOF, BEFORE[channel], target,
                                 stamp=STAMP, only=uids)
            self.assertEqual(summary["uids"], uids)
            self.assertEqual(read(target), read(os.path.join(OUT, name)), name)

    def test_a_channel_in_step_yields_an_empty_package(self):
        db = live_copy()[1]
        for channel in "ABCD":
            target = os.path.join(outdir(), f"plan-{channel}.ics")
            summary = line.delta(db, channel, START, END, ASOF, AFTER[channel], target,
                                 stamp=STAMP)
            self.assertTrue(summary["empty"], channel)
            self.assertEqual(events(read(target)), [])

    def test_running_twice_gives_the_same_bytes(self):
        db = live_copy()[1]
        folder = outdir()
        first, second = os.path.join(folder, "1.ics"), os.path.join(folder, "2.ics")
        for target in (first, second):
            line.delta(db, "B", START, END, ASOF, BEFORE["B"], target, stamp=STAMP)
        self.assertEqual(read(first), read(second))

    def test_only_restricts_the_package_but_not_the_bookkeeping(self):
        db = live_copy()[1]
        target = os.path.join(outdir(), "only.ics")
        summary = line.delta(db, "D", START, END, ASOF, BEFORE["D"], target,
                             stamp=STAMP, only=["U56-20260323"])
        self.assertEqual(summary["uids"], ["U56-20260323"])
        self.assertEqual([event["UID"] for event in events(read(target))], ["U56-20260323"])

    def test_an_only_uid_that_is_not_pending_produces_nothing(self):
        db = live_copy()[1]
        target = os.path.join(outdir(), "none.ics")
        summary = line.delta(db, "D", START, END, ASOF, AFTER["D"], target,
                             stamp=STAMP, only=["U56-20260323"])
        self.assertTrue(summary["empty"])
        self.assertEqual(events(read(target)), [])

    def test_every_delivered_item_is_confirmed_on_the_wire(self):
        receipts = json.load(open(os.path.join(OUT, "receipts-online-08-after.json")))
        for channel, _name, key, receipt, uids in RECOVERY:
            batch = [row for row in receipts[channel] if row["key"] == key][0]
            self.assertEqual(batch["receipt"], receipt)
            self.assertEqual(sorted(batch["rows"]), uids)
            for row in batch["rows"].values():
                self.assertEqual(row["status"], "CONFIRMED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
