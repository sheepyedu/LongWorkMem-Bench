"""Support look-ups: read-only answers, venue-local time, archive cross-check.

Run: python3 project/test_support.py

The desk needs one thing: what a venue actually sees for a session, and whether
that agrees with what was delivered (the batches are now in input/vault, read
through its index).  The entry point must be read-only and must not notify
anybody.
"""
import hashlib
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

import line
import portal
import support

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
LIVE = os.path.join(ROOT, "data", "portal.sqlite")
INDEX = os.path.join(INPUT, "vault", "index.json")
QUESTIONS = os.path.join(INPUT, "support.json")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def live_copy():
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(LIVE, path)
    return portal.ensure_schema(sqlite3.connect(path)), path


def memory(*orders):
    db = line.ensure_schema(sqlite3.connect(":memory:"))
    line.import_dir(db, INPUT)
    for index, rows in enumerate(orders):
        folder = tempfile.mkdtemp()
        shutil.copyfile(os.path.join(INPUT, "portfolio.json"), os.path.join(folder, "portfolio.json"))
        shutil.copyfile(os.path.join(INPUT, "identities.json"), os.path.join(folder, "identities.json"))
        os.makedirs(os.path.join(folder, "orders"))
        with open(os.path.join(folder, "orders", f"o{index}.json"), "w", encoding="utf-8") as handle:
            json.dump(dict(version=2 + index, rows=rows), handle)
        line.import_dir(db, folder)
    return db


def approval(oid, code, channels="A", start="2026-01-01", end="2026-12-31",
             rank=1, clock="16:30", basis="utc", shift=0):
    return dict(id=oid, code=code, channels=channels, start=start, end=end,
                rank=rank, clock=clock, basis=basis, shift_days=shift)


def revoke(oid, target, channels="A", start="2026-01-01", end="2026-12-31"):
    return dict(id=oid, target=target, channels=channels, start=start, end=end)


def sha(path):
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def vault(batches, extra_index=None):
    """A throw-away archive: index.json next to the batch files."""
    folder = tempfile.mkdtemp()
    os.makedirs(os.path.join(folder, "vault"), exist_ok=True)
    index = dict(extra_index or {})
    for channel, payload in batches.items():
        name = f"{channel}-batch.json"
        with open(os.path.join(folder, "vault", name), "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
        index[channel] = name
    path = os.path.join(folder, "vault", "index.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(index, handle)
    return path


# --------------------------------------------------------------------------- #
# the answer itself
# --------------------------------------------------------------------------- #
class VenueTime(unittest.TestCase):
    def setUp(self):
        self.db, self.path = live_copy()

    def tearDown(self):
        self.db.close()

    def test_base_layer_on_the_legacy_named_channels(self):
        for channel in ("A", "D"):
            answer = line.explain(self.db, channel, "Q29", "2026-03-16", 4)
            self.assertEqual(answer["local"], "2026-03-16 15:00 GMT")
            self.assertEqual(answer["utc"], "2026-03-16T15:00:00+00:00")
            self.assertEqual(answer["zone"], "Europe/London")
            self.assertEqual(answer["uid"], "Q29-20260316")
            self.assertEqual(answer["layer"]["kind"], "base")
            self.assertEqual(answer["candidates"], [])

    def test_approval_layer_on_the_partner_named_channels(self):
        answer = line.explain(self.db, "B", "Q29", "2026-03-16", 4)
        self.assertEqual(answer["local"], "2026-03-16 16:30 GMT")
        self.assertEqual(answer["uid"], "line-402-20260316")
        self.assertEqual(answer["layer"], dict(kind="approval", id="B-611", version=2, rank=2,
                                               shift_days=0))
        self.assertEqual([row["status"] for row in answer["candidates"]], ["applied"])
        # C is a different channel: the same approval does not reach it
        self.assertEqual(line.explain(self.db, "C", "Q29", "2026-03-16", 4)["layer"]["kind"], "base")

    def test_asof_picks_the_layer_that_was_known_then(self):
        older = line.explain(self.db, "B", "Q29", "2026-03-16", 1)
        newer = line.explain(self.db, "B", "Q29", "2026-03-16", 4)
        self.assertEqual(older["local"], "2026-03-16 15:00 GMT")
        self.assertEqual(older["layer"]["kind"], "base")
        self.assertEqual(older["uid"], newer["uid"])
        self.assertEqual(newer["local"], "2026-03-16 16:30 GMT")

    def test_london_summer_time_is_the_venue_clock(self):
        summer = line.explain(self.db, "A", "Q29", "2026-04-06", 4)
        self.assertEqual(summer["utc"], "2026-04-06T15:00:00+00:00")
        self.assertEqual(summer["local"], "2026-04-06 16:00 BST")

    def test_wall_clock_venues(self):
        berlin = line.explain(self.db, "A", "U56", "2026-03-16", 4)
        self.assertEqual(berlin["local"], "2026-03-16 08:20 CET")
        new_york = line.explain(self.db, "A", "N84", "2026-03-16", 4)
        self.assertEqual(new_york["local"], "2026-03-16 09:45 EDT")

    def test_a_day_without_a_session_has_no_answer(self):
        self.assertIsNone(line.explain(self.db, "A", "Q29", "2026-03-17", 4))   # Tuesday
        self.assertIsNone(line.explain(self.db, "A", "NOPE", "2026-03-16", 4))
        self.assertIsNone(line.explain(self.db, "A", "Q29", "2026-02-23", 4))   # before the base start

    def test_shifted_session_keeps_its_identity(self):
        db = memory([approval("S-1", "Q29", "A", start="2026-03-16", end="2026-03-16",
                              rank=5, clock="18:00", shift=2)])
        answer = line.explain(db, "A", "Q29", "2026-03-16", 2)
        self.assertEqual(answer["original_day"], "2026-03-16")
        self.assertEqual(answer["day"], "2026-03-18")
        self.assertEqual(answer["uid"], "Q29-20260316")
        self.assertEqual(answer["local"], "2026-03-18 18:00 GMT")
        db.close()

    def test_revoked_and_outranked_layers_are_explained(self):
        db = memory([approval("LOW-1", "Q29", "A", start="2026-03-16", end="2026-03-16",
                              rank=1, clock="17:00"),
                     approval("HIGH-1", "Q29", "A", start="2026-03-16", end="2026-03-16",
                              rank=9, clock="19:00")],
                    [revoke("REV-9", "HIGH-1", "A", start="2026-03-16", end="2026-03-16")])
        answer = line.explain(db, "A", "Q29", "2026-03-16", 3)
        status = {row["id"]: row["status"] for row in answer["candidates"]}
        self.assertEqual(status, {"HIGH-1": "revoked", "LOW-1": "applied"})
        self.assertEqual(answer["layer"]["id"], "LOW-1")
        self.assertEqual(answer["local"], "2026-03-16 17:00 GMT")
        db.close()


# --------------------------------------------------------------------------- #
# the entry point
# --------------------------------------------------------------------------- #
class ApiWhen(unittest.TestCase):
    def setUp(self):
        self.db, self.path = live_copy()

    def tearDown(self):
        self.db.close()

    def when(self, query):
        return json.loads(portal.route(self.db, "/api/when?" + query)[1])

    def test_found_shape(self):
        answer = self.when("channel=B&code=Q29&day=2026-03-16&asof=4")
        self.assertTrue(answer["found"])
        for key in ("code", "channel", "day", "original_day", "uid", "asof", "zone",
                    "clock", "basis", "utc", "local", "layer", "candidates"):
            self.assertIn(key, answer)
        self.assertEqual(answer["local"], "2026-03-16 16:30 GMT")

    def test_missing_session_is_an_answer_not_an_error(self):
        answer = self.when("channel=A&code=Q29&day=2026-03-17&asof=4")
        self.assertFalse(answer["found"])
        self.assertIn("reason", answer)

    def test_asof_defaults_to_the_latest_registered_version(self):
        self.assertEqual(self.when("channel=B&code=Q29&day=2026-03-16"),
                         self.when(f"channel=B&code=Q29&day=2026-03-16&asof={line.latest_version(self.db)}"))

    def test_bad_parameters_are_rejected(self):
        for query in ("channel=AB&code=Q29&day=2026-03-16", "channel=A&code=Q29&day=nope",
                      "channel=A&code=&day=2026-03-16", "channel=A&code=Q29&day=2026-03-16&asof=x"):
            with self.assertRaises(ValueError):
                portal.route(self.db, "/api/when?" + query)

    def test_the_entry_point_writes_nothing(self):
        before = sha(self.path)
        feeds = self.db.execute("select count(*) from line_feed").fetchone()[0]
        for channel in "ABCD":
            self.when(f"channel={channel}&code=Q29&day=2026-03-16&asof=4")
        self.db.commit()
        self.assertEqual(sha(self.path), before)
        self.assertEqual(self.db.execute("select count(*) from line_feed").fetchone()[0], feeds)


class HttpWhen(unittest.TestCase):
    """The deployed server, over real loopback HTTP."""

    @classmethod
    def setUpClass(cls):
        cls.path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        shutil.copyfile(LIVE, cls.path)
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            cls.port = probe.getsockname()[1]
        cls.server = subprocess.Popen(
            [sys.executable, os.path.join(ROOT, "project", "portal.py"), "serve", str(cls.port)],
            env=dict(os.environ, PORTAL_DB=cls.path), stderr=subprocess.DEVNULL)
        for _ in range(120):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{cls.port}/", timeout=1).read()
                return
            except urllib.error.URLError:
                if cls.server.poll() is not None:
                    raise
                time.sleep(0.025)
        raise RuntimeError("portal did not start")

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.wait()

    def get(self, path):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{self.port}{path}", timeout=5) as response:
                return response.status, response.read().decode()
        except urllib.error.HTTPError as problem:
            return problem.code, problem.read().decode()

    def test_over_http(self):
        status, body = self.get("/api/when?channel=B&code=Q29&day=2026-03-16&asof=4")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["local"], "2026-03-16 16:30 GMT")

    def test_bad_channel_is_a_400_and_old_routes_still_work(self):
        self.assertEqual(self.get("/api/when?channel=AB&code=Q29&day=2026-03-16")[0], 400)
        self.assertEqual(self.get("/api/v2?channel=A&from=2026-03-16&to=2026-03-16")[0], 200)
        self.assertEqual(self.get("/api/events?channel=A&from=2026-03-06&to=2026-03-27")[0], 200)


# --------------------------------------------------------------------------- #
# the preview handed to the desk
# --------------------------------------------------------------------------- #
class Preview(unittest.TestCase):
    def setUp(self):
        self.db, self.path = live_copy()

    def tearDown(self):
        self.db.close()

    def test_answers_every_question_in_support_json(self):
        questions = support.load_questions(QUESTIONS)
        result, problems = support.preview(self.db, questions, INDEX, db_path=self.path)
        self.assertEqual(problems, [])
        self.assertEqual(result["totals"], dict(asked=4, answered=4, archive_agrees=4, problems=0))
        self.assertTrue(result["read_only"])
        self.assertFalse(result["published"])
        asked = [(entry["asked"]["channel"], entry["asked"]["code"], entry["asked"]["day"])
                 for entry in result["entries"]]
        self.assertEqual(asked, [("A", "Q29", "2026-03-16"), ("B", "Q29", "2026-03-16"),
                                 ("C", "Q29", "2026-03-16"), ("D", "Q29", "2026-03-16")])
        for entry in result["entries"]:
            self.assertTrue(entry["agree"])
            self.assertEqual(entry["archive"]["status"], "CONFIRMED")

    def test_preview_matches_the_archived_delivery(self):
        result, _ = support.preview(self.db, support.load_questions(QUESTIONS), INDEX, db_path=self.path)
        for entry in result["entries"]:
            self.assertEqual(support.instant(entry["archive"]["utc"]),
                             support.instant(entry["answer"]["utc"]))

    def test_a_disagreeing_archive_is_flagged(self):
        batches = {channel: [dict(turn=4, key=f"{channel}-k", receipt=f"{channel}-00009",
                                  rows={"Q29-20260316": dict(uid="Q29-20260316",
                                                             utc="2026-03-16T14:00:00Z",
                                                             status="CONFIRMED")})]
                   for channel in "ABCD"}
        index = vault(batches)
        questions = [dict(channel="A", code="Q29", day="2026-03-16", asof=4)]
        result, problems = support.preview(self.db, questions, index, db_path=self.path)
        self.assertEqual(len(problems), 1)
        self.assertFalse(result["entries"][0]["agree"])
        self.assertIn("2026-03-16T14:00:00Z", result["entries"][0]["note"])

    def test_a_uid_missing_from_the_archive_is_flagged(self):
        index = vault({"A": [dict(turn=4, key="A-k", receipt="A-00009", rows={})]})
        result, problems = support.preview(self.db, [dict(channel="A", code="Q29", day="2026-03-16", asof=4)],
                                           index, db_path=self.path)
        self.assertEqual(len(problems), 1)
        self.assertIsNone(result["entries"][0]["archive"])
        self.assertIn("无法与已投递资料核对", result["entries"][0]["note"])

    def test_a_channel_without_an_archive_entry_is_flagged(self):
        index = vault({"A": [dict(turn=4, key="A-k", receipt="A-00009", rows={})]},
                      extra_index={})
        result, problems = support.preview(self.db, [dict(channel="C", code="Q29", day="2026-03-16", asof=4)],
                                           index, db_path=self.path)
        self.assertEqual(len(problems), 1)
        self.assertIsNone(result["entries"][0]["archive"])

    def test_a_day_without_a_session_is_flagged(self):
        result, problems = support.preview(self.db, [dict(channel="A", code="Q29", day="2026-03-17", asof=4)],
                                           INDEX, db_path=self.path)
        self.assertEqual(len(problems), 1)
        self.assertIsNone(result["entries"][0]["answer"])

    def test_preview_writes_nothing_and_publishes_nothing(self):
        before = sha(self.path)
        result, _ = support.preview(self.db, support.load_questions(QUESTIONS), INDEX, db_path=self.path)
        support.render_markdown(result, QUESTIONS)
        self.assertEqual(sha(self.path), before)
        self.assertFalse(hasattr(support, "publish"))

    def test_markdown_is_quotable(self):
        result, _ = support.preview(self.db, support.load_questions(QUESTIONS), INDEX, db_path=self.path)
        text = support.render_markdown(result, "input/support.json")
        self.assertIn("未通知客户", text)
        self.assertIn("2026-03-16 16:30 GMT", text)
        self.assertIn("`line-402-20260316`", text)
        self.assertIn("B-611", text)
        self.assertIn("一致", text)


class CommandLine(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.dir, "portal.sqlite")
        shutil.copyfile(LIVE, self.db_path)
        self.env = dict(os.environ, PORTAL_DB=self.db_path)

    def run_support(self, *args):
        return subprocess.run([sys.executable, os.path.join(ROOT, "project", "support.py")] + list(args),
                              cwd=ROOT, env=self.env, capture_output=True, text=True)

    def test_preview_writes_json_and_markdown(self):
        json_path = os.path.join(self.dir, "preview.json")
        md_path = os.path.join(self.dir, "preview.md")
        result = self.run_support("preview", QUESTIONS, "--index", INDEX,
                                  "--json", json_path, "--markdown", md_path)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["archive_agrees"], 4)
        self.assertTrue(os.path.exists(json_path) and os.path.exists(md_path))
        with open(json_path, encoding="utf-8") as handle:
            stored = json.load(handle)
        self.assertFalse(stored["published"])
        self.assertEqual(stored["database_sha256"], sha(self.db_path))

    def test_a_disagreeing_archive_exits_two(self):
        index = vault({"A": [dict(turn=4, key="A-k", receipt="A-00009",
                                  rows={"Q29-20260316": dict(uid="Q29-20260316",
                                                             utc="2026-03-16T14:00:00Z",
                                                             status="CONFIRMED")})]})
        questions = os.path.join(self.dir, "q.json")
        with open(questions, "w", encoding="utf-8") as handle:
            json.dump([dict(channel="A", code="Q29", day="2026-03-16", asof=4)], handle)
        result = self.run_support("preview", questions, "--index", index)
        self.assertEqual(result.returncode, 2)
        self.assertIn("不一致", result.stderr)

    def test_bad_questions_file_exits_two(self):
        result = self.run_support("preview", os.path.join(self.dir, "nope.json"))
        self.assertEqual(result.returncode, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
