"""Dual-version launch: identity registry, GET /api/v2, and V1 coexistence.

Run: python3 project/test_v2.py

Contract (input/contracts/interfaces.md): re-running `import` also migrates
identities.json, the wire prefix is looked up per code/channel and
UID = prefix-原定日YYYYMMDD; GET /api/v2?channel=&from=&to=&asof= answers JSON
rows of code, day, utc, uid while the old API keeps working; the service must
not read input/ at request time; and the new migration may not rewrite an old
UID or an existing booking.
"""
import builtins
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

import line
import portal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
LIVE = os.path.join(ROOT, "data", "portal.sqlite")
IDENTITIES = os.path.join(INPUT, "identities.json")
PORTFOLIO = os.path.join(INPUT, "portfolio.json")

DAY = "2026-03-30"


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def memory():
    return line.ensure_schema(sqlite3.connect(":memory:"))


def input_dir(identities="file", orders=None):
    """A throw-away INPUT_DIR holding the real portfolio and a chosen registry."""
    folder = tempfile.mkdtemp()
    shutil.copyfile(PORTFOLIO, os.path.join(folder, "portfolio.json"))
    os.makedirs(os.path.join(folder, "orders"))
    if identities == "file":
        shutil.copyfile(IDENTITIES, os.path.join(folder, "identities.json"))
    elif identities is not None:
        with open(os.path.join(folder, "identities.json"), "w", encoding="utf-8") as handle:
            json.dump(identities, handle)
    for name, batch in (orders or {}).items():
        with open(os.path.join(folder, "orders", name), "w", encoding="utf-8") as handle:
            json.dump(batch, handle)
    return folder


def approval(oid, code, channels="A", start="2026-01-01", end="2026-12-31",
             rank=1, clock="16:30", basis="utc", shift=0, version=None):
    row = dict(id=oid, code=code, channels=channels, start=start, end=end,
               rank=rank, clock=clock, basis=basis, shift_days=shift)
    if version is not None:
        row["version"] = version
    return row


def batch(version, *rows):
    return dict(version=version, rows=list(rows))


def loaded(*batches):
    """In-memory line database imported from the real portfolio + registry."""
    db = memory()
    orders = {f"ops-{i}.json": b for i, b in enumerate(batches)}
    line.import_dir(db, input_dir(orders=orders))
    return db


def api(db, url):
    return json.loads(portal.route(db, url)[1])


def v2(db, channel, start=DAY, end=DAY, asof=None):
    url = f"/api/v2?channel={channel}&from={start}&to={end}"
    if asof is not None:
        url += f"&asof={asof}"
    return api(db, url)


def live_copy():
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(LIVE, path)
    return portal.ensure_schema(sqlite3.connect(path)), path


# --------------------------------------------------------------------------- #
# identity registry
# --------------------------------------------------------------------------- #
class IdentityMigration(unittest.TestCase):
    def test_import_migrates_the_registry(self):
        db = memory()
        report = line.import_dir(db, input_dir())
        rows = db.execute("select code,channel,prefix from line_identity").fetchall()
        self.assertEqual(len(rows), 16)
        self.assertEqual({entry["action"] for entry in report["identities"]}, {"imported"})
        stored = {(code, channel): prefix for code, channel, prefix in rows}
        with open(IDENTITIES, encoding="utf-8") as handle:
            registered = json.load(handle)
        for code, channels in registered.items():
            for channel, prefix in channels.items():
                self.assertEqual(stored[(code, channel)], prefix)

    def test_reimport_is_a_no_op(self):
        folder = input_dir()
        db = memory()
        line.import_dir(db, folder)
        before = db.execute("select code,channel,prefix from line_identity order by 1,2").fetchall()
        report = line.import_dir(db, folder)
        after = db.execute("select code,channel,prefix from line_identity order by 1,2").fetchall()
        self.assertEqual(before, after)
        self.assertEqual({row["action"] for row in report["identities"]}, {"unchanged"})

    def test_changed_prefix_is_reported_and_applied(self):
        db = memory()
        line.import_dir(db, input_dir())
        folder = input_dir({"N84": {"B": "line-901"}})
        report = line.import_dir(db, folder)
        actions = {(r["code"], r["channel"]): r["action"] for r in report["identities"]}
        self.assertEqual(actions[("N84", "B")], "updated")
        self.assertEqual(line.prefix_for(db, "N84", "B"), "line-901")
        # a partial registry only speaks about its own entries; the rest stay put
        self.assertEqual(line.prefix_for(db, "N84", "A"), "N84")
        self.assertEqual(db.execute("select count(*) from line_identity").fetchone()[0], 16)

    def test_registry_is_optional(self):
        db = memory()
        report = line.import_dir(db, input_dir(identities=None))
        self.assertEqual(report["identities"], [])
        self.assertEqual(db.execute("select count(*) from line_identity").fetchone()[0], 0)

    def test_list_shaped_registry(self):
        db = memory()
        registry = [dict(code="N84", channel="B", prefix="line-401")]
        line.import_dir(db, input_dir(registry))
        self.assertEqual(line.prefix_for(db, "N84", "B"), "line-401")

    def test_bad_channel_is_rejected(self):
        db = memory()
        with self.assertRaises(ValueError):
            line.import_dir(db, input_dir({"N84": {"BB": "line-401"}}))
        with self.assertRaises(ValueError):
            line.import_dir(db, input_dir({"N84": {"B": ""}}))


class StableWireIdentity(unittest.TestCase):
    def test_uid_is_prefix_plus_original_day_per_channel(self):
        db = loaded()
        expected = {"A": "N84", "B": "line-401", "C": "line-401", "D": "N84"}
        for channel, prefix in expected.items():
            rows = [row for row in v2(db, channel) if row["code"] == "N84"]
            self.assertEqual([row["uid"] for row in rows], [f"{prefix}-20260330"])

    def test_uid_uses_the_original_day_not_the_shifted_one(self):
        db = loaded(batch(2, approval("M-701", "N84", "B", start=DAY, end=DAY,
                                     rank=2, clock="11:00", shift=1)))
        row = [r for r in v2(db, "B", asof=2) if r["code"] == "N84"][0]
        self.assertEqual(row["uid"], "line-401-20260330")     # original Monday
        self.assertEqual(row["day"], "2026-03-31")            # moved to Tuesday
        self.assertEqual(row["utc"], "2026-03-31T11:00:00+00:00")

    def test_uid_survives_a_later_clock_change(self):
        db = loaded(batch(2, approval("M-701", "N84", "B", start=DAY, end=DAY, clock="11:00")),
                    batch(3, approval("M-702", "N84", "B", start=DAY, end=DAY, clock="12:00", rank=2)))
        old = [r for r in v2(db, "B", asof=2) if r["code"] == "N84"][0]
        new = [r for r in v2(db, "B", asof=3) if r["code"] == "N84"][0]
        self.assertEqual(old["uid"], new["uid"])
        self.assertNotEqual(old["utc"], new["utc"])

    def test_unknown_registry_entry_falls_back_to_the_series_id(self):
        db = loaded()
        self.assertEqual(line.prefix_for(db, "N84", "Z"), "line-401")   # sid from portfolio
        self.assertEqual(line.prefix_for(db, "NOPE", "A"), "NOPE")

    def test_uid_shape(self):
        self.assertEqual(line.uid_for("line-401", "2026-03-09"), "line-401-20260309")
        self.assertEqual(line.uid_for("K17", portal.as_date("2026-03-06")), "K17-20260306")


# --------------------------------------------------------------------------- #
# HTTP v2
# --------------------------------------------------------------------------- #
class ApiV2(unittest.TestCase):
    def setUp(self):
        self.db = loaded(batch(2, approval("B-611", "Q29", "B", clock="16:30"),
                               approval("Z-213", "U56", "CD", start="2026-03-09",
                                        end="2026-03-23", clock="09:15", rank=2)))

    def tearDown(self):
        self.db.close()

    def test_row_shape(self):
        for row in v2(self.db, "A"):
            self.assertEqual(set(row), {"code", "day", "utc", "uid"})
            self.assertRegex(row["utc"], r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\+00:00$")

    def test_asof_gates_the_authorisations(self):
        base = {r["code"]: r for r in v2(self.db, "B", asof=1)}
        approved = {r["code"]: r for r in v2(self.db, "B", asof=2)}
        self.assertEqual(base["Q29"]["utc"], "2026-03-30T15:00:00+00:00")   # contract clock
        self.assertEqual(approved["Q29"]["utc"], "2026-03-30T16:30:00+00:00")
        self.assertEqual(base["Q29"]["uid"], approved["Q29"]["uid"])

    def test_asof_defaults_to_the_latest_registered_version(self):
        self.assertEqual(line.latest_version(self.db), 2)
        self.assertEqual(v2(self.db, "B"), v2(self.db, "B", asof=2))

    def test_channel_scoping(self):
        inside = v2(self.db, "C", start="2026-03-09", end="2026-03-09")
        other = v2(self.db, "A", start="2026-03-09", end="2026-03-09")
        self.assertEqual([r["utc"] for r in inside if r["code"] == "U56"], ["2026-03-09T09:15:00+00:00"])
        self.assertEqual([r["utc"] for r in other if r["code"] == "U56"], ["2026-03-09T07:20:00+00:00"])

    def test_empty_and_reversed_ranges(self):
        self.assertEqual(v2(self.db, "A", start="2026-03-31", end="2026-03-30"), [])
        self.assertEqual(v2(self.db, "A", start="", end=""), [])

    def test_bad_parameters_are_rejected(self):
        for url in ("/api/v2?channel=A&from=2026-03-30&to=2026-03-30&asof=soon",
                    "/api/v2?channel=AB&from=2026-03-30&to=2026-03-30",
                    "/api/v2?channel=A&from=2026-03-30&to=2026-03-30&asof=-1"):
            with self.assertRaises(ValueError):
                portal.route(self.db, url)

    def test_unimported_database_answers_empty(self):
        bare = portal.ensure_schema(sqlite3.connect(":memory:"))   # old tables only
        self.assertEqual(json.loads(portal.route(bare, "/api/v2?channel=A&from=2026-03-30&to=2026-03-30")[1]), [])
        bare.close()

    def test_service_does_not_read_input(self):
        db, _ = live_copy()
        self.addCleanup(db.close)
        line.import_dir(db, INPUT)
        real_open = builtins.open

        def guarded(file, *args, **kwargs):
            if isinstance(file, (str, bytes, os.PathLike)):
                path = os.path.abspath(os.fsdecode(file))
                if path == INPUT or path.startswith(INPUT + os.sep):
                    raise AssertionError(f"request path read {path}")
            return real_open(file, *args, **kwargs)

        builtins.open = guarded
        try:
            rows = v2(db, "B")
            portal.route(db, "/api/events?channel=A&from=2026-03-06&to=2026-03-27")
        finally:
            builtins.open = real_open
        self.assertEqual(len(rows), 4)


# --------------------------------------------------------------------------- #
# the old portal keeps its identities
# --------------------------------------------------------------------------- #
class DualVersionInvites(unittest.TestCase):
    """/invite/ resolves an old UID as before and a new-line UID by its identity."""

    def setUp(self):
        self.db, _ = live_copy()
        line.import_dir(self.db, INPUT)

    def tearDown(self):
        self.db.close()

    def invite(self, uid, query=""):
        return portal.route(self.db, f"/invite/{uid}{query}")[1]

    def test_new_line_uid_resolves(self):
        html = self.invite("line-401-20260309")
        self.assertIn('data-uid="line-401-20260309"', html)
        self.assertIn("13:45", html)                       # the session instant, UTC

    def test_new_line_uid_resolves_in_a_local_zone(self):
        self.assertIn("09:45", self.invite("line-401-20260309", "?tz=America/New_York"))

    def test_unknown_or_wrong_day_stays_empty(self):
        self.assertEqual(self.invite("line-401-20260310"), "<main></main>")
        self.assertEqual(self.invite("line-999-20260309"), "<main></main>")

    def test_old_uid_still_resolves_through_the_old_path(self):
        self.assertEqual(self.invite("M42-20260313"), "<main><article data-uid=\"M42-20260313\">2026-03-13 17:00</article></main>")


class HttpSurface(unittest.TestCase):
    """The deployed server, over real loopback HTTP."""

    @classmethod
    def setUpClass(cls):
        cls.path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        shutil.copyfile(LIVE, cls.path)
        db = portal.ensure_schema(sqlite3.connect(cls.path))
        line.import_dir(db, INPUT)
        db.commit()
        db.close()
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            cls.port = probe.getsockname()[1]
        cls.server = subprocess.Popen(
            [sys.executable, os.path.join(ROOT, "project", "portal.py"), "serve", str(cls.port)],
            env=dict(os.environ, PORTAL_DB=cls.path),
            stderr=subprocess.DEVNULL)
        for _ in range(120):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{cls.port}/", timeout=1).read()
                return
            except urllib.error.URLError:
                if cls.server.poll() is not None:
                    raise
                time.sleep(0.025)
        raise RuntimeError("portal did not start")

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.wait()

    def get(self, path):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{self.port}{path}", timeout=5) as response:
                return response.status, response.read().decode()
        except urllib.error.HTTPError as problem:
            return problem.code, problem.read().decode()

    def test_v2_answers_over_http(self):
        status, body = self.get("/api/v2?channel=B&from=2026-03-30&to=2026-03-30&asof=2")
        self.assertEqual(status, 200)
        rows = json.loads(body)
        self.assertEqual([row["uid"] for row in rows],
                         ["line-404-20260330", "line-401-20260330",
                          "line-402-20260330", "line-403-20260330"])
        self.assertEqual([row["utc"] for row in rows if row["code"] == "Q29"],
                         ["2026-03-30T16:30:00+00:00"])

    def test_old_api_still_answers_over_http(self):
        status, body = self.get("/api/events?channel=A&from=2026-03-06&to=2026-03-27")
        self.assertEqual(status, 200)
        uids = [row["uid"] for row in json.loads(body)]
        self.assertEqual(len(uids), 9)                     # K17 + M42 four Fridays each, one legacy
        self.assertIn("legacy-west", uids)
        status, body = self.get("/api/pages?channel=A&from=2026-03-06&to=2026-03-27&offset=2&limit=3")
        self.assertEqual(status, 200)
        self.assertEqual(len(json.loads(body)["items"]), 3)

    def test_bad_v2_parameters_are_a_400(self):
        status, body = self.get("/api/v2?channel=A&from=2026-03-30&to=2026-03-30&asof=soon")
        self.assertEqual(status, 400)
        self.assertIn("asof", body)

    def test_unknown_route_is_still_a_404(self):
        self.assertEqual(self.get("/api/nope")[0], 404)


OLD_URLS = ("/api/events?channel=A&from=2026-03-01&to=2026-03-31",
            "/api/events?channel=B&from=2026-03-01&to=2026-05-31",
            "/api/events?channel=A&from=2026-01-01&to=2026-12-31",
            "/api/pages?channel=A&from=2026-03-01&to=2026-03-31&offset=1&limit=2",
            "/",
            "/invite/M42-20260313",
            "/invite/K17-20260306")


class OldPortalUnchanged(unittest.TestCase):
    def setUp(self):
        self.db, self.path = live_copy()

    def tearDown(self):
        self.db.close()

    def test_migration_keeps_every_old_row(self):
        tables = ("events", "bookings", "series", "adjustment")
        before = {name: self.db.execute(f"select * from {name} order by 1").fetchall() for name in tables}
        line.import_dir(self.db, INPUT)
        after = {name: self.db.execute(f"select * from {name} order by 1").fetchall() for name in tables}
        self.assertEqual(before, after)
        self.assertGreater(len(before["bookings"]), 0)

    def test_migration_keeps_the_old_responses_byte_for_byte(self):
        before = {url: portal.route(self.db, url)[1] for url in OLD_URLS}
        line.import_dir(self.db, INPUT)
        after = {url: portal.route(self.db, url)[1] for url in OLD_URLS}
        self.assertEqual(before, after)

    def test_old_uid_scheme_is_still_parsed(self):
        self.assertEqual(portal.uid_day("M42-20260327"), portal.as_date("2026-03-27"))
        line.import_dir(self.db, INPUT)
        self.assertEqual(portal.uid_day("M42-20260327"), portal.as_date("2026-03-27"))

    def test_new_uid_never_collides_with_an_old_one(self):
        line.import_dir(self.db, INPUT)
        old = {row[0] for row in self.db.execute("select uid from events")}
        new = {row["uid"] for channel in "ABCD"
               for row in v2(self.db, channel, start="2026-03-02", end="2026-06-29", asof=9)}
        self.assertTrue(old)
        self.assertTrue(new)
        self.assertEqual(old & new, set())


if __name__ == "__main__":
    unittest.main(verbosity=2)
