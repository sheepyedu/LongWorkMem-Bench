"""Rebuildable release packages. Run: python3 project/test_release.py

The package for a release must be reproducible from the program (same inputs ->
same bytes -> same content-addressed key), verifiable against its manifest, and
pinned so that different bytes can never travel under a key that is already out.
"""
from datetime import datetime, timezone
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import line
import release

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
STAMP = "20260330T000000Z"
START, END, ASOF = "2026-03-02", "2026-03-23", 3
SERVICE_DAYS = ("20260302", "20260309", "20260316", "20260323")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def loaded(*orders):
    db = line.ensure_schema(sqlite3.connect(":memory:"))
    line.import_dir(db, INPUT)
    for name, batch in orders:
        folder = tempfile.mkdtemp()
        shutil.copyfile(os.path.join(INPUT, "portfolio.json"), os.path.join(folder, "portfolio.json"))
        shutil.copyfile(os.path.join(INPUT, "identities.json"), os.path.join(folder, "identities.json"))
        os.makedirs(os.path.join(folder, "orders"))
        with open(os.path.join(folder, "orders", name), "w", encoding="utf-8") as handle:
            json.dump(batch, handle)
        line.import_dir(db, folder)
    return db


def approval(oid, code, channels="A", start="2026-01-01", end="2026-12-31",
             rank=1, clock="16:30", basis="utc", shift=0):
    return dict(id=oid, code=code, channels=channels, start=start, end=end,
                rank=rank, clock=clock, basis=basis, shift_days=shift)


def outdir():
    return tempfile.mkdtemp()


def events(text):
    out, row = [], None
    for raw in text.replace("\r\n", "\n").split("\n"):
        name, _, value = raw.partition(":")
        if raw == "BEGIN:VEVENT":
            row = {}
        elif raw == "END:VEVENT":
            out.append(row)
            row = None
        elif row is not None:
            row[name] = value
    return out


def built(db, **kwargs):
    folder = outdir()
    manifest = release.build_all(db, START, END, ASOF, folder, stamp=STAMP, **kwargs)
    return folder, manifest


# --------------------------------------------------------------------------- #
# the package
# --------------------------------------------------------------------------- #
class Package(unittest.TestCase):
    def setUp(self):
        self.db = loaded()

    def tearDown(self):
        self.db.close()

    def test_every_channel_gets_the_four_march_service_days(self):
        folder, manifest = built(self.db)
        self.assertEqual([entry["channel"] for entry in manifest["channels"]], list("ABCD"))
        for entry in manifest["channels"]:
            with open(os.path.join(folder, entry["file"]), encoding="utf-8", newline="") as handle:
                rows = events(handle.read())
            self.assertEqual(len(rows), 16)                       # 4 series x 4 Mondays
            self.assertEqual({row["STATUS"] for row in rows}, {"CONFIRMED"})
            self.assertEqual(len({row["UID"] for row in rows}), 16)
            self.assertEqual(sorted({row["DTSTART"][:8] for row in rows}), list(SERVICE_DAYS))

    def test_wire_identities_follow_the_registry(self):
        folder, manifest = built(self.db)
        names = {entry["channel"]: set(entry["uids"]) for entry in manifest["channels"]}
        self.assertEqual(names["A"], {f"{code}-{day}" for code in ("J31", "N84", "Q29", "U56")
                                      for day in SERVICE_DAYS})
        self.assertEqual(names["B"], {f"line-40{n}-{day}" for n in (4, 1, 2, 3)
                                      for day in SERVICE_DAYS})
        self.assertEqual(names["A"], names["D"])
        self.assertEqual(names["B"], names["C"])

    def test_the_approved_layer_is_what_gets_published(self):
        folder, _ = built(self.db)
        with open(os.path.join(folder, "first-C-20260302-20260323.ics"), encoding="utf-8", newline="") as handle:
            rows = {row["UID"]: row["DTSTART"] for row in events(handle.read())}
        self.assertEqual(rows["line-403-20260302"], "20260302T072000Z")   # base: 08:20 CET
        self.assertEqual(rows["line-403-20260309"], "20260309T091500Z")   # Z-213
        self.assertEqual(rows["line-403-20260323"], "20260323T091500Z")

    def test_asof_selects_an_earlier_layer(self):
        _, latest = built(self.db)
        folder = outdir()
        older = release.build_all(self.db, START, END, 1, folder, tag="base", stamp=STAMP)
        self.assertEqual([e["uids"] for e in older["channels"]],
                         [e["uids"] for e in latest["channels"]])      # same identities
        self.assertNotEqual([e["sha256"] for e in older["channels"]],
                            [e["sha256"] for e in latest["channels"]])  # different times

    def test_window_edges_are_inclusive(self):
        folder = outdir()
        one = release.build_all(self.db, START, START, ASOF, folder, stamp=STAMP)
        self.assertEqual(one["channels"][0]["events"], 4)              # one service day
        folder = outdir()
        empty = release.build_all(self.db, "2026-03-03", "2026-03-08", ASOF, folder, stamp=STAMP)
        self.assertEqual(empty["channels"][0]["events"], 0)


# --------------------------------------------------------------------------- #
# reproducibility
# --------------------------------------------------------------------------- #
class Rebuildable(unittest.TestCase):
    def setUp(self):
        self.db = loaded()

    def tearDown(self):
        self.db.close()

    def test_rebuild_is_byte_identical(self):
        folder, first = built(self.db)
        before = {entry["channel"]: entry["sha256"] for entry in first["channels"]}
        again_folder, again = built(self.db)
        self.assertEqual(before, {entry["channel"]: entry["sha256"] for entry in again["channels"]})
        for entry in first["channels"]:
            with open(os.path.join(folder, entry["file"]), "rb") as handle:
                one = handle.read()
            with open(os.path.join(again_folder, entry["file"]), "rb") as handle:
                two = handle.read()
            self.assertEqual(one, two)

    def test_rebuild_does_not_grow_the_feed_state(self):
        folder = outdir()
        release.build_all(self.db, START, END, ASOF, folder, stamp=STAMP)
        count = self.db.execute("select count(*) from line_feed").fetchone()[0]
        release.build_all(self.db, START, END, ASOF, folder, stamp=STAMP)
        self.assertEqual(self.db.execute("select count(*) from line_feed").fetchone()[0], count)
        self.assertEqual(self.db.execute("select max(sequence) from line_feed").fetchone()[0], 0)

    def test_keys_are_content_addressed(self):
        folder, manifest = built(self.db)
        for entry in manifest["channels"]:
            self.assertTrue(entry["key"].startswith(f"{entry['channel']}-first-"))
            self.assertTrue(entry["key"].endswith(entry["sha256"][:8]))
        self.assertEqual(len({entry["key"] for entry in manifest["channels"]}), 4)

    def test_changed_content_means_a_changed_key(self):
        _, first = built(self.db)
        line.import_dir(self.db, INPUT)
        folder = tempfile.mkdtemp()
        shutil.copyfile(os.path.join(INPUT, "portfolio.json"), os.path.join(folder, "portfolio.json"))
        shutil.copyfile(os.path.join(INPUT, "identities.json"), os.path.join(folder, "identities.json"))
        os.makedirs(os.path.join(folder, "orders"))
        with open(os.path.join(folder, "orders", "later.json"), "w", encoding="utf-8") as handle:
            json.dump(dict(version=3, rows=[approval("L-1", "Q29", "B", clock="18:45", rank=5)]), handle)
        line.import_dir(self.db, folder)
        _, changed = built(self.db, tag="second")
        old = {entry["channel"]: entry for entry in first["channels"]}
        new = {entry["channel"]: entry for entry in changed["channels"]}
        self.assertNotEqual(old["B"]["sha256"], new["B"]["sha256"])
        self.assertNotEqual(old["B"]["key"], new["B"]["key"])
        self.assertEqual(old["A"]["sha256"], new["A"]["sha256"])     # untouched channel


# --------------------------------------------------------------------------- #
# verification
# --------------------------------------------------------------------------- #
class Verify(unittest.TestCase):
    def setUp(self):
        self.db = loaded()
        self.folder, self.manifest = built(self.db)
        self.path = os.path.join(self.folder, "first-manifest.json")

    def tearDown(self):
        self.db.close()

    def test_fresh_package_verifies(self):
        self.assertEqual(release.verify(self.db, self.path), [])

    def test_manifest_pins_the_bytes(self):
        stored = release.load_manifest(self.path)
        for entry in stored["channels"]:
            with open(os.path.join(self.folder, entry["file"]), encoding="utf-8", newline="") as handle:
                self.assertEqual(release.digest(handle.read()), entry["sha256"])

    def test_a_tampered_file_is_reported(self):
        target = os.path.join(self.folder, self.manifest["channels"][0]["file"])
        with open(target, "a", encoding="utf-8", newline="") as handle:
            handle.write("X-EXTRA:1\r\n")
        problems = release.verify(self.db, self.path)
        self.assertTrue(any("does not match its sha256" in problem for problem in problems))

    def test_database_drift_is_reported(self):
        folder = tempfile.mkdtemp()
        shutil.copyfile(os.path.join(INPUT, "portfolio.json"), os.path.join(folder, "portfolio.json"))
        shutil.copyfile(os.path.join(INPUT, "identities.json"), os.path.join(folder, "identities.json"))
        os.makedirs(os.path.join(folder, "orders"))
        with open(os.path.join(folder, "orders", "later.json"), "w", encoding="utf-8") as handle:
            json.dump(dict(version=3, rows=[approval("L-1", "U56", "CD", clock="11:05", rank=5)]), handle)
        line.import_dir(self.db, folder)
        problems = release.verify(self.db, self.path)
        self.assertTrue(any("rebuild from the database differs" in problem for problem in problems))

    def test_a_reused_key_is_reported(self):
        stored = release.load_manifest(self.path)
        stored["channels"][1]["key"] = stored["channels"][0]["key"]
        with open(self.path, "w", encoding="utf-8") as handle:
            json.dump(stored, handle)
        problems = release.verify(self.db, self.path)
        self.assertTrue(any("is not" in problem for problem in problems))

    def test_missing_file_is_reported(self):
        os.remove(os.path.join(self.folder, self.manifest["channels"][2]["file"]))
        problems = release.verify(self.db, self.path)
        self.assertTrue(any("missing file" in problem for problem in problems))


# --------------------------------------------------------------------------- #
# delivery record
# --------------------------------------------------------------------------- #
def receipts_from(folder, manifest, receipt_ids=None):
    """The shape the delivery service returns for a batch, read back from the package."""
    receipts = {}
    for entry in manifest["channels"]:
        with open(os.path.join(folder, entry["file"]), encoding="utf-8", newline="") as handle:
            starts = release.ics_starts(handle.read())
        rows = {}
        for uid, dtstart in starts.items():
            moment = datetime.strptime(dtstart, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
            rows[uid] = dict(uid=uid, utc=moment.strftime("%Y-%m-%dT%H:%M:%SZ"), status="CONFIRMED")
        receipts[entry["channel"]] = [dict(
            turn=4, key=entry["key"], rows=rows,
            receipt=(receipt_ids or {}).get(entry["channel"]) or f"{entry['channel']}-00001")]
    return receipts


class DeliveryRecord(unittest.TestCase):
    def setUp(self):
        self.db = loaded()
        self.folder, self.manifest = built(self.db)
        self.path = os.path.join(self.folder, "first-manifest.json")
        self.receipts = receipts_from(self.folder, self.manifest)
        self.receipts_path = os.path.join(self.folder, "receipts.json")
        with open(self.receipts_path, "w", encoding="utf-8") as handle:
            json.dump(self.receipts, handle)

    def tearDown(self):
        self.db.close()

    def test_record_matches_the_package(self):
        json_path = os.path.join(self.folder, "record.json")
        md_path = os.path.join(self.folder, "record.md")
        result, problems = release.record(self.db, self.path, self.receipts_path,
                                          json_path=json_path, markdown_path=md_path)
        self.assertEqual(problems, [])
        self.assertEqual(result["totals"], dict(channels=4, deliveries=64, confirmed=64))
        self.assertTrue(os.path.exists(json_path) and os.path.exists(md_path))
        with open(md_path, encoding="utf-8") as handle:
            text = handle.read()
        for entry in self.manifest["channels"]:
            self.assertIn(entry["key"], text)
            self.assertIn(entry["file"], text)
        self.assertIn("A-00001", text)
        with open(json_path, encoding="utf-8") as handle:
            stored = json.load(handle)
        self.assertEqual(len(stored["deliveries"]), 64)
        self.assertEqual({row["local"] for row in stored["deliveries"] if row["code"] == "N84"},
                         {"2026-03-02 09:45 EST", "2026-03-09 09:45 EDT",
                          "2026-03-16 09:45 EDT", "2026-03-23 09:45 EDT"})

    def test_a_disagreeing_receipt_is_reported(self):
        batch = self.receipts["C"][0]
        batch["rows"]["line-403-20260309"]["utc"] = "2026-03-09T10:15:00Z"
        with open(self.receipts_path, "w", encoding="utf-8") as handle:
            json.dump(self.receipts, handle)
        _, problems = release.record(self.db, self.path, self.receipts_path)
        self.assertTrue(any("line-403-20260309" in problem for problem in problems))

    def test_a_missing_receipt_is_reported(self):
        self.receipts["D"] = []
        with open(self.receipts_path, "w", encoding="utf-8") as handle:
            json.dump(self.receipts, handle)
        _, problems = release.record(self.db, self.path, self.receipts_path)
        self.assertTrue(any(problem.startswith("D: no receipt") for problem in problems))

    def test_a_wrong_status_is_reported(self):
        self.receipts["B"][0]["rows"]["line-401-20260302"]["status"] = "TENTATIVE"
        with open(self.receipts_path, "w", encoding="utf-8") as handle:
            json.dump(self.receipts, handle)
        _, problems = release.record(self.db, self.path, self.receipts_path)
        self.assertTrue(any("TENTATIVE" in problem for problem in problems))


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
class CommandLine(unittest.TestCase):
    def setUp(self):
        self.db_path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        self.env = dict(os.environ, PORTAL_DB=self.db_path)
        self.out = tempfile.mkdtemp()

    def run_release(self, *args):
        return subprocess.run([sys.executable, os.path.join(ROOT, "project", "release.py")] + list(args),
                              cwd=ROOT, env=self.env, capture_output=True, text=True)

    def test_build_then_verify(self):
        self.assertEqual(self.run_release("build", START, END, str(ASOF)).returncode, 2)  # nothing imported yet
        subprocess.run([sys.executable, os.path.join(ROOT, "project", "line.py"), "import", INPUT],
                       cwd=ROOT, env=self.env, check=True, capture_output=True)
        result = self.run_release("build", START, END, str(ASOF), "--outdir", self.out)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(result.stdout)
        self.assertEqual(len(manifest["channels"]), 4)
        path = os.path.join(self.out, "first-manifest.json")
        self.assertTrue(os.path.exists(path))
        result = self.run_release("verify", path, "--outdir", self.out)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(json.loads(result.stdout)["ok"])

    def test_verify_reports_drift_with_exit_two(self):
        subprocess.run([sys.executable, os.path.join(ROOT, "project", "line.py"), "import", INPUT],
                       cwd=ROOT, env=self.env, check=True, capture_output=True)
        self.assertEqual(self.run_release("build", START, END, str(ASOF),
                                          "--outdir", self.out).returncode, 0)
        path = os.path.join(self.out, "first-manifest.json")
        with open(os.path.join(self.out, "first-B-20260302-20260323.ics"), "a", encoding="utf-8") as handle:
            handle.write("X-EXTRA:1\r\n")
        result = self.run_release("verify", path, "--outdir", self.out)
        self.assertEqual(result.returncode, 2)
        self.assertFalse(json.loads(result.stdout)["ok"])

    def test_missing_manifest_exits_two(self):
        self.assertEqual(self.run_release("verify", os.path.join(self.out, "nope.json")).returncode, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
