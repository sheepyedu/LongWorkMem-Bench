"""Encoders for subscribers using one VEVENT per stable occurrence UID.

`encode` is the original pilot encoder, kept byte-for-byte for the delivered
feeds.  `encode_feed` is the new product line's generator: the same one-VEVENT-
per-UID shape plus SEQUENCE, so a rescheduled session updates the entry a
subscriber already holds instead of arriving as a second event.
"""
from datetime import datetime, timezone


def encode(rows):
    lines = ["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Schedule Desk//EN"]
    for row in rows:
        stamp = datetime.fromisoformat(row["utc"]).astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        lines.extend(["BEGIN:VEVENT","UID:"+row["uid"],"DTSTAMP:20260101T000000Z",
                      "DTSTART:"+stamp,"STATUS:"+row["status"],"END:VEVENT"])
    return "\r\n".join(lines+["END:VCALENDAR",""])


def encode_feed(rows):
    """Full VEVENT feed: one VEVENT per UID, STATUS from the row, SEQUENCE honoured."""
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Schedule Desk//EN"]
    for row in rows:
        start = datetime.fromisoformat(row["utc"]).astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        lines.extend(["BEGIN:VEVENT", "UID:" + row["uid"],
                      "DTSTAMP:" + row.get("stamp", "19700101T000000Z"),
                      "DTSTART:" + start,
                      "SEQUENCE:" + str(int(row.get("sequence", 0))),
                      "STATUS:" + row.get("status", "CONFIRMED"),
                      "END:VEVENT"])
    return "\r\n".join(lines + ["END:VCALENDAR", ""])
