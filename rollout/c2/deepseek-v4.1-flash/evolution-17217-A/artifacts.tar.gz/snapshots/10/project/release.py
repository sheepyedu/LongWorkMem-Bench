"""Rebuildable release packages for the new product line.

    python3 project/release.py build  START END ASOF [--tag first] [--outdir out]
    python3 project/release.py verify MANIFEST [--outdir out]
    python3 project/release.py record MANIFEST RECEIPTS [--json PATH] [--markdown PATH]

`build` renders one ICS per channel (A/B/C/D) from the schedule core and writes a
manifest that pins the package: for every channel its dedupe key, file name,
sha256, event count and stamp.  The key is content addressed
(`A-first-20260302-20260323-1f4c9ab2`), so the same bytes always get the same key
and different bytes can never be published under a key that is already out.

`verify` proves the package is reproducible: it checks the files on disk against
the manifest, then re-renders the package from the database and compares bytes.

Nothing here talks to the delivery service; `publish(channel, key, file)` is a
separate, deliberate step.

`record` turns the service's own receipts into the delivery record the support
desk quotes from: it matches each channel's receipt to the manifest key and
cross-checks it against the published file (same UID set, same instants,
CONFIRMED), so a record can never quietly disagree with what went out.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import sqlite3
import sys
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import line

CHANNELS = ("A", "B", "C", "D")
DEFAULT_TAG = "first"


# --------------------------------------------------------------------------- #
# rendering
# --------------------------------------------------------------------------- #
def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def key_for(channel, tag, start, end, sha):
    """Dedupe key: channel + tag + window + content digest (content addressed)."""
    return f"{channel}-{tag}-{start:%Y%m%d}-{end:%Y%m%d}-{sha[:8]}"


def render(db, channel, start, end, asof, stamp=None):
    """-> (ics text, rows) for one channel; updates the per-UID feed state."""
    rows = line.feed_rows(db, channel, start, end, asof, stamp=stamp)
    return calendar_io.encode_feed(rows), rows


def build(db, channel, start, end, asof, outdir, tag=DEFAULT_TAG, stamp=None):
    """Write one channel's release file; -> manifest entry."""
    start, end = line.as_day(start), line.as_day(end)
    text, rows = render(db, channel, start, end, asof, stamp=stamp)
    name = f"{tag}-{channel}-{start:%Y%m%d}-{end:%Y%m%d}.ics"
    path = os.path.join(outdir, name)
    os.makedirs(outdir, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)
    sha = digest(text)
    db.commit()
    return dict(channel=channel, key=key_for(channel, tag, start, end, sha),
                file=name, sha256=sha, events=len(rows),
                first_uid=rows[0]["uid"] if rows else None,
                last_uid=rows[-1]["uid"] if rows else None,
                uids=[row["uid"] for row in rows])


def build_all(db, start, end, asof, outdir, tag=DEFAULT_TAG, stamp=None):
    """Build every channel and write the manifest; -> manifest dict."""
    try:
        registered = db.execute("select count(*) from line_series").fetchone()[0]
    except sqlite3.OperationalError:
        registered = 0
    if not registered:
        raise ValueError("no series registered; run `line.py import INPUT_DIR` first")
    start, end = line.as_day(start), line.as_day(end)
    stamp = stamp or line.feed_stamp()
    channels = [build(db, channel, start, end, asof, outdir, tag=tag, stamp=stamp)
                for channel in CHANNELS]
    manifest = dict(tag=tag, start=start.isoformat(), end=end.isoformat(),
                    asof=int(asof), stamp=stamp, channels=channels)
    write_manifest(manifest, outdir)
    return manifest


def manifest_path(outdir, tag=DEFAULT_TAG):
    return os.path.join(outdir, f"{tag}-manifest.json")


def write_manifest(manifest, outdir):
    text = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    with open(manifest_path(outdir, manifest["tag"]), "w", encoding="utf-8") as handle:
        handle.write(text)
    return digest(text)


def load_manifest(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


# --------------------------------------------------------------------------- #
# delta against the real downstream
# --------------------------------------------------------------------------- #
DEFAULT_DELTA_TAG = "delta"


def read_batches(path):
    with open(path, encoding="utf-8") as handle:
        batches = json.load(handle)
    if isinstance(batches, dict):
        batches = [batches]
    return batches


def _resolve(entry, path):
    """A path from an index file, looked for next to it, one level up, then cwd."""
    base = os.path.dirname(os.path.abspath(path))
    for root in (base, os.path.dirname(base), os.getcwd()):
        candidate = entry if os.path.isabs(entry) else os.path.join(root, entry)
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    return None


def downstream_state(*paths):
    """What the downstream really holds; -> ({channel: {uid: utc}}, [sources]).

    Accepts the archive index (channel -> batch file, `input/vault/index.json`) as
    well as a receipts dump (channel -> [batch]); later batches beat earlier ones
    for the same UID, exactly as a subscriber applies them.
    """
    state, sources = {}, []
    for path in paths:
        with open(path, encoding="utf-8") as handle:
            index = json.load(handle)
        if isinstance(index, list):
            raise ValueError(f"{path}: expected channel -> batches, got a bare list")
        for channel, entry in index.items():
            channel = str(channel).strip().upper()
            if isinstance(entry, str):
                target = _resolve(entry, path)
                if target is None:
                    raise ValueError(f"{path}: cannot find the batch file {entry!r}")
                batches = read_batches(target)
                source = target
            else:
                batches = entry if isinstance(entry, list) else [entry]
                source = os.path.abspath(path)
            sources.append(dict(channel=channel, source=source, batches=len(batches)))
            rows = state.setdefault(channel, {})
            for batch in batches:
                for uid, row in (batch.get("rows") or {}).items():
                    rows[uid] = row.get("utc")
    return state, sources


def same_instant(left, right):
    """Two instants compared as instants: "…T15:00:00" == "…T15:00:00Z"."""
    if left is None or right is None:
        return left == right
    try:
        return stamp_of(left) == stamp_of(right)
    except (TypeError, ValueError):
        return left == right


def delta_rows(db, channel, start, end, asof, delivered, stamp=None):
    """Only what the downstream does not already hold; -> (changed, withdrawn).

    `changed` carries `was`, the instant the subscriber has now (None = never
    delivered); `withdrawn` lists delivered UIDs this window no longer schedules.
    """
    rows = line.feed_rows(db, channel, start, end, asof, stamp=stamp)
    changed = [dict(row, was=delivered.get(row["uid"]))
               for row in rows
               if not same_instant(delivered.get(row["uid"]), row["utc"])]
    known = {row["uid"] for row in rows}
    # Keep the report about this window only: other service days the subscriber
    # holds are not this package's business.
    withdrawn = [dict(uid=uid, was=utc) for uid, utc in sorted(delivered.items())
                 if uid not in known and line.in_window(uid, start, end)]
    return changed, withdrawn


def build_delta(db, start, end, asof, outdir, downstream, tag=DEFAULT_DELTA_TAG,
                channels=CHANNELS, stamp=None):
    """Build one package per channel holding only the current delta; -> manifest."""
    start, end = line.as_day(start), line.as_day(end)
    stamp = stamp or line.feed_stamp()
    state, sources = downstream_state(*downstream)
    entries, skipped, withdrawn_all = [], [], []
    for channel in channels:
        delivered = state.get(channel, {})
        changed, withdrawn = delta_rows(db, channel, start, end, asof, delivered, stamp=stamp)
        withdrawn_all.extend(dict(channel=channel, **row) for row in withdrawn)
        if not changed:
            skipped.append(dict(channel=channel, delivered=len(delivered),
                                reason="nothing differs from the delivered batches"))
            continue
        text = calendar_io.encode_feed(changed)
        name = f"{tag}-{channel}-{start:%Y%m%d}-{end:%Y%m%d}.ics"
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, name), "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
        sha = digest(text)
        entries.append(dict(channel=channel, key=key_for(channel, tag, start, end, sha),
                            file=name, sha256=sha, events=len(changed),
                            first_uid=changed[0]["uid"], last_uid=changed[-1]["uid"],
                            uids=[row["uid"] for row in changed],
                            previous={row["uid"]: row["was"] for row in changed}))
    db.commit()
    manifest = dict(tag=tag, start=start.isoformat(), end=end.isoformat(), asof=int(asof),
                    stamp=stamp, channels=entries, skipped=skipped,
                    withdrawn=withdrawn_all, downstream=sources)
    write_manifest(manifest, outdir)
    return manifest


def verify_delta(db, path, outdir=None, downstream=None):
    """Check a delta package and re-render it; -> list of problems."""
    manifest = load_manifest(path)
    outdir = outdir or os.path.dirname(os.path.abspath(path))
    start, end = line.as_day(manifest["start"]), line.as_day(manifest["end"])
    tag, asof, stamp = manifest["tag"], manifest["asof"], manifest.get("stamp")
    state = downstream_state(*downstream)[0] if downstream else None
    problems = []
    for entry in manifest["channels"]:
        channel, name = entry["channel"], entry["file"]
        full = os.path.join(outdir, name)
        if not os.path.exists(full):
            problems.append(f"{channel}: {name} is missing from {outdir}")
            continue
        with open(full, encoding="utf-8", newline="") as handle:
            text = handle.read()
        if digest(text) != entry["sha256"]:
            problems.append(f"{channel}: {name} on disk is not the recorded bytes")
        if key_for(channel, tag, start, end, digest(text)) != entry["key"]:
            problems.append(f"{channel}: key {entry['key']} is not the digest of {name}")
        rows = {row["uid"]: row for row in
                line.feed_rows(db, channel, start, end, asof, stamp=stamp)}
        kept = [rows[uid] for uid in entry["uids"] if uid in rows]
        if len(kept) != len(entry["uids"]):
            problems.append(f"{channel}: {len(entry['uids'])} UIDs in the package, "
                            f"{len(kept)} still scheduled")
        if list(ics_starts(text)) != [row["uid"] for row in kept]:
            problems.append(f"{channel}: {name} holds a different UID set than the manifest")
        if calendar_io.encode_feed(kept) != text:
            problems.append(f"{channel}: {name} does not rebuild from the schedule at asof {asof}")
        if state is not None:
            delivered = state.get(channel, {})
            changed, _ = delta_rows(db, channel, start, end, asof, delivered, stamp=stamp)
            if sorted(row["uid"] for row in changed) != sorted(entry["uids"]):
                problems.append(f"{channel}: the delta is stale; the schedule moved again")
            for row in kept:
                if same_instant(delivered.get(row["uid"]), row["utc"]):
                    problems.append(f"{channel}: {row['uid']} is unchanged downstream")
    db.commit()
    return problems


# --------------------------------------------------------------------------- #
# verification
# --------------------------------------------------------------------------- #
def verify(db, path, outdir=None):
    """Check the package on disk and re-render it; -> list of problems."""
    manifest = load_manifest(path)
    outdir = outdir or os.path.dirname(os.path.abspath(path))
    problems = []
    for entry in manifest["channels"]:
        target = os.path.join(outdir, entry["file"])
        if not os.path.exists(target):
            problems.append(f"{entry['channel']}: missing file {entry['file']}")
            continue
        with open(target, encoding="utf-8", newline="") as handle:
            on_disk = handle.read()
        if digest(on_disk) != entry["sha256"]:
            problems.append(f"{entry['channel']}: {entry['file']} does not match its sha256")
        rebuilt, rows = render(db, entry["channel"], manifest["start"], manifest["end"],
                               manifest["asof"], stamp=manifest["stamp"])
        if digest(rebuilt) != entry["sha256"]:
            problems.append(f"{entry['channel']}: rebuild from the database differs")
        elif [row["uid"] for row in rows] != entry["uids"]:
            problems.append(f"{entry['channel']}: rebuild has a different UID set")
        expected_key = key_for(entry["channel"], manifest["tag"],
                               line.as_day(manifest["start"]), line.as_day(manifest["end"]),
                               entry["sha256"])
        if expected_key != entry["key"]:
            problems.append(f"{entry['channel']}: key {entry['key']} is not {expected_key}")
    db.commit()
    return problems


# --------------------------------------------------------------------------- #
# delivery record
# --------------------------------------------------------------------------- #
def ics_starts(text):
    """{UID: DTSTART} from an ICS body."""
    out, uid = {}, None
    for raw in text.replace("\r\n", "\n").split("\n"):
        name, _, value = raw.partition(":")
        if raw == "BEGIN:VEVENT":
            uid = None
        elif name == "UID":
            uid = value
        elif name == "DTSTART" and uid:
            out[uid] = value
        elif raw == "END:VEVENT":
            uid = None
    return out


def stamp_of(utc):
    """ISO8601 instant -> the ICS basic format used in DTSTART."""
    return datetime.fromisoformat(utc.replace("Z", "+00:00")).astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def local_label(utc, zone):
    moment = datetime.fromisoformat(utc.replace("Z", "+00:00")).astimezone(ZoneInfo(zone))
    return moment.strftime("%Y-%m-%d %H:%M %Z")


def code_of(db, channel, uid):
    """The series code behind a wire UID (prefix lookup, per channel)."""
    prefix = uid.rpartition("-")[0]
    for row in db.execute("select code from line_series order by code"):
        if line.prefix_for(db, row[0], channel) == prefix:
            return row[0]
    return None


def zone_of(db, code):
    row = db.execute("select zone from line_series where code=?", (code,)).fetchone()
    return row[0] if row else "UTC"


def receipt_for(receipts, channel, key):
    for batch in receipts.get(channel, []):
        if batch.get("key") == key:
            return batch
    return None


def record(db, manifest_path, receipts_path, json_path=None, markdown_path=None, outdir=None):
    """Build the support-facing delivery record; -> (record dict, problems list)."""
    manifest = load_manifest(manifest_path)
    outdir = outdir or os.path.dirname(os.path.abspath(manifest_path))
    with open(receipts_path, encoding="utf-8") as handle:
        receipts = json.load(handle)

    problems, batches, deliveries = [], [], []
    for entry in manifest["channels"]:
        channel = entry["channel"]
        batch = receipt_for(receipts, channel, entry["key"])
        if batch is None:
            problems.append(f"{channel}: no receipt for key {entry['key']}")
            batches.append(dict(channel=channel, key=entry["key"], file=entry["file"],
                                sha256=entry["sha256"], events=entry["events"],
                                receipt=None, turn=None, receipt_rows=0))
            continue
        rows = batch.get("rows") or {}
        with open(os.path.join(outdir, entry["file"]), encoding="utf-8", newline="") as handle:
            published = ics_starts(handle.read())
        if len(rows) != entry["events"]:
            problems.append(f"{channel}: receipt has {len(rows)} rows, package has {entry['events']}")
        if sorted(rows) != sorted(entry["uids"]):
            problems.append(f"{channel}: receipt UID set differs from the package")
        for uid, row in sorted(rows.items()):
            if row.get("status") != "CONFIRMED":
                problems.append(f"{channel}: {uid} is {row.get('status')!r} on the service")
            if published.get(uid) != stamp_of(row["utc"]):
                problems.append(f"{channel}: {uid} is {row['utc']} on the service, "
                                f"{published.get(uid)} in {entry['file']}")
            code = code_of(db, channel, uid)
            deliveries.append(dict(channel=channel, uid=uid, code=code, utc=row["utc"],
                                   status=row["status"],
                                   local=local_label(row["utc"], zone_of(db, code) if code else "UTC")))
        batches.append(dict(channel=channel, key=entry["key"], file=entry["file"],
                            sha256=entry["sha256"], events=entry["events"],
                            receipt=batch.get("receipt"), turn=batch.get("turn"),
                            receipt_rows=len(rows)))

    kind = "delta" if "downstream" in manifest else "release"
    result = dict(tag=manifest["tag"], start=manifest["start"], end=manifest["end"],
                  asof=manifest["asof"], stamp=manifest["stamp"], kind=kind,
                  manifest=os.path.basename(manifest_path), batches=batches,
                  deliveries=deliveries,
                  downstream=manifest.get("downstream") or [],
                  skipped=manifest.get("skipped") or [],
                  previous={entry["channel"]: entry.get("previous") or {}
                            for entry in manifest["channels"]},
                  totals=dict(channels=len({row["channel"] for row in deliveries}),
                              deliveries=len(deliveries),
                              confirmed=sum(1 for row in deliveries if row["status"] == "CONFIRMED")))
    if json_path:
        os.makedirs(os.path.dirname(os.path.abspath(json_path)), exist_ok=True)
        with open(json_path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    if markdown_path:
        os.makedirs(os.path.dirname(os.path.abspath(markdown_path)), exist_ok=True)
        with open(markdown_path, "w", encoding="utf-8") as handle:
            handle.write(render_markdown(result))
    db.commit()
    return result, problems


def render_markdown(result):
    """A support desk can quote this as-is."""
    if result.get("kind") == "delta":
        sources = " ".join(f"--downstream {item['source']}" for item in result.get("downstream", []))
        rebuild = (f"python3 project/release.py delta {result['start']} {result['end']} "
                   f"{result['asof']} {sources} --tag {result['tag']}")
        label = "差量包"
    else:
        rebuild = (f"python3 project/release.py build {result['start']} {result['end']} "
                   f"{result['asof']} --tag {result['tag']}")
        label = "发布包"
    lines = [f"# 交付记录 · {result['tag']}（客服引用）", "",
             f"* 服务窗口（原定日，含端点）：{result['start']} .. {result['end']}",
             f"* 授权版本 ASOF：{result['asof']}",
             f"* {label}：`{result['manifest']}`（`{rebuild}` 可重建）",
             f"* DTSTAMP：{result['stamp']}",
             f"* 共 {result['totals']['channels']} 端 / {result['totals']['deliveries']} 条投递 / "
             f"{result['totals']['confirmed']} 条 CONFIRMED",
             "", "## 批次与回执", "",
             "| 端 | 回执 | key | 文件 | sha256 | VEVENT |", "| --- | --- | --- | --- | --- | --- |"]
    for entry in result["batches"]:
        lines.append(f"| {entry['channel']} | {entry.get('receipt', '—')} | `{entry['key']}` | "
                     f"`{entry['file']}` | `{entry['sha256'][:12]}…` | {entry['events']} |")
    delta = result.get("kind") == "delta"
    for channel in CHANNELS:
        rows = [row for row in result["deliveries"] if row["channel"] == channel]
        if not rows:
            continue
        before = (result.get("previous") or {}).get(channel, {})
        head = "| UID | 系列 | UTC | 场馆当地 | 此前下游所见 | 状态 |" if delta else \
               "| UID | 系列 | UTC | 场馆当地 | 状态 |"
        rule = "| --- | --- | --- | --- | --- | --- |" if delta else "| --- | --- | --- | --- | --- |"
        lines.extend(["", f"## {channel} 端（{len(rows)} 场）", "", head, rule])
        for row in rows:
            cells = (f"| `{row['uid']}` | {row['code']} | {row['utc']} | {row['local']} |")
            if delta:
                cells += f" {before.get(row['uid']) or '（未投递）'} |"
            lines.append(cells + f" {row['status']} |")
    if result.get("skipped"):
        lines.extend(["", "## 无差量、未投的端", "",
                      "| 端 | 原因 | 下游已有条数 |", "| --- | --- | --- |"])
        for entry in result["skipped"]:
            lines.append(f"| {entry['channel']} | {entry['reason']} | {entry.get('delivered', 0)} |")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main(argv=None):
    parser = argparse.ArgumentParser(prog="release.py")
    sub = parser.add_subparsers(dest="action", required=True)
    builder = sub.add_parser("build")
    builder.add_argument("start")
    builder.add_argument("end")
    builder.add_argument("asof", type=int)
    builder.add_argument("--tag", default=DEFAULT_TAG)
    builder.add_argument("--outdir", default="out")
    builder.add_argument("--stamp", default=None)
    checker = sub.add_parser("verify")
    checker.add_argument("manifest")
    checker.add_argument("--outdir", default=None)
    delta = sub.add_parser("delta")
    delta.add_argument("start")
    delta.add_argument("end")
    delta.add_argument("asof", type=int)
    delta.add_argument("--downstream", action="append", required=True)
    delta.add_argument("--tag", default=DEFAULT_DELTA_TAG)
    delta.add_argument("--channels", default="".join(CHANNELS))
    delta.add_argument("--outdir", default="out")
    delta.add_argument("--stamp", default=None)
    delta_check = sub.add_parser("verify-delta")
    delta_check.add_argument("manifest")
    delta_check.add_argument("--outdir", default=None)
    delta_check.add_argument("--downstream", action="append", default=None)
    recorder = sub.add_parser("record")
    recorder.add_argument("manifest")
    recorder.add_argument("receipts")
    recorder.add_argument("--json", dest="json_path", default=None)
    recorder.add_argument("--markdown", dest="markdown_path", default=None)
    recorder.add_argument("--outdir", default=None)
    args = parser.parse_args(argv)

    db = line.ensure_schema(sqlite3.connect(os.getenv("PORTAL_DB", "data/portal.sqlite")))
    try:
        if args.action == "build":
            manifest = build_all(db, args.start, args.end, args.asof, args.outdir,
                                 tag=args.tag, stamp=args.stamp)
            print(json.dumps(manifest, ensure_ascii=False))
            return 0
        if args.action == "delta":
            manifest = build_delta(db, args.start, args.end, args.asof, args.outdir,
                                   args.downstream, tag=args.tag,
                                   channels=[c.strip().upper() for c in args.channels if c.strip()],
                                   stamp=args.stamp)
            print(json.dumps(dict(tag=manifest["tag"], asof=manifest["asof"],
                                  channels=[dict(channel=e["channel"], events=e["events"],
                                                 key=e["key"], file=e["file"])
                                            for e in manifest["channels"]],
                                  skipped=[e["channel"] for e in manifest["skipped"]],
                                  withdrawn=len(manifest["withdrawn"])), ensure_ascii=False))
            return 0
        if args.action == "verify-delta":
            problems = verify_delta(db, args.manifest, args.outdir,
                                    downstream=args.downstream)
            for problem in problems:
                print(problem, file=sys.stderr)
            print(json.dumps(dict(manifest=args.manifest, ok=not problems,
                                  problems=len(problems)), ensure_ascii=False))
            return 0 if not problems else 2
        if args.action == "record":
            result, problems = record(db, args.manifest, args.receipts,
                                      json_path=args.json_path,
                                      markdown_path=args.markdown_path,
                                      outdir=args.outdir)
            for problem in problems:
                print(problem, file=sys.stderr)
            print(json.dumps(dict(batches=len(result["batches"]),
                                  deliveries=result["totals"]["deliveries"],
                                  confirmed=result["totals"]["confirmed"],
                                  problems=len(problems)), ensure_ascii=False))
            return 0 if not problems else 2
        problems = verify(db, args.manifest, args.outdir)
        for problem in problems:
            print(problem, file=sys.stderr)
        print(json.dumps(dict(manifest=args.manifest, ok=not problems,
                              problems=len(problems)), ensure_ascii=False))
        return 0 if not problems else 2
    except (ValueError, OSError, json.JSONDecodeError, sqlite3.Error) as problem:
        print(f"release.py {args.action} failed: {problem}", file=sys.stderr)
        return 2
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
