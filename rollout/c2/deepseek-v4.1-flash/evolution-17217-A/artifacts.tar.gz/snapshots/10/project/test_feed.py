"""ICS generator for the new product line. Run: python3 project/test_feed.py

Contract (input/contracts/interfaces.md): `project/line.py feed CHANNEL FROM TO
ASOF OUTPUT` writes the full VEVENT set (STATUS:CONFIRMED) for that window; one
VEVENT per UID, and a UID that is already out is updated in place -- same UID,
bumped SEQUENCE -- instead of multiplying.
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import calendar_io
import line

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
PORTFOLIO = os.path.join(INPUT, "portfolio.json")
IDENTITIES = os.path.join(INPUT, "identities.json")

STAMP_A = "20260330T000000Z"
STAMP_B = "20260406T000000Z"


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def input_dir(orders=None):
    folder = tempfile.mkdtemp()
    shutil.copyfile(PORTFOLIO, os.path.join(folder, "portfolio.json"))
    shutil.copyfile(IDENTITIES, os.path.join(folder, "identities.json"))
    os.makedirs(os.path.join(folder, "orders"))
    for name, batch in (orders or {}).items():
        with open(os.path.join(folder, "orders", name), "w", encoding="utf-8") as handle:
            json.dump(batch, handle)
    return folder


def approval(oid, code, channels="A", start="2026-01-01", end="2026-12-31",
             rank=1, clock="16:30", basis="utc", shift=0):
    return dict(id=oid, code=code, channels=channels, start=start, end=end,
                rank=rank, clock=clock, basis=basis, shift_days=shift)


def batch(version, *rows):
    return dict(version=version, rows=list(rows))


def loaded(*batches):
    db = line.ensure_schema(sqlite3.connect(":memory:"))
    line.import_dir(db, input_dir({f"ops-{i}.json": b for i, b in enumerate(batches)}))
    return db


def events(text):
    """[{uid, dtstart, sequence, status, dtstamp}] in file order."""
    out, row = [], None
    for raw in text.replace("\r\n", "\n").split("\n"):
        name, _, value = raw.partition(":")
        if raw == "BEGIN:VEVENT":
            row = {}
        elif raw == "END:VEVENT":
            out.append(row)
            row = None
        elif row is not None:
            row[name] = value
    return out


def write(db, channel, start, end, asof, stamp=None):
    path = os.path.join(tempfile.mkdtemp(), "feed.ics")
    line.feed(db, channel, start, end, asof, path, stamp=stamp)
    with open(path, encoding="utf-8", newline="") as handle:
        return path, handle.read()


# --------------------------------------------------------------------------- #
# shape
# --------------------------------------------------------------------------- #
class FullFeed(unittest.TestCase):
    def setUp(self):
        self.db = loaded(batch(2, approval("B-611", "Q29", "B", clock="16:30"),
                               approval("Z-213", "U56", "CD", start="2026-03-09",
                                        end="2026-03-23", clock="09:15", rank=2)))

    def tearDown(self):
        self.db.close()

    def test_one_confirmed_vevent_per_session(self):
        _, text = write(self.db, "C", "2026-03-09", "2026-03-23", 2, stamp=STAMP_A)
        self.assertTrue(text.startswith("BEGIN:VCALENDAR"))
        self.assertTrue(text.endswith("END:VCALENDAR\r\n"))
        rows = events(text)
        self.assertEqual(len(rows), 12)                       # 4 series x 3 Mondays
        self.assertEqual(len({row["UID"] for row in rows}), 12)
        self.assertEqual({row["STATUS"] for row in rows}, {"CONFIRMED"})

    def test_vevents_follow_the_published_schedule(self):
        _, text = write(self.db, "C", "2026-03-09", "2026-03-09", 2, stamp=STAMP_A)
        rows = {row["UID"]: row for row in events(text)}
        self.assertEqual(rows["line-403-20260309"]["DTSTART"], "20260309T091500Z")   # Z-213
        self.assertEqual(rows["line-401-20260309"]["DTSTART"], "20260309T134500Z")   # wall 09:45 EDT
        self.assertEqual(rows["line-404-20260309"]["DTSTART"], "20260309T013000Z")
        self.assertEqual(rows["line-402-20260309"]["DTSTART"], "20260309T150000Z")

    def test_asof_selects_the_authorised_layer(self):
        _, older = write(self.db, "C", "2026-03-09", "2026-03-09", 1, stamp=STAMP_A)
        _, newer = write(self.db, "C", "2026-03-09", "2026-03-09", 2, stamp=STAMP_A)
        old = {row["UID"]: row["DTSTART"] for row in events(older)}
        new = {row["UID"]: row["DTSTART"] for row in events(newer)}
        self.assertEqual(set(old), set(new))                  # same identities
        self.assertEqual(old["line-403-20260309"], "20260309T072000Z")
        self.assertEqual(new["line-403-20260309"], "20260309T091500Z")

    def test_empty_range_is_a_valid_calendar(self):
        _, text = write(self.db, "C", "2026-03-10", "2026-03-15", 2, stamp=STAMP_A)
        self.assertEqual(events(text), [])
        self.assertIn("BEGIN:VCALENDAR", text)
        self.assertIn("END:VCALENDAR", text)

    def test_dtstamp_comes_from_the_stamp_argument(self):
        _, text = write(self.db, "A", "2026-03-30", "2026-03-30", 2, stamp=STAMP_A)
        self.assertEqual({row["DTSTAMP"] for row in events(text)}, {STAMP_A})


# --------------------------------------------------------------------------- #
# update, not proliferation
# --------------------------------------------------------------------------- #
class UpdateInPlace(unittest.TestCase):
    def setUp(self):
        self.db = loaded(batch(2, approval("B-611", "Q29", "B", clock="16:30")))

    def tearDown(self):
        self.db.close()

    def test_rerun_is_byte_identical(self):
        path, first = write(self.db, "B", "2026-03-09", "2026-03-23", 2, stamp=STAMP_A)
        again = line.feed(self.db, "B", "2026-03-09", "2026-03-23", 2, path, stamp=STAMP_B)
        with open(path, encoding="utf-8", newline="") as handle:
            second = handle.read()
        self.assertEqual(first, second)          # unchanged rows keep their DTSTAMP
        self.assertEqual(again["updated"], 0)

    def test_a_moved_session_updates_the_same_uid(self):
        path, first = write(self.db, "B", "2026-03-09", "2026-03-09", 1, stamp=STAMP_A)
        before = events(first)
        line.import_dir(self.db, input_dir({"ops-1.json": batch(2, approval(
            "B-612", "Q29", "B", clock="17:15", rank=2))}))
        summary = line.feed(self.db, "B", "2026-03-09", "2026-03-09", 2, path, stamp=STAMP_B)
        with open(path, encoding="utf-8", newline="") as handle:
            after = events(handle.read())
        self.assertEqual(len(before), len(after))                     # no extra event
        self.assertEqual(len({row["UID"] for row in after}), len(after))
        self.assertEqual(summary["updated"], 1)
        changed = [row for row in after if row["UID"] == "line-402-20260309"][0]
        self.assertEqual(changed["SEQUENCE"], "1")
        self.assertEqual(changed["DTSTART"], "20260309T171500Z")
        self.assertEqual(changed["DTSTAMP"], STAMP_B)
        for row in after:                                            # nothing else moved
            if row["UID"] != "line-402-20260309":
                self.assertEqual(row["SEQUENCE"], "0")

    def test_repeated_changes_keep_counting_up(self):
        path, _ = write(self.db, "B", "2026-03-09", "2026-03-09", 1, stamp=STAMP_A)
        for step, clock in enumerate(("17:00", "18:00"), start=1):
            line.import_dir(self.db, input_dir({"ops-1.json": batch(2, approval(
                f"B-72{step}", "Q29", "B", clock=clock, rank=2))}))
            line.feed(self.db, "B", "2026-03-09", "2026-03-09", 2, path, stamp=STAMP_B)
        with open(path, encoding="utf-8", newline="") as handle:
            row = [r for r in events(handle.read()) if r["UID"] == "line-402-20260309"][0]
        self.assertEqual(row["SEQUENCE"], "2")
        self.assertEqual(row["DTSTART"], "20260309T180000Z")

    def test_shift_keeps_the_uid_and_moves_the_start(self):
        line.import_dir(self.db, input_dir({"ops-1.json": batch(2, approval(
            "S-1", "Q29", "B", start="2026-03-09", end="2026-03-09", clock="16:30", shift=2))}))
        _, text = write(self.db, "B", "2026-03-09", "2026-03-09", 2, stamp=STAMP_A)
        row = [r for r in events(text) if r["UID"] == "line-402-20260309"][0]
        self.assertEqual(row["UID"], "line-402-20260309")        # original Monday
        self.assertEqual(row["DTSTART"], "20260311T163000Z")      # moved to Wednesday


# --------------------------------------------------------------------------- #
# guards and CLI
# --------------------------------------------------------------------------- #
class Guards(unittest.TestCase):
    def test_two_series_may_not_share_a_uid(self):
        db = line.ensure_schema(sqlite3.connect(":memory:"))
        line.import_dir(db, input_dir())
        db.execute("insert into line_series(code,sid,zone,clock,basis,weekday,imported)"
                   " values('X1','line-401','Europe/London','15:00','utc',0,'')")
        with self.assertRaises(ValueError):
            line.feed(db, "B", "2026-03-09", "2026-03-09", 2,
                      os.path.join(tempfile.mkdtemp(), "clash.ics"), stamp=STAMP_A)
        db.close()

    def test_encode_is_unchanged_for_the_pilot_feeds(self):
        row = dict(uid="K17-20260306", utc="2026-03-06T15:00:00Z", status="CONFIRMED")
        self.assertEqual(calendar_io.encode([row]),
                         "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Schedule Desk//EN\r\n"
                         "BEGIN:VEVENT\r\nUID:K17-20260306\r\nDTSTAMP:20260101T000000Z\r\n"
                         "DTSTART:20260306T150000Z\r\nSTATUS:CONFIRMED\r\nEND:VEVENT\r\n"
                         "END:VCALENDAR\r\n")


class CommandLine(unittest.TestCase):
    def setUp(self):
        self.db_path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        self.env = dict(os.environ, PORTAL_DB=self.db_path)

    def run_line(self, *args):
        return subprocess.run([sys.executable, os.path.join(ROOT, "project", "line.py")] + list(args),
                              cwd=ROOT, env=self.env, capture_output=True, text=True)

    def test_feed_writes_the_file_and_reports(self):
        self.assertEqual(self.run_line("import", INPUT).returncode, 0)
        out = os.path.join(tempfile.mkdtemp(), "feed-B.ics")
        result = self.run_line("feed", "B", "2026-03-09", "2026-03-23", "2", out)
        self.assertEqual(result.returncode, 0, result.stderr)
        summary = json.loads(result.stdout)
        self.assertEqual(summary["events"], 12)
        self.assertEqual(summary["channel"], "B")
        with open(out, encoding="utf-8", newline="") as handle:
            self.assertEqual(len(events(handle.read())), 12)

    def test_bad_arguments_exit_two(self):
        self.assertEqual(self.run_line("import", INPUT).returncode, 0)
        out = os.path.join(tempfile.mkdtemp(), "feed.ics")
        self.assertEqual(self.run_line("feed", "B", "2026-03-09", "2026-03-23", "x", out).returncode, 2)
        self.assertEqual(self.run_line("feed", "AB", "2026-03-09", "2026-03-23", "2", out).returncode, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
