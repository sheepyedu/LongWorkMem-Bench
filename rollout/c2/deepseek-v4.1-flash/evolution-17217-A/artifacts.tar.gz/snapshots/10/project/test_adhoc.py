"""Ad-hoc go-live, version 6: temporary window, one move, cross-channel overrides.

Run: python3 project/test_adhoc.py

The approvals in input/orders/ops-6.json change three things and nothing else:

* T-72 opens a temporary window: Q29 at 17:00 UTC on 2026-03-09 and 2026-03-16
  only, on all four channels;
* V-57 moves one session (N84, original day 2026-03-16) one day earlier, in the
  venue's own wall clock, and the wire identity must survive the move;
* Z-87 overrides U56 on B and D, X-34 overrides J31 on A and C -- the channels
  that are not named keep the base schedule.

Only the difference against the real downstream goes out, so the delta package,
the feed, the portal and the support preview must all agree on the new rules.
"""
import json
import os
import re
import shutil
import sqlite3
import sys
import tempfile
import unittest

import line
import portal
import release

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
LIVE = os.path.join(ROOT, "data", "portal.sqlite")
INDEX = os.path.join(INPUT, "vault", "index.json")
SUPPORT = os.path.join(INPUT, "support.json")
STAMP = "20260330T000000Z"
START, END = "2026-03-02", "2026-03-23"
ASOF = 6
ALSOF = 4          # what support asked before this round
DAYS = ("2026-03-02", "2026-03-09", "2026-03-16", "2026-03-23")

# The four batches that really went out in turn 4 are the downstream state now.
DELTA = {
    "A": {"J31-20260309", "N84-20260316", "Q29-20260309", "Q29-20260316"},
    "B": {"line-401-20260316", "line-402-20260309", "line-402-20260316",
          "line-403-20260316", "line-403-20260323"},
    "C": {"line-401-20260316", "line-402-20260309", "line-402-20260316",
          "line-404-20260309"},
    "D": {"N84-20260316", "Q29-20260309", "Q29-20260316",
          "U56-20260316", "U56-20260323"},
}


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def fresh():
    """A DB holding the real input tree, i.e. versions <= 6."""
    db = line.ensure_schema(sqlite3.connect(":memory:"))
    line.import_dir(db, INPUT)
    return db


def live_copy():
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(LIVE, path)
    return line.ensure_schema(sqlite3.connect(path))


def outdir():
    return tempfile.mkdtemp()


def read(path):
    with open(path, encoding="utf-8", newline="") as handle:
        return handle.read()


def by_code(db, channel, day, asof=ASOF):
    """{(code, day): utc} for one channel over the release window."""
    return {(row["code"], row["day"]): row["utc"]
            for row in line.schedule(db, channel, START, END, asof)}


def ics(text):
    rows, row = {}, None
    for raw in text.replace("\r\n", "\n").split("\n"):
        name, _, value = raw.partition(":")
        if raw == "BEGIN:VEVENT":
            row = {}
        elif raw == "END:VEVENT":
            rows[row["UID"]] = row
            row = None
        elif row is not None:
            row[name] = value
    return rows


def schedule_receipts(db, channels=("A", "B", "C", "D")):
    """A receipts file that claims the downstream holds *everything* now."""
    dump = {}
    for channel in channels:
        rows = {row["uid"]: dict(uid=row["uid"], utc=row["utc"], status="CONFIRMED")
                for row in line.schedule(db, channel, START, END, ASOF)}
        dump[channel] = [dict(turn=6, key="sync", receipt="SYNC-1", rows=rows)]
    path = os.path.join(tempfile.mkdtemp(), "receipts.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(dump, handle)
    return path


# --------------------------------------------------------------------------- #
# the temporary window (T-72)
# --------------------------------------------------------------------------- #
class TemporaryWindow(unittest.TestCase):
    def test_the_window_is_seventeen_hundred_utc_on_both_days(self):
        db = fresh()
        for channel in "ABCD":
            rows = by_code(db, channel, DAYS[1])
            self.assertEqual(rows[("Q29", "2026-03-09")], "2026-03-09T17:00:00+00:00", channel)
            self.assertEqual(rows[("Q29", "2026-03-16")], "2026-03-16T17:00:00+00:00", channel)

    def test_the_window_does_not_reach_the_days_around_it(self):
        db = fresh()
        self.assertEqual(by_code(db, "A", DAYS[0])[("Q29", "2026-03-02")],
                         "2026-03-02T15:00:00+00:00")
        self.assertEqual(by_code(db, "B", DAYS[0])[("Q29", "2026-03-02")],
                         "2026-03-02T16:30:00+00:00")
        self.assertEqual(by_code(db, "A", DAYS[3])[("Q29", "2026-03-23")],
                         "2026-03-23T15:00:00+00:00")
        self.assertEqual(by_code(db, "B", DAYS[3])[("Q29", "2026-03-23")],
                         "2026-03-23T16:30:00+00:00")

    def test_the_window_is_invisible_before_its_own_version(self):
        db = fresh()
        for asof in (4, 5):
            self.assertEqual(by_code(db, "A", DAYS[1], asof)[("Q29", "2026-03-09")],
                             "2026-03-09T15:00:00+00:00", asof)
            self.assertEqual(by_code(db, "B", DAYS[2], asof)[("Q29", "2026-03-16")],
                             "2026-03-16T16:30:00+00:00", asof)

    def test_the_window_beats_the_older_approval_of_the_same_series(self):
        answer = line.explain(fresh(), "B", "Q29", "2026-03-16", ASOF)
        self.assertEqual([item["id"] for item in answer["candidates"]], ["T-72", "B-611"])
        self.assertEqual([item["status"] for item in answer["candidates"]],
                         ["applied", "outranked"])


# --------------------------------------------------------------------------- #
# the single-session move (V-57)
# --------------------------------------------------------------------------- #
class SingleSessionMove(unittest.TestCase):
    def test_the_session_lands_on_the_previous_day(self):
        db = fresh()
        for channel in "ABCD":
            rows = by_code(db, channel, DAYS[2])
            self.assertEqual(rows[("N84", "2026-03-15")], "2026-03-15T13:45:00+00:00", channel)
            self.assertNotIn(("N84", "2026-03-16"), rows, channel)

    def test_the_move_keeps_the_wire_identity(self):
        db = fresh()
        moved = [row for row in line.schedule(db, "A", START, END, ASOF)
                 if row["code"] == "N84" and row["day"] == "2026-03-15"]
        self.assertEqual([row["uid"] for row in moved], ["N84-20260316"])
        answer = line.explain(db, "A", "N84", "2026-03-16", ASOF)
        self.assertEqual((answer["original_day"], answer["day"]), ("2026-03-16", "2026-03-15"))
        self.assertEqual(answer["uid"], "N84-20260316")

    def test_the_move_is_a_wall_clock_move(self):
        answer = line.explain(fresh(), "A", "N84", "2026-03-16", ASOF)
        self.assertEqual((answer["clock"], answer["basis"]), ("09:45", "wall"))
        self.assertIn("09:45", answer["local"])

    def test_the_neighbouring_weeks_do_not_move(self):
        db = fresh()
        rows = by_code(db, "A", DAYS[1])
        self.assertEqual(rows[("N84", "2026-03-09")], "2026-03-09T13:45:00+00:00")
        rows = by_code(db, "A", DAYS[3])
        self.assertEqual(rows[("N84", "2026-03-23")], "2026-03-23T13:45:00+00:00")

    def test_the_feed_updates_the_existing_entry_instead_of_adding_one(self):
        db = fresh()
        before = line.feed_rows(db, "A", START, END, ALSOF, stamp=STAMP)
        after = line.feed_rows(db, "A", START, END, ASOF, stamp=STAMP)
        self.assertEqual(len(before), len(after))
        self.assertEqual(sorted(row["uid"] for row in before), sorted(row["uid"] for row in after))
        moved = [row for row in after if row["uid"] == "N84-20260316"][0]
        self.assertEqual(moved["utc"], "2026-03-15T13:45:00+00:00")
        self.assertEqual(moved["sequence"], 1)
        old = [row for row in before if row["uid"] == "N84-20260316"][0]
        self.assertEqual(old["sequence"], 0)

    def test_an_unchanged_rerun_is_byte_identical(self):
        db = fresh()
        first = release.render(db, "A", START, END, ASOF, stamp=STAMP)[0]
        second = release.render(db, "A", START, END, ASOF, stamp=STAMP)[0]
        self.assertEqual(first, second)


# --------------------------------------------------------------------------- #
# the cross-channel overrides (Z-87, X-34)
# --------------------------------------------------------------------------- #
class CrossChannelOverride(unittest.TestCase):
    def test_u56_moves_only_on_the_named_channels(self):
        db = fresh()
        self.assertEqual(by_code(db, "B", DAYS[2])[("U56", "2026-03-16")],
                         "2026-03-16T10:45:00+00:00")
        self.assertEqual(by_code(db, "B", DAYS[3])[("U56", "2026-03-23")],
                         "2026-03-23T10:45:00+00:00")
        self.assertEqual(by_code(db, "D", DAYS[2])[("U56", "2026-03-16")],
                         "2026-03-16T10:45:00+00:00")
        self.assertEqual(by_code(db, "A", DAYS[2])[("U56", "2026-03-16")],
                         "2026-03-16T07:20:00+00:00")
        self.assertEqual(by_code(db, "C", DAYS[2])[("U56", "2026-03-16")],
                         "2026-03-16T09:15:00+00:00")

    def test_j31_moves_only_on_the_named_channels(self):
        db = fresh()
        self.assertEqual(by_code(db, "A", DAYS[1])[("J31", "2026-03-09")],
                         "2026-03-09T07:10:00+00:00")
        self.assertEqual(by_code(db, "C", DAYS[1])[("J31", "2026-03-09")],
                         "2026-03-09T07:10:00+00:00")
        self.assertEqual(by_code(db, "B", DAYS[1])[("J31", "2026-03-09")],
                         "2026-03-09T01:30:00+00:00")
        self.assertEqual(by_code(db, "D", DAYS[1])[("J31", "2026-03-09")],
                         "2026-03-09T01:30:00+00:00")

    def test_an_override_is_ignored_outside_its_own_window(self):
        db = fresh()
        self.assertEqual(by_code(db, "B", DAYS[0])[("U56", "2026-03-02")],
                         "2026-03-02T07:20:00+00:00")
        self.assertEqual(by_code(db, "A", DAYS[0])[("J31", "2026-03-02")],
                         "2026-03-02T01:30:00+00:00")

    def test_the_other_channel_cannot_see_the_override(self):
        db = fresh()
        answer = line.explain(db, "A", "U56", "2026-03-16", ASOF)
        self.assertEqual(answer["layer"]["kind"], "base")
        self.assertEqual((answer["clock"], answer["basis"]), ("08:20", "wall"))
        self.assertEqual(answer["utc"], "2026-03-16T07:20:00+00:00")
        # C is named by the older approval Z-213 (channels CD) but not by Z-87.
        answer = line.explain(db, "C", "U56", "2026-03-16", ASOF)
        self.assertEqual((answer["layer"]["id"], answer["clock"]), ("Z-213", "09:15"))


# --------------------------------------------------------------------------- #
# the delta against the real downstream
# --------------------------------------------------------------------------- #
class DownstreamDelta(unittest.TestCase):
    def test_only_changed_sessions_are_selected(self):
        db = fresh()
        folder = outdir()
        manifest = release.build_delta(db, START, END, ASOF, folder, [INDEX],
                                       tag="t6", stamp=STAMP)
        built = {entry["channel"]: set(entry["uids"]) for entry in manifest["channels"]}
        self.assertEqual(built, DELTA)
        for entry in manifest["channels"]:
            text = read(os.path.join(folder, entry["file"]))
            self.assertEqual(set(ics(text)), DELTA[entry["channel"]])
            self.assertEqual(entry["events"], len(DELTA[entry["channel"]]))

    def test_every_delivered_instant_is_the_new_one(self):
        db = fresh()
        folder = outdir()
        release.build_delta(db, START, END, ASOF, folder, [INDEX], tag="t6", stamp=STAMP)
        rows = {row["uid"]: row["utc"] for row in line.schedule(db, "B", START, END, ASOF)}
        text = read(os.path.join(folder, "t6-B-20260302-20260323.ics"))
        for uid, event in ics(text).items():
            self.assertEqual(event["DTSTART"], release.stamp_of(rows[uid]))
            self.assertEqual(event["STATUS"], "CONFIRMED")

    def test_the_moved_session_keeps_its_uid_and_bumps_its_sequence(self):
        db = fresh()
        line.feed_rows(db, "A", START, END, ALSOF, stamp="20260323T000000Z")  # what turn 4 sent
        folder = outdir()
        release.build_delta(db, START, END, ASOF, folder, [INDEX], tag="t6", stamp=STAMP)
        text = read(os.path.join(folder, "t6-A-20260302-20260323.ics"))
        moved = ics(text)["N84-20260316"]
        self.assertEqual(moved["DTSTART"], "20260315T134500Z")
        self.assertEqual(moved["SEQUENCE"], "1")

    def test_the_same_instant_written_differently_is_not_a_change(self):
        self.assertTrue(release.same_instant("2026-03-16T15:00:00", "2026-03-16T15:00:00Z"))
        self.assertFalse(release.same_instant("2026-03-15T15:00:00", "2026-03-16T15:00:00Z"))
        self.assertFalse(release.same_instant(None, "2026-03-16T15:00:00Z"))

    def test_a_downstream_that_is_already_synchronised_gets_nothing(self):
        db = fresh()
        receipts = schedule_receipts(db)
        folder = outdir()
        manifest = release.build_delta(db, START, END, ASOF, folder, [receipts],
                                       tag="t6", stamp=STAMP)
        self.assertEqual(manifest["channels"], [])
        self.assertEqual([entry["channel"] for entry in manifest["skipped"]], list("ABCD"))
        self.assertEqual(os.listdir(folder), ["t6-manifest.json"])

    def test_a_delivered_uid_that_is_gone_is_reported_not_silently_dropped(self):
        db = fresh()
        receipts = schedule_receipts(db)
        with open(receipts, encoding="utf-8") as handle:
            dump = json.load(handle)
        dump["A"][0]["rows"]["GONE-20260309"] = dict(uid="GONE-20260309",
                                                     utc="2026-03-09T08:00:00Z",
                                                     status="CONFIRMED")
        with open(receipts, "w", encoding="utf-8") as handle:
            json.dump(dump, handle)
        manifest = release.build_delta(db, START, END, ASOF, outdir(), [receipts],
                                       tag="t6", stamp=STAMP)
        self.assertEqual([(row["channel"], row["uid"]) for row in manifest["withdrawn"]],
                         [("A", "GONE-20260309")])

    def test_the_package_rebuilds_from_the_program(self):
        db = fresh()
        folder = outdir()
        first = release.build_delta(db, START, END, ASOF, folder, [INDEX], tag="t6", stamp=STAMP)
        keys = {entry["channel"]: (entry["key"], entry["sha256"]) for entry in first["channels"]}
        again = release.build_delta(db, START, END, ASOF, folder, [INDEX], tag="t6", stamp=STAMP)
        self.assertEqual({entry["channel"]: (entry["key"], entry["sha256"])
                          for entry in again["channels"]}, keys)

    def test_verification_catches_a_tampered_package(self):
        db = fresh()
        folder = outdir()
        release.build_delta(db, START, END, ASOF, folder, [INDEX], tag="t6", stamp=STAMP)
        path = os.path.join(folder, "t6-manifest.json")
        self.assertEqual(release.verify_delta(db, path, downstream=[INDEX]), [])
        target = os.path.join(folder, "t6-C-20260302-20260323.ics")
        text = read(target)
        with open(target, "w", encoding="utf-8", newline="") as handle:
            handle.write(text.replace("STATUS:CONFIRMED", "STATUS:TENTATIVE", 1))
        self.assertTrue(release.verify_delta(db, path, downstream=[INDEX]))

    def test_verification_catches_a_stale_delta(self):
        db = fresh()
        folder = outdir()
        release.build_delta(db, START, END, ASOF, folder, [INDEX], tag="t6", stamp=STAMP)
        path = os.path.join(folder, "t6-manifest.json")
        receipts = schedule_receipts(db)          # downstream moved on: nothing is a delta
        self.assertTrue(release.verify_delta(db, path, downstream=[receipts]))

    def test_a_key_never_carries_two_different_files(self):
        db = fresh()
        folder = outdir()
        manifest = release.build_delta(db, START, END, ASOF, folder, [INDEX],
                                       tag="t6", stamp=STAMP)
        for entry in manifest["channels"]:
            text = read(os.path.join(folder, entry["file"]))
            self.assertIn(release.digest(text)[:8], entry["key"])
            self.assertNotEqual(entry["key"], "first-" + entry["channel"])


# --------------------------------------------------------------------------- #
# the preview contract (input/contracts/support.md)
# --------------------------------------------------------------------------- #
class PreviewContract(unittest.TestCase):
    def test_answers_are_one_to_one_and_keep_every_question_key(self):
        db = fresh()
        with open(SUPPORT, encoding="utf-8") as handle:
            questions = json.load(handle)
        answers = line.preview_answers(db, questions)
        self.assertEqual(len(answers), len(questions))
        for question, answer in zip(questions, answers):
            self.assertEqual(list(answer)[:len(question)], list(question))
            self.assertEqual({key: answer[key] for key in question}, question)
            self.assertIn("local", answer)

    def test_local_is_london_to_the_minute(self):
        db = fresh()
        with open(SUPPORT, encoding="utf-8") as handle:
            questions = json.load(handle)
        for answer in line.preview_answers(db, questions):
            self.assertRegex(answer["local"], r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$")

    def test_the_asked_version_is_answered_not_the_latest_one(self):
        db = fresh()
        asked = line.preview_answers(db, [dict(channel="A", code="Q29", day="2026-03-16", asof=4)])
        now = line.preview_answers(db, [dict(channel="A", code="Q29", day="2026-03-16", asof=ASOF)])
        self.assertEqual(asked[0]["local"], "2026-03-16 15:00")
        self.assertEqual(now[0]["local"], "2026-03-16 17:00")

    def test_a_batch_default_applies_when_a_request_has_no_version(self):
        db = fresh()
        answer = line.preview_answers(db, [dict(channel="B", code="Q29", day="2026-03-16")],
                                      asof=ALSOF)[0]
        self.assertEqual(answer["local"], "2026-03-16 16:30")
        self.assertEqual(list(answer), ["channel", "code", "day", "local"])

    def test_a_day_without_a_session_keeps_its_keys_and_answers_nothing(self):
        db = fresh()
        answer = line.preview_answers(db, [dict(channel="A", code="Q29", day="2026-03-17", asof=ASOF)])[0]
        self.assertEqual(answer, dict(channel="A", code="Q29", day="2026-03-17",
                                      asof=ASOF, local=None))

    def test_the_answer_file_is_written(self):
        db = fresh()
        target = os.path.join(outdir(), "preview.json")
        summary = line.preview(db, SUPPORT, target)
        self.assertEqual(summary["requests"], 4)
        with open(target, encoding="utf-8") as handle:
            written = json.load(handle)
        self.assertEqual(written, summary["answers"])

    def test_the_move_is_visible_in_the_preview_when_asked_at_six(self):
        db = fresh()
        answer = line.preview_answers(db, [dict(channel="A", code="N84", day="2026-03-16",
                                                asof=ASOF)])[0]
        self.assertEqual(answer["local"], "2026-03-15 13:45")


# --------------------------------------------------------------------------- #
# the portal sees the same rules
# --------------------------------------------------------------------------- #
class PortalReflects(unittest.TestCase):
    def test_v2_defaults_to_everything_registered(self):
        db = live_copy()
        rows = json.loads(portal.v2_json(db, dict(channel="A", **{"from": START, "to": END})))
        self.assertEqual([row["utc"] for row in rows if row["code"] == "Q29"],
                         ["2026-03-02T15:00:00+00:00", "2026-03-09T17:00:00+00:00",
                          "2026-03-16T17:00:00+00:00", "2026-03-23T15:00:00+00:00"])

    def test_v2_keeps_the_old_answer_for_an_old_version(self):
        db = live_copy()
        rows = json.loads(portal.v2_json(db, dict(channel="B", asof=ALSOF,
                                                  **{"from": "2026-03-16", "to": "2026-03-16"})))
        self.assertEqual([(row["code"], row["utc"]) for row in rows],
                         [("J31", "2026-03-16T01:30:00+00:00"),
                          ("N84", "2026-03-16T13:45:00+00:00"),
                          ("Q29", "2026-03-16T16:30:00+00:00"),
                          ("U56", "2026-03-16T07:20:00+00:00")])

    def test_when_shows_the_moved_day_and_the_layer_behind_it(self):
        db = live_copy()
        # At the version this round shipped, V-57 moves the session to the Sunday.
        answer = json.loads(portal.when_json(db, dict(channel="B", code="N84",
                                                      day="2026-03-16", asof=6)))
        self.assertTrue(answer["found"])
        self.assertEqual((answer["day"], answer["uid"]), ("2026-03-15", "line-401-20260316"))
        self.assertEqual((answer["layer"]["id"], answer["layer"]["shift_days"]), ("V-57", -1))
        # Without an asof the answer follows the latest version, where the newer
        # rank-7 approval A-82 wins and puts the session back on its own Monday.
        answer = json.loads(portal.when_json(db, dict(channel="B", code="N84", day="2026-03-16")))
        self.assertEqual((answer["day"], answer["uid"]), ("2026-03-16", "line-401-20260316"))
        self.assertEqual((answer["layer"]["id"], answer["layer"]["shift_days"]), ("A-82", 0))

    def test_when_shows_the_cross_channel_override(self):
        db = live_copy()
        answer = json.loads(portal.when_json(db, dict(channel="D", code="U56", day="2026-03-16")))
        self.assertEqual((answer["layer"]["id"], answer["utc"]),
                         ("Z-87", "2026-03-16T10:45:00+00:00"))
        # 2026-03-23 on D is a version-7 question: Z-87 is withdrawn there.
        answer = json.loads(portal.when_json(db, dict(channel="D", code="U56",
                                                      day="2026-03-23", asof=6)))
        self.assertEqual((answer["layer"]["id"], answer["utc"]),
                         ("Z-87", "2026-03-23T10:45:00+00:00"))

    def test_the_old_portal_tables_are_untouched_by_the_new_approvals(self):
        db = live_copy()
        self.assertEqual(db.execute("select count(*) from events").fetchone()[0], 4)
        self.assertEqual(db.execute("select count(*) from bookings").fetchone()[0], 4)
        self.assertIn(b"M42-20260306",
                      db.execute("select group_concat(uid) from events").fetchone()[0].encode())


if __name__ == "__main__":
    unittest.main(verbosity=2)
