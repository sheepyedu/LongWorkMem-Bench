"""Dispute inquiry: what was due, what was received, what stayed open.

Run: python3 project/test_inquiry.py

The customer disputes earlier releases, so every answer has to be reproducible
from the record alone: `due` follows the policy that was known at the version in
the question, `received` only uses receipt batches that had actually arrived by
then (`turn <= asof`, archive included), and `pending` is nothing more than
"those two instants differ".  The tool is read only: it must not send, not
re-publish and not touch the database or the feed bookkeeping.
"""
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import line

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
OUT = os.path.join(ROOT, "out")
QUESTIONS = os.path.join(INPUT, "questions.json")
RECEIPTS = os.path.join(OUT, "receipts-all.json")
ANSWER = os.path.join(OUT, "inquiry.json")
KEYS = ["channel", "code", "day", "asof", "due", "received", "pending"]


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def read(path):
    with open(path, encoding="utf-8", newline="") as handle:
        return handle.read()


def load(path):
    return json.loads(read(path))


def questions():
    return load(QUESTIONS)


def receipts():
    return load(RECEIPTS)


def fresh_db():
    db = line.ensure_schema(sqlite3.connect(":memory:"))
    line.import_dir(db, INPUT)
    return db


def answers_of(channel, code, day):
    return {(row["asof"]): row for row in load(ANSWER)
            if (row["channel"], row["code"], row["day"]) == (channel, code, day)}


def digest(path):
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


# --------------------------------------------------------------------------- #
# the delivered answer set
# --------------------------------------------------------------------------- #
class DeliveredAnswers(unittest.TestCase):
    def setUp(self):
        self.rows = load(ANSWER)

    def test_one_row_per_question_in_the_order_asked(self):
        asked = questions()
        self.assertEqual(len(self.rows), len(asked))
        self.assertEqual([{key: row[key] for key in ("channel", "code", "day", "asof")} for row in self.rows],
                         [{"channel": q["channel"], "code": q["code"], "day": q["day"], "asof": q["asof"]}
                          for q in asked])

    def test_every_row_has_exactly_the_agreed_columns(self):
        for row in self.rows:
            self.assertEqual(list(row.keys()), KEYS, row)

    def test_every_instant_is_utc_iso8601(self):
        for row in self.rows:
            for key in ("due", "received"):
                value = row[key]
                if value is None:
                    continue
                self.assertTrue(value.endswith("Z"), (key, value))
                line._instant(value)                      # parses, or raises
            self.assertIsInstance(row["pending"], bool)

    def test_pending_is_exactly_the_two_instants_differing(self):
        for row in self.rows:
            same = line.same_instant(row["due"], row["received"])
            self.assertEqual(row["pending"], not same, row)

    def test_the_answer_file_reproduces_byte_for_byte(self):
        db = fresh_db()
        try:
            summary = line.history(db, QUESTIONS, RECEIPTS, ANSWER + ".check")
            self.assertEqual(summary["questions"], len(self.rows))
            self.assertEqual(read(ANSWER + ".check"), read(ANSWER))
        finally:
            if os.path.exists(ANSWER + ".check"):
                os.remove(ANSWER + ".check")


# --------------------------------------------------------------------------- #
# due: the policy known at that version
# --------------------------------------------------------------------------- #
class Due(unittest.TestCase):
    def test_due_follows_the_version_in_the_question(self):
        rows = answers_of("B", "N84", "2026-03-16")
        self.assertEqual(rows[4]["due"], "2026-03-16T13:45:00Z")   # base Monday
        self.assertEqual(rows[6]["due"], "2026-03-15T13:45:00Z")   # V-57 moved it
        self.assertEqual(rows[7]["due"], "2026-03-15T13:45:00Z")
        self.assertEqual(rows[8]["due"], "2026-03-15T13:45:00Z")
        self.assertEqual(rows[9]["due"], "2026-03-16T12:50:00Z")   # A-82 moved it back

    def test_due_is_the_same_policy_the_support_desk_quotes(self):
        db = fresh_db()
        for row in load(ANSWER):
            answer = line.explain(db, row["channel"], row["code"], row["day"], row["asof"])
            self.assertIsNotNone(answer, row)
            self.assertEqual(row["due"], line._wire(answer["utc"]), row)

    def test_a_day_with_no_session_has_no_due(self):
        db = fresh_db()
        rows = line.history_answers(db, [
            dict(channel="A", code="Q29", day="2026-03-17", asof=4),   # a Tuesday
            dict(channel="A", code="Q29", day="2026-02-23", asof=4)],  # before the base schedule
            {"A": []})
        self.assertEqual([(row["due"], row["received"], row["pending"]) for row in rows],
                         [(None, None, False), (None, None, False)])


# --------------------------------------------------------------------------- #
# received: only what the record shows had arrived
# --------------------------------------------------------------------------- #
class Received(unittest.TestCase):
    def test_received_only_uses_batches_that_had_arrived(self):
        rows = answers_of("C", "Q29", "2026-03-16")
        self.assertEqual(rows[4]["received"], "2026-03-16T15:00:00Z")
        self.assertEqual(rows[6]["received"], "2026-03-16T17:00:00Z")   # turn 6 moved it
        self.assertEqual(rows[7]["received"], "2026-03-16T17:00:00Z")   # turn 8 not yet
        self.assertEqual(rows[8]["received"], "2026-03-16T15:00:00Z")   # turn 8 arrived

    def test_the_archive_counts_as_received(self):
        rows = answers_of("A", "N84", "2026-03-16")
        self.assertEqual(rows[4]["received"], "2026-03-16T13:45:00Z")   # the sealed turn-4 batch
        db = fresh_db()
        without_archive = {channel: [batch for batch in batches if batch["turn"] != 4]
                           for channel, batches in receipts().items()}
        answer = line.history_answers(db, [dict(channel="A", code="N84", day="2026-03-16", asof=4)],
                                      without_archive)[0]
        self.assertIsNone(answer["received"], "the vault batch is what makes this received")
        self.assertTrue(answer["pending"])

    def test_nothing_received_is_null_not_a_guess(self):
        for asof in (4, 6, 7, 8):
            row = answers_of("D", "N84", "2026-11-02")[asof]
            self.assertIsNone(row["received"], asof)
            self.assertTrue(row["pending"], asof)
        row = answers_of("D", "N84", "2026-11-02")[9]
        self.assertEqual((row["received"], row["pending"]), ("2026-11-02T13:30:00Z", False))

    def test_received_never_outruns_the_channel_it_belongs_to(self):
        db = fresh_db()
        answer = line.history_answers(db, [dict(channel="B", code="N84", day="2026-03-16", asof=9)],
                                      {"A": receipts()["A"]})[0]
        self.assertIsNone(answer["received"])
        self.assertTrue(answer["pending"])

    def test_receipts_must_be_keyed_by_channel(self):
        db = fresh_db()
        with self.assertRaises(ValueError):
            line.history_answers(db, questions()[:1], receipts()["A"])


# --------------------------------------------------------------------------- #
# what stayed open, per version
# --------------------------------------------------------------------------- #
class OpenItems(unittest.TestCase):
    def test_open_items_at_the_change_committee_version(self):
        # Version 7 withdrew the approvals that had moved these sessions: the
        # policy moved back, the subscribers still held the old instants.
        pending = {(row["channel"], row["code"], row["day"]) for row in load(ANSWER)
                   if row["asof"] == 7 and row["pending"]}
        self.assertEqual(pending, {("A", "N84", "2026-11-02"), ("B", "N84", "2026-11-02"),
                                   ("C", "N84", "2026-11-02"), ("D", "N84", "2026-11-02"),
                                   ("B", "Q29", "2026-03-16"), ("C", "Q29", "2026-03-16"),
                                   ("D", "Q29", "2026-03-16"), ("D", "U56", "2026-03-23")})

    def test_the_revocation_gap_was_closed_by_the_next_batch(self):
        for channel, code, day in (("B", "Q29", "2026-03-16"), ("C", "Q29", "2026-03-16"),
                                   ("D", "Q29", "2026-03-16"), ("D", "U56", "2026-03-23")):
            self.assertTrue(answers_of(channel, code, day)[7]["pending"])
            self.assertFalse(answers_of(channel, code, day)[8]["pending"])

    def test_the_one_item_still_open_at_the_latest_version(self):
        pending = [(row["channel"], row["code"], row["day"], row["due"], row["received"])
                   for row in load(ANSWER) if row["asof"] == 9 and row["pending"]]
        self.assertEqual(pending, [("B", "N84", "2026-03-16",
                                    "2026-03-16T12:50:00Z", "2026-03-15T13:45:00Z")])

    def test_the_autumn_sessions_were_open_until_they_were_released(self):
        rows = answers_of("A", "N84", "2026-11-02")
        self.assertEqual([rows[asof]["pending"] for asof in (4, 6, 7, 8, 9)],
                         [True, True, True, True, False])
        self.assertEqual(rows[9]["received"], "2026-11-02T14:45:00Z")


# --------------------------------------------------------------------------- #
# the tool is read only and rerunnable
# --------------------------------------------------------------------------- #
class ReadOnly(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.mkdtemp()
        self.db = os.path.join(self.folder, "record.sqlite")
        shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), self.db)

    def tearDown(self):
        shutil.rmtree(self.folder, ignore_errors=True)

    def snapshot(self):
        db = sqlite3.connect(f"file:{self.db}?mode=ro", uri=True)
        try:
            feed = db.execute("select uid, sequence, stamp from line_feed order by uid").fetchall()
            counts = {name: db.execute(f'select count(*) from "{name}"').fetchone()[0]
                      for name in ("events", "bookings", "line_order", "line_identity", "line_feed")}
        finally:
            db.close()
        return digest(self.db), counts, feed

    def run_cli(self, output):
        env = dict(os.environ, PORTAL_DB=self.db)
        return subprocess.run([sys.executable, os.path.join(ROOT, "project", "line.py"),
                               "history", QUESTIONS, RECEIPTS, output],
                              capture_output=True, text=True, env=env, cwd=ROOT)

    def test_the_record_is_untouched(self):
        before = self.snapshot()
        result = self.run_cli(os.path.join(self.folder, "inquiry.json"))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.snapshot(), before)
        self.assertFalse(os.path.exists(self.db + "-journal"))
        self.assertFalse(os.path.exists(self.db + "-wal"))

    def test_the_same_question_gets_the_same_answer_twice(self):
        first = os.path.join(self.folder, "first.json")
        second = os.path.join(self.folder, "second.json")
        self.assertEqual(self.run_cli(first).returncode, 0)
        self.assertEqual(self.run_cli(second).returncode, 0)
        self.assertEqual(read(first), read(second))
        self.assertEqual(read(first), read(ANSWER))

    def test_the_run_reports_what_it_found(self):
        result = self.run_cli(os.path.join(self.folder, "inquiry.json"))
        summary = json.loads(result.stdout)
        self.assertEqual(summary["questions"], 80)
        self.assertEqual(summary["pending"], 21)
        self.assertEqual(summary["due"], 80)
        self.assertEqual(summary["received"], 64)
        self.assertEqual(summary["channels"], ["A", "B", "C", "D"])


if __name__ == "__main__":
    sys.exit(unittest.main(verbosity=2))
