"""Read-only support look-ups, cross-checked against the archived deliveries.

    python3 project/support.py preview QUESTIONS [--index input/vault/index.json]
                                        [--json out/PREVIEW.json] [--markdown notes/NOTE.md]

QUESTIONS is a JSON list of `{channel, code, day, asof}` (input/support.json).
For each one the preview states what the *venue* sees (`local`, in the series'
own zone), the instant in UTC, the UID the subscriber holds, and the layer that
decided it -- then reads the archived delivery batches through the archive index
and reports whether the archive agrees.

Nothing here writes to the database and nothing is published: `publish` is not
imported, the schedule core is called read-only, and the preview carries
`read_only: true` / `published: false`.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import line

DEFAULT_INDEX = os.path.join("input", "vault", "index.json")


# --------------------------------------------------------------------------- #
# inputs
# --------------------------------------------------------------------------- #
def load_questions(path):
    with open(path, encoding="utf-8") as handle:
        questions = json.load(handle)
    if isinstance(questions, dict) and isinstance(questions.get("questions"), list):
        questions = questions["questions"]
    if not isinstance(questions, list) or not questions:
        raise ValueError(f"{path}: expected a non-empty list of questions")
    return questions


def load_index(path):
    """-> {channel: absolute batch path}, resolved from the archive index."""
    with open(path, encoding="utf-8") as handle:
        index = json.load(handle)
    roots = [os.path.dirname(os.path.abspath(path)),
             os.path.dirname(os.path.dirname(os.path.abspath(path))),
             os.getcwd()]
    resolved = {}
    for channel, entry in index.items():
        for root in roots:
            candidate = entry if os.path.isabs(entry) else os.path.join(root, entry)
            if os.path.exists(candidate):
                resolved[str(channel).strip().upper()] = os.path.abspath(candidate)
                break
    return resolved


def archive_batches(path):
    with open(path, encoding="utf-8") as handle:
        batches = json.load(handle)
    if isinstance(batches, dict):
        batches = [batches]
    return batches


def archive_lookup(index, channel, uid):
    """What the archived batches say a channel holds for one UID; -> entry or None."""
    path = index.get(channel)
    if path is None:
        return None
    for batch in archive_batches(path):
        row = (batch.get("rows") or {}).get(uid)
        if row is not None:
            return dict(source=path, receipt=batch.get("receipt"), key=batch.get("key"),
                        turn=batch.get("turn"), utc=row.get("utc"), status=row.get("status"))
    return None


# --------------------------------------------------------------------------- #
# answers
# --------------------------------------------------------------------------- #
def instant(text):
    if text is None:
        return None
    return datetime.fromisoformat(str(text).replace("Z", "+00:00")).astimezone(timezone.utc)


def answer_one(db, question, index):
    """-> one preview entry (question, engine answer, archive finding, verdict)."""
    channel = str(question.get("channel", "")).strip().upper()
    code = str(question.get("code", "")).strip()
    day = question.get("day")
    asof = question.get("asof")
    asked = dict(channel=channel, code=code, day=day, asof=asof)

    found = line.explain(db, channel, code, day, asof if asof is not None else line.latest_version(db))
    entry = dict(asked=asked, answer=found, archive=None, agree=None, note="")
    if found is None:
        entry["note"] = "该系列在该原定日没有场次，需向客服确认客户看到的是哪一场"
        return entry

    archived = archive_lookup(index, channel, found["uid"])
    entry["archive"] = archived
    if archived is None:
        entry["note"] = "档案索引里没有该端的这份 UID，无法与已投递资料核对"
        return entry
    same = instant(archived.get("utc")) == instant(found["utc"])
    same_status = (archived.get("status") or "").upper() == "CONFIRMED"
    entry["agree"] = bool(same and same_status)
    if entry["agree"]:
        entry["note"] = "归档投递与该场次一致"
    elif not same:
        entry["note"] = f"归档投递是 {archived.get('utc')}，与现在的 {found['utc']} 不一致"
    else:
        entry["note"] = f"归档状态是 {archived.get('status')}，不是 CONFIRMED"
    return entry


def fingerprint(path):
    """sha256 of the database consulted, so the preview says what it looked at."""
    try:
        with open(path, "rb") as handle:
            return hashlib.sha256(handle.read()).hexdigest()
    except OSError:
        return None


def preview(db, questions, index_path=DEFAULT_INDEX, db_path=None):
    """-> (preview dict, problems list)."""
    index = load_index(index_path)
    entries, problems = [], []
    for question in questions:
        entry = answer_one(db, question, index)
        entries.append(entry)
        if entry["answer"] is None or entry["agree"] is not True:
            problems.append(f"{entry['asked']['channel']}/{entry['asked']['code']}/"
                            f"{entry['asked']['day']}: {entry['note']}")
    result = dict(read_only=True, published=False,
                  questions_file=None, index=os.path.abspath(index_path),
                  database=os.path.abspath(db_path) if db_path else None,
                  database_sha256=fingerprint(db_path) if db_path else None,
                  entries=entries,
                  totals=dict(asked=len(entries),
                              answered=sum(1 for e in entries if e["answer"] is not None),
                              archive_agrees=sum(1 for e in entries if e["agree"] is True),
                              problems=len(problems)))
    return result, problems


def render_markdown(result, questions_file=None):
    rows = result["entries"]
    header = rows[0]["answer"]["day"] if rows and rows[0]["answer"] else "—"
    lines = [f"# 客服核对预览 · 场次日 {header}", "",
             "* 只读查询，未通知客户、未投递（`read_only: true` / `published: false`）",
             f"* 问题清单：`{questions_file or result.get('questions_file') or '—'}`",
             f"* 档案索引：`{os.path.relpath(result['index'])}`",
             f"* 数据库：`{os.path.basename(result['database'] or '—')}`"
             f"（sha256 `{(result['database_sha256'] or '—')[:12]}…`）",
             f"* 提问 {result['totals']['asked']} 条 / 有场次 {result['totals']['answered']} 条 / "
             f"与归档一致 {result['totals']['archive_agrees']} 条", "",
             "| 端 | 系列 | 场次日 | 门店当地时间 | UTC | UID | 归档 | 结论 |",
             "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for entry in rows:
        asked, answer, archive = entry["asked"], entry["answer"], entry["archive"]
        if answer is None:
            lines.append(f"| {asked['channel']} | {asked['code']} | {asked['day']} | — | — | — | — | 无场次 |")
            continue
        verdict = "一致" if entry["agree"] else ("不一致" if entry["agree"] is False else "无法核对")
        lines.append(f"| {asked['channel']} | {asked['code']} | {answer['original_day']} | "
                     f"{answer['local']} | {answer['utc']} | `{answer['uid']}` | "
                     f"{archive['receipt'] if archive else '—'} | {verdict} |")
    for index, entry in enumerate(rows, start=1):
        asked, answer = entry["asked"], entry["answer"]
        lines.extend(["", f"## {index}. {asked['channel']} 端 · {asked['code']} · {asked['day']}"
                           f"（asof {answer['asof'] if answer else asked['asof']}）", ""])
        if answer is None:
            lines.append(f"* 未找到场次：{entry['note']}")
            continue
        layer = answer["layer"]
        who = ("基础周排期" if layer["kind"] == "base"
               else f"批准 `{layer['id']}`（v{layer['version']}，rank {layer['rank']}）")
        lines.extend([
            f"* **门店所见：{answer['local']}**（UTC {answer['utc']}，时区 {answer['zone']}）",
            f"* UID：`{answer['uid']}`" + ("" if answer["day"] == answer["original_day"]
                                          else f"（原定日 {answer['original_day']}，已改到 {answer['day']}）"),
            f"* 生效层：{who}；钟点 {answer['clock']}，基准 {answer['basis']}",
        ])
        if entry["archive"]:
            lines.append(f"* 归档核对：`{entry['archive']['receipt']}` / `{entry['archive']['key']}` / "
                         f"{entry['archive']['utc']} / {entry['archive']['status']} → "
                         f"{'一致' if entry['agree'] else '不一致'}")
        else:
            lines.append(f"* 归档核对：{entry['note']}")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main(argv=None):
    parser = argparse.ArgumentParser(prog="support.py")
    sub = parser.add_subparsers(dest="action", required=True)
    viewer = sub.add_parser("preview")
    viewer.add_argument("questions")
    viewer.add_argument("--index", default=DEFAULT_INDEX)
    viewer.add_argument("--json", dest="json_path", default=None)
    viewer.add_argument("--markdown", dest="markdown_path", default=None)
    args = parser.parse_args(argv)

    db_path = os.getenv("PORTAL_DB", "data/portal.sqlite")
    db = line.ensure_schema(sqlite3.connect(db_path))
    try:
        result, problems = preview(db, load_questions(args.questions), args.index, db_path=db_path)
        result["questions_file"] = args.questions
        if args.json_path:
            os.makedirs(os.path.dirname(os.path.abspath(args.json_path)), exist_ok=True)
            with open(args.json_path, "w", encoding="utf-8") as handle:
                handle.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        if args.markdown_path:
            os.makedirs(os.path.dirname(os.path.abspath(args.markdown_path)), exist_ok=True)
            with open(args.markdown_path, "w", encoding="utf-8") as handle:
                handle.write(render_markdown(result, args.questions))
        for problem in problems:
            print(problem, file=sys.stderr)
        print(json.dumps(result["totals"], ensure_ascii=False))
        return 0 if not problems else 2
    except (ValueError, OSError, json.JSONDecodeError, sqlite3.Error) as problem:
        print(f"support.py {args.action} failed: {problem}", file=sys.stderr)
        return 2
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
