"""New product line schedule core. Run: python3 project/test_line.py

Covers the re-entrant import (out-of-order / re-sent batches, immutable ids) and
the query core (base weekly Monday schedule, business-day range, known-version
ASOF, per-channel approvals, (rank,version,id) precedence, revocation fallback,
and shift_days), plus isolation from the old portal.
"""
import json
import os
import shutil
import sqlite3
import tempfile
import unittest

import line
import portal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
PORTFOLIO = os.path.join(INPUT, "portfolio.json")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def fresh():
    return line.ensure_schema(sqlite3.connect(":memory:"))


def sent_orders():
    """Every authorisation id currently sitting in input/orders/."""
    ids = []
    folder = os.path.join(INPUT, "orders")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".json"):
            with open(os.path.join(folder, name), encoding="utf-8") as handle:
                ids.extend(row["id"] for row in json.load(handle)["rows"])
    return ids


def input_dir(orders, portfolio=PORTFOLIO):
    """A throw-away INPUT_DIR with the real portfolio and the given batches."""
    folder = tempfile.mkdtemp()
    shutil.copyfile(portfolio, os.path.join(folder, "portfolio.json"))
    os.makedirs(os.path.join(folder, "orders"))
    for name, batch in orders.items():
        with open(os.path.join(folder, "orders", name), "w", encoding="utf-8") as handle:
            json.dump(batch, handle, ensure_ascii=False)
    return folder


def index(rows):
    return {(row["code"], row["day"]): row["utc"] for row in rows}


def one(rows, code, day):
    return index(rows).get((code, day))


def approval(oid, code, channels="A", start="2026-01-01", end="2026-12-31",
             rank=1, clock="16:30", basis="utc", shift=0):
    return dict(id=oid, code=code, channels=channels, start=start, end=end,
                rank=rank, clock=clock, basis=basis, shift_days=shift)


def revoke(oid, target, channels="A", start=None, end=None):
    row = dict(id=oid, target=target, channels=channels)
    if start is not None:
        row["start"] = start
    if end is not None:
        row["end"] = end
    return row


# --------------------------------------------------------------------------- #
# import is re-entrant
# --------------------------------------------------------------------------- #
class ImportReentrant(unittest.TestCase):
    def test_real_input_imports_then_repeats_cleanly(self):
        db = fresh()
        expected = sent_orders()          # every id in input/orders/*.json, this round included
        first = line.import_dir(db, INPUT)
        self.assertEqual({p["code"] for p in first["portfolio"]}, {"N84", "Q29", "U56", "J31"})
        self.assertTrue(all(p["action"] == "imported" for p in first["portfolio"]))
        self.assertEqual({o["id"] for o in first["orders"]}, set(expected))
        self.assertTrue(all(o["action"] == "imported" for o in first["orders"]))
        self.assertEqual(db.execute("select count(*) from line_series").fetchone()[0], 4)
        self.assertEqual(db.execute("select count(*) from line_order").fetchone()[0], len(expected))

        again = line.import_dir(db, INPUT)
        self.assertTrue(all(p["action"] == "unchanged" for p in again["portfolio"]))
        self.assertTrue(all(o["action"] == "duplicate" for o in again["orders"]))
        self.assertEqual(db.execute("select count(*) from line_order").fetchone()[0], len(expected))

    def test_out_of_order_batches_match(self):
        v2 = {"version": 2, "rows": [approval("hi", "Q29", "B", rank=2, clock="16:30"),
                                     approval("lo", "Q29", "B", rank=1, clock="14:00")]}
        v3 = {"version": 3, "rows": [revoke("r1", "hi", "B", "2026-03-09", "2026-03-09")]}
        first = input_dir({"a-v2.json": v2, "b-v3.json": v3})
        second = input_dir({"a-v3.json": v3, "b-v2.json": v2})
        databases = []
        for folder in (first, second):
            db = fresh()
            line.import_dir(db, folder)
            databases.append(db)
        for asof in (2, 3):
            self.assertEqual(line.query(databases[0], "B", "2026-03-09", "2026-03-09", asof),
                             line.query(databases[1], "B", "2026-03-09", "2026-03-09", asof))

    def test_re_sent_id_with_different_content_is_refused(self):
        db = fresh()
        line.import_dir(db, input_dir({"a.json": {"version": 2,
                                                  "rows": [approval("x", "Q29", "B", clock="16:30")]}}))
        bad = input_dir({"b.json": {"version": 2,
                                    "rows": [approval("x", "Q29", "B", clock="17:30")]}})
        with self.assertRaises(ValueError):
            line.import_dir(db, bad)
        # the first registration survived the failed batch
        self.assertEqual(line.query(db, "B", "2026-03-09", "2026-03-09", 2)[0]["code"], "J31")
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 2), "Q29", "2026-03-09"),
                         "2026-03-09T16:30:00+00:00")

    def test_per_row_version_overrides_the_file_version(self):
        db = fresh()
        row = approval("future", "Q29", "B", clock="18:00")
        row["version"] = 3
        line.import_dir(db, input_dir({"o.json": {"version": 2, "rows": [row]}}))
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 2), "Q29", "2026-03-09"),
                         "2026-03-09T15:00:00+00:00")   # version 3 not visible at ASOF 2
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 3), "Q29", "2026-03-09"),
                         "2026-03-09T18:00:00+00:00")

    def test_unknown_zone_and_basis_are_rejected(self):
        folder = tempfile.mkdtemp()
        with open(os.path.join(folder, "portfolio.json"), "w") as handle:
            json.dump([{"code": "X1", "zone": "Mars/Olympus", "clock": "10:00",
                        "basis": "wall", "weekday": 0}], handle)
        os.makedirs(os.path.join(folder, "orders"))
        with self.assertRaises(ValueError):
            line.import_dir(fresh(), folder)
        with open(os.path.join(folder, "portfolio.json"), "w") as handle:
            json.dump([{"code": "X1", "zone": "UTC", "clock": "10:00",
                        "basis": "moon", "weekday": 0}], handle)
        with self.assertRaises(ValueError):
            line.import_dir(fresh(), folder)


# --------------------------------------------------------------------------- #
# base schedule
# --------------------------------------------------------------------------- #
class BaseSchedule(unittest.TestCase):
    def setUp(self):
        self.db = fresh()
        line.import_dir(self.db, INPUT)

    def test_weeklies_start_2026_03_02_and_are_mondays(self):
        rows = line.query(self.db, "A", "2026-02-01", "2026-03-16", 2)
        days = sorted({row["day"] for row in rows})
        self.assertEqual(days, ["2026-03-02", "2026-03-09", "2026-03-16"])
        self.assertTrue(all(portal.as_date(day).weekday() == 0 for day in days))
        for day in days:
            self.assertEqual({row["code"] for row in rows if row["day"] == day},
                             {"N84", "Q29", "U56", "J31"})

    def test_range_endpoints_are_inclusive(self):
        rows = line.query(self.db, "A", "2026-03-02", "2026-03-02", 2)
        self.assertEqual(len(rows), 4)
        self.assertEqual({row["day"] for row in rows}, {"2026-03-02"})
        self.assertEqual(line.query(self.db, "A", "2026-03-03", "2026-03-08", 2), [])

    def test_wall_and_utc_bases_across_dst(self):
        rows = index(line.query(self.db, "A", "2026-03-02", "2026-03-30", 2))
        self.assertEqual(rows[("N84", "2026-03-02")], "2026-03-02T14:45:00+00:00")  # EST
        self.assertEqual(rows[("N84", "2026-03-09")], "2026-03-09T13:45:00+00:00")  # EDT
        self.assertEqual(rows[("N84", "2026-03-30")], "2026-03-30T13:45:00+00:00")
        self.assertEqual(rows[("U56", "2026-03-02")], "2026-03-02T07:20:00+00:00")  # CET
        self.assertEqual(rows[("U56", "2026-03-30")], "2026-03-30T06:20:00+00:00")  # CEST
        self.assertEqual(rows[("Q29", "2026-03-02")], "2026-03-02T15:00:00+00:00")  # utc basis
        self.assertEqual(rows[("J31", "2026-03-30")], "2026-03-30T01:30:00+00:00")


# --------------------------------------------------------------------------- #
# approvals, versions, precedence
# --------------------------------------------------------------------------- #
class Approvals(unittest.TestCase):
    def test_channel_and_asof_gating_on_real_orders(self):
        db = fresh()
        line.import_dir(db, INPUT)
        # B-611 only reaches channel B and only from version 2
        self.assertEqual(one(line.query(db, "B", "2026-03-02", "2026-03-02", 1), "Q29", "2026-03-02"),
                         "2026-03-02T15:00:00+00:00")
        self.assertEqual(one(line.query(db, "B", "2026-03-02", "2026-03-02", 2), "Q29", "2026-03-02"),
                         "2026-03-02T16:30:00+00:00")
        self.assertEqual(one(line.query(db, "A", "2026-03-02", "2026-03-02", 2), "Q29", "2026-03-02"),
                         "2026-03-02T15:00:00+00:00")
        # Z-213 covers U56 on C/D only inside 2026-03-09..2026-03-23
        self.assertEqual(one(line.query(db, "C", "2026-03-09", "2026-03-09", 1), "U56", "2026-03-09"),
                         "2026-03-09T07:20:00+00:00")
        self.assertEqual(one(line.query(db, "C", "2026-03-09", "2026-03-09", 2), "U56", "2026-03-09"),
                         "2026-03-09T09:15:00+00:00")
        self.assertEqual(one(line.query(db, "C", "2026-03-30", "2026-03-30", 2), "U56", "2026-03-30"),
                         "2026-03-30T06:20:00+00:00")   # window closed -> base
        self.assertEqual(one(line.query(db, "A", "2026-03-09", "2026-03-09", 2), "U56", "2026-03-09"),
                         "2026-03-09T07:20:00+00:00")

    def test_rank_then_version_then_id(self):
        rows = [approval("r1", "Q29", "B", rank=1, clock="13:00"),
                approval("v2a", "Q29", "B", rank=2, clock="16:00"),
                approval("v3", "Q29", "B", rank=2, clock="16:20")]
        rows[1]["version"] = 2
        db = fresh()
        # version comes from the file, the per-row 'version' key is ignored
        line.import_dir(db, input_dir({"o.json": {"version": 2, "rows": rows[:2]}}))
        line.import_dir(db, input_dir({"o.json": {"version": 3, "rows": [rows[2]]}}))
        # rank 2 beats rank 1; among rank 2, version 3 beats version 2
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 3), "Q29", "2026-03-09"),
                         "2026-03-09T16:20:00+00:00")

    def test_id_breaks_a_rank_and_version_tie(self):
        db = fresh()
        line.import_dir(db, input_dir({"o.json": {"version": 2, "rows": [
            approval("aaa", "Q29", "B", rank=2, clock="16:00"),
            approval("zzz", "Q29", "B", rank=2, clock="16:10")]}}))
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 2), "Q29", "2026-03-09"),
                         "2026-03-09T16:10:00+00:00")


# --------------------------------------------------------------------------- #
# revocation
# --------------------------------------------------------------------------- #
class Revocation(unittest.TestCase):
    def build(self, approvals, revocations, version=3):
        db = fresh()
        line.import_dir(db, input_dir({"a.json": {"version": 2, "rows": approvals}}))
        if revocations:
            line.import_dir(db, input_dir({"r.json": {"version": version, "rows": revocations}}))
        return db

    def test_falls_back_to_the_next_remaining_layer(self):
        db = self.build([approval("lo", "Q29", "B", rank=1, clock="14:00"),
                         approval("hi", "Q29", "B", rank=2, clock="16:30")],
                        [revoke("r", "hi", "B", "2026-03-09", "2026-03-09")])
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 2), "Q29", "2026-03-09"),
                         "2026-03-09T16:30:00+00:00")   # asof 2: revocation not visible
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 3), "Q29", "2026-03-09"),
                         "2026-03-09T14:00:00+00:00")   # asof 3: next layer, not base

    def test_revocation_is_scoped_to_channel_and_day(self):
        db = self.build([approval("hi", "Q29", "AB", rank=2, clock="16:30"),
                         approval("lo", "Q29", "AB", rank=1, clock="14:00")],
                        [revoke("r", "hi", "B", "2026-03-09", "2026-03-09")])
        self.assertEqual(one(line.query(db, "A", "2026-03-09", "2026-03-09", 3), "Q29", "2026-03-09"),
                         "2026-03-09T16:30:00+00:00")   # A unaffected
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 3), "Q29", "2026-03-09"),
                         "2026-03-09T14:00:00+00:00")
        self.assertEqual(one(line.query(db, "B", "2026-03-16", "2026-03-16", 3), "Q29", "2026-03-16"),
                         "2026-03-16T16:30:00+00:00")   # other Monday unaffected

    def test_revocation_without_a_window_removes_the_whole_target(self):
        db = self.build([approval("hi", "Q29", "AB", rank=2, clock="16:30"),
                         approval("lo", "Q29", "AB", rank=1, clock="14:00")],
                        [revoke("r", "hi", "AB")])
        for channel in ("A", "B"):
            self.assertEqual(one(line.query(db, channel, "2026-03-16", "2026-03-16", 3), "Q29", "2026-03-16"),
                             "2026-03-16T14:00:00+00:00")

    def test_revoking_an_unknown_target_is_inert(self):
        db = self.build([approval("hi", "Q29", "B", clock="16:30")],
                        [revoke("r", "does-not-exist", "B", "2026-03-09", "2026-03-09")])
        self.assertEqual(one(line.query(db, "B", "2026-03-09", "2026-03-09", 3), "Q29", "2026-03-09"),
                         "2026-03-09T16:30:00+00:00")


# --------------------------------------------------------------------------- #
# shift_days
# --------------------------------------------------------------------------- #
class ShiftDays(unittest.TestCase):
    def test_wall_basis_moves_the_day_then_sets_the_clock(self):
        db = fresh()
        line.import_dir(db, input_dir({"o.json": {"version": 2, "rows": [
            approval("s", "N84", "A", start="2026-03-09", end="2026-03-09",
                     rank=5, clock="09:45", basis="wall", shift=-1)]}}))
        row = [r for r in line.query(db, "A", "2026-03-09", "2026-03-09", 2) if r["code"] == "N84"][0]
        self.assertEqual(row["day"], "2026-03-08")                         # moved to Sunday
        self.assertEqual(row["utc"], "2026-03-08T13:45:00+00:00")          # then wall clock

    def test_utc_basis_moves_the_day_then_sets_the_clock(self):
        db = fresh()
        line.import_dir(db, input_dir({"o.json": {"version": 2, "rows": [
            approval("s", "Q29", "A", start="2026-03-09", end="2026-03-09",
                     rank=5, clock="23:30", basis="utc", shift=1)]}}))
        row = [r for r in line.query(db, "A", "2026-03-09", "2026-03-09", 2) if r["code"] == "Q29"][0]
        self.assertEqual(row["day"], "2026-03-10")
        self.assertEqual(row["utc"], "2026-03-10T23:30:00+00:00")

    def test_the_window_matches_the_original_monday_not_the_shifted_day(self):
        db = fresh()
        line.import_dir(db, input_dir({"o.json": {"version": 2, "rows": [
            approval("s", "N84", "A", start="2026-03-09", end="2026-03-09",
                     rank=5, clock="09:45", basis="wall", shift=-1)]}}))
        # asking only for the Sunday does not select the Monday that shifts onto it
        self.assertEqual(line.query(db, "A", "2026-03-08", "2026-03-08", 2), [])


# --------------------------------------------------------------------------- #
# isolation from the old portal
# --------------------------------------------------------------------------- #
class OldPortalKeptWorking(unittest.TestCase):
    def test_line_import_leaves_the_portal_tables_and_routes_untouched(self):
        path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), path)
        db = portal.ensure_schema(sqlite3.connect(path))

        def fixed():
            return {table: db.execute(f"select * from {table} order by 1").fetchall()
                    for table in ("events", "bookings", "series", "adjustment")}

        before = fixed()
        before_api = portal.route(db, "/api/events?from=2026-03-06&to=2026-03-20&channel=B")[1]
        line.import_dir(db, INPUT)
        self.assertEqual(fixed(), before)
        self.assertEqual(portal.route(db, "/api/events?from=2026-03-06&to=2026-03-20&channel=B")[1],
                         before_api)
        # the new tables coexist in the same database
        self.assertEqual(db.execute("select count(*) from line_series").fetchone()[0], 4)
        db.close()


class CommandLine(unittest.TestCase):
    def test_import_then_query_through_the_cli(self):
        import subprocess
        import sys
        db = os.path.join(tempfile.mkdtemp(), "line.sqlite")
        env = dict(os.environ, PORTAL_DB=db)
        run = subprocess.run([sys.executable, "project/line.py", "import", "input"],
                             cwd=ROOT, env=env, capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        with open(os.path.join(ROOT, "input", "version.txt"), encoding="utf-8") as handle:
            deployed = int(handle.read().strip())
        self.assertIn(f'"release_version": {deployed}', run.stdout.replace(", ", ","))
        run = subprocess.run([sys.executable, "project/line.py", "query", "B",
                              "2026-03-09", "2026-03-09", "2"],
                             cwd=ROOT, env=env, capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        rows = json.loads(run.stdout)
        self.assertEqual({row["code"]: row["utc"] for row in rows}["Q29"], "2026-03-09T16:30:00+00:00")
        bad = subprocess.run([sys.executable, "project/line.py", "query", "B",
                              "2026-03-09", "2026-03-09", "not-a-version"],
                             cwd=ROOT, env=env, capture_output=True, text=True)
        self.assertEqual(bad.returncode, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
