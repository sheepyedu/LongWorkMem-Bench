# 委托：修复长区间无声截断 + 增设 /api/pages 分页兼容入口（业务日 2026-03-30）

范围：门户 V1 只读服务面（project/portal.py）与回归套件；未改数据、未生成/投递任何 ICS。
依据：`input/contracts/paging.md`。

## 1. 根因：长区间无声截断
`occurrences()` 原来默认 `limit=MAX_OCCURRENCES(1000)`，`series_rows()` 调用时沿用该默认，
于是**同一系列在长区间里最多展开 1000 场，超出的静默丢弃**（旧交接 migration.md 遗留里也写明
"单次请求每系列展开上限 1000 场"）。`/api/events` 与 `prepare` 都受此影响。

修复（project/portal.py）：
- `occurrences(..., limit=None, ...)`：默认**按请求区间完整展开**，不再有每系列 1000 场上限；
  循环改为 `while limit is None or len(out) < limit`。
- 为防止无界死循环：当 `limit is None` 且 `end is None` 时直接 `ValueError`（没有任何调用方这样用；
  migrate 仍显式 `limit=1` 取首场，行为不变）。
- 保留 `MAX_OCCURRENCES` 常量并在文档说明其为历史值，不再是默认上限。

## 2. 新入口：GET /api/pages（分页兼容）
`route()` 新增 `/api/pages`，与 `/api/events` **取同一份已按 UID 字典序排好的行**
（同 channel、同 from/to 服务日范围、`expand=bounded`，legacy 存量项照旧并入、按 UID 去重），
再切片返回：

    {"items": [ {uid, utc, status}, ... ], "next": 下一偏移整数 或 null }

- 页大小 `limit` 省略/非法/≤0 → 返回剩余全部、`next=null`；`offset` 省略/非法/负数 → 按 0/0 处理。
- `next = offset + len(items)`，到尾部为 `null`；`offset` 超过总数 → `{items:[], next:null}`。
- 纯读、按 UID 稳定排序、同一请求结果恒定 → **可复跑**；逐页取完可无损重建 `/api/events` 全集
  （无重复、无缺口、字典序）。
- `/api/events`（仍是 JSON 数组）与 `/invite/...` 形状/语义未改；`/api/events` 唯一变化是长区间
  现在返回完整集合（这正是本次要修的 bug）。

## 3. 交付物
- `project/portal.py`：上述 `occurrences()` 修复 + `_count()`/`page_slice()` + `/api/pages` 分支 + 模块文档。
- `project/test_pages.py`：**新增 12 项**回归。
- `notes/paging-and-long-range.md`：本说明。
- 为让既有回归套件可运行，已将 `input/previous-release/out/` 的上一轮交付件**原样复制回 `out/`**
  （与 `project/prepare.py` 重算逐字节一致，非新投递、未调用 publish）。

## 4. 验证
- 全套测试 **106 项全过**：test_portal 11、test_migrate 14、test_prepare 8、test_adjust 15、
  test_ch64 10、test_recover 16、test_backup 10、test_q2 10、**test_pages 12**。
- test_pages 覆盖：单系列长区间 >1000 不截断（K17/M42 各 1044 场）、`/api/events` 长区间完整
  （2026-03-06..2046-03-06 = 2×1044+1 legacy = 2089 行）、显式 `limit=1` 仍可用于探针、
  无界且无 end 时报错、`/api/pages` 形状/字段、逐页重建 == `/api/events`、含 legacy、
  末页 `next=null`、越界空页、无 limit 返回全部、同请求可复跑、频道口径（M42-20260320 A=17:00Z/B=15:00Z）、
  非法/负参数容错。
- 真实环回服务（project/http_read.py）：`/api/pages` 分页 `next` 正确；`/api/events` 200 年区间 2089 行；
  尾部页 `next=null`；`/` 与 `/invite/legacy-east?tz=Asia/Tokyo` 文本未变。
- 极端区间终止性：1900..2100 → 7812 行/0.04s；2026..2500 → 49554 行/0.19s；2026..9999 → 832112 行/4.5s
  （溢出被捕获并停止，无挂死）。
- 数据未动：events 4 / bookings 4 / series 2 / adjustment 4 原样；只读查询不写库。

## 5. 遗留 / 注意
- 分页是无状态 offset 切片：每页都会重算该区间全集，超长区间（如到 9999 年）深翻页会重复付出
  展开成本；正常业务区间（数年级）可忽略。若将来要支撑超长区间高频翻页，可加区间结果缓存。
- `next` 采用"下一页起始偏移"语义；客户端应循环到 `next is null` 为止，不要假定固定页大小。
- `/api/events` 仍按 UTC 日期（即原定场次日）过滤；legacy 存量项以其 `starts` 的 UTC 日归属区间，
  与既有契约一致（旧交接 handoff.md 已注明此语义未改）。
- 取消场次（STATUS:CANCELLED）仍未支持，需另行确认口径——本次未触碰。
- 未新增/修改任何签批或排期，故无新 ICS、无 publish、无新回执。
