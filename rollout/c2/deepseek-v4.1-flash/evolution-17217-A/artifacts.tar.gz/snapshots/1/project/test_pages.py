"""Paging compatibility entry and long-range expansion.

Run: python3 project/test_pages.py

Contract (input/contracts/paging.md): the old V1 gains
GET /api/pages?channel=A&from=DATE&to=DATE&offset=N&limit=N returning
{items:[old /api/events rows], next: next-offset-int or null}, UID-lexicographic
over the whole original service-day range, legacy items included, and never
silently losing a series that has more than 1000 occurrences.  /api/events and
/invite/... must keep working.
"""
import json
import os
import shutil
import sqlite3
import tempfile
import unittest

import portal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIVE = os.path.join(ROOT, "data", "portal.sqlite")

START = portal.as_date("2026-03-06")
LONG = portal.as_date("2046-03-06")            # ~20 years: 1044 Fridays per series
WEEKS = (LONG - START).days // 7 + 1           # occurrences per series in the long range
PAGE = 500


def seeded():
    """A writable copy of the deployed database (real series + adjustments)."""
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(LIVE, path)
    return portal.ensure_schema(sqlite3.connect(path))


def api(db, url):
    return json.loads(portal.route(db, url)[1])


def service_day_range():
    return f"from={START}&to={LONG}"


class LongRangeNotTruncated(unittest.TestCase):
    def setUp(self):
        self.db = seeded()

    def tearDown(self):
        self.db.close()

    def test_series_expansion_has_no_per_series_cap(self):
        rows = portal.series_rows(self.db, START, LONG, "A")
        self.assertEqual(len(rows), 2 * WEEKS)
        self.assertGreater(len(rows), 2 * 1000)        # would have been capped at 2*1000
        for code in ("K17", "M42"):
            held = [r for r in rows if r["uid"].startswith(code + "-")]
            self.assertGreater(len(held), 1000)         # each series alone exceeds 1000
            self.assertEqual(len(held), WEEKS)

    def test_api_events_long_range_is_complete(self):
        rows = api(self.db, f"/api/events?channel=A&{service_day_range()}")
        # 2*WEEKS pilot occurrences, plus legacy-west on the first service day;
        # K17/M42-20260306 already live in the events table and are not double-counted.
        self.assertEqual(len(rows), 2 * WEEKS + 1)
        self.assertGreater(len(rows), 2 * 1000)
        self.assertEqual(len({r["uid"] for r in rows}), len(rows))

    def test_explicit_limit_is_still_available_for_a_probe(self):
        row = self.db.execute(
            "select " + ",".join(portal.SERIES_COLUMNS) + " from series where code='K17'").fetchone()
        series = dict(zip(portal.SERIES_COLUMNS, row))
        self.assertEqual(len(portal.occurrences(series, START, LONG, limit=1)), 1)

    def test_unbounded_expansion_without_a_bound_fails_loudly(self):
        row = self.db.execute(
            "select " + ",".join(portal.SERIES_COLUMNS) + " from series where code='K17'").fetchone()
        series = dict(zip(portal.SERIES_COLUMNS, row))
        with self.assertRaises(ValueError):
            portal.occurrences(series)


class PagingEntry(unittest.TestCase):
    def setUp(self):
        self.db = seeded()

    def tearDown(self):
        self.db.close()

    def test_response_is_items_plus_next(self):
        page = api(self.db, f"/api/pages?channel=A&{service_day_range()}&offset=0&limit=5")
        self.assertEqual(list(page), ["items", "next"])
        self.assertIsInstance(page["items"], list)
        self.assertEqual(sorted(page["items"][0]), ["status", "uid", "utc"])
        self.assertTrue(all(r["status"] == "CONFIRMED" for r in page["items"]))
        self.assertEqual(page["next"], 5)

    def test_paging_reconstructs_the_events_set(self):
        full = api(self.db, f"/api/events?channel=A&{service_day_range()}")
        collected, offset, pages, guard = [], 0, 0, 0
        while True:
            page = api(self.db, f"/api/pages?channel=A&{service_day_range()}"
                               f"&offset={offset}&limit={PAGE}")
            collected.extend(page["items"])
            pages += 1
            guard += 1
            self.assertLess(guard, 1000)
            if page["next"] is None:
                break
            offset = page["next"]
        self.assertGreater(pages, 1)
        self.assertEqual(collected, full)                       # same rows, same UID order
        self.assertEqual([r["uid"] for r in collected],
                         sorted(r["uid"] for r in collected))
        self.assertEqual(len({r["uid"] for r in collected}), len(collected))   # no duplicates

    def test_legacy_items_are_included(self):
        full = api(self.db, f"/api/events?channel=A&from=2026-03-06&to=2026-03-27")
        self.assertIn("legacy-west", {r["uid"] for r in full})
        whole = api(self.db, "/api/pages?channel=A&from=2026-03-06&to=2026-03-27")
        self.assertIn("legacy-west", {r["uid"] for r in whole["items"]})
        self.assertIsNone(whole["next"])

    def test_last_page_reports_null_and_offset_past_end_is_empty(self):
        total = len(api(self.db, f"/api/events?channel=A&from=2026-03-06&to=2026-03-27"))
        last = api(self.db, f"/api/pages?channel=A&from=2026-03-06&to=2026-03-27"
                            f"&offset={total - 1}&limit=10")
        self.assertEqual(len(last["items"]), 1)
        self.assertIsNone(last["next"])
        past = api(self.db, f"/api/pages?channel=A&from=2026-03-06&to=2026-03-27"
                            f"&offset={total + 50}&limit=10")
        self.assertEqual(past, {"items": [], "next": None})

    def test_no_limit_returns_everything_with_null_next(self):
        page = api(self.db, "/api/pages?channel=A&from=2026-03-06&to=2026-03-27&offset=0")
        full = api(self.db, "/api/events?channel=A&from=2026-03-06&to=2026-03-27")
        self.assertEqual(page["items"], full)
        self.assertIsNone(page["next"])

    def test_same_request_is_repeatable(self):
        url = "/api/pages?channel=B&from=2026-03-06&to=2026-03-27&offset=2&limit=3"
        self.assertEqual(api(self.db, url), api(self.db, url))

    def test_channel_scoping_reaches_the_page(self):
        url = "/api/pages?channel={0}&from=2026-03-20&to=2026-03-20&offset=0&limit=100"
        a = {r["uid"]: r["utc"] for r in api(self.db, url.format("A"))["items"]}
        b = {r["uid"]: r["utc"] for r in api(self.db, url.format("B"))["items"]}
        self.assertEqual(a["M42-20260320"], "2026-03-20T17:00:00Z")   # CH-53 still applies to A
        self.assertEqual(b["M42-20260320"], "2026-03-20T15:00:00Z")   # CH-64 restores B

    def test_malformed_paging_parameters_do_not_break_the_page(self):
        full = api(self.db, "/api/events?channel=A&from=2026-03-06&to=2026-03-27")
        bad = api(self.db, "/api/pages?channel=A&from=2026-03-06&to=2026-03-27"
                           "&offset=nope&limit=nope")
        self.assertEqual(bad["items"], full)
        self.assertIsNone(bad["next"])
        negative = api(self.db, "/api/pages?channel=A&from=2026-03-06&to=2026-03-27"
                               "&offset=-9&limit=3")
        first = api(self.db, "/api/pages?channel=A&from=2026-03-06&to=2026-03-27"
                            "&offset=0&limit=3")
        self.assertEqual(negative, first)


if __name__ == "__main__":
    unittest.main(verbosity=2)
