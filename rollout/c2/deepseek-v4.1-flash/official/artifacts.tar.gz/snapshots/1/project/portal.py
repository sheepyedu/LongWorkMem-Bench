"""Deployed v1 application. Run python3 project/portal.py serve [port].

Local-date fix (Tokyo overnight reports):
the HTML views used to glue the *UTC* date onto the *local* time, so any
occurrence whose local wall clock falls on the previous UTC day was shown one
day early (e.g. 2026-03-05T23:30Z rendered as "2026-03-05 08:30" in
Asia/Tokyo although it happens on 2026-03-06 08:30 local).  The date and the
time of a label are now both taken from the same instant converted into the
requested zone.  The /api/events contract (uid/utc/status, range filter on the
scheduled day, inclusive) is intentionally untouched.
"""
import argparse
from datetime import datetime, timezone
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import sqlite3
from urllib.parse import parse_qs, urlsplit
from zoneinfo import ZoneInfo


def events(db, start, end, channel):
    rows = db.execute("select uid, starts from events order by uid")
    return [dict(uid=u, utc=s, status="CONFIRMED") for u,s in rows if start <= s[:10] <= end]


def as_utc(stamp):
    """Stored timestamps are UTC; tolerate a naive value by reading it as UTC."""
    moment = datetime.fromisoformat(stamp)
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone(timezone.utc)


def local_label(utc, zone):
    """Wall-clock label in `zone`; date and time come from one instant."""
    local = as_utc(utc).astimezone(ZoneInfo(zone))
    return local.strftime("%Y-%m-%d %H:%M")


def route(db, url):
    parts = urlsplit(url)
    query = {k:v[0] for k,v in parse_qs(parts.query).items()}
    rows = events(db, query.get("from","1900"), query.get("to","2100"), query.get("channel","A"))
    if parts.path == "/api/events":
        return "application/json", json.dumps(rows)
    if parts.path.startswith("/invite/"):
        rows = [r for r in rows if r["uid"] == parts.path.split("/")[-1]]
    elif parts.path != "/":
        raise KeyError("unknown route")
    zone = query.get("tz","UTC")
    return "text/html", "<main>" + "".join(
        f'<article data-uid="{escape(r["uid"])}">{escape(local_label(r["utc"],zone),quote=False)}</article>' for r in rows
    ) + "</main>"


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action", choices=["serve","request","migrate"])
    p.add_argument("value", nargs="?")
    args=p.parse_args()
    db=sqlite3.connect(os.getenv("PORTAL_DB","data/portal.sqlite"))
    if args.action == "migrate":
        db.commit()
    elif args.action == "request":
        print(route(db,args.value)[1])
    else:
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                try:
                    mime, text = route(db,self.path)
                    self.send_response(200)
                except KeyError:
                    mime,text = "text/plain","missing"
                    self.send_response(404)
                self.send_header("Content-Type",mime+"; charset=utf-8")
                self.end_headers()
                self.wfile.write(text.encode())
        HTTPServer(("127.0.0.1",int(args.value or 8090)),Handler).serve_forever()


if __name__ == "__main__":
    main()
