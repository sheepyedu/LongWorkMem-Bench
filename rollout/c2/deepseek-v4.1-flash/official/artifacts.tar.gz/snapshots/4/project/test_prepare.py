"""Tests for the publish preparation entry. Run: python3 project/test_prepare.py"""
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import portal
import prepare

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def ics_rows(text):
    events = re.findall(r"BEGIN:VEVENT\r\n(.*?)END:VEVENT\r\n", text, re.S)
    return [dict(line.split(":", 1) for line in body.strip().split("\r\n")) for body in events]


class Build(unittest.TestCase):
    def setUp(self):
        self.path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), self.path)

    def build(self, channel, start, end):
        text, rows = prepare.build(channel, start, end, self.path)
        return text, rows

    def test_four_weeks_for_each_channel(self):
        for channel in ("A", "B"):
            text, rows = self.build(channel, "2026-03-06", "2026-03-27")
            events = ics_rows(text)
            self.assertEqual(len(events), 8)
            self.assertEqual([e["UID"] for e in events],
                             ["K17-20260306", "K17-20260313", "K17-20260320", "K17-20260327",
                              "M42-20260306", "M42-20260313", "M42-20260320", "M42-20260327"])
            self.assertTrue(all(e["STATUS"] == "CONFIRMED" for e in events))
            self.assertFalse(any(e["UID"].startswith("legacy") for e in events))

    def test_approval_clocks_reach_the_file(self):
        text, _ = self.build("A", "2026-03-06", "2026-03-27")
        starts = {e["UID"]: e["DTSTART"] for e in ics_rows(text)}
        self.assertEqual(starts["K17-20260306"], "20260306T150000Z")
        self.assertEqual(starts["K17-20260313"], "20260313T140000Z")   # 场馆当地钟随夏令时
        self.assertEqual(starts["M42-20260313"], "20260313T150000Z")   # UTC 钟固定

    def test_self_contained_and_deterministic(self):
        first, _ = self.build("A", "2026-03-06", "2026-03-27")
        second, _ = self.build("A", "2026-03-06", "2026-03-27")
        self.assertEqual(first, second)                                  # reproducible bytes
        self.assertTrue(first.startswith("BEGIN:VCALENDAR\r\n"))
        self.assertTrue(first.endswith("END:VCALENDAR\r\n"))
        self.assertEqual(first.count("BEGIN:VCALENDAR"), 1)
        self.assertNotIn("\n\n", first)
        self.assertEqual(ics_rows(first)[0]["DTSTAMP"], "20260101T000000Z")   # stable, no clock noise

    def test_empty_range_still_valid(self):
        text, rows = self.build("A", "2026-03-02", "2026-03-04")
        self.assertEqual(rows, [])
        self.assertEqual(text, "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Schedule Desk//EN\r\nEND:VCALENDAR\r\n")

    def test_bad_arguments(self):
        for args in (("C", "2026-03-06", "2026-03-27"), ("A", "2026-03-27", "2026-03-06"),
                     ("A", "not-a-date", "2026-03-27")):
            with self.assertRaises(ValueError):
                self.build(*args)

    def test_channel_scope_reaches_both_entries(self):
        db = sqlite3.connect(self.path)
        db.execute("update series set channel='A' where code='M42'")     # 频道范围变更
        db.commit()
        a_text, _ = self.build("A", "2026-03-06", "2026-03-27")
        b_text, _ = self.build("B", "2026-03-06", "2026-03-27")
        self.assertEqual(len(ics_rows(a_text)), 8)
        self.assertEqual([e["UID"] for e in ics_rows(b_text)],
                         ["K17-20260306", "K17-20260313", "K17-20260320", "K17-20260327"])
        api_b = portal.route(db, "/api/events?from=2026-03-06&to=2026-03-27&channel=B")[1]
        self.assertNotIn("M42-20260320", api_b)                           # same scope in the portal API
        self.assertIn("K17-20260320", api_b)
        self.assertIn("legacy-west", api_b)                               # non-pilot untouched
        # invite links stay channel-agnostic
        self.assertIn("M42-20260320", portal.route(db, "/invite/M42-20260320?tz=UTC")[1])
        db.close()


class Cli(unittest.TestCase):
    def test_cli_writes_file_and_reports_key(self):
        out = os.path.join(tempfile.mkdtemp(), "sub", "b.ics")
        result = subprocess.run([sys.executable, os.path.join(ROOT, "project", "prepare.py"),
                                 "B", "2026-03-06", "2026-03-27", out],
                                cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("key-suggestion=B-pilot-20260306-20260327-", result.stdout)
        with open(out, newline="") as handle:
            self.assertEqual(len(ics_rows(handle.read())), 8)

    def test_cli_rejects_bad_channel(self):
        result = subprocess.run([sys.executable, os.path.join(ROOT, "project", "prepare.py"),
                                 "Z", "2026-03-06", "2026-03-27", os.path.join(tempfile.mkdtemp(), "z.ics")],
                                cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("prepare failed", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
