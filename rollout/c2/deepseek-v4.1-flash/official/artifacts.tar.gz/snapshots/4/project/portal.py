"""Deployed v1 application. Run python3 project/portal.py serve [port].

Local-date fix (Tokyo overnight reports):
labels take date *and* time from one instant converted into the requested zone
(the HTML used to glue the UTC date onto the local time, so occurrences whose
local wall clock falls on the previous UTC day showed one day early).

Pilot intake (migrate):
`python3 project/portal.py migrate [INTAKE] [RECORDS]` imports the series listed
in intake.json, resolving each entry's approval ticket from the records library
and repeating it weekly with no end date.  Occurrences are expanded per
requested range, not materialised, and are keyed by the stable VEVENT UID
`CODE-原定日`, so invite links and bookings survive.  Re-running is a no-op; a
later intake with new ticket numbers is imported incrementally and earlier
series are kept.
"""
import argparse
from datetime import date, datetime, timedelta, timezone
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import re
import sqlite3
from urllib.parse import parse_qs, urlsplit
from zoneinfo import ZoneInfo

INTAKE = "input/intake.json"
RECORDS = "input/records"
CLOCK = "input/clock.txt"

RULE_LOCAL = "venue_local_clock"   # keep the first occurrence's venue local clock
RULE_UTC = "utc_clock"            # keep the first occurrence's UTC clock
MAX_OCCURRENCES = 1000
TICKET = re.compile(r"\b[A-Z]{2,}-\d{3,}\b")

SERIES_COLUMNS = ("code", "ord", "anchor", "zone", "rule", "weekday", "clock", "channel")


# --------------------------------------------------------------------------- #
# storage
# --------------------------------------------------------------------------- #
def ensure_schema(db):
    db.execute("create table if not exists events(uid text primary key, starts text not null)")
    db.execute("create table if not exists bookings(id text primary key, uid text not null)")
    db.execute("""create table if not exists series(
        code text primary key, ord text not null, anchor text not null,
        zone text not null, rule text not null, weekday integer not null,
        clock text not null, channel text, imported text)""")
    return db


def as_utc(stamp):
    """Stored timestamps are UTC; tolerate a naive value by reading it as UTC."""
    moment = datetime.fromisoformat(stamp)
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone(timezone.utc)


def as_date(value):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def stamp(moment):
    return moment.strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------- #
# schedules
# --------------------------------------------------------------------------- #
def occurrences(series, start=None, end=None, limit=MAX_OCCURRENCES):
    """Weekly occurrences of one series inside [start, end] on its UID day."""
    zone = ZoneInfo(series["zone"])
    anchor = as_utc(series["anchor"])
    if series["rule"] == RULE_UTC:
        clock = anchor.time().replace(tzinfo=None)
        first = anchor
    else:                                   # venue local clock: UTC drifts with DST
        local = anchor.astimezone(zone)
        clock = local.time().replace(tzinfo=None)
        first = datetime.combine(local.date(), clock, tzinfo=zone)
    base_day = first.date() if series["rule"] == RULE_UTC else first.astimezone(zone).date()
    step = timedelta(days=7)
    k = 0
    if start and start > base_day:
        k = max(0, -(-(start - base_day).days // 7))
    out = []
    while len(out) < limit:
        try:
            if series["rule"] == RULE_UTC:
                moment, day = first + step * k, base_day + step * k
            else:
                day = base_day + step * k
                moment = datetime.combine(day, clock, tzinfo=zone).astimezone(timezone.utc)
        except (OverflowError, ValueError):     # UID/range outside the calendar
            break
        if end and day > end:
            break
        out.append(dict(uid=f'{series["code"]}-{day:%Y%m%d}', utc=stamp(moment), status="CONFIRMED"))
        k += 1
    return out


def series_rows(db, start=None, end=None, channel=None):
    """Pilot occurrences in range; a series without a channel belongs to both."""
    sql = "select " + ",".join(SERIES_COLUMNS) + " from series"
    args = ()
    if channel is not None:
        sql += " where channel is null or channel=?"
        args = (channel,)
    try:
        rows = db.execute(sql + " order by code", args).fetchall()
    except sqlite3.OperationalError:        # database never migrated
        return []
    found = []
    for row in rows:
        found.extend(occurrences(dict(zip(SERIES_COLUMNS, row)), start, end))
    return found


def uid_day(uid):
    """The 原定日 encoded in a UID such as K17-20260306."""
    _, _, tail = uid.rpartition("-")
    if len(tail) != 8 or not tail.isdigit():
        return None
    return as_date(f"{tail[:4]}-{tail[4:6]}-{tail[6:]}")


def resolve_occurrence(db, uid):
    """Single pilot occurrence addressed by its UID, if that UID is real."""
    code, day = uid.rpartition("-")[0], uid_day(uid)
    if not code or day is None:
        return None
    for row in occurrences_around(db, code, day):
        if row["uid"] == uid:
            return row
    return None


def occurrences_around(db, code, day):
    try:
        row = db.execute("select " + ",".join(SERIES_COLUMNS) + " from series where code=?", (code,)).fetchone()
    except sqlite3.OperationalError:
        return []
    if not row:
        return []
    return occurrences(dict(zip(SERIES_COLUMNS, row)), day, day)


# --------------------------------------------------------------------------- #
# approvals
# --------------------------------------------------------------------------- #
def rule_from_text(text):
    if "UTC" in text.upper():
        return RULE_UTC
    if "当地" in text or "本地" in text:
        return RULE_LOCAL
    return None


def approval_rule(records, order, seen=()):
    """Scheduling rule of an approval ticket; a ticket may point at another one."""
    path = os.path.join(records, order + ".txt")
    if not os.path.exists(path):
        raise ValueError(f"approval for {order} not found: {path}")
    with open(path, encoding="utf-8") as handle:
        text = handle.read()
    rule = rule_from_text(text)
    if rule:
        return rule, order
    for reference in TICKET.findall(text):
        if reference != order and reference not in seen:
            return approval_rule(records, reference, seen + (order,))
    raise ValueError(f"cannot read a scheduling rule from {path}: {text.strip()!r}")


# --------------------------------------------------------------------------- #
# migration
# --------------------------------------------------------------------------- #
def migrate(db, intake=INTAKE, records=RECORDS):
    """Incremental, repeatable import of the pilot series in intake.json."""
    ensure_schema(db)
    if not os.path.exists(intake):
        print(f"no intake at {intake}; nothing to import")
        return []
    with open(intake, encoding="utf-8") as handle:
        entries = json.load(handle)
    business_day = ""
    if os.path.exists(CLOCK):
        with open(CLOCK, encoding="utf-8") as handle:
            business_day = handle.read().strip()
    report = []
    for entry in entries:
        code, order, zone_name = entry["code"], entry["order"], entry["zone"]
        anchor = as_utc(entry["anchor"])
        zone = ZoneInfo(zone_name)                     # unknown zone fails loudly
        rule, source = approval_rule(records, order)
        local = anchor.astimezone(zone)
        # the reference calendar of the rule: UTC clock -> UTC days, venue clock -> venue days
        reference, clock = (anchor, anchor.strftime("%H:%M")) if rule == RULE_UTC else (local, local.strftime("%H:%M"))
        wanted = dict(code=code, ord=order, anchor=stamp(anchor), zone=zone_name, rule=rule,
                      weekday=reference.weekday(), clock=clock, channel=entry.get("channel"))
        current = db.execute("select " + ",".join(SERIES_COLUMNS) + " from series where code=?", (code,)).fetchone()
        if current is None:
            db.execute("insert into series(" + ",".join(SERIES_COLUMNS) + ",imported) values("
                       + ",".join("?" * (len(SERIES_COLUMNS) + 1)) + ")",
                       tuple(wanted[c] for c in SERIES_COLUMNS) + (business_day,))
            action = "imported"
        elif dict(zip(SERIES_COLUMNS, current)) == wanted:
            action = "unchanged"
        else:
            db.execute("update series set ord=?,anchor=?,zone=?,rule=?,weekday=?,clock=?,channel=? where code=?",
                       (wanted["ord"], wanted["anchor"], wanted["zone"], wanted["rule"],
                        wanted["weekday"], wanted["clock"], wanted["channel"], code))
            action = "updated"
        first = occurrences(wanted, limit=1)[0]
        before = db.execute("select starts from events where uid=?", (first["uid"],)).fetchone()
        merged = "kept"
        if before is None:
            db.execute("insert into events(uid, starts) values(?,?)", (first["uid"], first["utc"]))
            merged = "inserted"
        elif before[0] != first["utc"]:
            db.execute("update events set starts=? where uid=?", (first["utc"], first["uid"]))
            merged = "rescheduled"
        report.append(dict(code=code, order=order, source=source, rule=rule, zone=zone_name,
                           weekday=reference.weekday(), first=first["uid"], utc=first["utc"],
                           series=action, event=merged))
        print(f'{code:>5} {order} rule={rule} via={source} zone={zone_name} '
              f'weekday={reference.strftime("%a")} first={first["uid"]}@{first["utc"]} '
              f'series={action} event={merged}')
    db.commit()
    return report


# --------------------------------------------------------------------------- #
# http surface
# --------------------------------------------------------------------------- #
def events(db, start, end, channel, expand=False):
    rows = db.execute("select uid, starts from events order by uid")
    found = [dict(uid=u, utc=s, status="CONFIRMED") for u,s in rows if start <= s[:10] <= end]
    if expand:
        known = {uid for uid,_ in db.execute("select uid, starts from events")}
        for row in series_rows(db, as_date(start), as_date(end), channel):
            if row["uid"] not in known:
                found.append(row)
                known.add(row["uid"])
        found.sort(key=lambda r: r["uid"])
    return found


def local_label(utc, zone):
    """Wall-clock label in `zone`; date and time come from one instant."""
    local = as_utc(utc).astimezone(ZoneInfo(zone))
    return local.strftime("%Y-%m-%d %H:%M")


def route(db, url):
    parts = urlsplit(url)
    query = {k:v[0] for k,v in parse_qs(parts.query).items()}
    start, end = query.get("from","1900"), query.get("to","2100")
    from_day, to_day = as_date(start), as_date(end)
    bounded = from_day is not None and to_day is not None and from_day <= to_day
    rows = events(db, start, end, query.get("channel","A"), expand=bounded)
    if parts.path == "/api/events":
        return "application/json", json.dumps(rows)
    if parts.path.startswith("/invite/"):
        uid = parts.path.split("/")[-1]
        rows = [r for r in rows if r["uid"] == uid]
        if not rows:
            row = resolve_occurrence(db, uid)
            if row and (not bounded or from_day <= uid_day(uid) <= to_day):
                rows = [row]
    elif parts.path != "/":
        raise KeyError("unknown route")
    zone = query.get("tz","UTC")
    return "text/html", "<main>" + "".join(
        f'<article data-uid="{escape(r["uid"])}">{escape(local_label(r["utc"],zone),quote=False)}</article>' for r in rows
    ) + "</main>"


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action", choices=["serve","request","migrate"])
    p.add_argument("value", nargs="?")
    p.add_argument("rest", nargs="*")
    args=p.parse_args()
    db=ensure_schema(sqlite3.connect(os.getenv("PORTAL_DB","data/portal.sqlite")))
    if args.action == "migrate":
        migrate(db, args.value or INTAKE, (args.rest or [RECORDS])[0])
    elif args.action == "request":
        print(route(db,args.value)[1])
    else:
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                try:
                    mime, text = route(db,self.path)
                    self.send_response(200)
                except KeyError:
                    mime,text = "text/plain","missing"
                    self.send_response(404)
                self.send_header("Content-Type",mime+"; charset=utf-8")
                self.end_headers()
                self.wfile.write(text.encode())
        HTTPServer(("127.0.0.1",int(args.value or 8090)),Handler).serve_forever()


if __name__ == "__main__":
    main()
