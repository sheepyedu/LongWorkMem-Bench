"""Publish preparation: python3 project/prepare.py CHANNEL FROM TO OUTPUT

Writes a self-contained ICS holding every occurrence of that channel's pilot
series inside FROM..TO (原定日, endpoints included).  Non-pilot legacy activity
is never included; an empty range still yields a valid VCALENDAR.  Output is
deterministic, so identical content always hashes to the same digest and can be
retried with the same dedupe key.
"""
import hashlib
import os
import sqlite3
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import portal

CHANNELS = ("A", "B")


def build(channel, start, end, db_path=None):
    if channel not in CHANNELS:
        raise ValueError(f"channel must be one of {CHANNELS}, got {channel!r}")
    start, end = date.fromisoformat(start), date.fromisoformat(end)
    if start > end:
        raise ValueError(f"empty range: {start} > {end}")
    db = portal.ensure_schema(sqlite3.connect(db_path or os.getenv("PORTAL_DB", "data/portal.sqlite")))
    rows = portal.series_rows(db, start, end, channel)          # pilots only
    rows.sort(key=lambda r: r["uid"])
    return calendar_io.encode(rows), rows


def main(argv):
    if len(argv) != 5:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    channel, start, end, output = argv[1], argv[2], argv[3], argv[4]
    try:
        text, rows = build(channel, start, end)
    except ValueError as problem:
        print(f"prepare failed: {problem}", file=sys.stderr)
        return 2
    os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
    with open(output, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)
    digest = hashlib.sha256(text.encode()).hexdigest()[:8]
    print(f"channel={channel} range={start}..{end} events={len(rows)} output={output}")
    tag = f"{date.fromisoformat(start):%Y%m%d}-{date.fromisoformat(end):%Y%m%d}"
    print(f"key-suggestion={channel}-pilot-{tag}-{digest}  sha256={digest}")
    for row in rows:
        print(f"  {row['uid']} {row['utc']} {row['status']}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
