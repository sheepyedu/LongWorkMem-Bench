"""Build a self-contained ICS for one channel and one service-day range.

Usage: python3 project/prepare.py CHANNEL FROM TO OUTPUT

Only recurring pilot series are included; legacy one-off activities are never
part of a pilot release.  An empty range still produces a legal VCALENDAR.
Output is deterministic, so the same inputs can be prepared (and retried)
repeatedly without changing the payload.
"""
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import portal

USAGE = "usage: python3 project/prepare.py CHANNEL FROM TO OUTPUT"


def build(channel, start, end, db_path=None):
    db = sqlite3.connect(db_path or os.getenv("PORTAL_DB", "data/portal.sqlite"))
    rows = []
    for series in portal.series_rows(db):
        if channel not in portal.series_channels(series):
            continue
        rows.extend(portal.occurrences(series, start, end))
    rows.sort(key=lambda row: (row["utc"], row["uid"]))
    return rows


def main(argv):
    if len(argv) != 5:
        print(USAGE, file=sys.stderr)
        return 2
    channel, start, end, output = argv[1:]
    if channel not in ("A", "B"):
        print(f"unknown channel: {channel}", file=sys.stderr)
        return 2
    if not (portal.is_iso_date(start) and portal.is_iso_date(end)):
        print("FROM and TO must be YYYY-MM-DD", file=sys.stderr)
        return 2
    if start > end:
        print("FROM must not be after TO", file=sys.stderr)
        return 2
    rows = build(channel, start, end)
    payload = calendar_io.encode(rows)
    directory = os.path.dirname(output)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(output, "w", encoding="utf-8", newline="") as handle:
        handle.write(payload)
    print(json.dumps({"channel": channel, "from": start, "to": end,
                      "output": output, "events": len(rows)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
