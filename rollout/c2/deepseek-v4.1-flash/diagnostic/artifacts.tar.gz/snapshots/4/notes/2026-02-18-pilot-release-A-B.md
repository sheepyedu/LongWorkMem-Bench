# 2026-02-18 试点首发：K17 / M42 四周（2026-03-06..03-27）发 A、B

## 发布准备入口
新增 project/prepare.py：
`python3 project/prepare.py CHANNEL FROM TO OUTPUT`
- 仅展开该频道、该服务日区间的试点系列（series 表），不含 legacy 旧活动。
- 用 project/calendar_io.py 编码，输出自包含 ICS（每场一个稳定 UID VEVENT，
  DTSTART/STATUS:CONFIRMED），CRLF 行尾。
- 空区间输出合法 VCALENDAR（无 VEVENT）。
- 输出确定性：相同输入重复生成逐字节一致，可安全重跑/重试。
- 频道范围：series.channels（默认 A,B）；prepare 与门户 API 均按频道过滤，
  非本频道系列不展开、邀请不解析。
  （events 表中的 legacy 行无频道属性，仍按原样对所有频道可见。）

## 首发内容
- 频道 A、B 各自 ICS：8 个 VEVENT（K17/M42 × 03-06/13/20/27）。
- K17：03-06 15:00Z，03-13/20/27 14:00Z（纽约墙钟 10:00 跨 DST）。
- M42：全部 15:00Z（UTC 钟点）。
- 发布前 receipts(A)/(B) 均为空，故 8 场均属“需要改变”，全量首发。

## 实际投递
- A：publish(channel=A, key=pilot-20260306-20260327-A-001,
  file=out/pilot-20260306-20260327-A.ics) → 回执 A-00001。
- B：publish(channel=B, key=pilot-20260306-20260327-B-001,
  file=out/pilot-20260306-20260327-B.ics) → 回执 B-00001。
- receipts 核对：A/B 各 1 批、8 行，UID/UTC/status 与 ICS 完全一致。
- 未重复投递；未变更 key；未在预览阶段投递。

## 验证
- ICS 解析：A/B 各 8 个 VEVENT，UID 正确，STATUS 全 CONFIRMED，DTSTART 以 Z 结尾。
- 空区间 ICS：BEGIN/END:VCALENDAR 合法，无 VEVENT。
- prepare 重跑逐字节一致。
- 既有门户入口（API/列表/邀请）输出与迁移前基线逐字节一致。
- 频道范围演练（临时库 K17 改为 A）：prepare B 只剩 M42 4 场；
  API channel=B 不再展开 K17 场次；邀请 K17-20260313 channel=B 为空。

## 后续更新原则
- 无变化不投递；有变化只把需要改变的 VEVENT 放入新批次，沿用原 UID（改期不换 UID）。
- 同 key 仅可重试语义相同内容；语义不同必须换新 key。
