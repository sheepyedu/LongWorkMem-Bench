# 2026-02-18 东京显示日期提前一天修复

## 现象
门户列表 `/` 与邀请详情 `/invite/UID` 的可见文本用 `utc[:10]`（UTC 日期）拼接当地 `HH:MM`。
东侧时区（如 Asia/Tokyo）当地时钟跨过午夜后，日期仍是 UTC 前一天，表现为“偶尔提前一天”。
例：K17-20260306（2026-03-06T15:00:00Z）在 tz=Asia/Tokyo 显示 `2026-03-06 00:00`，实际当地为 `2026-03-07 00:00`。

## 修复
project/portal.py `local_label()` 改为先转换时区，再由转换后的本地时间取日期：
`datetime.fromisoformat(utc).astimezone(ZoneInfo(zone)).strftime("%Y-%m-%d %H:%M")`。
仅影响 HTML 可见文本。

## 未改动（保持兼容）
- `/api/events`：返回 uid/utc/status，筛选仍按 `starts[:10]`（原定场次日），输出与修复前逐字节一致。
- `/invite/UID`：路由、UID、链接不变。
- `bookings` 表与报名记录未触碰（4 条仍在）。
- 数据库结构与数据未变。

## 验证
- Asia/Tokyo：K17 2026-03-07 00:00、legacy-east 2026-03-06 08:30、legacy-west 2026-03-06 11:15。
- America/New_York：legacy-west 2026-03-05 21:15（此前为 03-06 21:15）。
- tz=UTC 列表与 invite 输出与修复前完全一致。
- 三组 API 查询与修复前 cmp 相同；bookings 未变。
- local_label 对 4 场 x 7 时区做参考实现比对，全部一致。
