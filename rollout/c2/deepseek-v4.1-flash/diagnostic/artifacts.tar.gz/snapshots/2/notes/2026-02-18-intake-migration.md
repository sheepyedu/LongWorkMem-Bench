# 2026-02-18 intake 迁移：K17 / M42 两个试点系列

## 输入
input/intake.json：
- K17，anchor 2026-03-06T15:00:00Z，zone America/New_York，order OP-381
- M42，anchor 2026-03-06T15:00:00Z，zone America/New_York，order OP-629

签批（input/records/）：
- OP-381：全年保持首场的**场馆当地钟点**（K17 → 每周五 10:00 America/New_York）
- OP-629：全年保持首场的 **UTC 钟点**（M42 → 每周五 15:00Z）

## 实现（project/portal.py）
- 新增 `series` 表：code/zone/rule/anchor_utc/weekday/local_time/utc_time/order_id。
  rule 由签批文本判定（“场馆当地钟点”→ local_clock，“UTC 钟点”→ utc_clock），
  不按系列代码硬编码，故新编号引用同一批准时自动继承同一规则。
- `migrate`：
  - 读 input/intake.json（缺文件 → 无新增）；可传可选路径参数（测试/批量导入用）。
  - 逐条校验 zone（zoneinfo）、解析 anchor、解析签批规则。
  - `insert ... on conflict(code) do update` 幂等写入 series。
  - 首场 UID = 代码-原定日（local_clock 取场馆当地日，utc_clock 取 UTC 日），
    以 `insert or ignore` 合并进 events：已存在的 UID（K17-20260306 / M42-20260306）
    原样保留，报名 bookings 完全不触碰；新编号则补建首场。
  - 不删除任何既有系列/活动 → 增量导入，重复执行无副作用。
- 排期展开：`occurrences(series, start, end)` 按区间展开每周五场次；
  local_clock 用场馆时区墙钟（跨 DST 自动换算，如 K17 2026-03-13 → 14:00Z），
  utc_clock 固定 UTC 钟点（M42 恒 15:00Z）。无截止。
- 门户：显式 from/to（两者均为 ISO 日期）时，`/` 与 `/api/events` 在已存活动上
  合并系列展开并按 UID 去重，已存 UID 优先（保留改期/报名）。
  未给区间时维持原行为（仅已存活动），避免 1900–2100 展开成上万行。
  `/invite/UID` 先查已存活动，未命中则按 UID 反解系列并按需生成该场次，
  未来场次的邀请链接可用；UID 不变。
- 未支持：引用“临时时移/到期终止”类 ARC 旧签批会显式报错，避免把过期临时时移
  误当长期规则。

## 验证
- 迁移前后备份：data/portal.sqlite.pre-migrate-backup（迁移前）。
- migrate 连跑两次：series=2、events=4、bookings=4 不变；K17/M42 首场 UTC 不变。
- 既有入口逐字节不变：`/api/events`（03-01..03-10、03-06 单日、无区间）、
  `/?tz=UTC`、`/invite/legacy-east?tz=UTC` 与迁移前 cmp 相同。
- 2026-03 区间：K17 03-06 15:00Z、03-13/20/27 14:00Z；M42 全部 15:00Z。
- 2026-10-30..11-13：K17 10-30 14:00Z、11-06 起 15:00Z（DST 回落正确）。
- 邀请：`/invite/K17-20260313?tz=Asia/Tokyo` → 2026-03-13 23:00；
  `/invite/M42-20261106?tz=America/New_York` → 2026-11-06 10:00。
- 增量/新编号：临时库导入 Z80(OP-381, Asia/Tokyo) 与 Q11(OP-629, Pacific/Auckland)，
  旧系列与报名保留，重复导入不重复；缺 intake 文件 → 无新增且不报错。

## 备份/回滚
- 回滚：用 data/portal.sqlite.pre-migrate-backup 覆盖 data/portal.sqlite。
- 上线后新增编号：把条目加入 input/intake.json（签批放 input/records/），
  再执行 `python3 project/portal.py migrate` 即可，无需改代码。
