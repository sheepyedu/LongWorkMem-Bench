"""Deployed v2 application. Run python3 project/portal.py serve [port].

`migrate` imports the recurring series listed in input/intake.json.  Each entry
cites a signed approval in input/records/<order>.txt; the approval decides
whether the series keeps the venue-local clock time or the UTC clock time of
its first occurrence.  Migration is incremental and repeatable: series rows are
upserted, the first occurrence is merged into `events` without overwriting an
existing UID, and bookings are never touched.
"""
import argparse
from datetime import date, datetime, time, timedelta, timezone
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import sqlite3
from urllib.parse import parse_qs, urlsplit
from zoneinfo import ZoneInfo

RECORDS = os.path.join("input", "records")
INTAKE = os.path.join("input", "intake.json")

SERIES_SCHEMA = """
CREATE TABLE IF NOT EXISTS series(
    code TEXT PRIMARY KEY,
    zone TEXT NOT NULL,
    rule TEXT NOT NULL,          -- local_clock | utc_clock
    anchor_utc TEXT NOT NULL,
    weekday INTEGER NOT NULL,    -- Monday=0 .. Sunday=6
    local_time TEXT,             -- HH:MM for local_clock
    utc_time TEXT,               -- HH:MM for utc_clock
    order_id TEXT NOT NULL
)
"""


def parse_utc(text):
    return datetime.fromisoformat(text.replace("Z", "+00:00"))


def fmt_utc(stamp):
    return stamp.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def is_iso_date(text):
    try:
        date.fromisoformat(text)
    except (TypeError, ValueError):
        return False
    return True


def stored_events(db, start, end):
    rows = db.execute("select uid, starts from events order by uid")
    return [dict(uid=u, utc=s, status="CONFIRMED") for u,s in rows if start <= s[:10] <= end]


def series_rows(db):
    try:
        cur = db.execute("select code,zone,rule,anchor_utc,weekday,local_time,utc_time,order_id from series")
    except sqlite3.OperationalError:
        return []
    cols = ("code","zone","rule","anchor_utc","weekday","local_time","utc_time","order_id")
    return [dict(zip(cols, row)) for row in cur]


def occurrences(series, start, end):
    """Expand one series over the inclusive service-day range [start, end]."""
    zone = ZoneInfo(series["zone"])
    day = date.fromisoformat(start) - timedelta(days=1)
    last = date.fromisoformat(end) + timedelta(days=1)
    rows = []
    while day <= last:
        if day.weekday() == series["weekday"]:
            if series["rule"] == "local_clock":
                local = datetime.combine(day, time.fromisoformat(series["local_time"]), tzinfo=zone)
                stamp = local.astimezone(timezone.utc)
                service = local.date()
            else:
                stamp = datetime.combine(day, time.fromisoformat(series["utc_time"]), tzinfo=timezone.utc)
                service = stamp.date()
            if start <= service.isoformat() <= end:
                rows.append(dict(uid=series["code"] + "-" + service.strftime("%Y%m%d"),
                                 utc=fmt_utc(stamp), status="CONFIRMED"))
        day += timedelta(days=1)
    return rows


def expanded_events(db, start, end):
    """Stored events plus series occurrences; a stored UID always wins."""
    rows = stored_events(db, start, end)
    seen = {row["uid"] for row in rows}
    for series in series_rows(db):
        for row in occurrences(series, start, end):
            if row["uid"] not in seen:
                seen.add(row["uid"])
                rows.append(row)
    return sorted(rows, key=lambda row: row["uid"])


def find_event(db, uid):
    """Resolve an invite target by UID, materialising series occurrences on demand."""
    for u, s in db.execute("select uid, starts from events where uid=?", (uid,)):
        return dict(uid=u, utc=s, status="CONFIRMED")
    code, sep, day = uid.rpartition("-")
    if not sep or len(day) != 8 or not day.isdigit():
        return None
    try:
        service = date(int(day[:4]), int(day[4:6]), int(day[6:]))
    except ValueError:
        return None
    for series in series_rows(db):
        if series["code"] != code:
            continue
        for row in occurrences(series, service.isoformat(), service.isoformat()):
            if row["uid"] == uid:
                return row
    return None


def local_label(utc, zone):
    # Derive the date from the converted local time; the UTC date prefix is a day
    # early for zones east of UTC once the local clock has crossed midnight.
    return datetime.fromisoformat(utc).astimezone(ZoneInfo(zone)).strftime("%Y-%m-%d %H:%M")


def route(db, url):
    parts = urlsplit(url)
    query = {k:v[0] for k,v in parse_qs(parts.query).items()}
    channel = query.get("channel", "A")
    start = query.get("from")
    end = query.get("to")
    start = start if start is not None else "1900"
    end = end if end is not None else "2100"
    expand = is_iso_date(start) and is_iso_date(end)

    if parts.path == "/api/events":
        rows = expanded_events(db, start, end) if expand else stored_events(db, start, end)
        return "application/json", json.dumps(rows)
    if parts.path.startswith("/invite/"):
        row = find_event(db, parts.path.split("/")[-1])
        rows = [row] if row else []
    elif parts.path == "/":
        rows = expanded_events(db, start, end) if expand else stored_events(db, start, end)
    else:
        raise KeyError("unknown route")
    return "text/html", "<main>" + "".join(
        f'<article data-uid="{escape(r["uid"])}">{local_label(r["utc"],query.get("tz","UTC"))}</article>' for r in rows
    ) + "</main>"


def approval_rule(order_id):
    """Read the signed approval from the record store and return its clock rule."""
    path = os.path.join(RECORDS, order_id + ".txt")
    with open(path, encoding="utf-8") as handle:
        text = handle.read()
    if "场馆当地钟点" in text:
        return "local_clock"
    if "UTC 钟点" in text:
        return "utc_clock"
    raise ValueError(f"approval {order_id} does not define a recurring clock rule")


def migrate(db, path=None):
    """Incrementally import every series cited by the intake file."""
    db.executescript(SERIES_SCHEMA)
    path = path or INTAKE
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as handle:
        entries = json.load(handle)
    if isinstance(entries, dict):
        entries = entries.get("series", [])
    summary = []
    for entry in entries:
        code = str(entry["code"]).strip()
        zone_name = str(entry["zone"]).strip()
        order_id = str(entry["order"]).strip()
        zone = ZoneInfo(zone_name)
        anchor = parse_utc(str(entry["anchor"]))
        rule = approval_rule(order_id)
        if rule == "local_clock":
            local = anchor.astimezone(zone)
            weekday = local.weekday()
            local_time = local.strftime("%H:%M")
            utc_time = None
            service = local.date()
            stamp = datetime.combine(service, time.fromisoformat(local_time), tzinfo=zone).astimezone(timezone.utc)
        else:
            utc = anchor.astimezone(timezone.utc)
            weekday = utc.weekday()
            local_time = None
            utc_time = utc.strftime("%H:%M")
            service = utc.date()
            stamp = datetime.combine(service, time.fromisoformat(utc_time), tzinfo=timezone.utc)
        db.execute(
            """insert into series(code,zone,rule,anchor_utc,weekday,local_time,utc_time,order_id)
               values(?,?,?,?,?,?,?,?)
               on conflict(code) do update set zone=excluded.zone, rule=excluded.rule,
                 anchor_utc=excluded.anchor_utc, weekday=excluded.weekday,
                 local_time=excluded.local_time, utc_time=excluded.utc_time, order_id=excluded.order_id""",
            (code, zone_name, rule, fmt_utc(anchor), weekday, local_time, utc_time, order_id))
        uid = code + "-" + service.strftime("%Y%m%d")
        db.execute("insert or ignore into events(uid,starts) values(?,?)", (uid, fmt_utc(stamp)))
        summary.append(dict(code=code, order=order_id, rule=rule, zone=zone_name, first_uid=uid,
                            first_utc=fmt_utc(stamp), weekday=weekday))
    return summary


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action", choices=["serve","request","migrate"])
    p.add_argument("value", nargs="?")
    args=p.parse_args()
    db=sqlite3.connect(os.getenv("PORTAL_DB","data/portal.sqlite"))
    if args.action == "migrate":
        print(json.dumps(migrate(db, args.value), ensure_ascii=False))
        db.commit()
    elif args.action == "request":
        print(route(db,args.value)[1])
    else:
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                try:
                    mime, text = route(db,self.path)
                    self.send_response(200)
                except KeyError:
                    mime,text = "text/plain","missing"
                    self.send_response(404)
                self.send_header("Content-Type",mime+"; charset=utf-8")
                self.end_headers()
                self.wfile.write(text.encode())
        HTTPServer(("127.0.0.1",int(args.value or 8090)),Handler).serve_forever()


if __name__ == "__main__":
    main()
