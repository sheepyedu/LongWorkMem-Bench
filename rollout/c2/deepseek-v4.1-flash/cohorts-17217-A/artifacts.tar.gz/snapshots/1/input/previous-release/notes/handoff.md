# 委托：东京运营报告日期早一天 — 修复交接

业务日 2026-02-18。范围：仅门户显示层，未改动数据、未投递任何批次。

## 根因
project/portal.py 的 local_label() 把 **UTC 日期**（utc[:10]）直接拼到 **当地时刻**上：

    return utc[:10] + " " + datetime.fromisoformat(utc).astimezone(ZoneInfo(zone)).strftime("%H:%M")

凡是"当地时钟跨过午夜、UTC 仍在昨天"的场次，日期就少一天。UTC 与 Europe/London（零偏移）
看不出问题，Asia/Tokyo（+9）在傍晚/夜间场次上暴露，故称"偶尔提前一天"。
实测 4 场（data/portal.sqlite）：
- legacy-east  2026-03-05T23:30Z → 东京 2026-03-06 08:30（旧显示 2026-03-05 08:30）
- K17-20260306 2026-03-06T15:00Z → 东京 2026-03-07 00:00（旧显示 2026-03-06 00:00）
- M42-20260306 同上
- legacy-west  2026-03-06T02:15Z → 东京 2026-03-06 11:15（本来就对）

## 改动（唯一改动文件：project/portal.py）
- 新增 as_utc()：解析存储时间戳为 UTC 感知时刻；无时区的值按 UTC 解释（不再落到宿主本地时区）。
- local_label() 改为**日期与时刻取自同一当地时刻**：`as_utc(utc).astimezone(ZoneInfo(zone)).strftime("%Y-%m-%d %H:%M")`。
- 列表 `/` 与邀请详情 `/invite/UID` 共用该函数，两处同步修好，文本格式仍为 `YYYY-MM-DD HH:MM`。
- 输出文本做了 escape（quote=False），data-uid 属性与 UID 链接结构不变。
- 未改：events() 的取数/排序、/api/events 的 JSON 字段与 utc 原值、日期范围语义（仍按原定场次日/含端点）、
  404 处理、Portal DB schema、bookings。没有新增/删除任何行，无需重新导入或投递。

## 验证
1. 回归测试 `python3 project/test_portal.py`：11 项全通过（东京跨日双向、邀请详情与列表一致、
   UTC/London 不变、New_York/Kolkata/Kiritimati、无时区+带偏移时间戳、API 字段与 utc 原值、
   范围过滤、UID 链接、未知路由/未知时区仍 404、bookings 未被读取改动）。
2. 真实服务进程（project/http_read.py）逐 URL 与修复前基线逐字节比对：
   /api/events（含 channel=A/B 与两段 from/to）、/invite/legacy-west?tz=UTC、/invite/K17-20260306?tz=Europe/London、
   /?tz=UTC、/?tz=Europe/London —— 8/8 完全一致（UTC API 未变）。
3. 交叉核对：4 场 × 9 个时区，列表与邀请详情的文本与独立参考实现计算值全部一致，0 处不符。
4. 数据未动：events、bookings 与修复前备份（scratch/portal.backup.sqlite）逐行相同；
   报名 4 条（seat-K17-20260306 / seat-M42-20260306 / seat-legacy-east / seat-legacy-west）在列。

## 遗留 / 注意
- /api/events 仍按 UTC 日期（即原定场次日）过滤：东京 03-07 00:00 的 K17 场次属于 from/to=2026-03-06 的区间。
  这是既有接口契约，为不破坏旧消费方而未改；若运营希望 API 也按当地日过滤，需要新参数另行确认。
- 因此当 tz 与场次日不一致时，"列表页某行显示的当地日期"可能落在请求区间之外（如上面 K17 场次）。
  本次仅修日期文本，未改筛选，避免影响既有 UTC API 与历史链接。
- 未知 tz 仍返回 404（ZoneInfoNotFoundError 是 KeyError 子类，沿用原有分支），与修复前一致。
- project/portal.py 的 migrate 仍是空操作（无 input/intake.json，无新增系列）；本委托不涉及排期变更，
  因此没有生成/投递 ICS，也没有调用 publish。若后续要发版给订阅端，从 PORTAL_DB + project/ 即可重启。
