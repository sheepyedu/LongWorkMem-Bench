# 委托：备份交接 + 第二季度全量发布（业务日 2026-03-30）

交付：`out/backup.sqlite`（交接备份）、`out/q2-A.ics`、`out/q2-B.ics`（本批实际投递件）、
`out/new-A.ics`（新订阅者的第二季度全量，仅交文件、**未投递**）。实际投递 2 次（A、B 各一批 26 场）。

## 1. 交接备份
新增入口：`python3 project/backup.py OUTPUT [SOURCE]`
- 用 sqlite3 在线备份 API，读连接以 `mode=ro` 打开：**不会写生产库**，读写并发下也是一致快照。
- 落地后 `pragma journal_mode=delete`，成品是**单文件**（无 -wal/-shm），配合 `project/` 即可
  `PORTAL_DB=<该文件>` 干净重启；`pragma integrity_check=ok`。
- 目标文件先删再写，不与旧页混合；不是门户库（缺 events/bookings/series/adjustment）直接拒绝。
- 输出计数与 sha256：`integrity=ok events=4 bookings=4 series=2 adjustment=4`，
  `sha256=0e780026467b12200b22c5a795cc9e58ceb3f562d794230e01fa10cff6659b81`。

干净实例验证（只有 `project/` + `handover.sqlite`，**没有 input/、data/、notes/**）：
- 17/17 个 URL 与生产库输出逐字节相同：`/api/events`（无参、03-06..03-27 两频道、06-01..06-30 两频道）、
  `/?tz=`（UTC、东京、伦敦）、六个旧邀请（legacy-east、legacy-west、K17-20260306、M42-20260320 A/B、M42-20260327）。
- 真服务进程（`project/http_read.py`）在干净实例里同样作答；`migrate` 无 input 时打印 "nothing to import" 不报错；
  `prepare` 能复现 `out/new-A.ics` 逐字节相同；`recover` 入口也在。
- events 4 / bookings 4 / series 2 / adjustment 4 行逐行相同 → **旧报名、旧邀请身份都在**。
- 收件历史不在库里（属订阅端），干净实例照样用 `receipts(CHANNEL)` 重新取。

## 2. 第二季度发布（2026-04-01 ~ 2026-06-30）
两系列各 13 个周五 = 26 场，均为合同钟点，该季无任何签批/更正生效，两频道一致：
- K17（OP-381 场馆当地钟点）10:00 纽约 → 全季 EDT，`14:00Z`；
- M42（OP-629 UTC 钟点）→ 全季 `15:00Z`；
- 非试点旧活动（legacy-east / legacy-west）不在区间内，也没有混入文件。

| 频道 | 相对收件历史的变化 | 键 / 回执 |
|---|---|---|
| A | 26 场（该季此前未投递） | `A-delta-20260401-20260630-5fc0bbd8` / **A-00004** |
| B | 26 场 | `B-delta-20260401-20260630-5fc0bbd8` / **B-00005** |

- 键后缀就是文件 sha256 前 8 位，重试同键同内容安全；两频道该季内容相同故摘要相同，但**键带频道前缀**，互不覆盖。
- 回执核对：A 4 批、B 5 批；两频道合并态与门户排期逐场一致（03-06..06-30 共 34 场，0 处不符）。
- 投递后再算增量：两频道该季 **0 场**（无遗留待补）；七月以后尚有 26 场未投（本委托只到六月，属正常待发）。
- `data/receipts-A.json`、`data/receipts-B.json` 已追加本批真实回执，可直接用于下次 `--since`。

## 3. 新订阅者全量文件 `out/new-A.ics`
- `python3 project/prepare.py A 2026-04-01 2026-06-30 out/new-A.ics`（不带 `--since` = 全量口径）。
- 26 个 VEVENT，全部 CONFIRMED，UID 为 `系列代码-原定日`，自包含 VCALENDAR，确定性输出。
- 因为它覆盖的正是本批刚发出的那 26 场，文件与 `out/q2-A.ics`、`out/q2-B.ics` **逐字节相同**
  （sha256 `5fc0bbd8…`）。这是"该季此前零投递"的必然结果，不是拿增量冒充全量：用别的区间试（如
  03-06..06-30）全量与增量就会分叉。
- **未投递**：新订阅者走各自的接入流程；对 A 再投一次同内容只会多一次通知。

## 4. 验证
- 测试 94 项全过：test_portal 11、test_migrate 14、test_prepare 8、test_adjust 15、test_ch64 10、
  test_recover 16、**test_backup 10**、**test_q2 10**。
  - test_backup：逐行一致、单文件自包含、旧文件不混合、非门户库/缺文件被拒、快照不动生产库、CLI 报告、
    干净实例（子进程 + 真服务）页面一致、旧邀请仍可定位、干净实例可继续 migrate/prepare、
    交付的 backup.sqlite 与生产库同一份数据。
  - test_q2：26 个周五、合同钟点、无旧活动混入、两频道一致、26 场都到过两频道、
    该季增量复算 = 0（已送达）、投递批次复算 = 26 场且与交付文件逐字节相同、
    新订阅者文件 26 场/唯一 UID/全 CONFIRMED/自包含/可重复生成/与三月文件不同。
- 交付件 sha256：`out/backup.sqlite 0e780026…`、`out/q2-{A,B}.ics` 与 `out/new-A.ics` 均 `5fc0bbd8…`。
- 重新生成备份与交付件逐字节相同 → 交付物仍是当前状态。

## 5. 遗留 / 注意
- 备份只含数据库；`data/receipts-*.json` 是收件历史快照，随工位走，但权威来源是 `receipts(CHANNEL)`，
  干净实例上重新取即可，不必拷 data/。
- 该季两频道内容相同，但频道在别处会分叉（如 `M42-20260320`：A 17:00Z / B 15:00Z）。手工拼邀请链接时
  给 B 的一律带 `&channel=B`，默认是 A。
- 七月以后（2026-07-01 起）已排期但未投递，26 场，需下一次委托按区间发。
- `out/preview.json` 仍是最初伦敦预览，未随排期更新；它不是交付依据，保留只为留痕。
- 交接时若要连排期历史一起带走：`out/backup.sqlite` + `project/` 足够；`notes/` 只是给人看的说明。
