# 委托：迁移 intake.json 两个试点系列并按签批续排（业务日 2026-02-19）

## 签批解读（资料库 input/records/*.txt）
| 工单 | 系列 | 文本要点 | 规则 |
|---|---|---|---|
| OP-381 | K17 | 「全年保持首场的**场馆当地钟点**」 | `venue_local_clock` |
| OP-629 | M42 | 「全年保持首场的 **UTC 钟点**」 | `utc_clock` |
首场锚点均为 2026-03-06T15:00:00Z，场馆 America/New_York（当地 10:00 EST，周五）。
两条签批在美东 2026-03-08 进入夏令时后**分叉**：K17 因锁定当地 10:00 改为 14:00Z；
M42 锁定 15:00Z 不变（当地变 11:00）。11-01 退出夏令时后 K17 回到 15:00Z。

## 实现（project/portal.py）
1. `migrate [INTAKE] [RECORDS]`（默认 input/intake.json、input/records）：
   - 逐条读 intake：`code`/`anchor`/`zone`/`order`；未知 IANA 时区直接报错。
   - 签批解析 `approval_rule()`：文本含 `UTC` → utc_clock；含 `当地/本地` → venue_local_clock；
     两者皆无但提到别的工单号（如「同意按 OP-381 之条款执行」）→ 递归沿用该工单规则（带环检测）；
     都解析不出 → `ValueError` 报错退出，不猜测。
   - 新增 `series` 表（code 主键, ord, anchor, zone, rule, weekday, clock, channel, imported）：
     `create table if not exists`，已存在且内容相同 → `unchanged`（幂等），不同 → `updated`（不删旧系列）。
   - 首场合并：算出的首场 UID 若已在 events 中则**保留原行**（UID 与报名不变），缺失才插入；
     仅当时刻与签批不符才按新时刻改写同一 UID（本次两者相同，故 events 一行未动）。
   - 全部动作在同一事务，末尾 commit；中途报错不落盘。缺 intake 文件时打印提示、无新增。
2. 排期展开 `occurrences()`：每周一次、无截止；按规则的参照日历取「原定日」——
   场馆钟规则用场馆当地日历，UTC 钟规则用 UTC 日历；UID = `系列代码-原定日`（如 K17-20260313），
   与已部署订阅端的 VEVENT UID 约定一致。当地钟规则逐日 `ZoneInfo` 换算，夏令时自动生效。
3. 服务面：`/api/events`、`/`、`/invite/UID` 共用同一取数。
   - **仅当 from 与 to 都给出且可解析**时按区间展开试点场次（与存量 events 行按 UID 去重，存量优先）；
     无区间请求不展开（否则无限），因此无参 `/api/events` 输出与迁移前**逐字节相同**。
   - `/invite/UID`：先查存量，未命中再按 UID 里的系列代码+日期反查该单场（校验确为该系列的周五场次），
     所以未来场次的邀请链接可用、伪造/非场次日返回空 `<main>`。
   - `channel` 参数沿用既有行为（intake 无渠道字段，仍不参与过滤），非试点旧接口不变。

## 验证
- `python3 project/test_migrate.py`：14 项通过（导入两条签批、报名与既有邀请标识不变、
  连跑 3 次完全幂等、缺 intake 无动作、签批读不出则整体回滚、
  K17 随夏令时 15:00Z→14:00Z→15:00Z / M42 恒定 15:00Z、只出周五且无截止（2040 年仍有场次）、
  两条系列当地钟点标签 10:00 与 11:00、未来邀请链接可用+假 UID 不解析、
  无区间 API 仍 4 行、非试点旧 API 不变、**新工单号增量导入**（OP-777 引用 OP-381 → 沿用场馆钟规则，
  H95 伦敦 3 月 15:00Z、4 月 14:00Z，K17/M42 保留）与 CLI 同入口二次执行只报 unchanged）。
- `python3 project/test_portal.py`：11 项仍通过（上一委托的东京日期修复未回退）。
- 真库 `data/portal.sqlite` 实跑 migrate 3 次：第 1 次 imported×2，第 2、3 次 unchanged×2；
  events 仍 4 行且与迁移前逐行相同，bookings 仍 4 条。
- 真服务进程（project/http_read.py）比对上一委托基线：无参 `/api/events`（A/B）、
  `/invite/legacy-west?tz=UTC`、`/invite/K17-20260306?tz=Europe/London`、`/?tz=UTC`、`/?tz=Europe/London`
  6/6 逐字节未变；区间请求新增试点场次：
  2026-03-13..14 → K17-20260313 14:00Z、M42-20260313 15:00Z；页面标签 NY 10:00 / 11:00。

## 上线后接收新编号
同一入口 `python3 project/portal.py migrate`（或 PORTAL_DB=... 指定库）即可：新增/追加 intake.json
条目（新工单号、可指向已有签批）+ 资料库放入对应工单文本 → 再次执行即增量导入，旧系列、旧邀请、旧报名全部保留。

## 遗留 / 注意
- intake 无 `channel` 字段，`series.channel` 留空且不参与过滤（与既有部署一致）；将来若要按渠道分发，
  需签批/ intake 提供渠道后再启用 A/B 独立。
- `prepare.py`/`recover.py` 尚未在本工位出现，因此本次**未生成 ICS、未调用 publish**（无投递、无新回执）。
  订阅端分发待发布准备入口就绪后按 range 展开（本模块 `occurrences()` 可直接复用）。
- 签批只支持「场馆当地钟点 / UTC 钟点」两类；若出现「临时时移 ±N 小时」等其它措辞会直接报错待人工确认，不静默猜测。
- 夏令时跳变的墙钟歧义/不存在时刻按 PEP 495 fold=0 处理（本次锚点 10:00 不涉及）。
- 单次请求每系列展开上限 1000 场（超长区间截断，不会拖垮响应）。
- 迁移前备份：scratch/portal.pre-migrate.sqlite；干净重启 = 该备份 + project/（PORTAL_DB 指向备份即可，
  serve 会自动 `create table if not exists`）。
