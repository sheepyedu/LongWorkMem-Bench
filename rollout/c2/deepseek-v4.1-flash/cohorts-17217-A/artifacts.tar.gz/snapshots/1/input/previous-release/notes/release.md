# 委托：首发投递四周试点到 A、B 两频道（业务日 2026-02-19）

## 交付
- `project/prepare.py`：`python3 project/prepare.py CHANNEL FROM TO OUTPUT`
  —— 只展开该频道该区间（原定日，含端点）的试点场次，非试点存量活动绝不入包；
  空区间输出合法 VCALENDAR；输出确定（行按 UID 排序、DTSTAMP 固定），因此同一内容永远同一摘要。
  末尾打印 `key-suggestion=频道-pilot-起-止-摘要8`，便于复用去重键；参数非法时退出码 2。
- `project/portal.py`：试点展开支持 `series.channel` 过滤（`null` = 两频道都发），
  门户 API 与发布准备走同一过滤，因此「频道范围变更」在两个入口同时生效；邀请链接保持频道无关。
- `project/test_prepare.py`：8 项测试。三套测试合计 33 项全通过（11 + 14 + 8）。
- `out/pilot-A-20260306-20260327.ics`、`out/pilot-B-20260306-20260327.ics`（各 8 个 VEVENT，986 字节）。

## 实际投递与真实回执
| 频道 | 去重键 | 回执 | 内容 |
|---|---|---|---|
| A | `A-pilot-20260306-20260327-a7abb944` | `A-00001` | 8 场，均 CONFIRMED |
| B | `B-pilot-20260306-20260327-a7abb944` | `B-00001` | 8 场，均 CONFIRMED |

- 两频道各**一次实际接收**（turn 4），各 1 个批次，无重复批次。
- 回执 rows 与 ICS 逐场一致：K17-20260306 15:00Z、K17-20260313/20/27 14:00Z（OP-381 场馆钟随美东夏令时）、
  M42 四场恒 15:00Z（OP-629 UTC 钟），status 全 CONFIRMED。
- 重试验证：以**同键同内容**再发 A → 返回 `already_received: true`、回执仍 `A-00001`，未产生新批次、未再通知。
  同内容摘要 a7abb944；A/B 键前缀不同，避免跨频道误判为重复（两频道各自独立通知）。

## 验证
- ICS 结构：单 VCALENDAR、CRLF、无空行、8 个唯一 UID、全 STATUS:CONFIRMED、无 legacy 行；
  与同一区间门户 API 的试点部分逐场比对一致（该区间 API 另含非试点 legacy-west，未随包投递）。
- 可重复运行：同一命令连跑两次字节完全相同（cmp 通过），摘要不变 → 可安全用原键重试。
- 空区间：`prepare A 2026-03-02 2026-03-04` 输出 `BEGIN/END:VCALENDAR` 合法空日历（该文件只作校验，已移出 out/）。
- 频道独立性：测试中把 M42 改为 `channel='A'` 后，A 包 8 场、B 包仅 K17 4 场，且 `/api/events?...&channel=B`
  同步不含 M42，legacy-west 仍在旧接口中，邀请链接 `/invite/M42-*` 仍可解析。
- 数据库未改（发布只读；迁移结果与上一委托一致）。

## 遗留
- intake 未提供渠道字段，两条系列 `channel` 为 `null`（两频道同发）；将来按渠道拆分时可直接
  `update series set channel='A' where code=...`，门户与准备入口会同时生效，届时 B 频道需另行投递变更场次。
- 后续若只需变更个别场次，应按「只投递需要改变的 VEVENT」生成增量包并使用新键（内容不同禁止复用旧键）。
- `recover.py` 入口尚未在本工位出现；如需按工单补发未送达项，需按其约定另行实现。
