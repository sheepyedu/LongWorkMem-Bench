"""Update the expectations that the urgent correction legitimately moves."""
import io

def patch(path, pairs):
    with io.open(path, encoding="utf-8") as handle:
        text = handle.read()
    for old, new in pairs:
        assert text.count(old) == 1, (path, text.count(old), old[:60])
        text = text.replace(old, new, 1)
    with io.open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    print("patched", path)


patch("project/test_migrate.py", [(
    '        self.assertEqual(utc["M42-20260327"], "2026-03-27T15:00:00Z")   # 到期恢复\n',
    '        self.assertEqual(utc["M42-20260327"], "2026-03-27T16:30:00Z")   # 值班台紧急更正 +90 分钟\n',
)])

patch("project/test_prepare.py", [(
    '        self.assertEqual(starts["M42-20260327"], "20260327T150000Z")   # 到期恢复\n',
    '        self.assertEqual(starts["M42-20260327"], "20260327T163000Z")   # 值班台紧急更正 +90 分钟\n',
)])

patch("project/test_adjust.py", [
    ('            "M42-20260327": "2026-03-27T15:00:00Z",     # 到期恢复\n',
     '            "M42-20260327": "2026-03-27T16:30:00Z",     # 值班台紧急更正 +90 分钟\n'),
    ('        untouched = {"K17-20260306", "K17-20260313", "K17-20260327", "M42-20260306", "M42-20260327"}\n',
     '        untouched = {"K17-20260306", "K17-20260313", "K17-20260327", "M42-20260306"}\n'),
    ('        self.assertEqual(week["M42-20260327"], "2026-03-27T15:00:00Z")\n',
     '        self.assertEqual(week["M42-20260327"], "2026-03-27T16:30:00Z")   # 值班台更正, 与本批签批无关\n'),
    ('            "M42-20260327": {"uid": "M42-20260327", "utc": "2026-03-27T15:00:00Z", "status": "CONFIRMED"},\n'
     '        }}], handle)\n',
     '            "M42-20260327": {"uid": "M42-20260327", "utc": "2026-03-27T15:00:00Z", "status": "CONFIRMED"},\n'
     '        }},\n'
     '        # 值班台的紧急更正已经收到, 相对这份历史也不是变化\n'
     '        {"key": "urgent-0327-A", "receipt": "A-00003", "rows": {\n'
     '            "M42-20260327": {"uid": "M42-20260327", "utc": "2026-03-27T16:30:00Z", "status": "CONFIRMED"},\n'
     '        }}], handle)\n'),
])

patch("project/test_ch64.py", [
    ('            self.assertEqual(got["M42-20260327"], "2026-03-27T15:00:00Z")   # 到期恢复\n',
     '            self.assertEqual(got["M42-20260327"], "2026-03-27T16:30:00Z")   # 值班台紧急更正 +90 分钟\n'),
    ('                       {"key": "delta", "receipt": f"{channel}-00002",\n'
     '                        "rows": {u: {"uid": u, "utc": t, "status": "CONFIRMED"} for u, t in delta.items()}}],\n',
     '                       {"key": "delta", "receipt": f"{channel}-00002",\n'
     '                        "rows": {u: {"uid": u, "utc": t, "status": "CONFIRMED"} for u, t in delta.items()}},\n'
     '                       # 值班台的紧急更正已收到, 与本批签批无关\n'
     '                       {"key": f"urgent-0327-{channel}", "receipt": f"{channel}-00003",\n'
     '                        "rows": {"M42-20260327": {"uid": "M42-20260327",\n'
     '                                                  "utc": "2026-03-27T16:30:00Z", "status": "CONFIRMED"}}}],\n'),
])
