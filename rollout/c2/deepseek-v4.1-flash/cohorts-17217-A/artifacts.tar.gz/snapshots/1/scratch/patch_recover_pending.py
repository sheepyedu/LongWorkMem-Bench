import io
PATH = "project/recover.py"
with io.open(PATH, encoding="utf-8") as handle:
    text = handle.read()
old = '''def pending(entry, state, by_key=None):
    """True when the channel does not already hold exactly this occurrence."""
    held = state.get(entry["uid"])
    if held is None:
        return True
    if held.get("utc") != entry["utc"] or held.get("status") != entry["status"]:
        return True
    sent = (by_key or {}).get(entry["key"])
    if sent:                                  # the original key must stay honest
        row = sent.get(entry["uid"])
        if row and (row.get("utc") != entry["utc"] or row.get("status") != entry["status"]):
            raise ValueError(f"key {entry['key']} already carried different content for "
                             f"{entry['uid']} ({row.get('utc')}); refusing to reuse it")
    return False
'''
new = '''def pending(entry, state, by_key=None):
    """True when the channel does not already hold exactly this occurrence."""
    held = state.get(entry["uid"])
    if (held is not None and held.get("utc") == entry["utc"]
            and held.get("status") == entry["status"]):
        return False                          # already received: nothing to send
    sent = (by_key or {}).get(entry["key"])   # about to send under the original key
    if sent:
        row = sent.get(entry["uid"])
        if row and (row.get("utc") != entry["utc"] or row.get("status") != entry["status"]):
            raise ValueError(f"key {entry['key']} already carried different content for "
                             f"{entry['uid']} ({row.get('utc')}); refusing to reuse it")
    return True
'''
assert text.count(old) == 1
with io.open(PATH, "w", encoding="utf-8") as handle:
    handle.write(text.replace(old, new, 1))
print("patched")
