src = open("project/portal.py").read()

# A) day scanner + revocation parser, inserted before parse_adjustment
anchor = "def parse_adjustment(text, series_by_code):"
addition = '''def listed_days(text, year):
    """Days written as 3月13日、20日 (a shared month may be omitted)."""
    days, month = set(), None
    for written_month, written_day in DAY_WORD.findall(text):
        if written_month:
            month = int(written_month)
        if month is None:
            raise ValueError(f"ticket day without a month: {text.strip()!r}")
        try:
            days.add(date(year, month, int(written_day)))
        except ValueError:
            raise ValueError(f"ticket has an impossible date: {text.strip()!r}")
    if not days:
        raise ValueError(f"ticket names no 原定 day: {text.strip()!r}")
    return sorted(days)


def parse_revocation(text, series_by_code, known):
    """A ticket that withdraws another one, possibly for one channel only (CH-64)."""
    if not REVOKE_WORD.search(text):
        return None
    target = next(iter(TICKET.findall(text)), None)
    if target is None:
        raise ValueError(f"撤销 ticket names no ticket to withdraw: {text.strip()!r}")
    codes = {row["code"] for row in known if row["ticket"] == target}
    if len(codes) != 1:
        raise ValueError(f"cannot tell what {target} schedules (found {sorted(codes) or 'nothing'})")
    code = codes.pop()
    days_listed = listed_days(text, as_utc(series_by_code[code]["anchor"]).year)
    if len(days_listed) != 1:
        raise ValueError(f"撤销 ticket names several days, needs a human: {text.strip()!r}")
    windows = [row for row in known if row["ticket"] == target and row["kind"] != KIND_REVOKE]
    if not any(as_date(row["from_day"]) <= days_listed[0] <= as_date(row["to_day"]) for row in windows):
        raise ValueError(f"{target} does not cover {days_listed[0]} ({text.strip()!r})")
    return dict(code=code, kind=KIND_REVOKE, from_day=days_listed[0].isoformat(),
                to_day=days_listed[0].isoformat(), days=0, minutes=0,
                basis=RULE_ORIGINAL, channel=channels_of(text), target=target)


'''
assert anchor in src
src = src.replace(anchor, addition + anchor, 1)

# B) day scanning now shared, and non-revoke tickets carry channel/target
old_days = '''    year = as_utc(series["anchor"]).year
    days_listed, month = set(), None
    for written_month, written_day in DAY_WORD.findall(text):
        if written_month:
            month = int(written_month)
        if month is None:
            raise ValueError(f"ticket day without a month: {text.strip()!r}")
        try:
            days_listed.add(date(year, month, int(written_day)))
        except ValueError:
            raise ValueError(f"ticket has an impossible date: {text.strip()!r}")
    days_listed = sorted(days_listed)'''
assert old_days in src
src = src.replace(old_days, '''    days_listed = listed_days(text, as_utc(series["anchor"]).year)''')

old_return = '''    return dict(code=code, kind=kind, from_day=days_listed[0].isoformat(),
                to_day=days_listed[-1].isoformat(), days=days, minutes=minutes, basis=basis)'''
assert old_return in src
src = src.replace(old_return, '''    return dict(code=code, kind=kind, from_day=days_listed[0].isoformat(),
                to_day=days_listed[-1].isoformat(), days=days, minutes=minutes, basis=basis,
                channel=channels_of(text), target=None)''')

# C) importer: both kinds, channel in the key, channel/target persisted
old_parse = '''        parsed = parse_adjustment(text, series_by_code)
        if parsed is None:
            continue
        check_adjustment(series_by_code[parsed["code"]], parsed)
        key = f'{ticket}:{parsed["code"]}:{parsed["kind"]}:{parsed["from_day"]}\''''
assert old_parse in src, "parse block"
src = src.replace(old_parse, '''        known = adjustments(db)
        parsed = parse_revocation(text, series_by_code, known) if REVOKE_WORD.search(text) else None
        if parsed is None:
            parsed = parse_adjustment(text, series_by_code)
        if parsed is None:
            continue
        check_adjustment(series_by_code[parsed["code"]], parsed)
        key = f'{ticket}:{parsed["code"]}:{parsed["kind"]}:{parsed["from_day"]}'
        if parsed["channel"]:
            key += f':{parsed["channel"]}\'''')

old_update = '''            db.execute("update adjustment set ticket=?,code=?,kind=?,from_day=?,to_day=?,days=?,minutes=?,basis=? where id=?",
                       (wanted["ticket"], wanted["code"], wanted["kind"], wanted["from_day"],
                        wanted["to_day"], wanted["days"], wanted["minutes"], wanted["basis"], key))'''
assert old_update in src
src = src.replace(old_update, '''            db.execute("update adjustment set ticket=?,code=?,kind=?,from_day=?,to_day=?,days=?,minutes=?,basis=?,channel=?,target=? where id=?",
                       (wanted["ticket"], wanted["code"], wanted["kind"], wanted["from_day"],
                        wanted["to_day"], wanted["days"], wanted["minutes"], wanted["basis"],
                        wanted["channel"], wanted["target"], key))''')

old_print = '''        print(f'{ticket} {parsed["code"]} {parsed["kind"]} {parsed["from_day"]}..{parsed["to_day"]} '
              f'days={parsed["days"]:+d} minutes={parsed["minutes"]:+d} basis={parsed["basis"]} adjustment={action}')'''
assert old_print in src
src = src.replace(old_print, '''        scope = parsed["channel"] or "A+B"
        tail = f' target={parsed["target"]}' if parsed["target"] else ""
        print(f'{ticket} {parsed["code"]} {parsed["kind"]} {parsed["from_day"]}..{parsed["to_day"]} '
              f'days={parsed["days"]:+d} minutes={parsed["minutes"]:+d} basis={parsed["basis"]} '
              f'channel={scope}{tail} adjustment={action}')''')

# D) invitation lookups follow the channel of the link
old_resolve = '''def resolve_occurrence(db, uid):
    """Single pilot occurrence addressed by its UID, if that UID is real."""
    code, day = uid.rpartition("-")[0], uid_day(uid)
    if not code or day is None:
        return None
    for row in occurrences_around(db, code, day):'''
assert old_resolve in src
src = src.replace(old_resolve, '''def resolve_occurrence(db, uid, channel=None):
    """Single pilot occurrence addressed by its UID, if that UID is real."""
    code, day = uid.rpartition("-")[0], uid_day(uid)
    if not code or day is None:
        return None
    for row in occurrences_around(db, code, day, channel):''')

src = src.replace('def occurrences_around(db, code, day):', 'def occurrences_around(db, code, day, channel=None):')
old_around = '''    series = dict(zip(SERIES_COLUMNS, row))
    return occurrences(series, day, day, rules=rules_by_code(db).get(series["code"], ()))'''
assert old_around in src
src = src.replace(old_around, '''    series = dict(zip(SERIES_COLUMNS, row))
    active, revokes = rules_by_code(db, channel)
    name = series["code"]
    return occurrences(series, day, day, rules=active.get(name, ()), revokes=revokes.get(name, ()))''')

src = src.replace("            row = resolve_occurrence(db, uid)",
                  '            row = resolve_occurrence(db, uid, query.get("channel", "A"))')
open("project/portal.py","w").write(src)
print("patched")
