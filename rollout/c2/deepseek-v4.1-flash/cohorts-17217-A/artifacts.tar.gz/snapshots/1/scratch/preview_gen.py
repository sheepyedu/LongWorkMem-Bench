"""One-off: London partner preview, 2026-03-06..2026-03-27, pilot series only."""
import json, sqlite3, sys
from datetime import date, timedelta
sys.path.insert(0, "project")
import portal

ZONE = "Europe/London"
START, END = date(2026, 3, 6), date(2026, 3, 27)

db = portal.ensure_schema(sqlite3.connect("data/portal.sqlite"))
# widen the expansion window so the London-calendar filter can't clip an edge occurrence
rows = portal.series_rows(db, START - timedelta(days=2), END + timedelta(days=2))
pilots = [r for r in rows if portal.uid_day(r["uid"]) is not None]      # series table only -> pilots
preview = []
for row in pilots:
    label = portal.local_label(row["utc"], ZONE)
    if START <= date.fromisoformat(label[:10]) <= END:                  # 按伦敦日历取四周
        preview.append({"uid": row["uid"], "local": label})
preview.sort(key=lambda r: (r["local"], r["uid"]))
json.dump(preview, open("out/preview.json", "w"), indent=2, ensure_ascii=False)
print(json.dumps(preview, indent=2, ensure_ascii=False))
