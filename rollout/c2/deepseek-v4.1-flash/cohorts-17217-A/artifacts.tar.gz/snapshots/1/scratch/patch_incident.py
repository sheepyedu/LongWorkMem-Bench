"""Add the duty-desk incident corrections to the deployed app (idempotent patch)."""
import io

PATH = "project/portal.py"
with io.open(PATH, encoding="utf-8") as handle:
    text = handle.read()

# 1. constant -----------------------------------------------------------------
old = 'CLOCK = "input/clock.txt"\n'
new = 'CLOCK = "input/clock.txt"\nINCIDENT = "input/incident.json"   # urgent corrections the duty desk recorded\n'
assert old in text
text = text.replace(old, new, 1)

# 2. migrate() also imports the incident corrections ---------------------------
old = """    import_adjustments(db, records, business_day)
    db.commit()
"""
new = """    import_adjustments(db, records, business_day)
    incident_adjustments(db, os.getenv("INCIDENT", INCIDENT), business_day)
    db.commit()
"""
assert old in text
text = text.replace(old, new, 1)

# 3. factor the adjustment upsert out of import_adjustments --------------------
old = '''        key = f'{ticket}:{parsed["code"]}:{parsed["kind"]}:{parsed["from_day"]}'
        if parsed["channel"]:
            key += f':{parsed["channel"]}'
        wanted = dict(parsed, id=key, ticket=ticket)
        current = db.execute("select " + ",".join(ADJUSTMENT_COLUMNS) + " from adjustment where id=?", (key,)).fetchone()
        if current is None:
            db.execute("insert into adjustment(" + ",".join(ADJUSTMENT_COLUMNS) + ",imported) values("
                       + ",".join("?" * (len(ADJUSTMENT_COLUMNS) + 1)) + ")",
                       tuple(wanted[c] for c in ADJUSTMENT_COLUMNS) + (business_day,))
            action = "imported"
        elif dict(zip(ADJUSTMENT_COLUMNS, current)) == wanted:
            action = "unchanged"
        else:
            db.execute("update adjustment set ticket=?,code=?,kind=?,from_day=?,to_day=?,days=?,minutes=?,basis=?,channel=?,target=? where id=?",
                       (wanted["ticket"], wanted["code"], wanted["kind"], wanted["from_day"],
                        wanted["to_day"], wanted["days"], wanted["minutes"], wanted["basis"],
                        wanted["channel"], wanted["target"], key))
            action = "updated"
        imported.append(wanted)
'''
new = '''        wanted, action = store_adjustment(db, ticket, parsed, business_day)
        imported.append(wanted)
'''
assert old in text
text = text.replace(old, new, 1)

# 4. new helpers after import_adjustments --------------------------------------
anchor = '''# --------------------------------------------------------------------------- #
# http surface
# --------------------------------------------------------------------------- #
'''
assert anchor in text
block = '''def store_adjustment(db, ticket, parsed, business_day=""):
    """Insert or update one adjustment; the id is stable, so re-runs are no-ops."""
    key = f'{ticket}:{parsed["code"]}:{parsed["kind"]}:{parsed["from_day"]}'
    if parsed["channel"]:
        key += f':{parsed["channel"]}'
    wanted = dict(parsed, id=key, ticket=ticket)
    current = db.execute("select " + ",".join(ADJUSTMENT_COLUMNS) + " from adjustment where id=?", (key,)).fetchone()
    if current is None:
        db.execute("insert into adjustment(" + ",".join(ADJUSTMENT_COLUMNS) + ",imported) values("
                   + ",".join("?" * (len(ADJUSTMENT_COLUMNS) + 1)) + ")",
                   tuple(wanted[c] for c in ADJUSTMENT_COLUMNS) + (business_day,))
        return wanted, "imported"
    if dict(zip(ADJUSTMENT_COLUMNS, current)) == wanted:
        return wanted, "unchanged"
    db.execute("update adjustment set ticket=?,code=?,kind=?,from_day=?,to_day=?,days=?,minutes=?,basis=?,channel=?,target=? where id=?",
               (wanted["ticket"], wanted["code"], wanted["kind"], wanted["from_day"],
                wanted["to_day"], wanted["days"], wanted["minutes"], wanted["basis"],
                wanted["channel"], wanted["target"], key))
    return wanted, "updated"


# --------------------------------------------------------------------------- #
# urgent corrections (duty desk incident)
# --------------------------------------------------------------------------- #
def incident_ticket(entries):
    """Origin of the per-channel keys: urgent-0327-A / urgent-0327-B -> urgent-0327."""
    names = set()
    for channel, entry in entries.items():
        key = entry.get("key") or ""
        tail = f"-{channel}"
        names.add(key[:-len(tail)] if key.endswith(tail) else key)
    if len(names) != 1 or not next(iter(names)):
        raise ValueError(f"incident keys do not share one ticket name: {sorted(names)}")
    return names.pop()


def correction_of(series, base, moment):
    """A corrected UTC time read in the series' own clock -> (kind, days, minutes, basis)."""
    delta = moment - base
    if not delta:
        raise ValueError(f"incident repeats the contract time {stamp(moment)}; nothing to record")
    if series["rule"] == RULE_UTC:
        basis = RULE_UTC                       # 按通常 UTC 时刻
    else:                                      # 场馆钟点: the wall clock must move as far
        zone = ZoneInfo(series["zone"])
        wall = (moment.astimezone(zone).replace(tzinfo=None)
                - base.astimezone(zone).replace(tzinfo=None))
        if wall != delta:
            raise ValueError(f"correction {delta} crosses a clock change; needs a human")
        basis = RULE_LOCAL
    seconds = delta.total_seconds()
    if seconds % 86400 == 0:
        return KIND_MOVE, int(seconds // 86400), 0, basis
    if seconds % 60 == 0:
        return KIND_SHIFT, 0, int(seconds // 60), basis
    raise ValueError(f"correction of {delta} is not a whole number of minutes")


def incident_adjustments(db, incident=INCIDENT, business_day=""):
    """Record the urgent corrections in `adjustment`, so every reader agrees.

    The portal list, the invite page and the delta preparation all take the
    schedule from `adjustment`.  A correction that only reached one channel
    before the desk was cut off has to live here too, otherwise the next delta
    would push the subscribers back to the contract time.
    """
    if not incident or not os.path.exists(incident):
        return []
    with open(incident, encoding="utf-8") as handle:
        entries = json.load(handle)
    if not entries:
        return []
    ticket = incident_ticket(entries)
    series_by_code = {row[0]: dict(zip(SERIES_COLUMNS, row))
                      for row in db.execute("select " + ",".join(SERIES_COLUMNS) + " from series")}
    groups = {}
    for channel, entry in entries.items():
        if channel not in ("A", "B"):
            raise ValueError(f"incident names an unknown channel {channel!r}")
        groups.setdefault((entry["uid"], stamp(as_utc(entry["utc"])), entry["status"]), set()).add(channel)
    imported = []
    for (uid, moment, status), channels in sorted(groups.items()):
        code, day = uid.rpartition("-")[0], uid_day(uid)
        if not code or day is None or code not in series_by_code:
            raise ValueError(f"incident names an unknown occurrence {uid!r}")
        series = series_by_code[code]
        base = next((row for row in occurrences(series, day, day) if row["uid"] == uid), None)
        if base is None:
            raise ValueError(f"{code} has no occurrence on {day}")
        kind, days, minutes, basis = correction_of(series, as_utc(base["utc"]), as_utc(moment))
        scope = None if channels == {"A", "B"} else sorted(channels)[0]
        parsed = dict(code=code, kind=kind, from_day=day.isoformat(), to_day=day.isoformat(),
                      days=days, minutes=minutes, basis=basis, channel=scope, target=None)
        check_adjustment(series, parsed)
        wanted, action = store_adjustment(db, ticket, parsed, business_day)
        for channel in sorted(channels):        # the stored rule must reproduce the incident
            got = next(row for row in occurrences_around(db, code, day, channel) if row["uid"] == uid)
            if got["utc"] != moment or got["status"] != status:
                raise ValueError(f"{ticket} gives {uid} {got['utc']} on {channel}, "
                                 f"incident says {moment}")
        imported.append(wanted)
        print(f'{ticket} {code} {kind} {parsed["from_day"]}..{parsed["to_day"]} '
              f'days={days:+d} minutes={minutes:+d} basis={basis} '
              f'channel={scope or "A+B"} {uid}@{moment} adjustment={action}')
    return imported


'''
text = text.replace(anchor, block + anchor, 1)

with io.open(PATH, "w", encoding="utf-8") as handle:
    handle.write(text)
print("patched", PATH)
