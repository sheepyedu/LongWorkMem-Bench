import io
PATH = "project/portal.py"
with io.open(PATH, encoding="utf-8") as handle:
    text = handle.read()

old = '''        code, day = uid.rpartition("-")[0], uid_day(uid)
        if not code or day is None or code not in series_by_code:
            raise ValueError(f"incident names an unknown occurrence {uid!r}")
'''
new = '''        code, day = uid.rpartition("-")[0], uid_day(uid)
        if not code or day is None:
            raise ValueError(f"incident names a malformed occurrence {uid!r}")
        if code not in series_by_code:          # a deployment that does not carry that series
            print(f"{ticket} {code} skipped: no {code} series in this database ({uid})")
            continue
'''
assert old in text
text = text.replace(old, new, 1)
with io.open(PATH, "w", encoding="utf-8") as handle:
    handle.write(text)
print("patched")
