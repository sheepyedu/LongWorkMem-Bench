"""Recovery of an interrupted urgent update. Run: python3 project/test_recover.py"""
import json
import os
import shutil
import sqlite3
import tempfile
import unittest

import portal
import prepare
import recover

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INCIDENT = os.path.join(ROOT, "input", "incident.json")
RECORDS = os.path.join(ROOT, "input", "records")
INTAKE = os.path.join(ROOT, "input", "intake.json")


def write(folder, name, payload):
    path = os.path.join(folder, name)
    with open(path, "w", encoding="utf-8") as handle:
        if isinstance(payload, str):
            handle.write(payload)
        else:
            json.dump(payload, handle)
    return path


def batch(key, receipt, rows):
    return {"key": key, "receipt": receipt,
            "rows": {uid: {"uid": uid, "utc": utc, "status": "CONFIRMED"} for uid, utc in rows.items()}}


def entries(text):
    """(uid, DTSTART, STATUS) of every VEVENT in an ICS text."""
    found, current = [], {}
    for line in text.replace("\r\n", "\n").split("\n"):
        if line == "BEGIN:VEVENT":
            current = {}
        elif line == "END:VEVENT":
            found.append((current.get("UID"), current.get("DTSTART"), current.get("STATUS")))
        elif ":" in line:
            name, _, value = line.partition(":")
            current[name] = value
    return found


class Catalogue(unittest.TestCase):
    """The four states a channel can be in when the desk was cut off."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.incident = write(self.tmp, "incident.json", {
            "A": {"key": "urgent-0327-A", "uid": "M42-20260327",
                  "utc": "2026-03-27T16:30:00Z", "status": "CONFIRMED"},
            "B": {"key": "urgent-0327-B", "uid": "M42-20260327",
                  "utc": "2026-03-27T16:30:00Z", "status": "CONFIRMED"}})

    def history(self, name, *batches):
        return write(self.tmp, name, list(batches))

    def test_item_never_received_is_pending(self):
        path = self.history("r-B.json", batch("B-00001", "B-00001", {"M42-20260320": "2026-03-20T15:00:00Z"}))
        text, rows, entry = recover.build(self.incident, path, "B")
        self.assertEqual([(r["uid"], r["utc"]) for r in rows], [("M42-20260327", "2026-03-27T16:30:00Z")])
        self.assertEqual(entries(text), [("M42-20260327", "20260327T163000Z", "CONFIRMED")])
        self.assertEqual(entry["key"], "urgent-0327-B")          # 重发使用原 key

    def test_item_held_at_the_old_time_is_still_pending(self):
        path = self.history("r-B.json", batch("B-00001", "B-00001", {"M42-20260327": "2026-03-27T15:00:00Z"}))
        _, rows, _ = recover.build(self.incident, path, "B")
        self.assertEqual([r["uid"] for r in rows], ["M42-20260327"])

    def test_item_already_received_is_not_sent_again(self):
        path = self.history("r-B.json", batch("urgent-0327-B", "B-00004", {"M42-20260327": "2026-03-27T16:30:00Z"}))
        text, rows, _ = recover.build(self.incident, path, "B")
        self.assertEqual(rows, [])                               # 避免重复通知
        self.assertEqual(entries(text), [])                      # 空结果: 合法日历, 无 VEVENT
        self.assertTrue(text.startswith("BEGIN:VCALENDAR\r\n"))
        self.assertTrue(text.endswith("END:VCALENDAR\r\n"))

    def test_latest_batch_decides(self):
        # a later batch puts the occurrence back to the contract time -> missing again
        path = self.history("r-B.json",
                            batch("urgent-0327-B", "B-00004", {"M42-20260327": "2026-03-27T16:30:00Z"}),
                            batch("B-00005", "B-00005", {"M42-20260327": "2026-03-27T15:00:00Z"}))
        _, rows, _ = recover.build(self.incident, path, "B")
        self.assertEqual([r["uid"] for r in rows], ["M42-20260327"])

    def test_a_channel_is_judged_on_its_own_history(self):
        done = self.history("r-A.json", batch("urgent-0327-A", "A-00003", {"M42-20260327": "2026-03-27T16:30:00Z"}))
        behind = self.history("r-B.json", batch("B-00001", "B-00001", {"M42-20260327": "2026-03-27T15:00:00Z"}))
        self.assertEqual(recover.build(self.incident, done, "A")[1], [])
        self.assertEqual(len(recover.build(self.incident, behind, "B")[1]), 1)

    def test_original_key_is_never_reused_for_other_content(self):
        path = self.history("r-B.json", batch("urgent-0327-B", "B-00004", {"M42-20260327": "2026-03-27T15:00:00Z"}))
        with self.assertRaises(ValueError) as caught:
            recover.build(self.incident, path, "B")
        self.assertIn("refusing to reuse", str(caught.exception))


class Entry(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.incident = os.path.join(ROOT, "input", "incident.json")
        self.receipts = {channel: os.path.join(ROOT, "data", f"receipts-{channel}.json")
                         for channel in ("A", "B")}

    def run_cli(self, *args):
        import io
        import sys
        from contextlib import redirect_stderr, redirect_stdout
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = recover.main(["recover.py"] + list(args))
        return code, out.getvalue(), err.getvalue()

    def test_cli_writes_the_output_and_reports_the_key(self):
        history = write(self.tmp, "r-B.json", [batch("B-00001", "B-00001", {})])
        target = os.path.join(self.tmp, "out", "recover-B.ics")
        code, out, _ = self.run_cli(self.incident, history, "B", target)
        self.assertEqual(code, 0)
        self.assertIn("pending=1", out)
        self.assertIn("key=urgent-0327-B", out)
        with open(target, encoding="utf-8", newline="") as handle:
            self.assertEqual(entries(handle.read()), [("M42-20260327", "20260327T163000Z", "CONFIRMED")])

    def test_cli_is_deterministic(self):
        history = write(self.tmp, "r-B.json", [batch("B-00001", "B-00001", {})])
        first = os.path.join(self.tmp, "one.ics")
        second = os.path.join(self.tmp, "two.ics")
        self.run_cli(self.incident, history, "B", first)
        self.run_cli(self.incident, history, "B", second)
        with open(first, "rb") as a, open(second, "rb") as b:
            self.assertEqual(a.read(), b.read())

    def test_live_recovery_has_nothing_pending(self):
        for channel in ("A", "B"):
            code, out, _ = self.run_cli(self.incident, self.receipts[channel], channel,
                                        os.path.join(self.tmp, f"live-{channel}.ics"))
            self.assertEqual(code, 0, out)
            self.assertIn(f"nothing pending on {channel}", out)
            with open(os.path.join(self.tmp, f"live-{channel}.ics"), encoding="utf-8", newline="") as handle:
                self.assertEqual(entries(handle.read()), [])

    def test_bad_input_fails_loudly(self):
        history = write(self.tmp, "r-B.json", [batch("B-00001", "B-00001", {})])
        broken = write(self.tmp, "broken.json", "{not json")
        incomplete = write(self.tmp, "incomplete.json", {"B": {"key": "k", "uid": "M42-20260327"}})
        cases = [
            (self.incident, history, "C", "channel must be one of"),          # 未知频道
            ("/nope/incident.json", history, "B", "no incident file"),        # 工单缺失
            (broken, history, "B", "not JSON"),                               # 工单读不懂
            (incomplete, history, "B", "lacks"),                              # 工单字段缺失
            (write(self.tmp, "only-a.json", {"A": {"key": "k-A", "uid": "M42-20260327",
                                                   "utc": "2026-03-27T16:30:00Z", "status": "CONFIRMED"}}),
             history, "B", "names nothing for channel B"),                     # 该频道没有待确认项
            (self.incident, "/nope/receipts.json", "B", "no receipt history"),  # 回执缺失
            (self.incident, write(self.tmp, "bad-utc.json", [{"key": "x", "rows": {}}]),
             "B", "pending"),                                                  # 无行也无妨, 空历史
        ]
        for incident, receipts, channel, expected in cases:
            code, _, err = self.run_cli(incident, receipts, channel, os.path.join(self.tmp, "x.ics"))
            if expected == "pending":
                self.assertEqual(code, 0)                                     # 空历史 -> 全部待补
                continue
            self.assertEqual(code, 2, f"{incident} {channel}: {err}")
            self.assertIn(expected, err)

    def test_bad_argument_count(self):
        code, _, err = self.run_cli("only-one-argument")
        self.assertEqual(code, 2)
        self.assertIn("recover.py INCIDENT RECEIPTS CHANNEL OUTPUT", err)


class Correction(unittest.TestCase):
    """The correction has to live in the portal, not only in the delivered file."""

    def setUp(self):
        self.path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), self.path)
        self.db = portal.ensure_schema(sqlite3.connect(self.path))

    def tearDown(self):
        self.db.close()

    def schedule(self, channel):
        rows = json.loads(portal.route(self.db, f"/api/events?from=2026-03-06&to=2026-03-27&channel={channel}")[1])
        return {r["uid"]: r["utc"] for r in rows}

    def test_incident_is_recorded_once_as_an_adjustment(self):
        portal.migrate(self.db, INTAKE, RECORDS)
        rows = {row["id"]: row for row in portal.adjustments(self.db)}
        urgent = [row for row in rows.values() if row["ticket"] == "urgent-0327"]
        self.assertEqual(len(urgent), 1)
        self.assertEqual((urgent[0]["code"], urgent[0]["kind"]), ("M42", portal.KIND_SHIFT))
        self.assertEqual((urgent[0]["from_day"], urgent[0]["to_day"]), ("2026-03-27", "2026-03-27"))
        self.assertEqual((urgent[0]["minutes"], urgent[0]["basis"]), (90, portal.RULE_UTC))
        self.assertIsNone(urgent[0]["channel"])          # 两个频道都要更正
        before = self.db.execute("select count(*) from adjustment").fetchone()[0]
        portal.migrate(self.db, INTAKE, RECORDS)         # 重复执行不新增
        self.assertEqual(self.db.execute("select count(*) from adjustment").fetchone()[0], before)

    def test_portal_and_invite_show_the_corrected_time(self):
        portal.migrate(self.db, INTAKE, RECORDS)
        for channel in ("A", "B"):
            got = self.schedule(channel)
            self.assertEqual(got["M42-20260327"], "2026-03-27T16:30:00Z")
            self.assertEqual(got["K17-20260327"], "2026-03-27T14:00:00Z")   # 不受影响
            self.assertEqual(got["K17-20260320"], "2026-03-19T14:00:00Z")   # CH-51 保留
        self.assertEqual(self.schedule("A")["M42-20260320"], "2026-03-20T17:00:00Z")
        self.assertEqual(self.schedule("B")["M42-20260320"], "2026-03-20T15:00:00Z")   # CH-64 保留
        self.assertIn("2026-03-27 16:30", portal.route(self.db, "/invite/M42-20260327?tz=UTC")[1])
        self.assertIn('data-uid="M42-20260327"', portal.route(self.db, "/invite/M42-20260327?tz=UTC")[1])

    def test_correction_survives_a_restart_without_input(self):
        portal.migrate(self.db, INTAKE, RECORDS)
        self.db.commit()
        self.db.close()
        restarted = sqlite3.connect(self.path)           # 只有数据库, 没有重新导入
        try:
            rows = json.loads(portal.route(restarted, "/api/events?from=2026-03-27&to=2026-03-27")[1])
            self.assertEqual({r["uid"]: r["utc"] for r in rows if r["uid"].startswith("M42")},
                             {"M42-20260327": "2026-03-27T16:30:00Z"})
        finally:
            restarted.close()
        self.db = portal.ensure_schema(sqlite3.connect(self.path))

    def test_series_missing_from_the_database_is_skipped(self):
        empty = portal.ensure_schema(sqlite3.connect(os.path.join(tempfile.mkdtemp(), "other.sqlite")))
        try:
            self.assertEqual(portal.incident_adjustments(empty, INCIDENT), [])
        finally:
            empty.close()

    def test_delta_and_recovery_agree_on_the_missing_item(self):
        portal.migrate(self.db, INTAKE, RECORDS)
        history = write(tempfile.mkdtemp(), "r-B.json", [batch("B-00001", "B-00001", {
            "K17-20260306": "2026-03-06T15:00:00Z", "K17-20260313": "2026-03-13T14:00:00Z",
            "K17-20260320": "2026-03-19T14:00:00Z", "K17-20260327": "2026-03-27T14:00:00Z",
            "M42-20260306": "2026-03-06T15:00:00Z", "M42-20260313": "2026-03-13T17:00:00Z",
            "M42-20260320": "2026-03-20T15:00:00Z", "M42-20260327": "2026-03-27T15:00:00Z"})])
        _, delta_rows = prepare.build("B", "2026-03-06", "2026-03-27", self.path, since=history)
        _, recovery_rows, _ = recover.build(INCIDENT, history, "B")
        self.assertEqual([(r["uid"], r["utc"]) for r in delta_rows], [(r["uid"], r["utc"]) for r in recovery_rows])
        self.assertEqual([r["uid"] for r in delta_rows], ["M42-20260327"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
