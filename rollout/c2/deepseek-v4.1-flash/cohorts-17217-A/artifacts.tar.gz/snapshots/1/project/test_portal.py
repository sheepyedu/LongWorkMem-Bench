"""Regression tests for the portal local-date label. Run: python3 project/test_portal.py"""
import json
import os
import sqlite3
import tempfile
import unittest

import portal


def make_db(rows):
    path = os.path.join(tempfile.mkdtemp(), "t.sqlite")
    db = sqlite3.connect(path)
    db.execute("create table events(uid text primary key, starts text not null)")
    db.execute("create table bookings(id text primary key, uid text not null)")
    db.executemany("insert into events values(?,?)", rows)
    db.executemany("insert into bookings values(?,?)", [("seat-"+u,u) for u,_ in rows])
    db.commit()
    return db


DB = make_db([
    ("K17-20260306", "2026-03-06T15:00:00Z"),   # 2026-03-07 00:00 Asia/Tokyo
    ("legacy-east", "2026-03-05T23:30:00Z"),    # 2026-03-06 08:30 Asia/Tokyo
    ("legacy-west", "2026-03-06T02:15:00Z"),    # 2026-03-06 11:15 Asia/Tokyo
])


def body(url):
    return portal.route(DB, url)[1]


class LocalLabel(unittest.TestCase):
    def test_tokyo_date_follows_local_wall_clock(self):
        html = body("/?tz=Asia/Tokyo")
        self.assertIn(">2026-03-06 08:30<", html)   # was "2026-03-05 08:30"
        self.assertIn(">2026-03-07 00:00<", html)   # was "2026-03-06 00:00"
        self.assertNotIn("2026-03-05 08:30", html)
        self.assertNotIn("2026-03-06 00:00", html)

    def test_invite_detail_matches_list(self):
        self.assertIn("2026-03-06 08:30", body("/invite/legacy-east?tz=Asia/Tokyo"))
        self.assertIn("2026-03-07 00:00", body("/invite/K17-20260306?tz=Asia/Tokyo"))

    def test_utc_rendering_untouched(self):
        html = body("/?tz=UTC")
        self.assertIn("2026-03-06 15:00", html)
        self.assertIn("2026-03-05 23:30", html)
        self.assertEqual(body("/?tz=Europe/London"), html)  # zero offset, same day

    def test_other_zones(self):
        self.assertIn("2026-03-05 21:15", body("/?tz=America/New_York"))
        self.assertIn("2026-03-06 05:00", body("/invite/legacy-east?tz=Asia/Kolkata"))
        self.assertIn("2026-03-07 05:00", body("/invite/K17-20260306?tz=Pacific/Kiritimati"))

    def test_naive_stamp_read_as_utc(self):
        self.assertEqual(portal.local_label("2026-03-05T23:30:00", "Asia/Tokyo"), "2026-03-06 08:30")

    def test_offset_stamp(self):
        self.assertEqual(portal.local_label("2026-03-06T08:30:00+09:00", "Asia/Tokyo"), "2026-03-06 08:30")


class ContractsKept(unittest.TestCase):
    def test_api_fields_and_utc_values(self):
        rows = json.loads(portal.route(DB, "/api/events?channel=A")[1])
        self.assertEqual(sorted(rows[0]), ["status", "uid", "utc"])
        self.assertEqual({r["uid"]: r["utc"] for r in rows}["legacy-east"], "2026-03-05T23:30:00Z")
        self.assertTrue(all(r["status"] == "CONFIRMED" for r in rows))

    def test_api_range_filter_on_scheduled_day(self):
        rows = json.loads(portal.route(DB, "/api/events?from=2026-03-06&to=2026-03-06")[1])
        self.assertEqual({r["uid"] for r in rows}, {"K17-20260306", "legacy-west"})

    def test_uid_links_keep_working(self):
        self.assertIn('data-uid="legacy-east"', body("/invite/legacy-east?tz=Asia/Tokyo"))
        self.assertEqual(body("/invite/nope?tz=Asia/Tokyo"), "<main></main>")

    def test_unknown_route_and_zone(self):
        with self.assertRaises(KeyError):
            portal.route(DB, "/nope")
        with self.assertRaises(KeyError):
            portal.route(DB, "/?tz=Mars/Olympus")

    def test_bookings_survive_reads(self):
        body("/?tz=Asia/Tokyo")
        self.assertEqual(DB.execute("select count(*) from bookings").fetchone()[0], 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
