"""Single reschedule (CH-51) and temporary window (CH-53). Run: python3 project/test_adjust.py"""
import json
import os
import re
import shutil
import sqlite3
import tempfile
import unittest

import portal
import prepare

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RECORDS = os.path.join(ROOT, "input", "records")
INTAKE = os.path.join(ROOT, "input", "intake.json")


def live_copy():
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), path)
    return path, portal.ensure_schema(sqlite3.connect(path))


def schedule(db, start="2026-03-06", end="2026-03-27", channel="A"):
    url = f"/api/events?from={start}&to={end}&channel={channel}"
    rows = json.loads(portal.route(db, url)[1])
    return {r["uid"]: r["utc"] for r in rows}
    

class Parsing(unittest.TestCase):
    def setUp(self):
        self.path, self.db = live_copy()
        self.series = {row[0]: dict(zip(portal.SERIES_COLUMNS, row))
                       for row in self.db.execute("select " + ",".join(portal.SERIES_COLUMNS) + " from series")}

    def tearDown(self):
        self.db.close()

    def read(self, ticket):
        with open(os.path.join(RECORDS, ticket + ".txt"), encoding="utf-8") as handle:
            return handle.read()

    def test_single_reschedule(self):
        parsed = portal.parse_adjustment(self.read("CH-51"), self.series)
        self.assertEqual(parsed, dict(code="K17", kind="move", from_day="2026-03-20",
                                      to_day="2026-03-20", days=-1, minutes=0,
                                      basis="venue_local_clock", channel=None, target=None))

    def test_temporary_window_lists_both_days(self):
        parsed = portal.parse_adjustment(self.read("CH-53"), self.series)
        self.assertEqual(parsed, dict(code="M42", kind="shift", from_day="2026-03-13",
                                      to_day="2026-03-20", days=0, minutes=120,
                                      basis="utc_clock", channel=None, target=None))

    def test_contract_approvals_are_not_adjustments(self):
        self.assertIsNone(portal.parse_adjustment(self.read("OP-381"), self.series))

    def test_ticket_without_a_clock_fails_loudly(self):
        with self.assertRaises(ValueError):
            portal.parse_adjustment("K17 原定 3月20日 场次提前一日。", self.series)

    def test_day_that_is_not_an_occurrence_is_refused(self):
        parsed = portal.parse_adjustment("K17 原定 3月21日 场次提前一日，仍用场馆惯用钟点。", self.series)
        with self.assertRaises(ValueError):
            portal.check_adjustment(self.series["K17"], parsed)

    def test_unknown_series_is_refused(self):
        with self.assertRaises(ValueError):
            portal.parse_adjustment("Z99 原定 3月20日 场次提前一日，按通常 UTC 时刻。", self.series)

    def test_window_that_would_sweep_extra_occurrences_is_refused(self):
        parsed = dict(code="M42", kind="shift", from_day="2026-03-06", to_day="2026-03-20",
                      days=0, minutes=120, basis="utc_clock")
        with self.assertRaises(ValueError):
            portal.check_adjustment(self.series["M42"], parsed)


class Applied(unittest.TestCase):
    def setUp(self):
        self.path, self.db = live_copy()
        portal.migrate(self.db, INTAKE, RECORDS)

    def tearDown(self):
        self.db.close()

    def test_week_after_both_approvals(self):
        self.assertEqual(schedule(self.db), {
            "K17-20260306": "2026-03-06T15:00:00Z",
            "K17-20260313": "2026-03-13T14:00:00Z",
            "K17-20260320": "2026-03-19T14:00:00Z",     # CH-51 提前一日, venue clock kept
            "K17-20260327": "2026-03-27T14:00:00Z",
            "M42-20260306": "2026-03-06T15:00:00Z",
            "M42-20260313": "2026-03-13T17:00:00Z",     # CH-53 窗口内 +2h
            "M42-20260320": "2026-03-20T17:00:00Z",
            "M42-20260327": "2026-03-27T16:30:00Z",     # 值班台紧急更正 +90 分钟
            "legacy-west": "2026-03-06T02:15:00Z",      # 非试点不受影响
        })

    def test_both_channels_get_the_same_change(self):
        a, b = schedule(self.db, channel="A"), schedule(self.db, channel="B")
        differing = {uid for uid in a if a[uid] != b[uid]}
        self.assertEqual(differing, {"M42-20260320"})     # CH-64 withdrew that one on B only
        self.assertEqual(a["M42-20260320"], "2026-03-20T17:00:00Z")
        self.assertEqual(b["M42-20260320"], "2026-03-20T15:00:00Z")

    def test_invite_identity_is_kept(self):
        moved = portal.route(self.db, "/invite/K17-20260320?tz=America/New_York")[1]
        self.assertIn('data-uid="K17-20260320"', moved)          # 原 UID
        self.assertIn("2026-03-19 10:00", moved)                 # 新日期, 场馆钟点
        self.assertEqual(portal.route(self.db, "/invite/K17-20260319?tz=UTC")[1], "<main></main>")
        self.assertIn("2026-03-13 17:00", portal.route(self.db, "/invite/M42-20260313?tz=UTC")[1])

    def test_only_the_shifted_occurrences_moved(self):
        week = schedule(self.db)
        untouched = {"K17-20260306", "K17-20260313", "K17-20260327", "M42-20260306"}
        for uid in untouched:
            self.assertNotIn(uid, {"K17-20260320", "M42-20260313", "M42-20260320"})
        self.assertEqual(week["M42-20260327"], "2026-03-27T16:30:00Z")   # 值班台更正, 与本批签批无关

    def test_migration_stays_repeatable(self):
        snapshot = {t: self.db.execute(f"select * from {t} order by 1").fetchall()
                    for t in ("events", "bookings", "series", "adjustment")}
        portal.migrate(self.db, INTAKE, RECORDS)
        again = {t: self.db.execute(f"select * from {t} order by 1").fetchall()
                 for t in ("events", "bookings", "series", "adjustment")}
        self.assertEqual(again, snapshot)


class Delivery(unittest.TestCase):
    def setUp(self):
        self.path, self.db = live_copy()

    def tearDown(self):
        self.db.close()

    def delta(self, channel, history_path):
        text, rows = prepare.build(channel, "2026-03-06", "2026-03-27", self.path, since=history_path)
        return rows, text

    def test_only_changed_events_are_pushed(self):
        # history as it stood before CH-51/CH-53
        before = os.path.join(tempfile.mkdtemp(), "receipts-A.json")
        with open(before, "w") as handle:
            json.dump([{"key": "old", "receipt": "A-00001", "rows": {
            "K17-20260306": {"uid": "K17-20260306", "utc": "2026-03-06T15:00:00Z", "status": "CONFIRMED"},
            "K17-20260313": {"uid": "K17-20260313", "utc": "2026-03-13T14:00:00Z", "status": "CONFIRMED"},
            "K17-20260320": {"uid": "K17-20260320", "utc": "2026-03-20T14:00:00Z", "status": "CONFIRMED"},
            "K17-20260327": {"uid": "K17-20260327", "utc": "2026-03-27T14:00:00Z", "status": "CONFIRMED"},
            "M42-20260306": {"uid": "M42-20260306", "utc": "2026-03-06T15:00:00Z", "status": "CONFIRMED"},
            "M42-20260313": {"uid": "M42-20260313", "utc": "2026-03-13T15:00:00Z", "status": "CONFIRMED"},
            "M42-20260320": {"uid": "M42-20260320", "utc": "2026-03-20T15:00:00Z", "status": "CONFIRMED"},
            "M42-20260327": {"uid": "M42-20260327", "utc": "2026-03-27T15:00:00Z", "status": "CONFIRMED"},
        }},
        # 值班台的紧急更正已经收到, 相对这份历史也不是变化
        {"key": "urgent-0327-A", "receipt": "A-00003", "rows": {
            "M42-20260327": {"uid": "M42-20260327", "utc": "2026-03-27T16:30:00Z", "status": "CONFIRMED"},
        }}], handle)
        rows, text = self.delta("A", before)
        self.assertEqual([r["uid"] for r in rows],
                         ["K17-20260320", "M42-20260313", "M42-20260320"])
        self.assertEqual(text.count("BEGIN:VEVENT"), 3)
        self.assertTrue(all("STATUS:CONFIRMED" in text for _ in [0]))

    def test_nothing_is_pushed_when_the_channel_is_current(self):
        current = os.path.join(ROOT, "data", "receipts-A.json")     # after this release
        rows, text = self.delta("A", current)
        self.assertEqual(rows, [])
        self.assertEqual(text.count("BEGIN:VEVENT"), 0)
        self.assertTrue(text.startswith("BEGIN:VCALENDAR") and text.endswith("END:VCALENDAR\r\n"))

    def test_full_preparation_stays_self_contained(self):
        text, rows = prepare.build("B", "2026-03-06", "2026-03-27", self.path)
        self.assertEqual(len(rows), 8)
        self.assertIn("DTSTART:20260319T140000Z", text)
        self.assertIn("DTSTART:20260313T170000Z", text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
