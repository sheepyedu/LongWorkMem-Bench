"""Tests for the pilot intake migration. Run: python3 project/test_migrate.py"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import portal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INTAKE = os.path.join(ROOT, "input", "intake.json")
RECORDS = os.path.join(ROOT, "input", "records")


def seeded_db(rows=None, bookings=None):
    """A copy of the deployed database (existing invites + registrations)."""
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), path)
    return path, portal.ensure_schema(sqlite3.connect(path))


def dump(path):
    db = sqlite3.connect(path)
    return {t: db.execute(f"select * from {t} order by 1").fetchall()
            for t in ("events", "bookings", "series")}


def api(db, url):
    return json.loads(portal.route(db, url)[1])


class Migration(unittest.TestCase):
    def setUp(self):
        self.path, self.db = seeded_db()
        self.before = dump(self.path)

    def tearDown(self):
        self.db.close()

    def test_imports_both_series_from_their_own_approval(self):
        report = portal.migrate(self.db, INTAKE, RECORDS)
        self.assertEqual([r["code"] for r in report], ["K17", "M42"])
        self.assertEqual({r["code"]: (r["order"], r["rule"]) for r in report},
                         {"K17": ("OP-381", "venue_local_clock"),
                          "M42": ("OP-629", "utc_clock")})

    def test_existing_invites_and_bookings_survive(self):
        portal.migrate(self.db, INTAKE, RECORDS)
        after = dump(self.path)
        self.assertEqual(after["bookings"], self.before["bookings"])
        self.assertEqual({u: s for u, s in after["events"]},
                         {u: s for u, s in self.before["events"]})
        self.assertEqual(portal.route(self.db, "/invite/legacy-east?tz=Asia/Tokyo")[1],
                         '<main><article data-uid="legacy-east">2026-03-06 08:30</article></main>')
        self.assertEqual(portal.route(self.db, "/invite/K17-20260306?tz=America/New_York")[1],
                         '<main><article data-uid="K17-20260306">2026-03-06 10:00</article></main>')

    def test_repeatable(self):
        portal.migrate(self.db, INTAKE, RECORDS)
        once = dump(self.path)
        for _ in range(3):
            portal.migrate(self.db, INTAKE, RECORDS)
        self.assertEqual(dump(self.path), once)

    def test_no_intake_is_a_no_op(self):
        report = portal.migrate(self.db, os.path.join(ROOT, "input", "missing.json"), RECORDS)
        self.assertEqual(report, [])
        self.assertEqual(dump(self.path), self.before)

    def test_unreadable_approval_changes_nothing(self):
        tmp = tempfile.mkdtemp()
        intake = os.path.join(tmp, "intake.json")
        json.dump([{"code": "Z99", "anchor": "2026-03-06T15:00:00Z",
                    "zone": "UTC", "order": "OP-000"}], open(intake, "w"))
        with self.assertRaises(ValueError):
            portal.migrate(self.db, intake, RECORDS)
        self.db.close()
        self.assertEqual(dump(self.path), self.before)   # nothing committed
        self.db = portal.ensure_schema(sqlite3.connect(self.path))


class Scheduling(unittest.TestCase):
    """Each series repeats weekly on its approval's own clock."""

    def setUp(self):
        self.path, self.db = seeded_db()
        portal.migrate(self.db, INTAKE, RECORDS)

    def tearDown(self):
        self.db.close()

    def utc_of(self, start, end):
        return {r["uid"]: r["utc"] for r in api(self.db, f"/api/events?from={start}&to={end}&channel=A")}

    def test_venue_clock_series_follows_dst(self):
        utc = self.utc_of("2026-03-01", "2026-11-15")
        self.assertEqual(utc["K17-20260306"], "2026-03-06T15:00:00Z")   # EST, anchor merged
        self.assertEqual(utc["K17-20260313"], "2026-03-13T14:00:00Z")   # EDT
        self.assertEqual(utc["K17-20260320"], "2026-03-19T14:00:00Z")   # CH-51: 提前一日, same UID
        self.assertEqual(utc["K17-20261030"], "2026-10-30T14:00:00Z")
        self.assertEqual(utc["K17-20261106"], "2026-11-06T15:00:00Z")   # back to EST

    def test_utc_clock_series_keeps_its_utc_clock(self):
        utc = self.utc_of("2026-03-01", "2026-11-15")
        self.assertEqual(utc["M42-20260313"], "2026-03-13T17:00:00Z")   # CH-53 window +2h
        self.assertEqual(utc["M42-20260320"], "2026-03-20T17:00:00Z")   # CH-53 window +2h
        self.assertEqual(utc["M42-20260327"], "2026-03-27T16:30:00Z")   # 值班台紧急更正 +90 分钟
        for day in ("20260306", "20261030", "20261106"):
            self.assertEqual(utc[f"M42-{day}"], f"{day[:4]}-{day[4:6]}-{day[6:]}T15:00:00Z")

    def test_weekly_fridays_only_and_no_end_date(self):
        utc = self.utc_of("2026-03-01", "2026-04-30")
        k17 = sorted(u for u in utc if u.startswith("K17-"))
        self.assertEqual(k17, ["K17-20260306", "K17-20260313", "K17-20260320",
                               "K17-20260327", "K17-20260403", "K17-20260410",
                               "K17-20260417", "K17-20260424"])
        far = self.utc_of("2040-01-01", "2040-01-31")
        self.assertTrue(any(u.startswith("K17-2040") for u in far))     # no cut-off

    def test_labels_use_each_series_clock(self):
        self.assertIn("2026-04-03 10:00", portal.route(self.db, "/invite/K17-20260403?tz=America/New_York")[1])
        self.assertIn("2026-04-03 11:00", portal.route(self.db, "/invite/M42-20260403?tz=America/New_York")[1])

    def test_future_invite_links_resolve_and_bogus_ones_do_not(self):
        self.assertIn("data-uid=\"M42-20261113\"", portal.route(self.db, "/invite/M42-20261113?tz=Asia/Tokyo")[1])
        self.assertEqual(portal.route(self.db, "/invite/K17-20260307?tz=UTC")[1], "<main></main>")
        self.assertEqual(portal.route(self.db, "/invite/Z99-20260306?tz=UTC")[1], "<main></main>")

    def test_unbounded_requests_do_not_expand(self):
        # the deployed database has grown since go-live, so compare with what it
        # actually stores: no range means no expansion, never a future occurrence
        stored = [row[0] for row in self.db.execute("select uid from events order by uid")]
        rows = api(self.db, "/api/events?channel=A")
        self.assertEqual([r["uid"] for r in rows], stored)
        self.assertNotIn("K17-20260313", [r["uid"] for r in rows])

    def test_non_pilot_legacy_api_unchanged(self):
        rows = api(self.db, "/api/events?from=2026-03-05&to=2026-03-06&channel=B")
        legacy = {r["uid"]: r["utc"] for r in rows if r["uid"].startswith("legacy")}
        self.assertEqual(legacy, {"legacy-east": "2026-03-05T23:30:00Z",
                                  "legacy-west": "2026-03-06T02:15:00Z"})


class LaterIntake(unittest.TestCase):
    """The same entry point must accept new ticket numbers later on."""

    def test_new_ticket_reusing_an_existing_approval(self):
        tmp = tempfile.mkdtemp()
        records = os.path.join(tmp, "records")
        os.makedirs(records)
        shutil.copyfile(os.path.join(RECORDS, "OP-381.txt"), os.path.join(records, "OP-381.txt"))
        # a new ticket that cites the existing approval instead of restating it
        open(os.path.join(records, "OP-777.txt"), "w").write(
            "OP-777 正式批准：同意按 OP-381 之条款执行。\n")
        intake = os.path.join(tmp, "intake.json")
        json.dump([{"code": "H95", "anchor": "2026-03-06T15:00:00Z",
                    "zone": "Europe/London", "order": "OP-777"}], open(intake, "w"))

        path, db = seeded_db()
        portal.migrate(db, INTAKE, RECORDS)                     # go-live import
        before = dump(path)
        report = portal.migrate(db, intake, records)             # later intake, new number
        after = dump(path)
        self.assertEqual([r["code"] for r in report], ["H95"])
        self.assertEqual(report[0]["rule"], "venue_local_clock")
        self.assertEqual([r[0] for r in after["series"]], ["H95", "K17", "M42"])   # earlier kept
        self.assertEqual(after["bookings"], before["bookings"])
        kept = dict(after["events"])
        for uid, starts in before["events"]:            # every earlier invite kept as-is
            self.assertEqual(kept[uid], starts)
        self.assertEqual(sorted(set(kept) - {u for u, _ in before["events"]}), ["H95-20260306"])
        utc = {r["uid"]: r["utc"] for r in api(db, "/api/events?from=2026-03-01&to=2026-04-05")}
        self.assertEqual(utc["H95-20260313"], "2026-03-13T15:00:00Z")   # London still GMT
        self.assertEqual(utc["H95-20260403"], "2026-04-03T14:00:00Z")   # BST
        db.close()

    def test_cli_accepts_the_new_number_through_the_same_command(self):
        tmp = tempfile.mkdtemp()
        records = os.path.join(tmp, "records")
        os.makedirs(records)
        open(os.path.join(records, "OP-888.txt"), "w").write(
            "OP-888 正式批准：按合同 全年保持首场的 UTC 钟点。\n")
        intake = os.path.join(tmp, "intake.json")
        json.dump([{"code": "N01", "anchor": "2026-03-06T15:00:00Z",
                    "zone": "Asia/Tokyo", "order": "OP-888"}], open(intake, "w"))
        db_path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        env = dict(os.environ, PORTAL_DB=db_path)
        cmd = [sys.executable, os.path.join(ROOT, "project", "portal.py"), "migrate", intake, records]
        first = subprocess.run(cmd, env=env, cwd=ROOT, capture_output=True, text=True)
        second = subprocess.run(cmd, env=env, cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertIn("series=imported", first.stdout)
        self.assertIn("series=unchanged", second.stdout)
        db = sqlite3.connect(db_path)
        self.assertEqual(db.execute("select code, rule from series").fetchall(), [("N01", "utc_clock")])
        self.assertEqual(db.execute("select count(*) from series").fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
