"""Recovery of an interrupted urgent update.

python3 project/recover.py INCIDENT RECEIPTS CHANNEL OUTPUT

INCIDENT  incident.json written by the duty desk when an urgent update was cut
          off: {channel: {key, uid, utc, status}}.  The entry is the authority
          for that occurrence and `key` is the dedupe key the interrupted send
          already used, so the resend reuses it verbatim.
RECEIPTS  that channel's receipt history — the JSON array the subscription
          service returns, oldest batch first (data/receipts-<CHANNEL>.json).
CHANNEL   A or B.
OUTPUT    ICS path; holds only the VEVENTs the channel has not actually
          received.  Nothing pending means an empty VCALENDAR with no VEVENT,
          which must not be published — that is what keeps recovery from
          sending a second notification for an item that did arrive.

A batch counts as received only when the channel's latest state for that UID
already carries the incident's UTC and status; a UID held at an older time is
still missing.  Sending under the original key is safe (same key, same content
is a retry); if that key was already used for different content the run stops
instead of reusing it.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import portal

CHANNELS = ("A", "B")
FIELDS = ("key", "uid", "utc", "status")


def load_incident(path):
    """Incident entries by channel, with every field the resend needs."""
    try:
        with open(path, encoding="utf-8") as handle:
            entries = json.load(handle)
    except FileNotFoundError:
        raise ValueError(f"no incident file at {path}")
    except json.JSONDecodeError as problem:
        raise ValueError(f"incident file is not JSON: {problem}")
    if not isinstance(entries, dict):
        raise ValueError(f"incident file must map channel -> entry: {path}")
    found = {}
    for channel, entry in entries.items():
        if channel not in CHANNELS:
            raise ValueError(f"incident names an unknown channel {channel!r}")
        if not isinstance(entry, dict):
            raise ValueError(f"incident entry for {channel} is not an object")
        missing = [field for field in FIELDS if not entry.get(field)]
        if missing:
            raise ValueError(f"incident entry for {channel} lacks {missing}")
        if entry["status"] != "CONFIRMED":
            raise ValueError(f"incident entry for {channel} has status {entry['status']!r}")
        try:
            utc = portal.stamp(portal.as_utc(entry["utc"]))
        except ValueError:
            raise ValueError(f"incident entry for {channel} has a bad UTC {entry['utc']!r}")
        found[channel] = dict(key=entry["key"], uid=entry["uid"], utc=utc, status=entry["status"])
    if not found:
        raise ValueError(f"incident file lists nothing to recover: {path}")
    return found


def history(path):
    """-> (state, batches_by_key) for one channel's receipt history."""
    try:
        with open(path, encoding="utf-8") as handle:
            batches = json.load(handle)
    except FileNotFoundError:
        raise ValueError(f"no receipt history at {path}")
    except json.JSONDecodeError as problem:
        raise ValueError(f"receipt history is not JSON: {problem}")
    if not isinstance(batches, list):
        raise ValueError(f"receipt history must be the JSON array of batches: {path}")
    state, by_key = {}, {}
    for batch in batches:
        rows = (batch or {}).get("rows") or {}
        for uid, row in rows.items():
            state[uid] = row                 # later batches win
        key = (batch or {}).get("key")
        if key:
            by_key.setdefault(key, {}).update(rows)
    return state, by_key


def pending(entry, state, by_key=None):
    """True when the channel does not already hold exactly this occurrence."""
    held = state.get(entry["uid"])
    if (held is not None and held.get("utc") == entry["utc"]
            and held.get("status") == entry["status"]):
        return False                          # already received: nothing to send
    sent = (by_key or {}).get(entry["key"])   # about to send under the original key
    if sent:
        row = sent.get(entry["uid"])
        if row and (row.get("utc") != entry["utc"] or row.get("status") != entry["status"]):
            raise ValueError(f"key {entry['key']} already carried different content for "
                             f"{entry['uid']} ({row.get('utc')}); refusing to reuse it")
    return True


def build(incident_path, receipts_path, channel):
    """-> (ics text, rows to send, the incident entry used)."""
    if channel not in CHANNELS:
        raise ValueError(f"channel must be one of {CHANNELS}, got {channel!r}")
    entries = load_incident(incident_path)
    if channel not in entries:
        raise ValueError(f"incident names nothing for channel {channel}")
    entry = entries[channel]
    state, by_key = history(receipts_path)
    rows = [dict(uid=entry["uid"], utc=entry["utc"], status=entry["status"])] \
        if pending(entry, state, by_key) else []
    rows.sort(key=lambda row: row["uid"])
    return calendar_io.encode(rows), rows, entry


def main(argv):
    if len(argv) != 5:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    incident, receipts, channel, output = argv[1], argv[2], argv[3], argv[4]
    try:
        text, rows, entry = build(incident, receipts, channel)
    except ValueError as problem:
        print(f"recover failed: {problem}", file=sys.stderr)
        return 2
    os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
    with open(output, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)
    print(f"channel={channel} incident={incident} receipts={receipts} "
          f"pending={len(rows)} output={output}")
    for row in rows:
        print(f"  {row['uid']} {row['utc']} {row['status']}")
    if rows:
        print(f"key={entry['key']}  (original key — resend reuses it)")
    else:
        print(f"nothing pending on {channel}: {entry['uid']} already received at "
              f"{entry['utc']} — do not publish")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
