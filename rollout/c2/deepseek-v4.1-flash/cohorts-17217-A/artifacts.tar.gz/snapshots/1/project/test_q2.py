"""Q2 delivery: April–June for both channels, plus the new subscriber's file.
Run: python3 project/test_q2.py
"""
import json
import os
import sqlite3
import tempfile
import unittest

import portal
import prepare

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIVE = os.path.join(ROOT, "data", "portal.sqlite")
FRIDAYS = ["2026-04-03", "2026-04-10", "2026-04-17", "2026-04-24",
           "2026-05-01", "2026-05-08", "2026-05-15", "2026-05-22", "2026-05-29",
           "2026-06-05", "2026-06-12", "2026-06-19", "2026-06-26"]


def read(path):
    with open(path, "rb") as handle:
        return handle.read()


def events(text):
    """(UID, DTSTART, STATUS) of every VEVENT, in file order."""
    found, current = [], {}
    for line in text.replace("\r\n", "\n").split("\n"):
        if line == "BEGIN:VEVENT":
            current = {}
        elif line == "END:VEVENT":
            found.append((current.get("UID"), current.get("DTSTART"), current.get("STATUS")))
        elif ":" in line:
            name, _, value = line.partition(":")
            current[name] = value
    return found


def db():
    return portal.ensure_schema(sqlite3.connect(LIVE))


def history(channel):
    with open(os.path.join(ROOT, "data", f"receipts-{channel}.json"), encoding="utf-8") as handle:
        state = {}
        for batch in json.load(handle):
            state.update(batch["rows"])
        return state


class Schedule(unittest.TestCase):
    def setUp(self):
        self.db = db()

    def tearDown(self):
        self.db.close()

    def q2(self, channel):
        return portal.series_rows(self.db, portal.as_date("2026-04-01"), portal.as_date("2026-06-30"), channel)

    def test_quarter_holds_every_friday_of_both_series(self):
        for channel in ("A", "B"):
            rows = self.q2(channel)
            self.assertEqual(len(rows), 26)
            self.assertEqual(sorted(r["uid"] for r in rows),
                             sorted([f"K17-{day.replace('-', '')}" for day in FRIDAYS]
                                    + [f"M42-{day.replace('-', '')}" for day in FRIDAYS]))
            self.assertTrue(all(r["status"] == "CONFIRMED" for r in rows))

    def test_contract_clocks_hold_across_the_quarter(self):
        rows = {r["uid"]: r["utc"] for r in self.q2("A")}
        for day in FRIDAYS:
            stamp = day.replace("-", "")
            self.assertEqual(rows[f"K17-{stamp}"], f"{day}T14:00:00Z")   # 10:00 纽约, 夏令时
            self.assertEqual(rows[f"M42-{stamp}"], f"{day}T15:00:00Z")   # 首场 UTC 钟点
        self.assertIn("2026-04-03 10:00", portal.route(self.db, "/invite/K17-20260403?tz=America/New_York")[1])
        self.assertIn("2026-06-26 10:00", portal.route(self.db, "/invite/K17-20260626?tz=America/New_York")[1])

    def test_non_pilot_activity_is_never_in_the_quarter(self):
        for channel in ("A", "B"):
            self.assertFalse([r for r in self.q2(channel) if not r["uid"].startswith(("K17-", "M42-"))])

    def test_both_channels_agree_inside_the_quarter(self):
        self.assertEqual([(r["uid"], r["utc"]) for r in self.q2("A")],
                         [(r["uid"], r["utc"]) for r in self.q2("B")])

    def test_every_occurrence_reached_both_channels(self):
        for channel in ("A", "B"):
            held = history(channel)
            for row in self.q2(channel):
                self.assertEqual(held[row["uid"]]["utc"], row["utc"], f"{channel} {row['uid']}")
                self.assertEqual(held[row["uid"]]["status"], "CONFIRMED")


class Files(unittest.TestCase):
    def build(self, channel, since=None):
        return prepare.build(channel, "2026-04-01", "2026-06-30", LIVE, since=since)

    def test_quarter_delta_is_the_whole_quarter(self):
        for channel in ("A", "B"):
            text, rows = self.build(channel, os.path.join(ROOT, "data", f"receipts-{channel}.json"))
            self.assertEqual(rows, [])            # 已全部送达, 无变化不投递
            self.assertEqual(events(text), [])

    def test_the_delivered_batch_was_exactly_the_quarter(self):
        """复算投递时的增量: 只留该季之前的收件, 应正好是这 26 场。"""
        for channel in ("A", "B"):
            before = {uid: row for uid, row in history(channel).items()
                      if uid[4:8] == "2026" and uid[8:12] < "0401"}
            self.assertTrue(before)                                  # 三月那些场次还在
            path = os.path.join(tempfile.mkdtemp(), "before.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump([{"key": "before", "receipt": f"{channel}-00000", "rows": before}], handle)
            text, rows = self.build(channel, path)
            self.assertEqual(len(rows), 26)
            self.assertEqual(text.encode(), read(os.path.join(ROOT, "out", f"q2-{channel}.ics")))

    def test_new_subscriber_file_is_the_full_quarter(self):
        text, rows = self.build("A")
        self.assertEqual(len(rows), 26)
        found = events(text)
        self.assertEqual(len(found), 26)
        self.assertEqual({uid for uid, _, _ in found}, {r["uid"] for r in rows})
        self.assertTrue(all(status == "CONFIRMED" for _, _, status in found))
        self.assertTrue(text.startswith("BEGIN:VCALENDAR\r\n"))
        self.assertTrue(text.endswith("END:VCALENDAR\r\n"))
        self.assertTrue(all(not uid.startswith("legacy") for uid, _, _ in found))
        self.assertTrue(all(start.startswith("2026") for _, start, _ in found))

    def test_new_subscriber_file_matches_the_delivered_ones(self):
        delivered = read(os.path.join(ROOT, "out", "new-A.ics"))
        self.assertEqual(delivered, self.build("A")[0].encode())          # 可重复生成
        self.assertEqual(delivered, read(os.path.join(ROOT, "out", "q2-A.ics")))
        self.assertEqual(delivered, read(os.path.join(ROOT, "out", "q2-B.ics")))
        self.assertEqual(delivered, self.build("B")[0].encode())          # 两频道该季一致

    def test_quarter_file_differs_from_the_earlier_months(self):
        quarter = read(os.path.join(ROOT, "out", "q2-A.ics"))
        march = read(os.path.join(ROOT, "out", "pilot-A-20260306-20260327.ics"))
        self.assertNotEqual(quarter, march)
        self.assertNotIn(b"K17-20260306", quarter)
        self.assertIn(b"UID:K17-20260403", quarter)


if __name__ == "__main__":
    unittest.main(verbosity=2)
