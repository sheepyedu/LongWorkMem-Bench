"""Tests for GET /api/pages and the long-range expansion fix.

Run: python3 project/test_pages.py
"""
import json
import os
import shutil
import sqlite3
import tempfile
import unittest

import portal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LONG = dict(code="L99", anchor="1970-01-02T15:00:00Z", zone="UTC",
            rule="utc_clock", clock="15:00", weekday=4)


def seeded():
    """A copy of the deployed portal database (legacy invites + pilot rows)."""
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), path)
    return path, portal.ensure_schema(sqlite3.connect(path))


def page(db, **params):
    query = "&".join(f"{k}={v}" for k, v in params.items())
    return json.loads(portal.route(db, "/api/pages?" + query)[1])


def events(db, url):
    return json.loads(portal.route(db, url)[1])


class Paging(unittest.TestCase):
    def setUp(self):
        self.path, self.db = seeded()

    def tearDown(self):
        self.db.close()

    def walk(self, channel, start, end, limit):
        """Follow `next` from offset 0 and return every row seen."""
        seen, offset, calls = [], 0, 0
        while True:
            body = page(self.db, channel=channel, offset=offset, limit=limit,
                        **{"from": start, "to": end})
            calls += 1
            self.assertLessEqual(len(body["items"]), limit)
            seen.extend(body["items"])
            if body["next"] is None:
                break
            self.assertEqual(body["next"], offset + len(body["items"]))
            offset = body["next"]
            self.assertLess(calls, 10000)          # a walk must terminate
        return seen

    def test_page_shape(self):
        body = page(self.db, channel="A", offset=0, limit=2,
                    **{"from": "2026-03-05", "to": "2026-03-06"})
        self.assertEqual(sorted(body), ["items", "next"])
        self.assertEqual([r["uid"] for r in body["items"]],
                         ["K17-20260306", "M42-20260306"])
        self.assertEqual(body["next"], 2)
        for row in body["items"]:
            self.assertEqual(sorted(row), ["status", "uid", "utc"])
            self.assertEqual(row["status"], "CONFIRMED")

    def test_legacy_rows_are_paged_too(self):
        body = page(self.db, channel="A", offset=2, limit=10,
                    **{"from": "2026-03-05", "to": "2026-03-06"})
        self.assertEqual([r["uid"] for r in body["items"]],
                         ["legacy-east", "legacy-west"])
        self.assertIsNone(body["next"])

    def test_walk_visits_every_uid_once_in_uid_order(self):
        for channel in ("A", "B"):
            seen = self.walk(channel, "2026-03-01", "2026-04-30", 3)
            uids = [r["uid"] for r in seen]
            self.assertEqual(uids, sorted(set(uids)))          # no gaps, no repeats
            self.assertEqual(seen, events(self.db, f"/api/events?from=2026-03-01"
                                                  f"&to=2026-04-30&channel={channel}"))

    def test_pages_slice_matches_the_old_api(self):
        whole = events(self.db, "/api/events?from=2026-02-01&to=2026-12-31&channel=B")
        for offset in (0, 1, 7, len(whole) - 1):
            body = page(self.db, channel="B", offset=offset, limit=5,
                        **{"from": "2026-02-01", "to": "2026-12-31"})
            self.assertEqual(body["items"], whole[offset:offset + 5])

    def test_offset_past_the_end_is_empty(self):
        body = page(self.db, channel="A", offset=999, limit=10,
                    **{"from": "2026-03-05", "to": "2026-03-06"})
        self.assertEqual(body, {"items": [], "next": None})

    def test_the_same_request_returns_the_same_page(self):
        first = page(self.db, channel="A", offset=1, limit=2,
                     **{"from": "2026-02-01", "to": "2026-12-31"})
        again = page(self.db, channel="A", offset=1, limit=2,
                     **{"from": "2026-02-01", "to": "2026-12-31"})
        self.assertEqual(first, again)

    def test_channel_difference_stays_visible(self):
        def row(channel):
            body = page(self.db, channel=channel, offset=0, limit=100,
                        **{"from": "2026-03-20", "to": "2026-03-20"})
            return {r["uid"]: r["utc"] for r in body["items"]}["M42-20260320"]
        self.assertEqual(row("A"), "2026-03-20T17:00:00Z")     # CH-53 window
        self.assertEqual(row("B"), "2026-03-20T15:00:00Z")     # CH-64 withdrew it

    def test_original_day_not_the_shifted_utc_day(self):
        # K17-20260320 was moved to 03-19 (CH-51) but is still filed under 03-20
        on_19 = page(self.db, channel="A", offset=0, limit=100,
                     **{"from": "2026-03-19", "to": "2026-03-19"})["items"]
        on_20 = page(self.db, channel="A", offset=0, limit=100,
                     **{"from": "2026-03-20", "to": "2026-03-20"})["items"]
        self.assertNotIn("K17-20260320", [r["uid"] for r in on_19])
        self.assertEqual({r["uid"]: r["utc"] for r in on_20}["K17-20260320"],
                         "2026-03-19T14:00:00Z")

    def test_no_range_mirrors_unbounded_events(self):
        body = page(self.db, channel="A", offset=0, limit=100)
        self.assertEqual(body["items"], events(self.db, "/api/events?channel=A"))
        self.assertIsNone(body["next"])

    def test_bad_parameters_are_refused(self):
        for params in (dict(**{"from": "2026-03-06", "to": "2026-03-05"}),
                       dict(**{"from": "x", "to": "2026-03-06"}),
                       dict(offset=-1, **{"from": "2026-03-06", "to": "2026-03-06"}),
                       dict(limit=0, **{"from": "2026-03-06", "to": "2026-03-06"}),
                       dict(offset="two", **{"from": "2026-03-06", "to": "2026-03-06"})):
            with self.assertRaises(portal.BadRequest):
                page(self.db, **params)

    def test_old_surface_is_untouched(self):
        self.assertIn('data-uid="legacy-east"',
                      portal.route(self.db, "/invite/legacy-east?tz=Asia/Tokyo")[1])
        self.assertIn("2026-03-06 08:30",
                      portal.route(self.db, "/invite/legacy-east?tz=Asia/Tokyo")[1])
        with self.assertRaises(KeyError):
            portal.route(self.db, "/nope")


class LongRange(unittest.TestCase):
    """One series must not lose its tail when the range holds >1000 occurrences."""

    def setUp(self):
        self.path, self.db = seeded()
        self.db.execute("insert into series(code,ord,anchor,zone,rule,weekday,clock,channel,imported)"
                        " values(?,?,?,?,?,?,?,?,?)",
                        (LONG["code"], "OP-000", LONG["anchor"], LONG["zone"], LONG["rule"],
                         LONG["weekday"], LONG["clock"], None, "2026-03-30"))
        self.db.commit()

    def tearDown(self):
        self.db.close()

    def long_rows(self, url):
        rows = events(self.db, url)
        return [r for r in rows if r["uid"].startswith("L99-")]

    def test_events_returns_the_whole_range(self):
        rows = self.long_rows("/api/events?from=1970-01-01&to=2026-03-30&channel=A")
        self.assertGreater(len(rows), 1000)                    # was silently capped at 1000
        self.assertEqual(rows[0]["uid"], "L99-19700102")
        self.assertEqual(rows[-1]["uid"], "L99-20260327")      # the tail survived

    def test_pages_carry_every_occurrence(self):
        whole = events(self.db, "/api/events?from=1970-01-01&to=2026-03-30&channel=A")
        seen, offset = [], 0
        while True:
            body = page(self.db, channel="A", offset=offset, limit=500,
                        **{"from": "1970-01-01", "to": "2026-03-30"})
            seen.extend(body["items"])
            if body["next"] is None:
                break
            offset = body["next"]
        self.assertGreater(len(seen), 1000)
        self.assertEqual(seen, whole)                          # every UID, once, in order
        self.assertEqual([r["uid"] for r in seen if r["uid"].startswith("L99-")][-1],
                         "L99-20260327")

    def test_an_unbounded_expansion_fails_loudly(self):
        with self.assertRaises(portal.RangeTooWide):
            portal.occurrences(LONG)
        # a caller that asks for a fixed number still gets it
        self.assertEqual(len(portal.occurrences(LONG, limit=5)), 5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
