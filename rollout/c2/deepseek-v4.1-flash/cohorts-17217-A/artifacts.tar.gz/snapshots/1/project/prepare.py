"""Publish preparation: python3 project/prepare.py CHANNEL FROM TO OUTPUT [--since RECEIPTS.json]

Writes a self-contained ICS holding every occurrence of that channel's pilot
series inside FROM..TO (原定日, endpoints included).  Non-pilot legacy activity
is never included; an empty range still yields a valid VCALENDAR.  Output is
deterministic, so identical content always hashes to the same digest and can be
retried with the same dedupe key.

With --since, RECEIPTS.json is a channel's receipt history (the JSON array the
subscription service returns, oldest batch first) and only the VEVENTs that are
new or differ from what that channel already holds are written — the delivery
side of "只投递需要改变的 VEVENT".  UIDs are never rewritten, so a rescheduled
occurrence updates the subscriber's existing entry instead of adding a new one.
"""
import hashlib
import json
import os
import sqlite3
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import portal

CHANNELS = ("A", "B")


def build(channel, start, end, db_path=None, since=None):
    if channel not in CHANNELS:
        raise ValueError(f"channel must be one of {CHANNELS}, got {channel!r}")
    start, end = date.fromisoformat(start), date.fromisoformat(end)
    if start > end:
        raise ValueError(f"empty range: {start} > {end}")
    db = portal.ensure_schema(sqlite3.connect(db_path or os.getenv("PORTAL_DB", "data/portal.sqlite")))
    rows = portal.series_rows(db, start, end, channel)          # pilots only
    rows.sort(key=lambda r: r["uid"])
    if since:
        rows = changed_only(rows, received_state(since))
    return calendar_io.encode(rows), rows


def received_state(path):
    """What a channel already holds: UID -> row, later batches winning."""
    with open(path, encoding="utf-8") as handle:
        batches = json.load(handle)
    state = {}
    for batch in batches:
        for uid, row in (batch.get("rows") or {}).items():
            state[uid] = row
    return state


def changed_only(rows, state):
    """Rows that a subscriber holding `state` does not have yet, or has differently."""
    return [row for row in rows
            if row["uid"] not in state
            or state[row["uid"]].get("utc") != row["utc"]
            or state[row["uid"]].get("status") != row["status"]]


def main(argv):
    argv = list(argv)
    since = None
    if "--since" in argv:
        at = argv.index("--since")
        if at + 1 >= len(argv):
            print("--since needs a receipts JSON file", file=sys.stderr)
            return 2
        since = argv[at + 1]
        del argv[at:at + 2]
    if len(argv) != 5:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    channel, start, end, output = argv[1], argv[2], argv[3], argv[4]
    try:
        text, rows = build(channel, start, end, since=since)
    except ValueError as problem:
        print(f"prepare failed: {problem}", file=sys.stderr)
        return 2
    os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
    with open(output, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)
    digest = hashlib.sha256(text.encode()).hexdigest()[:8]
    mode = "delta" if since else "full"
    print(f"channel={channel} range={start}..{end} mode={mode} events={len(rows)} output={output}")
    if since:
        print(f"since={since} (only VEVENTs that differ from what the channel holds)")
    tag = f"{date.fromisoformat(start):%Y%m%d}-{date.fromisoformat(end):%Y%m%d}"
    label = "delta" if since else "pilot"
    print(f"key-suggestion={channel}-{label}-{tag}-{digest}  sha256={digest}")
    for row in rows:
        print(f"  {row['uid']} {row['utc']} {row['status']}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
