"""CH-64: withdraw CH-53 for channel B on 2026-03-20 only. Run: python3 project/test_ch64.py"""
import json
import os
import shutil
import sqlite3
import tempfile
import unittest

import portal
import prepare

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RECORDS = os.path.join(ROOT, "input", "records")
INTAKE = os.path.join(ROOT, "input", "intake.json")


def live_copy():
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(os.path.join(ROOT, "data", "portal.sqlite"), path)
    return path, portal.ensure_schema(sqlite3.connect(path))


def schedule(db, channel):
    rows = json.loads(portal.route(db, f"/api/events?from=2026-03-06&to=2026-03-27&channel={channel}")[1])
    return {r["uid"]: r["utc"] for r in rows}


class Revocation(unittest.TestCase):
    def setUp(self):
        self.path, self.db = live_copy()
        portal.migrate(self.db, INTAKE, RECORDS)
        with open(os.path.join(RECORDS, "CH-64.txt"), encoding="utf-8") as handle:
            self.text = handle.read()

    def tearDown(self):
        self.db.close()

    def test_ticket_parsed_as_channel_scoped_revocation(self):
        with open(os.path.join(RECORDS, "CH-53.txt"), encoding="utf-8") as handle:
            portal.migrate(self.db, INTAKE, RECORDS)
        series = {row[0]: dict(zip(portal.SERIES_COLUMNS, row))
                  for row in self.db.execute("select " + ",".join(portal.SERIES_COLUMNS) + " from series")}
        parsed = portal.parse_revocation(self.text, series, portal.adjustments(self.db))
        self.assertEqual(parsed["kind"], portal.KIND_REVOKE)
        self.assertEqual(parsed["target"], "CH-53")
        self.assertEqual(parsed["channel"], "B")
        self.assertEqual((parsed["code"], parsed["from_day"]), ("M42", "2026-03-20"))
        self.assertEqual(parsed["basis"], portal.RULE_ORIGINAL)

    def test_only_the_named_occurrence_on_the_named_channel_moves_back(self):
        a, b = schedule(self.db, "A"), schedule(self.db, "B")
        self.assertEqual(a["M42-20260320"], "2026-03-20T17:00:00Z")   # A 的批复继续有效
        self.assertEqual(b["M42-20260320"], "2026-03-20T15:00:00Z")   # 恢复原合同时间
        self.assertEqual(b["M42-20260313"], "2026-03-13T17:00:00Z")   # 只撤销 20 日那一场
        self.assertEqual(a["M42-20260313"], "2026-03-13T17:00:00Z")

    def test_venue_reschedule_survives_on_both_channels(self):
        for channel in ("A", "B"):
            got = schedule(self.db, channel)
            self.assertEqual(got["K17-20260320"], "2026-03-19T14:00:00Z")   # CH-51 保留
            self.assertEqual(got["M42-20260327"], "2026-03-27T16:30:00Z")   # 值班台紧急更正 +90 分钟
            self.assertEqual(got["legacy-west"], "2026-03-06T02:15:00Z")    # 非试点不动

    def test_invite_links_are_channel_aware(self):
        self.assertIn("2026-03-20 17:00", portal.route(self.db, "/invite/M42-20260320?tz=UTC&channel=A")[1])
        self.assertIn("2026-03-20 15:00", portal.route(self.db, "/invite/M42-20260320?tz=UTC&channel=B")[1])
        self.assertIn("2026-03-20 17:00", portal.route(self.db, "/invite/M42-20260320?tz=UTC")[1])  # 默认 A
        self.assertIn('data-uid="M42-20260320"', portal.route(self.db, "/invite/M42-20260320?tz=UTC&channel=B")[1])


class Delivery(unittest.TestCase):
    def setUp(self):
        self.path, self.db = live_copy()

    def tearDown(self):
        self.db.close()

    def before_ch64(self, channel):
        """The channel's history as it stood after CH-51/CH-53, before this ticket."""
        first = {"K17-20260306": "2026-03-06T15:00:00Z", "K17-20260313": "2026-03-13T14:00:00Z",
                 "K17-20260320": "2026-03-20T14:00:00Z", "K17-20260327": "2026-03-27T14:00:00Z",
                 "M42-20260306": "2026-03-06T15:00:00Z", "M42-20260313": "2026-03-13T15:00:00Z",
                 "M42-20260320": "2026-03-20T15:00:00Z", "M42-20260327": "2026-03-27T15:00:00Z"}
        delta = {"K17-20260320": "2026-03-19T14:00:00Z", "M42-20260313": "2026-03-13T17:00:00Z",
                 "M42-20260320": "2026-03-20T17:00:00Z"}
        path = os.path.join(tempfile.mkdtemp(), f"receipts-{channel}.json")
        with open(path, "w") as handle:
            json.dump([{"key": "first", "receipt": f"{channel}-00001",
                        "rows": {u: {"uid": u, "utc": t, "status": "CONFIRMED"} for u, t in first.items()}},
                       {"key": "delta", "receipt": f"{channel}-00002",
                        "rows": {u: {"uid": u, "utc": t, "status": "CONFIRMED"} for u, t in delta.items()}},
                       # 值班台的紧急更正已收到, 与本批签批无关
                       {"key": f"urgent-0327-{channel}", "receipt": f"{channel}-00003",
                        "rows": {"M42-20260327": {"uid": "M42-20260327",
                                                  "utc": "2026-03-27T16:30:00Z", "status": "CONFIRMED"}}}],
                      handle)
        return path

    def test_a_needs_no_delivery_and_b_gets_one_event(self):
        a_text, a_rows = prepare.build("A", "2026-03-06", "2026-03-27", self.path,
                                       since=self.before_ch64("A"))
        b_text, b_rows = prepare.build("B", "2026-03-06", "2026-03-27", self.path,
                                       since=self.before_ch64("B"))
        self.assertEqual(a_rows, [])
        self.assertEqual(a_text.count("BEGIN:VEVENT"), 0)
        self.assertEqual([(r["uid"], r["utc"]) for r in b_rows],
                         [("M42-20260320", "2026-03-20T15:00:00Z")])
        self.assertEqual(b_text.count("BEGIN:VEVENT"), 1)
        self.assertIn("UID:M42-20260320", b_text)          # identity kept, in-place correction
        self.assertIn("STATUS:CONFIRMED", b_text)

    def test_channels_are_now_in_sync_with_their_own_history(self):
        for channel in ("A", "B"):
            _, rows = prepare.build(channel, "2026-03-06", "2026-03-27", self.path,
                                    since=os.path.join(ROOT, "data", f"receipts-{channel}.json"))
            self.assertEqual(rows, [], f"{channel} should have nothing left to push")


class Upgrade(unittest.TestCase):
    def test_database_created_before_ch64_is_upgraded_in_place(self):
        path = os.path.join(tempfile.mkdtemp(), "old.sqlite")
        db = sqlite3.connect(path)
        db.execute("create table events(uid text primary key,starts text not null)")
        db.execute("create table bookings(id text primary key,uid text not null)")
        db.execute("""create table series(code text primary key, ord text not null, anchor text not null,
                      zone text not null, rule text not null, weekday integer not null, clock text not null,
                      channel text, imported text)""")
        db.execute("""create table adjustment(id text primary key, ticket text not null, code text not null,
                      kind text not null, from_day text not null, to_day text not null,
                      days integer not null default 0, minutes integer not null default 0,
                      basis text not null, imported text)""")
        db.commit()
        portal.ensure_schema(db)                                  # adds channel/target
        columns = {row[1] for row in db.execute("pragma table_info(adjustment)")}
        self.assertTrue({"channel", "target"} <= columns)
        report = portal.migrate(db, INTAKE, RECORDS)
        self.assertEqual([r["code"] for r in report], ["K17", "M42"])
        self.assertEqual(db.execute("select kind, channel, target from adjustment where ticket='CH-64'").fetchone(),
                         ("revoke", "B", "CH-53"))
        db.close()

    def test_migration_is_repeatable(self):
        path, db = live_copy()
        dump = lambda: {t: db.execute(f"select * from {t} order by 1").fetchall()
                        for t in ("events", "bookings", "series", "adjustment")}
        portal.migrate(db, INTAKE, RECORDS)
        once = dump()
        portal.migrate(db, INTAKE, RECORDS)
        self.assertEqual(dump(), once)
        db.close()


class Guards(unittest.TestCase):
    def setUp(self):
        self.path, self.db = live_copy()
        portal.migrate(self.db, INTAKE, RECORDS)
        self.series = {row[0]: dict(zip(portal.SERIES_COLUMNS, row))
                       for row in self.db.execute("select " + ",".join(portal.SERIES_COLUMNS) + " from series")}

    def tearDown(self):
        self.db.close()

    def test_withdrawing_a_day_the_ticket_does_not_cover(self):
        with self.assertRaises(ValueError):
            portal.parse_revocation("仅撤销 CH-53 对 B 的 3月27日单场批准，恢复原合同时间。",
                                    self.series, portal.adjustments(self.db))

    def test_withdrawing_an_unknown_ticket(self):
        with self.assertRaises(ValueError):
            portal.parse_revocation("仅撤销 CH-99 对 B 的 3月20日单场批准，恢复原合同时间。",
                                    self.series, portal.adjustments(self.db))


if __name__ == "__main__":
    unittest.main(verbosity=2)
