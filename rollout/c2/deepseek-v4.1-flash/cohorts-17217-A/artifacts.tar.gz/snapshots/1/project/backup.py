"""Handover backup of the portal database.

python3 project/backup.py OUTPUT [SOURCE]

SOURCE is a portal database (default: $PORTAL_DB or data/portal.sqlite) and
OUTPUT is the handover copy.  The copy uses sqlite3's online backup API, so it
is consistent even while the portal is being read, and it is a single
self-contained file (`journal_mode=delete`, no -wal/-shm side files): a clean
instance needs only `project/` plus this file at $PORTAL_DB, with no notes,
input/ or data/ from the original workstation.

Receipts are not part of the database — they belong to the subscription service
and are re-read with receipts(CHANNEL).  Bookings, series, events and the
adjustment rows a reschedule/correction lives in are all inside the snapshot.
"""
import hashlib
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import portal

TABLES = ("events", "bookings", "series", "adjustment")


def snapshot(source, target):
    """Copy `source` into `target`; -> report dict, raises ValueError on a non-portal file."""
    if not os.path.exists(source):
        raise ValueError(f"no portal database at {source}")
    reader = sqlite3.connect(f"file:{os.path.abspath(source)}?mode=ro", uri=True)
    try:
        present = {row[0] for row in reader.execute(
            "select name from sqlite_master where type='table'")}
        missing = [table for table in TABLES if table not in present]
        if missing:
            raise ValueError(f"{source} is not a portal database (no {missing})")
        counts = {table: reader.execute(f"select count(*) from {table}").fetchone()[0]
                  for table in TABLES}
        os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
        if os.path.exists(target):
            os.unlink(target)                     # never mix pages with a stale copy
        writer = sqlite3.connect(target)
        try:
            with writer:
                reader.backup(writer)
            writer.execute("pragma journal_mode=delete")   # one self-contained file
            integrity = writer.execute("pragma integrity_check").fetchone()[0]
        finally:
            writer.close()
    finally:
        reader.close()
    with open(target, "rb") as handle:
        digest = hashlib.sha256(handle.read()).hexdigest()
    return dict(source=source, target=target, counts=counts, integrity=integrity, sha256=digest)


def main(argv):
    if len(argv) not in (2, 3):
        print(__doc__.strip(), file=sys.stderr)
        return 2
    target = argv[1]
    source = argv[2] if len(argv) == 3 else os.getenv("PORTAL_DB", "data/portal.sqlite")
    try:
        report = snapshot(source, target)
    except ValueError as problem:
        print(f"backup failed: {problem}", file=sys.stderr)
        return 2
    counts = " ".join(f"{table}={report['counts'][table]}" for table in TABLES)
    print(f"source={report['source']} target={report['target']} integrity={report['integrity']} {counts}")
    print(f"sha256={report['sha256']}")
    print("handover: copy project/ and this file, then PORTAL_DB=<file>; receipts come from receipts(CHANNEL)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
