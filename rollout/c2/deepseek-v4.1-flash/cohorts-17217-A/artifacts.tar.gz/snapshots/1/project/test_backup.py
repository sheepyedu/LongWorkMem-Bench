"""Handover backup: one database file plus project/ is a working portal.
Run: python3 project/test_backup.py
"""
import io
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout

import backup
import portal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIVE = os.path.join(ROOT, "data", "portal.sqlite")
DELIVERED = os.path.join(ROOT, "out", "backup.sqlite")

OLD_LINKS = ("/invite/legacy-east?tz=Asia/Tokyo",
             "/invite/legacy-west?tz=UTC",
             "/invite/K17-20260306?tz=America/New_York",
             "/invite/M42-20260320?tz=UTC&channel=A",
             "/invite/M42-20260320?tz=UTC&channel=B",
             "/invite/M42-20260327?tz=Europe/London")


def rows(path, table):
    db = sqlite3.connect(path)
    try:
        return db.execute(f"select * from {table} order by 1").fetchall()
    finally:
        db.close()


class Snapshot(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def test_every_row_comes_across(self):
        target = os.path.join(self.tmp, "backup.sqlite")
        report = backup.snapshot(LIVE, target)
        self.assertEqual(report["integrity"], "ok")
        for table in backup.TABLES:
            self.assertEqual(rows(target, table), rows(LIVE, table), table)
        self.assertEqual(report["counts"]["bookings"], 4)      # 旧报名不可丢

    def test_the_file_is_self_contained(self):
        target = os.path.join(self.tmp, "backup.sqlite")
        backup.snapshot(LIVE, target)
        self.assertEqual(os.listdir(self.tmp), ["backup.sqlite"])   # no -wal / -shm
        db = sqlite3.connect(target)
        try:
            self.assertEqual(db.execute("pragma journal_mode").fetchone()[0], "delete")
            self.assertEqual(db.execute("pragma integrity_check").fetchone()[0], "ok")
        finally:
            db.close()

    def test_a_stale_target_is_replaced_not_merged(self):
        target = os.path.join(self.tmp, "backup.sqlite")
        stale = sqlite3.connect(target)
        stale.execute("create table junk(x)")
        stale.commit()
        stale.close()
        backup.snapshot(LIVE, target)
        db = sqlite3.connect(target)
        try:
            self.assertEqual(db.execute(
                "select count(*) from sqlite_master where name='junk'").fetchone()[0], 0)
        finally:
            db.close()

    def test_something_that_is_not_a_portal_database_is_refused(self):
        empty = os.path.join(self.tmp, "empty.sqlite")
        sqlite3.connect(empty).close()
        with self.assertRaises(ValueError) as caught:
            backup.snapshot(empty, os.path.join(self.tmp, "out.sqlite"))
        self.assertIn("not a portal database", str(caught.exception))
        with self.assertRaises(ValueError):
            backup.snapshot(os.path.join(self.tmp, "missing.sqlite"), os.path.join(self.tmp, "out.sqlite"))

    def test_the_live_database_is_not_modified(self):
        before = [rows(LIVE, table) for table in backup.TABLES]
        backup.snapshot(LIVE, os.path.join(self.tmp, "backup.sqlite"))
        self.assertEqual([rows(LIVE, table) for table in backup.TABLES], before)

    def test_cli_reports_counts_and_digest(self):
        target = os.path.join(self.tmp, "backup.sqlite")
        out = io.StringIO()
        previous = os.environ.get("PORTAL_DB")
        os.environ["PORTAL_DB"] = LIVE              # the default source is $PORTAL_DB
        try:
            with redirect_stdout(out):
                code = backup.main(["backup.py", target])
        finally:
            if previous is None:
                del os.environ["PORTAL_DB"]
            else:
                os.environ["PORTAL_DB"] = previous
        self.assertEqual(code, 0)
        text = out.getvalue()
        self.assertIn("integrity=ok", text)
        self.assertIn("bookings=4", text)
        self.assertIn("sha256=", text)
        self.assertTrue(os.path.exists(target))
        err = io.StringIO()
        with redirect_stderr(err), redirect_stdout(io.StringIO()):
            self.assertEqual(backup.main(["backup.py"]), 2)


class CleanInstance(unittest.TestCase):
    """Only project/ and the snapshot: no input/, no data/, no notes/."""

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        shutil.copytree(os.path.join(ROOT, "project"), os.path.join(self.dir, "project"))
        self.db = os.path.join(self.dir, "backup.sqlite")
        backup.snapshot(LIVE, self.db)

    def request(self, url):
        env = dict(os.environ, PORTAL_DB=self.db)
        done = subprocess.run([sys.executable, "project/portal.py", "request", url],
                              cwd=self.dir, env=env, capture_output=True, text=True)
        self.assertEqual(done.returncode, 0, done.stderr)
        return done.stdout

    def test_the_same_pages_are_served(self):
        live = portal.ensure_schema(sqlite3.connect(LIVE))
        try:
            for url in ("/api/events", "/", "/api/events?from=2026-04-01&to=2026-06-30&channel=B") + OLD_LINKS:
                self.assertEqual(self.request(url).strip(), portal.route(live, url)[1].strip(), url)
        finally:
            live.close()

    def test_old_invites_still_resolve(self):
        self.assertIn('data-uid="legacy-east"', self.request("/invite/legacy-east?tz=Asia/Tokyo"))
        self.assertIn("2026-03-06 08:30", self.request("/invite/legacy-east?tz=Asia/Tokyo"))
        self.assertIn("2026-03-20 15:00", self.request("/invite/M42-20260320?tz=UTC&channel=B"))
        self.assertIn("2026-03-20 17:00", self.request("/invite/M42-20260320?tz=UTC&channel=A"))
        self.assertIn("2026-03-27 16:30", self.request("/invite/M42-20260327?tz=Europe/London"))
        self.assertEqual(self.request("/invite/K17-20260319?tz=UTC").strip(), "<main></main>")

    def test_the_cleaned_instance_can_carry_on(self):
        env = dict(os.environ, PORTAL_DB=self.db)
        # 迁移在没有 input/ 的干净实例上是空操作, 不会失败
        done = subprocess.run([sys.executable, "project/portal.py", "migrate"],
                              cwd=self.dir, env=env, capture_output=True, text=True)
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertIn("nothing to import", done.stdout)
        # 发布准备与恢复入口都还能用
        out = os.path.join(self.dir, "q2.ics")
        done = subprocess.run([sys.executable, "project/prepare.py", "A", "2026-04-01", "2026-06-30", out],
                              cwd=self.dir, env=env, capture_output=True, text=True)
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertIn("events=26", done.stdout)
        with open(out, "rb") as a, open(os.path.join(ROOT, "out", "new-A.ics"), "rb") as b:
            self.assertEqual(a.read(), b.read())          # 同一个数据库 -> 同一份全量文件

    def test_delivered_backup_is_the_same_database(self):
        for table in backup.TABLES:
            self.assertEqual(rows(DELIVERED, table), rows(LIVE, table), table)


if __name__ == "__main__":
    unittest.main(verbosity=2)
