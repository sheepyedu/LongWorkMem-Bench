"""重新对账：应有（门户 + 春季版本 7 账本） vs 实收（归档 ∪ 在线回执）。

python3 scratch/verify-holdings.py [--online scratch/receipts]
归档 = input/vault/*-closing-04.json（春季早期批次）+ data/receipts-{A,B}.json（试点批次）
"""
import json, os, sqlite3, sys
sys.path.insert(0, "project")
import portal, service

db = portal.ensure_schema(sqlite3.connect(f"file:data/portal.sqlite?mode=ro", uri=True))
online = {}
for ch in "ABCD":
    online[ch] = json.load(open(f"scratch/receipts/live-{ch}.json"))

held = {}
for ch in "ABCD":
    state = {}
    for path in ([f"input/vault/{ch}-closing-04.json"] +
                 ([f"data/receipts-{ch}.json"] if ch in "AB" else [])):
        for batch in json.load(open(path)):
            state.update(batch.get("rows") or {})
    for batch in online[ch]:
        state.update(batch.get("rows") or {})
    held[ch] = state

def same(a, b):
    if a is None or b is None:
        return a is b or a == b
    return service.instant(a, "held") == service.instant(b, "book")

bad = []
print(f"{'ch':<3}{'uid':<26}{'应有(UTC)':<22}{'实收(UTC)':<22}凭证       判定")
for ch in "ABCD":
    want = [(r["uid"], r["utc"]) for r in service.rows_as_of(db, ch, 7)]
    if ch in "AB":          # 试点系列 (K17/M42) 只发 A、B 两个频道 (prepare.CHANNELS)
        for row in portal.series_rows(db, portal.as_date("2026-03-06"),
                                      portal.as_date("2026-06-30"), ch):
            want.append((row["uid"], row["utc"]))
    for uid, utc in sorted(set(want), key=lambda pair: pair[0]):
        got = (held[ch].get(uid) or {}).get("utc")
        ok = same(utc, got)
        source = "在线" if any(uid in (b.get("rows") or {}) for b in online[ch]) else "归档"
        if not ok:
            bad.append((ch, uid, utc, got))
        print(f"{ch:<3}{uid:<26}{utc:<22}{str(got):<22}{source:<10}{'一致' if ok else '缺/不同'}")
print()
print("实收条目数:", {ch: len(held[ch]) for ch in "ABCD"})
print("不符项:", bad if bad else "无")
db.close()
