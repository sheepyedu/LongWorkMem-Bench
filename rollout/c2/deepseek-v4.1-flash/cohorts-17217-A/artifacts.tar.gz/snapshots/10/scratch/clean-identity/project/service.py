"""Spring course intake and lookups for the four customer mailboxes.

python3 project/service.py import DIR

    Register DIR/schedule.json, DIR/roster.json and whatever has arrived as
    DIR/migration.json and DIR/orders/*.json into $PORTAL_DB (default
    data/portal.sqlite).  Re-sending the same arrival changes nothing; an
    arrival carries a logical version (DIR/version.txt) and an older version
    never rewrites newer history.  Attachment paths are relative to DIR, and
    only the annex the schedule points at is used -- and only when its number
    matches.  Q29 takes each account's UTC clock from that annex; N84 uses the
    venue wall clock.  Rows are mirrored into the portal's own events and
    bookings, so the old invite links and listings keep working; the pilot and
    earlier bookings are never removed.

python3 project/service.py view ACCOUNT [ASOF]

    Print every business row of ACCOUNT as a JSON array, as of logical version
    ASOF (default: latest; an ISO business day is accepted and means "the last
    version imported on or before that day").  A row is account, code, day,
    booking, uid, utc: `day` is the 原定业务日, `utc` carries an explicit
    offset, and UID = prefix-YYYYMMDD.  A booking starts out under its
    old_prefix; once the identity release in DIR/migration.json applies (from
    the logical `version` it names), each registration compares its own `joined`
    instant with the release `cutover`: strictly earlier keeps the old prefix
    for life, everything else takes the prefix of its business channel and
    class.  Both generations therefore work side by side in one channel, and an
    invitation or booking already handed out is never renamed under a client --
    the new prefix is a new UID, the old one stays readable.

python3 project/service.py delta ACCOUNT FROM [TO] [OUTPUT]

    The rows of ACCOUNT that appear or change between logical versions FROM and
    TO (default TO: latest).  With OUTPUT they are written as a self-contained
    CONFIRMED ICS ready for publishing; without it they are printed as JSON.

python3 project/service.py history [ACCOUNT]

    Every recorded version and the rows it wrote, as JSON.

view, delta and history read only the database and their explicit arguments.
"""
import argparse
import hashlib
import json
import os
import re
import sqlite3
import sys
from datetime import date, datetime, time, timezone
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import portal

BASIS_ANNEX = "signed-annex"      # the signed attachment dictates the clock
BASIS_WALL = "wall"               # the venue wall clock dictates the instant
SIGNED = ("signed", "active", "effective")

CLASS_COLUMNS = ("code", "basis", "zone", "clock", "ref", "approval", "rank", "version", "imported")
ACCOUNT_COLUMNS = ("account", "code", "channel", "joined", "old_prefix", "booking", "rank",
                   "prefix", "generation", "version", "imported")
DAY_COLUMNS = ("day", "rank", "version", "imported")
ROW_FIELDS = ("booking", "uid", "utc", "rank")          # what identifies a row's content
HISTORY_COLUMNS = ("account", "code", "day", "booking", "uid", "utc", "rank", "version", "imported")


# --------------------------------------------------------------------------- #
# storage
# --------------------------------------------------------------------------- #
def ensure(db):
    """Portal schema plus the service tables; safe to run on an existing database."""
    portal.ensure_schema(db)
    db.execute("""create table if not exists service_class(
        code text primary key, basis text not null, zone text, clock text,
        ref text, approval text, rank integer not null default 0,
        version integer not null, imported text)""")
    db.execute("""create table if not exists service_account(
        account text not null, code text not null, channel text, joined text,
        old_prefix text not null, booking text not null, rank integer not null default 0,
        version integer not null, imported text,
        prefix text, generation text, primary key(account, code))""")
    present = {row[1] for row in db.execute("pragma table_info(service_account)")}
    for column in ("prefix", "generation"):        # databases created before the identity release
        if column not in present:
            db.execute(f"alter table service_account add column {column} text")
    db.execute("""create table if not exists service_day(
        day text primary key, rank integer not null default 0,
        version integer not null, imported text)""")
    db.execute("""create table if not exists service_row(
        account text not null, code text not null, day text not null,
        booking text not null, uid text not null, utc text not null,
        rank integer not null default 0, version integer not null, imported text,
        primary key(account, code, day))""")
    db.execute("""create table if not exists service_history(
        account text not null, code text not null, day text not null,
        booking text not null, uid text not null, utc text not null,
        rank integer not null default 0, version integer not null, imported text,
        primary key(account, code, day, version))""")
    db.execute("""create table if not exists service_import(
        version integer primary key, digest text not null, source text, imported text)""")
    db.execute("""create table if not exists service_prefix(
        prefix text primary key, code text not null)""")
    return db


def store_meta(db, table, key_columns, wanted, value_columns, version, imported):
    """Insert or update one metadata row; -> added / changed / unchanged."""
    key = tuple(wanted[column] for column in key_columns)
    where = " and ".join(f"{column}=?" for column in key_columns)
    current = db.execute("select " + ",".join(value_columns) + f" from {table} where {where}",
                         key).fetchone()
    values = tuple(wanted[column] for column in value_columns)
    if current is not None and tuple(current) == values:
        return "unchanged"
    if current is None:
        db.execute(f"insert into {table}(" + ",".join(key_columns + value_columns + ("version", "imported"))
                   + ") values(" + ",".join("?" * (len(key_columns) + len(value_columns) + 2)) + ")",
                   key + values + (version, imported))
        return "added"
    db.execute(f"update {table} set " + ",".join(f"{column}=?" for column in value_columns + ("version", "imported"))
               + f" where {where}", values + (version, imported) + key)
    return "changed"


def store_row(db, row, version, imported):
    """Upsert one business row and keep the per-version history; -> action."""
    key = (row["account"], row["code"], row["day"])
    content = tuple(row[field] for field in ROW_FIELDS)
    current = db.execute("select " + ",".join(ROW_FIELDS) + ",version from service_row"
                         " where account=? and code=? and day=?", key).fetchone()
    if current is not None and tuple(current[:-1]) == content:
        db.execute("insert or ignore into service_history(" + ",".join(HISTORY_COLUMNS) + ") values("
                   + ",".join("?" * len(HISTORY_COLUMNS)) + ")",
                   key + content + (current[-1], imported))
        return "unchanged"
    if current is None:
        db.execute("insert into service_row(account,code,day," + ",".join(ROW_FIELDS) + ",version,imported)"
                   " values(?,?,?," + ",".join("?" * (len(ROW_FIELDS) + 2)) + ")",
                   key + content + (version, imported))
        action = "added"
    else:
        db.execute("update service_row set " + ",".join(f"{field}=?" for field in ROW_FIELDS)
                   + ",version=?,imported=? where account=? and code=? and day=?",
                   content + (version, imported) + key)
        action = "changed"
    db.execute("insert or replace into service_history(" + ",".join(HISTORY_COLUMNS) + ") values("
               + ",".join("?" * len(HISTORY_COLUMNS)) + ")",
               key + content + (version, imported))
    return action


def mirror(db, rows, imported):
    """Keep the portal's own events/bookings in step; never drop an old identity."""
    seen = {}
    for row in sorted(rows, key=lambda item: item["day"]):
        starts = datetime.fromisoformat(row["utc"]).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        current = db.execute("select starts from events where uid=?", (row["uid"],)).fetchone()
        if current is None:
            db.execute("insert into events(uid, starts) values(?,?)", (row["uid"], starts))
        elif current[0] != starts:
            db.execute("update events set starts=? where uid=?", (starts, row["uid"]))
        seen.setdefault(row["booking"], row["uid"])
    for booking, uid in seen.items():               # a booking keeps its first occurrence UID
        if db.execute("select 1 from bookings where id=?", (booking,)).fetchone() is None:
            db.execute("insert into bookings(id, uid) values(?,?)", (booking, uid))


# --------------------------------------------------------------------------- #
# reading the arrival
# --------------------------------------------------------------------------- #
def load_json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def read_text(path):
    with open(path, encoding="utf-8") as handle:
        return handle.read().strip()


def clock_value(text, where):
    parts = str(text).split(":")
    if len(parts) != 2 or not all(part.isdigit() for part in parts):
        raise ValueError(f"{where} has no HH:MM clock: {text!r}")
    hour, minute = int(parts[0]), int(parts[1])
    if not (0 <= hour < 24 and 0 <= minute < 60):
        raise ValueError(f"{where} has an impossible clock: {text!r}")
    return time(hour, minute)


def signed(document, where):
    status = str(document.get("status", "")).lower()
    if status not in SIGNED:
        raise ValueError(f"{where} is {status or 'unsigned'}, not signed")
    return document


def annex_clocks(directory, code, spec, accounts):
    """The clocks of the signed annex the schedule points at; nothing else counts."""
    ref, approval = spec.get("ref"), spec.get("approval")
    if not ref or not approval:
        raise ValueError(f"class {code} is {BASIS_ANNEX} but names no ref/approval")
    path = os.path.join(directory, ref)
    if not os.path.isfile(path):
        raise ValueError(f"class {code} points at {ref}, which is not in {directory}")
    document = signed(load_json(path), f"annex {ref}")
    if document.get("id") != approval:
        raise ValueError(f"class {code} needs annex {approval}, but {ref} is {document.get('id')!r}")
    clocks = document.get("utc_by_account") or {}
    missing = [account for account in accounts if account not in clocks]
    if missing:
        raise ValueError(f"annex {approval} gives no UTC clock for {missing}")
    return {account: clock_value(clocks[account], f"annex {approval} / {account}")
            for account in accounts}


def instant(text, where):
    """An absolute moment; a value without an offset is refused, not guessed at."""
    try:
        moment = datetime.fromisoformat(str(text).strip())
    except (TypeError, ValueError):
        raise ValueError(f"{where} is not an ISO instant: {text!r}")
    if moment.tzinfo is None:
        raise ValueError(f"{where} carries no UTC offset, so its order is unknown: {text!r}")
    return moment.astimezone(timezone.utc)


def identity_release(directory, files):
    """Optional migration.json: the release that renames UID prefixes.

    `version` is the logical version the new identifiers start with, `cutover`
    the absolute instant that splits the registrations, and `prefixes` the
    prefix per business channel and class.  Comparing joined with cutover is a
    comparison of instants, not of the local clock a client happened to write
    down: 2026-01-31T18:59:59-05:00 is before 2026-02-01T00:00:00Z while
    2026-02-01T01:00:00+01:00 is exactly on it.
    """
    path = os.path.join(directory, "migration.json")
    if not os.path.isfile(path):
        return None
    files.append("migration.json")
    document = load_json(path)
    version = document.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise ValueError(f"migration.json names no logical version: {version!r}")
    cutover = instant(document.get("cutover"), "migration.json cutover")
    table = document.get("prefixes")
    if not isinstance(table, dict) or not table:
        raise ValueError("migration.json names no prefixes")
    prefixes = {}
    for channel, by_code in table.items():
        if not isinstance(by_code, dict) or not by_code:
            raise ValueError(f"migration.json names no prefix for channel {channel!r}")
        for code, prefix in by_code.items():
            prefix = str(prefix or "").strip()
            if not prefix:
                raise ValueError(f"migration.json has no usable prefix for {channel}/{code}")
            prefixes[(str(channel), str(code))] = prefix
    if len(set(prefixes.values())) != len(prefixes):
        raise ValueError("migration.json reuses one prefix for different channels/classes")
    return dict(version=version, cutover=cutover, prefixes=prefixes)


def order_days(directory, classes, accounts_by_code, files):
    """Optional orders/*.json: extra signed days for a class -> [(code, day, clocks)]."""
    folder = os.path.join(directory, "orders")
    if not os.path.isdir(folder):
        return []
    extra = []
    for name in sorted(os.listdir(folder)):
        if not name.endswith(".json"):
            continue
        rel = f"orders/{name}"
        files.append(rel)
        document = signed(load_json(os.path.join(folder, name)), rel)
        code = document.get("code")
        if code not in classes:
            raise ValueError(f"{rel} names class {code!r}, which the schedule does not have")
        raw = document.get("days") or ([document["day"]] if document.get("day") else [])
        if not raw:
            raise ValueError(f"{rel} names no day")
        need = [entry["account"] for entry in accounts_by_code.get(code, [])]
        for written in raw:
            try:
                day = date.fromisoformat(written)
            except (TypeError, ValueError):
                raise ValueError(f"{rel} names a day that is not a date: {written!r}")
            if classes[code]["basis"] == BASIS_ANNEX:
                clocks = document.get("utc_by_account") or {}
                missing = [account for account in need if account not in clocks]
                if missing:
                    raise ValueError(f"{rel} gives no UTC clock for {missing}")
                extra.append((code, day, {account: clock_value(clocks[account], f"{rel} / {account}")
                                          for account in need}))
            else:
                clock = document.get("clock") or classes[code]["clock_time"]
                extra.append((code, day, {account: clock_value(clock, f"{rel} / {account}")
                                          for account in need}))
    return extra


def business_day(directory):
    path = os.path.join(directory, "clock.txt")
    return read_text(path) if os.path.isfile(path) else ""


def declared_version(directory):
    path = os.path.join(directory, "version.txt")
    if not os.path.isfile(path):
        return None
    raw = read_text(path)
    if not raw.isdigit():
        raise ValueError(f"version.txt is not a logical version number: {raw!r}")
    return int(raw)


def make_row(registration, cls, day, prefix, clocks=None):
    if cls["basis"] == BASIS_ANNEX:
        moment = datetime.combine(day, (clocks or cls["clocks"])[registration["account"]],
                                  tzinfo=timezone.utc)
    else:
        moment = datetime.combine(day, cls["clock_time"],
                                  tzinfo=cls["zoneinfo"]).astimezone(timezone.utc)
    return dict(account=registration["account"], code=registration["code"], day=day.isoformat(),
                booking=registration["booking"], uid=f'{prefix}-{day:%Y%m%d}',
                utc=moment.isoformat(), rank=registration["rank"])


def heritage_rows(db, plan):
    """Business rows that were already in the portal before any service intake.

    The roster's old_prefix is what the earlier invitations were filed under, so
    a stored event whose UID is `<old_prefix>-YYYYMMDD` is that registration's
    row.  They become the baseline history (never rewritten by a later version).
    """
    by_prefix = {entry["old_prefix"]: entry for entry in plan["registrations"]}
    rows = []
    for uid, starts in db.execute("select uid, starts from events order by uid"):
        prefix, _, tail = uid.rpartition("-")
        registration = by_prefix.get(prefix)
        if registration is None or len(tail) != 8 or not tail.isdigit():
            continue
        try:
            day = date(int(tail[:4]), int(tail[4:6]), int(tail[6:]))
        except ValueError:
            continue
        moment = datetime.fromisoformat(starts)
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
        rows.append(dict(account=registration["account"], code=registration["code"],
                         day=day.isoformat(), booking=registration["booking"], uid=uid,
                         utc=moment.astimezone(timezone.utc).isoformat(),
                         rank=registration["rank"]))
    return rows


def build_plan(directory):
    """Read and validate one arrival; nothing is written here."""
    if not os.path.isdir(directory):
        raise ValueError(f"no arrival directory at {directory}")
    schedule_path = os.path.join(directory, "schedule.json")
    roster_path = os.path.join(directory, "roster.json")
    if not os.path.isfile(schedule_path) or not os.path.isfile(roster_path):
        raise ValueError(f"{directory} needs schedule.json and roster.json")
    schedule, roster = load_json(schedule_path), load_json(roster_path)
    files = ["schedule.json", "roster.json"]

    spec_classes = schedule.get("classes")
    if not isinstance(spec_classes, dict) or not spec_classes:
        raise ValueError("schedule.json names no classes")
    raw_days = schedule.get("days")
    if not isinstance(raw_days, list) or not raw_days:
        raise ValueError("schedule.json names no days")
    days, seen = [], set()
    for written in raw_days:
        try:
            day = date.fromisoformat(written)
        except (TypeError, ValueError):
            raise ValueError(f"schedule day is not a date: {written!r}")
        if day not in seen:
            seen.add(day)
            days.append(day)

    if not isinstance(roster, list) or not roster:
        raise ValueError("roster.json names no registrations")
    accounts_by_code = {}
    for entry in roster:
        code = entry.get("code")
        if code not in spec_classes:
            raise ValueError(f"roster names class {code!r}, schedule has {sorted(spec_classes)}")
        accounts_by_code.setdefault(code, []).append(entry)

    classes = {}
    for rank, (code, spec) in enumerate(spec_classes.items()):
        basis = spec.get("basis")
        item = dict(code=code, basis=basis, zone=None, clock=None, ref=None, approval=None, rank=rank)
        if basis == BASIS_ANNEX:
            accounts = [entry["account"] for entry in accounts_by_code.get(code, [])]
            item["clocks"] = annex_clocks(directory, code, spec, accounts)
            item["ref"], item["approval"] = spec.get("ref"), spec.get("approval")
            files.append(spec["ref"])
        elif basis == BASIS_WALL:
            zone_name, written = spec.get("zone"), spec.get("clock")
            if not zone_name or not written:
                raise ValueError(f"class {code} is {BASIS_WALL} but names no zone/clock")
            try:
                item["zoneinfo"] = ZoneInfo(zone_name)
            except KeyError:
                raise ValueError(f"class {code} names an unknown zone {zone_name!r}")
            item["zone"], item["clock"] = zone_name, written
            item["clock_time"] = clock_value(written, f"class {code}")
        else:
            raise ValueError(f"class {code} has an unknown basis {basis!r}")
        classes[code] = item

    release = identity_release(directory, files)
    declared = declared_version(directory)
    if release is not None:
        if declared is None:
            raise ValueError("migration.json needs version.txt to say which release this arrival is")
        if declared < release["version"]:
            raise ValueError(f"migration.json applies from logical version {release['version']},"
                             f" but version.txt says {declared}")

    registrations, pairs, bookings = [], set(), set()
    for entry in roster:
        account = str(entry.get("account") or "").strip()
        code = entry.get("code")
        booking = str(entry.get("booking") or "").strip()
        old_prefix = str(entry.get("old_prefix") or "").strip()
        channel = str(entry.get("channel") or "").strip()
        if not account or not booking or not old_prefix:
            raise ValueError(f"roster entry {entry!r} needs account, booking and old_prefix")
        if (account, code) in pairs:
            raise ValueError(f"roster registers {account} for {code} twice")
        if booking in bookings:
            raise ValueError(f"roster uses booking {booking} twice")
        pairs.add((account, code))
        bookings.add(booking)
        prefix, generation = old_prefix, "old"
        if release is not None:
            joined = instant(entry.get("joined"), f"roster {account}/{code} joined")
            if joined >= release["cutover"]:
                wanted = (channel, str(code))
                if wanted not in release["prefixes"]:
                    raise ValueError(
                        f"roster {account}/{code} joined at {joined.isoformat()}, not before the"
                        f" {release['cutover'].isoformat()} cutover, but migration.json has no prefix"
                        f" for channel {channel!r} / class {code}")
                prefix, generation = release["prefixes"][wanted], "new"
        registrations.append(dict(account=account, code=code, channel=channel or None,
                                  joined=entry.get("joined"), old_prefix=old_prefix,
                                  booking=booking, rank=classes[code]["rank"],
                                  prefix=prefix, generation=generation))

    extra = order_days(directory, classes, accounts_by_code, files)

    rows, uids = [], set()
    for registration in registrations:
        cls = classes[registration["code"]]
        prefix = registration["prefix"]
        for day in days:
            rows.append(make_row(registration, cls, day, prefix))
        for code, day, clocks in extra:
            if code == registration["code"]:
                rows.append(make_row(registration, cls, day, prefix, clocks))
    for row in rows:
        if row["uid"] in uids:
            raise ValueError(f"two business rows share the UID {row['uid']}")
        uids.add(row["uid"])

    prefixes = {}
    for registration in registrations:      # both generations of a UID count as that class
        for prefix in (registration["old_prefix"], registration["prefix"]):
            known = prefixes.setdefault(prefix, registration["code"])
            if known != registration["code"]:
                raise ValueError(f"UID prefix {prefix!r} is used for both {known} and"
                                 f" {registration['code']}")

    digest = hashlib.sha256()
    for rel in sorted(set(files)):
        digest.update(rel.encode())
        digest.update(b"\0")
        with open(os.path.join(directory, rel), "rb") as handle:
            digest.update(handle.read())
        digest.update(b"\0")
    return dict(directory=os.path.abspath(directory), classes=[classes[c] for c in spec_classes],
                registrations=registrations, days=days, rows=rows, release=release,
                prefixes=prefixes,
                version=declared, digest=digest.hexdigest(),
                business_day=business_day(directory))


# --------------------------------------------------------------------------- #
# import
# --------------------------------------------------------------------------- #
def do_import(db, directory):
    plan = build_plan(directory)                      # every check happens before any write
    imported = plan["business_day"]
    known = {digest: version for version, digest in
             db.execute("select version,digest from service_import").fetchall()}
    latest = max(known.values(), default=0)
    if plan["digest"] in known:
        print(f'unchanged: this arrival is already registered as version {known[plan["digest"]]}'
              f' digest={plan["digest"][:8]}')
        return 0
    declared = plan["version"]
    if declared is not None and declared < latest:
        print(f'stale arrival: logical version {declared} is older than {latest}; ignored'
              f' digest={plan["digest"][:8]}')
        return 0
    if declared is not None and declared <= latest:
        raise ValueError(f'logical version {declared} is already registered with different content;'
                         f' bump version.txt instead of rewriting history')
    version = declared if declared is not None else latest + 1

    actions = {"added": 0, "changed": 0, "unchanged": 0}
    baseline = 1 if version > 1 else 0
    try:
        if not db.execute("select count(*) from service_history").fetchone()[0]:
            heritage = heritage_rows(db, plan)
            for row in heritage:                    # registrations that predate the intake
                store_row(db, row, baseline, imported)
            if heritage:
                db.execute("insert or ignore into service_import(version,digest,source,imported)"
                           " values(?,?,?,?)", (baseline, "baseline", "portal", imported))
                print(f'baseline: {len(heritage)} registration row(s) recorded at version {baseline}')
        for cls in plan["classes"]:
            wanted = dict(cls, version=version, imported=imported)
            store_meta(db, "service_class", ("code",), wanted,
                     ("code", "basis", "zone", "clock", "ref", "approval", "rank"), version, imported)
        for registration in plan["registrations"]:
            wanted = dict(registration, version=version, imported=imported)
            store_meta(db, "service_account", ("account", "code"), wanted,
                     ("account", "code", "channel", "joined", "old_prefix", "booking", "rank",
                      "prefix", "generation"), version, imported)
        for rank, day in enumerate(plan["days"]):
            store_meta(db, "service_day", ("day",), dict(day=day.isoformat(), rank=rank),
                     ("day", "rank"), version, imported)
        for row in plan["rows"]:
            action = store_row(db, row, version, imported)
            actions[action] += 1
            print(f'{row["account"]} {row["code"]} {row["day"]} {row["booking"]} '
                  f'{row["uid"]} {row["utc"]} {action}')
        for prefix, code in sorted(plan["prefixes"].items()):
            db.execute("insert or replace into service_prefix(prefix, code) values(?,?)", (prefix, code))
        mirror(db, plan["rows"], imported)
        db.execute("insert into service_import(version,digest,source,imported) values(?,?,?,?)",
                   (version, plan["digest"], plan["directory"], imported))
        db.commit()
    except Exception:
        db.rollback()
        raise
    print(f'version={version} digest={plan["digest"][:8]} source={plan["directory"]} '
          f'added={actions["added"]} changed={actions["changed"]} unchanged={actions["unchanged"]}')
    return 0


# --------------------------------------------------------------------------- #
# queries (database and explicit arguments only)
# --------------------------------------------------------------------------- #
def latest_version(db):
    return db.execute("select max(version) from service_import").fetchone()[0] or 0


def as_version(db, token):
    """A logical version number; an ISO business day means the last version up to that day."""
    if token is None:
        return latest_version(db)
    text = str(token).strip().lower()
    if text in ("latest", "now", "head"):
        return latest_version(db)
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    try:
        day = date.fromisoformat(text)
    except ValueError:
        raise ValueError(f"ASOF must be a logical version number or an ISO business day, got {token!r}")
    found = db.execute("select max(version) from service_import where imported<=?",
                       (day.isoformat(),)).fetchone()[0]
    return found or 0


def rows_as_of(db, account, asof):
    """The rows of ACCOUNT as they stood at logical version `asof`."""
    found = {}
    query = ("select account,code,day,booking,uid,utc,rank,version from service_history"
             " where account=? and version<=? order by version")
    for row in db.execute(query, (account, asof)):
        found[(row[1], row[2])] = row              # ordered by version: the newest wins
    ordered = sorted(found.values(), key=lambda row: (row[2], row[6], row[1]))
    return [dict(account=row[0], code=row[1], day=row[2], booking=row[3], uid=row[4], utc=row[5])
            for row in ordered]


def changed_between(db, account, since, until):
    """Rows that are new or different at `until` compared with `since`."""
    before = {(row["code"], row["day"]): row for row in rows_as_of(db, account, since)}
    return [row for row in rows_as_of(db, account, until)
            if before.get((row["code"], row["day"])) != row]


def history(db, account=None):
    versions = []
    for version, digest, source, imported in db.execute(
            "select version,digest,source,imported from service_import order by version"):
        query = ("select account,code,day,booking,uid,utc,rank from service_history"
                 " where version=?")
        args = [version]
        if account is not None:
            query += " and account=?"
            args.append(account)
        rows = [dict(account=row[0], code=row[1], day=row[2], booking=row[3], uid=row[4], utc=row[5])
                for row in db.execute(query + " order by account,day,rank", args)]
        versions.append(dict(version=version, digest=digest, source=source,
                             imported=imported, rows=rows))
    return versions


# --------------------------------------------------------------------------- #
# command line
# --------------------------------------------------------------------------- #
def main(argv=None):
    parser = argparse.ArgumentParser(description="Spring course intake and lookups.")
    sub = parser.add_subparsers(dest="action", required=True)
    one = sub.add_parser("import")
    one.add_argument("directory")
    two = sub.add_parser("view")
    two.add_argument("account")
    two.add_argument("asof", nargs="?")
    three = sub.add_parser("delta")
    three.add_argument("account")
    three.add_argument("frm")
    three.add_argument("to", nargs="?")
    three.add_argument("output", nargs="?")
    four = sub.add_parser("history")
    four.add_argument("account", nargs="?")
    args = parser.parse_args(argv)
    db = ensure(sqlite3.connect(os.getenv("PORTAL_DB", "data/portal.sqlite")))
    try:
        if args.action == "import":
            return do_import(db, args.directory)
        if args.action == "view":
            rows = rows_as_of(db, args.account, as_version(db, args.asof))
            print(json.dumps(rows, ensure_ascii=False))
            return 0
        if args.action == "history":
            print(json.dumps(history(db, args.account), ensure_ascii=False))
            return 0
        since, until = as_version(db, args.frm), as_version(db, args.to)
        rows = changed_between(db, args.account, since, until)
        if args.output:
            text = calendar_io.encode([dict(row, status="CONFIRMED") for row in rows])
            os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
            with open(args.output, "w", encoding="utf-8", newline="") as handle:
                handle.write(text)
            print(f'account={args.account} from={since} to={until} rows={len(rows)} output={args.output}')
        else:
            print(json.dumps(rows, ensure_ascii=False))
        return 0
    except ValueError as problem:
        print(f"service failed: {problem}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
