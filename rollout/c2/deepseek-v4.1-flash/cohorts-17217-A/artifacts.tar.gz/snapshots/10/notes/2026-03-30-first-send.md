# 委托：两个服务日的全部邀请首发给四个邮箱（业务日 2026-03-30）

范围：投递。`schedule.json` 的全部课程 × 全部业务日（Q29 / N84 × 2026-03-02 / 2026-03-09），
**每个账户单独成包**，四个频道各一次首发，再用**在线真实回执**核对。库未改一行
（events 28 / bookings 12 / service_row 16 / service_history 24 / service_import 3）。

## 1. 包的内容与来历
包源是库本身，不是 input：`python3 project/service.py delta ACCOUNT 0 3 out/spring-<CH>.ics`
（`from=0` 表示"该账户此前什么都没收到"，因此是**全量**；`to=3` 是当前逻辑版本）。
每包 4 个 VEVENT，`STATUS:CONFIRMED`，UID 用各报名**自己的**第三代标识：

| 邮箱 | Q29（附件钟点） | N84（场馆墙钟） |
|---|---|---|
| A | `invite-a-31-*` 14:05Z | `n-n-*` 03-02 14:45Z / 03-09 13:45Z |
| B | `n-q-*` 15:10Z | `invite-b-32-*` 03-02 14:45Z / 03-09 13:45Z |
| C | `invite-c-31-*` 16:15Z | `s-n-*` 03-02 14:45Z / 03-09 13:45Z |
| D | `s-q-*` 17:20Z | `invite-d-32-*` 03-02 14:45Z / 03-09 13:45Z |

切点前报名的仍是 old_prefix，切点及以后的用新前缀——上一轮的标识规则，这次直接进了客户包。
`out/spring-{A,B,C,D}.ics` 各 4 个 VEVENT（生成后再用库逐行比对：UID/DTSTART/STATUS 全等）。

## 2. 投递（键 = 频道 + 范围 + 内容摘要）
键沿用既有习惯 `<CHANNEL>-<label>-<from>-<to>-<tag>`；`tag` 是**生成文本**的 sha256 前 8 位，
复算方式就是 `hashlib.sha256(open("out/spring-A.ics", encoding="utf-8").read().encode()).hexdigest()[:8]`
（读文件时若关掉通用换行、按 CRLF 字节算，会得到另一组 8 位：A e4b38051 / B 68c35a0a /
C 9c74a91b / D da9db885 —— 那只是命名口径不同，重送一律用下表已发的键）。
未占用 `handover-`（那是收件系统给超时项签发的）。

| 频道 | 键 | 文件 | 回执 | already_received |
|---|---|---|---|---|
| A | `A-spring-20260302-20260309-2ab7c151` | out/spring-A.ics | **A-00001** | false |
| B | `B-spring-20260302-20260309-57064426` | out/spring-B.ics | **B-00001** | false |
| C | `C-spring-20260302-20260309-30eefa66` | out/spring-C.ics | **C-00001** | false |
| D | `D-spring-20260302-20260309-0aa369e2` | out/spring-D.ics | **D-00001** | false |

## 3. 用真实回执核对（receipts(CHANNEL)）
四个频道此前在线回执都是空数组，所以这确实是首发。投递后再查：每个频道 1 个批次、4 行，
UID/utc/status 与库里该账户当前行**逐字段相同**、无多余行、无缺行：

- A-00001：`invite-a-31-20260302 14:05Z`、`n-n-20260302 14:45Z`、`invite-a-31-20260309 14:05Z`、`n-n-20260309 13:45Z`
- B-00001：`n-q-20260302 15:10Z`、`invite-b-32-20260302 14:45Z`、`n-q-20260309 15:10Z`、`invite-b-32-20260309 13:45Z`
- C-00001：`invite-c-31-20260302 16:15Z`、`s-n-20260302 14:45Z`、`invite-c-31-20260309 16:15Z`、`s-n-20260309 13:45Z`
- D-00001：`s-q-20260302 17:20Z`、`invite-d-32-20260302 14:45Z`、`s-q-20260309 17:20Z`、`invite-d-32-20260309 13:45Z`

回执原文存到 `data/receipts-spring-{A,B,C,D}.json`（`prepare --since` 可直接吃这个格式）。

## 4. 幂等复核
对 A 用同一键、同一文件重送一次：返回 `receipt=A-00001, already_received=true`，回执仍是
**1 个批次 4 行**、没有新增批次——"相同 key + 相同事件重送幂等"在真实收件端成立，也没有
给客户多发通知。

## 5. 遗留
- 只有 A/B/C/D 四个邮箱的课程包；旧试点 K17/M42 与 legacy 项未在本次范围内，未投递。
- 若日后课程再变（新业务日、改期、附件换版），按 `service.py delta ACCOUNT <旧版本> <新版本>`
  出**增量**包并用新键投递，不要重发全量。
- `data/receipts-A.json` / `-B.json` 是更早阶段的本地快照（turn 4 试点批次），与在线回执无关，
  未覆盖。
