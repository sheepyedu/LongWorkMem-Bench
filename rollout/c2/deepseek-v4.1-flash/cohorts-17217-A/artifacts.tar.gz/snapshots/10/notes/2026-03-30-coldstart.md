# 2026-03-30 从第七轮恢复：接管旧邀请、重查回执、解冻补齐、交冷启备份

## 工单
`input/repair-disk` 是第七轮只读恢复介质，`data` 已实际还原为 R7 收盘状态，所有客户现已解冻。
归档加在线回执是实收依据。按上轮恢复约定补发并再次核对。交 `out/backup.sqlite`；
只带 `project` 和该库亦须能查询各历史版本和计算差量。

## 1. 还原核对（先确认「还原到哪」）
- `data/portal.sqlite` 与 `input/repair-disk/portal.sqlite` **同一文件**（sha256 `7f39fb49…c677`，
  90112 字节）；与 `portal.before-order7.sqlite`（`b970bf7f…`，第六轮收盘）不同。
- 库内即 R7 收盘：`service_import` = 1/2/3/6/7（`f9a3026b` 为版本 7），`service_history` 31 行、
  `service_row` 16 行、`events` 28、`bookings` 12、`series` 2、`adjustment` 4（CH-51/53/64 + urgent-0327）、
  `service_prefix` 12、`service_account` 8，`pragma integrity_check = ok`。
- 本轮全部动作只读这个库（发布不改库）；收尾时 `data/portal.sqlite` 摘要仍是 `7f39fb49…c677`。

## 2. 接管旧邀请（还原后逐条验证仍可解析）
| 链接 | 结果 |
|---|---|
| `/invite/legacy-east?tz=Asia/Tokyo` | `2026-03-06 08:30` |
| `/invite/legacy-west?tz=UTC` | `2026-03-06 02:15` |
| `/invite/K17-20260306?tz=America/New_York` | `2026-03-06 10:00` |
| `/invite/M42-20260320?tz=UTC&channel=A` / `channel=B` | `17:00` / `15:00`（CH-53 加时、CH-64 只对 B 撤回） |
| `/invite/M42-20260327?tz=Europe/London` | `2026-03-27 16:30`（urgent-0327 +90 分钟） |
| 老前缀 `invite-a-31-20260309` / `invite-c-31-20260309` | `18:00` / `16:15`（保号一代仍在） |
| 新前缀 `n-q-20260309` / `s-q-20260309` | `15:10` / `17:20` |

报名 12 条全在（含 `seat-legacy-east/west`、`seat-K17-20260306`、`seat-M42-20260306` 与 8 条 `BK-*`）；
`service_account` 的 8 条报名记录仍是「按报名时刻比 cutover」的换代结果（A/N84、B/Q29、C/N84、D/Q29 为新一代，
其余保号）。旧邀请**未因还原丢失**，无需重新接管入库。

## 3. 重查回执（在线 + 归档）
| 频道 | 在线回执 | 归档 | 结论 |
|---|---|---|---|
| A | turn 6 `invite-a-31-20260309=18:00Z`、turn 8 `urgent-0327-A`（A-00003，M42-0327 16:30Z） | vault turn-4 4 场 + `data/receipts-A.json`（试点 8+3+1+26） | 齐 |
| B | turn 6 `18:00Z`、turn 8 `urgent-0327-B`（B-00003）、turn 8 `B-revert-…-9f8c490f`（B-00004，`n-q-20260309=15:10Z`） | vault turn-4 4 场 + `data/receipts-B.json`（试点 8+3+1+1+26） | 齐 |
| C | turn 6 `18:00Z`、turn 8 `handover-C-Q29`（C-00003，`16:15Z`） | vault turn-4 4 场 | 齐 |
| D | turn 6 `18:00Z`（**仍停在临时钟点**） | vault turn-4 4 场 | **缺 1 场** |

即：还原没有回滚订阅端，缺口只有上轮冻结遗留的那一笔（D 的 `s-q-20260309` 17:20Z）。

## 4. 解冻并补齐
- 未重发任何已收件项（A/B/C 全部零投递）；只发 D 的那一笔，用**原 key**、单项、单独一包：
  `publish("D", "handover-D-Q29", "out/plan-D.ics")` → **D-00003**，`s-q-20260309 = 2026-03-09T17:20:00Z`。
- 补齐后重算缺口：春季账 A/B/C/D 全 `to-send=0`；试点账 A、B `2026-03-06..2026-06-30` 全 `events=0`。
- 全量对账 `python3 scratch/verify-holdings.py`（应有 = 门户展开 + 春季版本 7 账本；实收 = 归档 ∪ 在线）：
  **不符项 0**；实收条目 A 38、B 38、C 4、D 4。
- `out/plan-B.ics`（`9f8c490f…`，B-revert 键）与 `out/plan-C.ics`（`37f7b5b9…`，handover-C-Q29 的内容）
  保持**当初投递的那份字节**，没有被今天的空缺口结果覆盖；当前缺口结果另存 `scratch/gap-*.ics`。

## 5. 交付：可冷启的备份
`python3 project/backup.py out/backup.sqlite`
```
source=data/portal.sqlite target=out/backup.sqlite integrity=ok events=28 bookings=12 series=2 adjustment=4
sha256=da4bc72266f2d787f51610cc07266ed94e802eb79ed6dde7b69fc6f93090dee5
handover: copy project/ and this file, then PORTAL_DB=<file>; receipts come from receipts(CHANNEL)
```
- 11 张表逐行与在线库相同（含 `service_import/history/row/prefix/account/class/day`）；
  `journal_mode=delete`、无 `-wal/-shm`、`integrity_check=ok`；在线库未被改动。
- 冷启验证（`scratch/cold/` 只有 `project/` + `backup.sqlite`，无 input/、data/、notes/、out/）：
  1. 门户 12 个 URL 与在线库逐字节一致（`/api/events`、`/`、q2 区间 `channel=B`、六条旧邀请链接、老/新前缀场次）；
     `/invite/K17-20260319` 仍为空 `<main></main>`（CH-51 把 03-20 场移到 03-19，UID 不按新日改名）。
  2. **历史版本**：`service.py view A 2 / A 7`、`view B 2`（`invite-b-31-*`）与 `view B 3`（`n-q-*`）都正确；
     `service.py history` 给出 1/2/3/6/7 五个版本与摘要。
  3. **计算差量**：同一份 turn-6 实收，`delta D 6` → 0 场（版本 6 就是 18:00Z）、`delta D 7` → 1 场 17:20Z；
     用完整实收 `delta D 7` → 空包。无需 `input/`。
  4. `prepare.py A 2026-04-01 2026-06-30` 在冷启实例产出 26 场，与 `out/new-A.ics` **逐字节相同**。
- 附带补齐的交付件（都由本产品现算，非拷归档）：`out/new-A.ics`、`out/q2-A.ics`、`out/q2-B.ics`，
  三份同一字节 `5fc0bbd8…`（26 场，K17 14:00Z / M42 15:00Z，全 CONFIRMED）；与旧归档同名件恰好逐字节相同（旁证）。

## 6. 测试
`test_adjust` 15、`test_backup` **10（首次全绿）**、`test_ch64` 10、`test_migrate` 14、`test_notify` 13、
`test_pages` 14、`test_portal` 11、`test_prepare` 8、`test_recover` 16、`test_service` 59、`test_support` 13 全过。
`test_q2` 10 项中仅剩 1 项：`test_quarter_file_differs_from_the_earlier_months` 需要
`out/pilot-A-20260306-20260327.ics`——**刻意不补**，理由见遗留 1。

## 7. 遗留
1. `out/pilot-A-20260306-20260327.ics` 未交付：现在用本产品重算三月试点包得到的是 `912330ff…`（8 场，
   已含 CH-51 移动、CH-53 加时、CH-64 只对 B 撤回、urgent-0327 加 90 分钟），与旧归档的 `a7abb944…`
   （更正前的合同钟点版）**不是同一份**；把归档件拷进 `out/` 等于拿旧试点归档当本产品交付，
   把重算件放进去又等于伪造历史交付物。这一件的归属需业务确认。
2. `data/receipt-cache.json` 仍是故障前镜像（缺 A-00003/B-00003/B-00004/C-00003/D-00003），按原样留作取证；
   本轮真实快照存 `scratch/receipts/live-<CH>.json`。
3. 试点账的实收证据只在归档 `data/receipts-{A,B}.json` 里（在线端只保留春季批次）；
   冷启交接时回执须由 `receipts(CHANNEL)` 重新取，归档件不能替代在线回执。
4. `handover-C-Q29`、`handover-D-Q29`、`urgent-0327-A/B`、`B-revert-…-9f8c490f` 均已消耗；
   同键同内容重试幂等，改内容必须换新键。
