"""Tests for the notification inquiry. Run: python3 project/test_inquiry.py"""
import io
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout

import service
import test_service

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VAULT = os.path.join(ROOT, "input", "vault")
WITHDRAWAL = {"7.json": dict(version=7, rows=[
    dict(id="W-264", target="T-260", day="2026-03-09", accounts=["B", "C", "D"])])}


def archive(channel):
    """The batch the channel signed for in the first spring send (turn 4)."""
    with open(os.path.join(VAULT, f"{channel}-closing-04.json"), encoding="utf-8") as handle:
        return json.load(handle)


def batch(turn, receipt, rows):
    return dict(turn=turn, receipt=receipt, rows=rows)


def row(uid, utc, status="CONFIRMED"):
    return dict(uid=uid, utc=utc, status=status)


def question(account="B", code="Q29", day="2026-03-09", **extra):
    found = dict(account=account, code=code, day=day)
    found.update(extra)
    return found


class Inquiry(unittest.TestCase):
    """A mailbox asks, item by item, what it was told and when."""

    def setUp(self):
        self.path, self.db = test_service.seeded()
        test_service.run_import(self.db, test_service.arrival())                        # 版本 2
        test_service.run_import(self.db, test_service.arrival(
            version=3, migration=test_service.release()))                               # 版本 3
        test_service.run_import(self.db, test_service.arrival(
            version=6, migration=test_service.release(),
            orders={"6.json": test_service.order()}))                                   # 版本 6
        test_service.run_import(self.db, test_service.arrival(
            version=7, migration=test_service.release(),
            orders={"6.json": test_service.order(), **WITHDRAWAL}))                     # 版本 7
        # 实收（归档 turn-4 + 在线 turn-6/8/9），与真实工位一致
        self.ledger = {channel: archive(channel) for channel in "ABCD"}
        for channel, uid in (("A", "invite-a-31-20260309"), ("B", "n-q-20260309"),
                             ("C", "invite-c-31-20260309"), ("D", "s-q-20260309")):
            self.ledger[channel].append(batch(6, f"{channel}-00002", {
                uid: row(uid, "2026-03-09T18:00:00Z")}))
        self.ledger["B"].append(batch(8, "B-00004", {
            "n-q-20260309": row("n-q-20260309", "2026-03-09T15:10:00Z")}))
        self.ledger["C"].append(batch(8, "C-00003", {
            "invite-c-31-20260309": row("invite-c-31-20260309", "2026-03-09T16:15:00Z")}))
        self.ledger["D"].append(batch(9, "D-00003", {
            "s-q-20260309": row("s-q-20260309", "2026-03-09T17:20:00Z")}))

    def tearDown(self):
        self.db.close()

    def ask(self, *questions, ledger=None):
        return service.inquiry(self.db, list(questions), ledger or self.ledger)

    def test_one_moved_invitation_across_the_whole_trajectory(self):
        answers = self.ask(*[question(asof=asof) for asof in (4, 6, 7, 8, 9)])
        self.assertEqual([answer["due"] for answer in answers],
                         ["2026-03-09T15:10:00+00:00",      # 合同钟点
                          "2026-03-09T18:00:00+00:00",      # T-260 临时钟点
                          "2026-03-09T15:10:00+00:00",      # W-264 撤回，B 被点名
                          "2026-03-09T15:10:00+00:00",
                          "2026-03-09T15:10:00+00:00"])
        self.assertEqual([answer["received"] for answer in answers],
                         ["2026-03-09T15:10:00Z", "2026-03-09T18:00:00Z",
                          "2026-03-09T18:00:00Z", "2026-03-09T15:10:00Z",
                          "2026-03-09T15:10:00Z"])
        self.assertEqual([answer["pending"] for answer in answers],
                         [False, False, True, False, False])

    def test_the_uid_survives_every_clock_change(self):
        answers = self.ask(*[question(asof=asof) for asof in (4, 6, 7, 9)])
        self.assertEqual({answer["uid"] for answer in answers}, {"n-q-20260309"})

    def test_a_batch_that_arrived_later_is_invisible(self):
        without = self.ask(question(asof=7))
        with_late = self.ask(question(asof=8))
        self.assertTrue(without[0]["pending"])
        self.assertFalse(with_late[0]["pending"])
        self.assertEqual(without[0]["received"], "2026-03-09T18:00:00Z")
        self.assertEqual(with_late[0]["received"], "2026-03-09T15:10:00Z")

    def test_an_untouched_class_is_settled_at_every_moment(self):
        answers = self.ask(*[question(code="N84", asof=asof) for asof in (4, 6, 7, 8, 9)])
        self.assertEqual({answer["pending"] for answer in answers}, {False})
        self.assertEqual({answer["due"] for answer in answers}, {"2026-03-09T13:45:00+00:00"})

    def test_the_unnamed_account_keeps_the_temporary_clock(self):
        answers = self.ask(question(account="A", asof=7), question(account="A", asof=9))
        self.assertEqual([answer["due"] for answer in answers],
                         ["2026-03-09T18:00:00+00:00"] * 2)
        self.assertEqual([answer["pending"] for answer in answers], [False, False])
        self.assertEqual(answers[0]["uid"], "invite-a-31-20260309")     # 保号那一代

    def test_a_mailbox_still_on_the_old_clock_is_pending(self):
        answers = self.ask(question(account="D", asof=8), ledger={"D": archive("D")})
        self.assertEqual(answers[0]["due"], "2026-03-09T17:20:00+00:00")
        self.assertEqual(answers[0]["received"], "2026-03-09T17:20:00Z")
        self.assertFalse(answers[0]["pending"])          # 归档 turn-4 就是合同钟点

    def test_no_signature_reads_as_null_and_pending(self):
        answer = self.ask(question(account="D", asof=7), ledger={"D": []})[0]
        self.assertIsNone(answer["received"])
        self.assertTrue(answer["pending"])
        self.assertEqual(answer["due"], "2026-03-09T17:20:00+00:00")

    def test_a_mailbox_with_no_ledger_entry_has_signed_nothing(self):
        answer = self.ask(question(account="C", asof=7), ledger={"A": archive("A")})[0]
        self.assertIsNone(answer["received"])
        self.assertTrue(answer["pending"])

    def test_the_answer_keeps_the_query_keys_and_their_order(self):
        asked = [question(account="D", asof=9), question(account="A", asof=4), question(account="C")]
        asked[0]["note"] = "客户来函第 3 条"
        answers = self.ask(*asked)
        self.assertEqual([(answer["account"], answer["asof"]) for answer in answers],
                         [("D", 9), ("A", 4), ("C", None)])
        self.assertEqual(answers[0]["note"], "客户来函第 3 条")
        self.assertEqual(set(answers[0]), {"account", "code", "day", "asof", "note",
                                          "uid", "due", "received", "pending"})

    def test_batches_are_applied_in_turn_order_whatever_the_file_order(self):
        shuffled = dict(self.ledger)
        shuffled["B"] = list(reversed(self.ledger["B"]))
        self.assertEqual(self.ask(question(asof=8), ledger=shuffled),
                         self.ask(question(asof=8)))

    def test_the_same_turn_is_broken_by_receipt(self):
        ledger = {"B": archive("B")[:] + [
            batch(8, "B-00004", {"n-q-20260309": row("n-q-20260309", "2026-03-09T18:00:00Z")}),
            batch(8, "B-00009", {"n-q-20260309": row("n-q-20260309", "2026-03-09T15:10:00Z")})]}
        answer = self.ask(question(asof=8), ledger=ledger)[0]
        self.assertEqual(answer["received"], "2026-03-09T15:10:00Z")     # B-00009 号更大, 后到
        self.assertFalse(answer["pending"])

    def test_a_cancelled_signature_still_reads_as_the_time_held(self):
        ledger = {"B": [batch(6, "B-00002", {
            "n-q-20260309": row("n-q-20260309", "2026-03-09T18:00:00Z", "CANCELLED")})]}
        answer = self.ask(question(asof=6), ledger=ledger)[0]
        self.assertEqual(answer["received"], "2026-03-09T18:00:00Z")
        self.assertFalse(answer["pending"])            # 工单口径: pending 只比时刻


class CommandLine(unittest.TestCase):
    def setUp(self):
        self.path, self.db = test_service.seeded()
        test_service.run_import(self.db, test_service.arrival(
            version=3, migration=test_service.release()))
        self.db.close()
        self.dir = tempfile.mkdtemp()
        self.questions = os.path.join(self.dir, "questions.json")
        with open(self.questions, "w", encoding="utf-8") as handle:
            json.dump([question(account="A", asof=4), question(account="B", asof=4)], handle)
        self.ledger = os.path.join(self.dir, "ledger.json")
        with open(self.ledger, "w", encoding="utf-8") as handle:
            json.dump({channel: archive(channel) for channel in "ABCD"}, handle)
        self.out = os.path.join(self.dir, "inquiry.json")

    def run_cli(self, *args):
        env = dict(os.environ, PORTAL_DB=self.path)
        return subprocess.run([sys.executable, "project/service.py", *args],
                              cwd=ROOT, env=env, capture_output=True, text=True)

    def test_the_file_is_written_and_the_run_repeats(self):
        first = self.run_cli("history", self.questions, self.ledger, self.out)
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertIn("questions=2", first.stdout)
        self.assertIn("pending=0", first.stdout)
        with open(self.out, "rb") as handle:
            once = handle.read()
        again = self.run_cli("history", self.questions, self.ledger, self.out)
        self.assertEqual(again.returncode, 0, again.stderr)
        with open(self.out, "rb") as handle:
            self.assertEqual(handle.read(), once)
        answers = json.loads(once)
        self.assertEqual([answer["uid"] for answer in answers],
                         ["invite-a-31-20260309", "n-q-20260309"])
        self.assertEqual([answer["received"] for answer in answers],
                         ["2026-03-09T14:05:00Z", "2026-03-09T15:10:00Z"])

    def test_a_missing_piece_is_refused(self):
        done = self.run_cli("history", os.path.join(self.dir, "nope.json"), self.ledger, self.out)
        self.assertEqual(done.returncode, 2)
        self.assertIn("service failed", done.stderr)

    def test_the_database_is_not_written(self):
        before = test_service.dump(self.path)
        self.run_cli("history", self.questions, self.ledger, self.out)
        self.assertEqual(test_service.dump(self.path), before)


class Refusals(unittest.TestCase):
    def setUp(self):
        self.path, self.db = test_service.seeded()

    def tearDown(self):
        self.db.close()

    def assert_refused(self, questions, ledger, fragment):
        with self.assertRaises(ValueError) as caught:
            service.inquiry(self.db, questions, ledger)
        self.assertIn(fragment, str(caught.exception))

    def test_no_questions(self):
        self.assert_refused([], {}, "non-empty")

    def test_a_question_without_its_keys(self):
        self.assert_refused([{"account": "A", "code": "Q29"}], {}, "lacks")

    def test_a_ledger_that_is_not_mailboxes(self):
        self.assert_refused([question(asof=4)], [], "ledger must map mailbox")

    def test_a_mailbox_entry_that_is_not_an_array(self):
        self.assert_refused([question(asof=4)], {"B": {"turn": 4}}, "not an array of batches")

    def test_an_unreadable_asof(self):
        self.assert_refused([question(asof="last tuesday")], {}, "ASOF must be")


if __name__ == "__main__":
    unittest.main(verbosity=2)
