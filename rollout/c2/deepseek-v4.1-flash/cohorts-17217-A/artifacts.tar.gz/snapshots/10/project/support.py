"""Answer a batch of support questions from the book, read-only.

python3 project/support.py QUESTIONS OUTPUT [--tz Europe/London]

QUESTIONS is a JSON array of questions that keep their own key names -- this
round each one is {account, code, day, asof}, an invitation as of a logical
version.  OUTPUT gets one answer per question, in the same order: the
question's keys are copied over untouched and `uid` plus `local` are added,
where `local` is the invitation's label in the support timezone as
`YYYY-MM-DD HH:MM`.

The database is opened read-only: a preview only answers.  It never registers
an arrival, never writes a row and never publishes.  A question the book cannot
answer at that version is refused by name instead of being dropped, so a
customer-service answer can never quietly go missing.
"""
import argparse
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import portal
import service

SUPPORT_ZONE = "Europe/London"
QUESTION_FIELDS = ("account", "code", "day", "asof")


def connect(path=None):
    """A read-only handle on the book; sqlite refuses any write through it."""
    path = os.path.abspath(path or os.getenv("PORTAL_DB", "data/portal.sqlite"))
    return sqlite3.connect(f"file:{path}?mode=ro", uri=True)


def read_questions(path):
    with open(path, encoding="utf-8") as handle:
        questions = json.load(handle)
    if not isinstance(questions, list) or not questions:
        raise ValueError(f"{path} holds no questions")
    return questions


def answer(db, question, zone=SUPPORT_ZONE):
    """One question -> its own keys plus uid and local; never a silent blank."""
    missing = [field for field in QUESTION_FIELDS if field not in question]
    if missing:
        raise ValueError(f"support question is missing {missing}: {question!r}")
    account, code = str(question["account"]), str(question["code"])
    day = str(question["day"])
    version = service.as_version(db, question["asof"])
    rows = [row for row in service.rows_as_of(db, account, version)
            if row["code"] == code and row["day"] == day]
    if not rows:
        raise ValueError(f"{account} has no {code} on {day} at logical version {version}")
    row = rows[-1]
    out = dict(question)                       # 保留查询键
    out["uid"] = row["uid"]
    out["local"] = portal.local_label(row["utc"], zone)
    return out


def preview(db, questions, zone=SUPPORT_ZONE):
    return [answer(db, question, zone) for question in questions]


def main(argv=None):
    parser = argparse.ArgumentParser(description="Read-only support preview.")
    parser.add_argument("questions")
    parser.add_argument("output")
    parser.add_argument("--tz", default=SUPPORT_ZONE)
    args = parser.parse_args(argv)
    db = connect()
    try:
        answers = preview(db, read_questions(args.questions), args.tz)
    except ValueError as problem:
        print(f"preview failed: {problem}", file=sys.stderr)
        return 2
    finally:
        db.close()
    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(answers, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    for row in answers:
        print(f'{row["account"]} {row["code"]} {row["day"]} asof={row["asof"]}'
              f' uid={row["uid"]} local={row["local"]} ({args.tz})')
    return 0


if __name__ == "__main__":
    sys.exit(main())
