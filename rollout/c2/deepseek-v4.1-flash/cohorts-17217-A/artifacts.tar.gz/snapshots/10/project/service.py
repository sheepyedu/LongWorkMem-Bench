"""Spring course intake and lookups for the four customer mailboxes.

python3 project/service.py import DIR

    Register DIR/schedule.json, DIR/roster.json and whatever has arrived as
    DIR/migration.json and DIR/orders/*.json into $PORTAL_DB (default
    data/portal.sqlite).  Re-sending the same arrival changes nothing; an
    arrival carries a logical version (DIR/version.txt) and an older version
    never rewrites newer history.  Attachment paths are relative to DIR, and
    only the annex the schedule points at is used -- and only when its number
    matches.  Q29 takes each account's UTC clock from that annex; N84 uses the
    venue wall clock.  Rows are mirrored into the portal's own events and
    bookings, so the old invite links and listings keep working; the pilot and
    earlier bookings are never removed.

python3 project/service.py view ACCOUNT [ASOF]

    Print every business row of ACCOUNT as a JSON array, as of logical version
    ASOF (default: latest; an ISO business day is accepted and means "the last
    version imported on or before that day").  A row is account, code, day,
    booking, uid, utc: `day` is the 原定业务日, `utc` carries an explicit
    offset, and UID = prefix-YYYYMMDD.  A booking starts out under its
    old_prefix; once the identity release in DIR/migration.json applies (from
    the logical `version` it names), each registration compares its own `joined`
    instant with the release `cutover`: strictly earlier keeps the old prefix
    for life, everything else takes the prefix of its business channel and
    class.  Both generations therefore work side by side in one channel, and an
    invitation or booking already handed out is never renamed under a client --
    the new prefix is a new UID, the old one stays readable.

python3 project/service.py delta ACCOUNT ASOF RECEIPTS_JSON OUTPUT

    What ACCOUNT should hold at logical version ASOF and does not: the batches in
    RECEIPTS_JSON (a channel's receipt history, a JSON array of {turn, receipt,
    rows}) are applied in (turn, receipt) order to get what the channel really
    signed for, and the book at ASOF is differenced against it.  OUTPUT gets a
    self-contained CONFIRMED ICS holding only the invitations that are missing or
    that the channel holds at another instant or status -- a package with no
    VEVENT is legal and means "nothing to send".  Writing a package is not
    publishing: nothing here talks to the subscription service.

python3 project/service.py history QUESTIONS_JSON LEDGER_JSON OUTPUT

    Trace earlier notifications, one question at a time.  QUESTIONS_JSON is a
    JSON array of {account, code, day, asof} (any further keys are carried
    through untouched).  LEDGER_JSON maps each mailbox to its batches -- the
    receipt arrays of the subscription service, archived and online together --
    and those batches are merged in (turn, receipt) order, counting only the
    ones up to the question's ASOF (ASOF defaults to the latest version, as in
    `view`; a delivery turn and a logical version are different counters, so
    ASOF bounds the batches by turn and resolves the book to the newest version
    at or before that number).  OUTPUT is a JSON array in question order
    holding the query keys plus uid, due, received and pending: `due` is what
    the book authorised at ASOF (so a temporary order or its withdrawal is
    reported as it stood then), `received` is what the mailbox had actually
    signed for by then (null when there is no signature under that UID), and
    `pending` is true when the two instants differ -- including a missing
    signature.  The run is read-only and repeatable: same questions and same
    ledger give the same bytes.

view, delta and history read only the database and their explicit arguments.
"""
import argparse
import hashlib
import json
import os
import re
import sqlite3
import sys
from datetime import date, datetime, time, timezone
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import portal

BASIS_ANNEX = "signed-annex"      # the signed attachment dictates the clock
BASIS_WALL = "wall"               # the venue wall clock dictates the instant
SIGNED = ("signed", "active", "effective")

CLASS_COLUMNS = ("code", "basis", "zone", "clock", "ref", "approval", "rank", "version", "imported")
ACCOUNT_COLUMNS = ("account", "code", "channel", "joined", "old_prefix", "booking", "rank",
                   "prefix", "generation", "version", "imported")
DAY_COLUMNS = ("day", "rank", "version", "imported")
ROW_FIELDS = ("booking", "uid", "utc", "rank")          # what identifies a row's content
HISTORY_COLUMNS = ("account", "code", "day", "booking", "uid", "utc", "rank", "version", "imported")


# --------------------------------------------------------------------------- #
# storage
# --------------------------------------------------------------------------- #
def ensure(db):
    """Portal schema plus the service tables; safe to run on an existing database."""
    portal.ensure_schema(db)
    db.execute("""create table if not exists service_class(
        code text primary key, basis text not null, zone text, clock text,
        ref text, approval text, rank integer not null default 0,
        version integer not null, imported text)""")
    db.execute("""create table if not exists service_account(
        account text not null, code text not null, channel text, joined text,
        old_prefix text not null, booking text not null, rank integer not null default 0,
        version integer not null, imported text,
        prefix text, generation text, primary key(account, code))""")
    present = {row[1] for row in db.execute("pragma table_info(service_account)")}
    for column in ("prefix", "generation"):        # databases created before the identity release
        if column not in present:
            db.execute(f"alter table service_account add column {column} text")
    db.execute("""create table if not exists service_day(
        day text primary key, rank integer not null default 0,
        version integer not null, imported text)""")
    db.execute("""create table if not exists service_row(
        account text not null, code text not null, day text not null,
        booking text not null, uid text not null, utc text not null,
        rank integer not null default 0, version integer not null, imported text,
        primary key(account, code, day))""")
    db.execute("""create table if not exists service_history(
        account text not null, code text not null, day text not null,
        booking text not null, uid text not null, utc text not null,
        rank integer not null default 0, version integer not null, imported text,
        primary key(account, code, day, version))""")
    db.execute("""create table if not exists service_import(
        version integer primary key, digest text not null, source text, imported text)""")
    db.execute("""create table if not exists service_prefix(
        prefix text primary key, code text not null)""")
    return db


def store_meta(db, table, key_columns, wanted, value_columns, version, imported):
    """Insert or update one metadata row; -> added / changed / unchanged."""
    key = tuple(wanted[column] for column in key_columns)
    where = " and ".join(f"{column}=?" for column in key_columns)
    current = db.execute("select " + ",".join(value_columns) + f" from {table} where {where}",
                         key).fetchone()
    values = tuple(wanted[column] for column in value_columns)
    if current is not None and tuple(current) == values:
        return "unchanged"
    if current is None:
        db.execute(f"insert into {table}(" + ",".join(key_columns + value_columns + ("version", "imported"))
                   + ") values(" + ",".join("?" * (len(key_columns) + len(value_columns) + 2)) + ")",
                   key + values + (version, imported))
        return "added"
    db.execute(f"update {table} set " + ",".join(f"{column}=?" for column in value_columns + ("version", "imported"))
               + f" where {where}", values + (version, imported) + key)
    return "changed"


def store_row(db, row, version, imported):
    """Upsert one business row and keep the per-version history; -> action."""
    key = (row["account"], row["code"], row["day"])
    content = tuple(row[field] for field in ROW_FIELDS)
    current = db.execute("select " + ",".join(ROW_FIELDS) + ",version from service_row"
                         " where account=? and code=? and day=?", key).fetchone()
    if current is not None and tuple(current[:-1]) == content:
        db.execute("insert or ignore into service_history(" + ",".join(HISTORY_COLUMNS) + ") values("
                   + ",".join("?" * len(HISTORY_COLUMNS)) + ")",
                   key + content + (current[-1], imported))
        return "unchanged"
    if current is None:
        db.execute("insert into service_row(account,code,day," + ",".join(ROW_FIELDS) + ",version,imported)"
                   " values(?,?,?," + ",".join("?" * (len(ROW_FIELDS) + 2)) + ")",
                   key + content + (version, imported))
        action = "added"
    else:
        db.execute("update service_row set " + ",".join(f"{field}=?" for field in ROW_FIELDS)
                   + ",version=?,imported=? where account=? and code=? and day=?",
                   content + (version, imported) + key)
        action = "changed"
    db.execute("insert or replace into service_history(" + ",".join(HISTORY_COLUMNS) + ") values("
               + ",".join("?" * len(HISTORY_COLUMNS)) + ")",
               key + content + (version, imported))
    return action


def mirror(db, rows, imported):
    """Keep the portal's own events/bookings in step; never drop an old identity."""
    seen = {}
    for row in sorted(rows, key=lambda item: item["day"]):
        starts = datetime.fromisoformat(row["utc"]).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        current = db.execute("select starts from events where uid=?", (row["uid"],)).fetchone()
        if current is None:
            db.execute("insert into events(uid, starts) values(?,?)", (row["uid"], starts))
        elif current[0] != starts:
            db.execute("update events set starts=? where uid=?", (starts, row["uid"]))
        seen.setdefault(row["booking"], row["uid"])
    for booking, uid in seen.items():               # a booking keeps its first occurrence UID
        if db.execute("select 1 from bookings where id=?", (booking,)).fetchone() is None:
            db.execute("insert into bookings(id, uid) values(?,?)", (booking, uid))


# --------------------------------------------------------------------------- #
# reading the arrival
# --------------------------------------------------------------------------- #
def load_json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def read_text(path):
    with open(path, encoding="utf-8") as handle:
        return handle.read().strip()


def clock_value(text, where):
    parts = str(text).split(":")
    if len(parts) != 2 or not all(part.isdigit() for part in parts):
        raise ValueError(f"{where} has no HH:MM clock: {text!r}")
    hour, minute = int(parts[0]), int(parts[1])
    if not (0 <= hour < 24 and 0 <= minute < 60):
        raise ValueError(f"{where} has an impossible clock: {text!r}")
    return time(hour, minute)


def signed(document, where):
    status = str(document.get("status", "")).lower()
    if status not in SIGNED:
        raise ValueError(f"{where} is {status or 'unsigned'}, not signed")
    return document


def annex_clocks(directory, code, spec, accounts):
    """The clocks of the signed annex the schedule points at; nothing else counts."""
    ref, approval = spec.get("ref"), spec.get("approval")
    if not ref or not approval:
        raise ValueError(f"class {code} is {BASIS_ANNEX} but names no ref/approval")
    path = os.path.join(directory, ref)
    if not os.path.isfile(path):
        raise ValueError(f"class {code} points at {ref}, which is not in {directory}")
    document = signed(load_json(path), f"annex {ref}")
    if document.get("id") != approval:
        raise ValueError(f"class {code} needs annex {approval}, but {ref} is {document.get('id')!r}")
    clocks = document.get("utc_by_account") or {}
    missing = [account for account in accounts if account not in clocks]
    if missing:
        raise ValueError(f"annex {approval} gives no UTC clock for {missing}")
    return {account: clock_value(clocks[account], f"annex {approval} / {account}")
            for account in accounts}


def instant(text, where):
    """An absolute moment; a value without an offset is refused, not guessed at."""
    try:
        moment = datetime.fromisoformat(str(text).strip())
    except (TypeError, ValueError):
        raise ValueError(f"{where} is not an ISO instant: {text!r}")
    if moment.tzinfo is None:
        raise ValueError(f"{where} carries no UTC offset, so its order is unknown: {text!r}")
    return moment.astimezone(timezone.utc)


def identity_release(directory, files):
    """Optional migration.json: the release that renames UID prefixes.

    `version` is the logical version the new identifiers start with, `cutover`
    the absolute instant that splits the registrations, and `prefixes` the
    prefix per business channel and class.  Comparing joined with cutover is a
    comparison of instants, not of the local clock a client happened to write
    down: 2026-01-31T18:59:59-05:00 is before 2026-02-01T00:00:00Z while
    2026-02-01T01:00:00+01:00 is exactly on it.
    """
    path = os.path.join(directory, "migration.json")
    if not os.path.isfile(path):
        return None
    files.append("migration.json")
    document = load_json(path)
    version = document.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise ValueError(f"migration.json names no logical version: {version!r}")
    cutover = instant(document.get("cutover"), "migration.json cutover")
    table = document.get("prefixes")
    if not isinstance(table, dict) or not table:
        raise ValueError("migration.json names no prefixes")
    prefixes = {}
    for channel, by_code in table.items():
        if not isinstance(by_code, dict) or not by_code:
            raise ValueError(f"migration.json names no prefix for channel {channel!r}")
        for code, prefix in by_code.items():
            prefix = str(prefix or "").strip()
            if not prefix:
                raise ValueError(f"migration.json has no usable prefix for {channel}/{code}")
            prefixes[(str(channel), str(code))] = prefix
    if len(set(prefixes.values())) != len(prefixes):
        raise ValueError("migration.json reuses one prefix for different channels/classes")
    return dict(version=version, cutover=cutover, prefixes=prefixes)


def order_changes(directory, classes, accounts_by_code, files, declared=None, days=()):
    """Optional orders/*.json: temporary absolute clocks, and their withdrawals.

    An *activation* row names a class, a 原定日, the accounts it applies to and the
    UTC clock that day is to be held at instead.  It is an instruction about a
    *scheduled* day, so an unknown day is refused rather than invented, and only
    the named accounts change: the other accounts, the other days and the other
    classes keep their annex / venue clock.

    A *withdrawal* row names no clock but a `target`: for the listed accounts on
    that day the named activation is taken back, so those invitations fall back
    to the contract clock that was never withdrawn.  Accounts the committee did
    not name keep the temporary clock.

    Rows are applied in (version, file name) order, so the newest issuance wins
    and a replayed arrival reaches the same state.  A document may carry
    `status`; if it does, it must be signed.

    -> (changes, withdrawn): changes maps (account, code, day) to (time, order id),
    withdrawn maps (account, code, day) to the order id that was taken back.
    """
    folder = os.path.join(directory, "orders")
    if not os.path.isdir(folder):
        return {}, {}
    wanted = {day for day in days}
    by_code = {code: [entry["account"] for entry in entries]
               for code, entries in accounts_by_code.items()}
    changes, withdrawn = {}, {}
    for name in sorted(os.listdir(folder)):
        if not name.endswith(".json"):
            continue
        rel = f"orders/{name}"
        files.append(rel)
        document = load_json(os.path.join(folder, name))
        issued = document.get("version")
        if issued is not None:
            if not isinstance(issued, int) or isinstance(issued, bool) or issued < 1:
                raise ValueError(f"{rel} names no logical version: {issued!r}")
            if declared is not None and issued > declared:
                raise ValueError(f"{rel} is issued for logical version {issued}, but this arrival"
                                 f" declares {declared}")
        status = document.get("status")
        if status is not None:
            signed(document, rel)
        rows = document.get("rows")
        if not isinstance(rows, list) or not rows:
            raise ValueError(f"{rel} names no rows")
        for row in rows:
            code = row.get("code")
            target = row.get("target")
            if code is not None and code not in classes and not target:
                raise ValueError(f"{rel} names class {code!r}, which the schedule does not have")
            written = row.get("days") or ([row["day"]] if row.get("day") else [])
            if not written:
                raise ValueError(f"{rel} names no day")
            accounts = row.get("accounts")
            if accounts is None:
                if target:
                    raise ValueError(f"{rel} withdraws {target} without saying whose it is")
                accounts = by_code.get(code, [])
            accounts = [str(account).strip() for account in accounts]
            order_id = str(row.get("id") or name)
            for day_text in written:
                try:
                    day = date.fromisoformat(str(day_text))
                except (TypeError, ValueError):
                    raise ValueError(f"{rel} names a day that is not a date: {day_text!r}")
                if day not in wanted:
                    raise ValueError(f"{rel} names {day}, which the schedule does not have")
                if target:                                  # 撤回
                    taken = [key for key, (_, made_by) in changes.items()
                             if made_by == str(target) and key[2] == day
                             and key[0] in accounts and (code is None or key[1] == code)]
                    if not taken:
                        raise ValueError(f"{rel} withdraws {target} for {accounts} on {day},"
                                         f" but nothing by that name is in force there")
                    for key in taken:
                        del changes[key]
                        withdrawn[key] = str(target)
                    continue
                unknown = [account for account in accounts
                           if account not in by_code.get(code, [])]
                if unknown:
                    raise ValueError(f"{rel} names {unknown}, who have no {code} registration")
                per_account = row.get("utc_by_account") or {}
                written_clock = row.get("utc_clock") or row.get("clock")
                for account in accounts:
                    raw = per_account.get(account, written_clock)
                    if not raw:
                        raise ValueError(f"{rel} gives no clock for {account} / {code} / {day}")
                    changes[(account, code, day)] = (clock_value(raw, f"{rel} / {account}"),
                                                     order_id)
                    withdrawn.pop((account, code, day), None)
    return changes, withdrawn


def business_day(directory):
    path = os.path.join(directory, "clock.txt")
    return read_text(path) if os.path.isfile(path) else ""


def declared_version(directory):
    path = os.path.join(directory, "version.txt")
    if not os.path.isfile(path):
        return None
    raw = read_text(path)
    if not raw.isdigit():
        raise ValueError(f"version.txt is not a logical version number: {raw!r}")
    return int(raw)


def make_row(registration, cls, day, prefix, utc_clock=None, order=None, reverted=None):
    """One business row; `utc_clock` is an issued absolute clock for that day."""
    if utc_clock is not None:
        moment = datetime.combine(day, utc_clock, tzinfo=timezone.utc)
    elif cls["basis"] == BASIS_ANNEX:
        moment = datetime.combine(day, cls["clocks"][registration["account"]], tzinfo=timezone.utc)
    else:
        moment = datetime.combine(day, cls["clock_time"],
                                  tzinfo=cls["zoneinfo"]).astimezone(timezone.utc)
    return dict(account=registration["account"], code=registration["code"], day=day.isoformat(),
                booking=registration["booking"], uid=f'{prefix}-{day:%Y%m%d}',
                utc=moment.isoformat(), rank=registration["rank"], order=order,
                reverted=reverted)


def heritage_rows(db, plan):
    """Business rows that were already in the portal before any service intake.

    The roster's old_prefix is what the earlier invitations were filed under, so
    a stored event whose UID is `<old_prefix>-YYYYMMDD` is that registration's
    row.  They become the baseline history (never rewritten by a later version).
    """
    by_prefix = {entry["old_prefix"]: entry for entry in plan["registrations"]}
    rows = []
    for uid, starts in db.execute("select uid, starts from events order by uid"):
        prefix, _, tail = uid.rpartition("-")
        registration = by_prefix.get(prefix)
        if registration is None or len(tail) != 8 or not tail.isdigit():
            continue
        try:
            day = date(int(tail[:4]), int(tail[4:6]), int(tail[6:]))
        except ValueError:
            continue
        moment = datetime.fromisoformat(starts)
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
        rows.append(dict(account=registration["account"], code=registration["code"],
                         day=day.isoformat(), booking=registration["booking"], uid=uid,
                         utc=moment.astimezone(timezone.utc).isoformat(),
                         rank=registration["rank"]))
    return rows


def build_plan(directory):
    """Read and validate one arrival; nothing is written here."""
    if not os.path.isdir(directory):
        raise ValueError(f"no arrival directory at {directory}")
    schedule_path = os.path.join(directory, "schedule.json")
    roster_path = os.path.join(directory, "roster.json")
    if not os.path.isfile(schedule_path) or not os.path.isfile(roster_path):
        raise ValueError(f"{directory} needs schedule.json and roster.json")
    schedule, roster = load_json(schedule_path), load_json(roster_path)
    files = ["schedule.json", "roster.json"]

    spec_classes = schedule.get("classes")
    if not isinstance(spec_classes, dict) or not spec_classes:
        raise ValueError("schedule.json names no classes")
    raw_days = schedule.get("days")
    if not isinstance(raw_days, list) or not raw_days:
        raise ValueError("schedule.json names no days")
    days, seen = [], set()
    for written in raw_days:
        try:
            day = date.fromisoformat(written)
        except (TypeError, ValueError):
            raise ValueError(f"schedule day is not a date: {written!r}")
        if day not in seen:
            seen.add(day)
            days.append(day)

    if not isinstance(roster, list) or not roster:
        raise ValueError("roster.json names no registrations")
    accounts_by_code = {}
    for entry in roster:
        code = entry.get("code")
        if code not in spec_classes:
            raise ValueError(f"roster names class {code!r}, schedule has {sorted(spec_classes)}")
        accounts_by_code.setdefault(code, []).append(entry)

    classes = {}
    for rank, (code, spec) in enumerate(spec_classes.items()):
        basis = spec.get("basis")
        item = dict(code=code, basis=basis, zone=None, clock=None, ref=None, approval=None, rank=rank)
        if basis == BASIS_ANNEX:
            accounts = [entry["account"] for entry in accounts_by_code.get(code, [])]
            item["clocks"] = annex_clocks(directory, code, spec, accounts)
            item["ref"], item["approval"] = spec.get("ref"), spec.get("approval")
            files.append(spec["ref"])
        elif basis == BASIS_WALL:
            zone_name, written = spec.get("zone"), spec.get("clock")
            if not zone_name or not written:
                raise ValueError(f"class {code} is {BASIS_WALL} but names no zone/clock")
            try:
                item["zoneinfo"] = ZoneInfo(zone_name)
            except KeyError:
                raise ValueError(f"class {code} names an unknown zone {zone_name!r}")
            item["zone"], item["clock"] = zone_name, written
            item["clock_time"] = clock_value(written, f"class {code}")
        else:
            raise ValueError(f"class {code} has an unknown basis {basis!r}")
        classes[code] = item

    release = identity_release(directory, files)
    declared = declared_version(directory)
    if release is not None:
        if declared is None:
            raise ValueError("migration.json needs version.txt to say which release this arrival is")
        if declared < release["version"]:
            raise ValueError(f"migration.json applies from logical version {release['version']},"
                             f" but version.txt says {declared}")

    registrations, pairs, bookings = [], set(), set()
    for entry in roster:
        account = str(entry.get("account") or "").strip()
        code = entry.get("code")
        booking = str(entry.get("booking") or "").strip()
        old_prefix = str(entry.get("old_prefix") or "").strip()
        channel = str(entry.get("channel") or "").strip()
        if not account or not booking or not old_prefix:
            raise ValueError(f"roster entry {entry!r} needs account, booking and old_prefix")
        if (account, code) in pairs:
            raise ValueError(f"roster registers {account} for {code} twice")
        if booking in bookings:
            raise ValueError(f"roster uses booking {booking} twice")
        pairs.add((account, code))
        bookings.add(booking)
        prefix, generation = old_prefix, "old"
        if release is not None:
            joined = instant(entry.get("joined"), f"roster {account}/{code} joined")
            if joined >= release["cutover"]:
                wanted = (channel, str(code))
                if wanted not in release["prefixes"]:
                    raise ValueError(
                        f"roster {account}/{code} joined at {joined.isoformat()}, not before the"
                        f" {release['cutover'].isoformat()} cutover, but migration.json has no prefix"
                        f" for channel {channel!r} / class {code}")
                prefix, generation = release["prefixes"][wanted], "new"
        registrations.append(dict(account=account, code=code, channel=channel or None,
                                  joined=entry.get("joined"), old_prefix=old_prefix,
                                  booking=booking, rank=classes[code]["rank"],
                                  prefix=prefix, generation=generation))

    changes, withdrawn = order_changes(directory, classes, accounts_by_code, files,
                                      declared, days)

    rows, uids = [], set()
    for registration in registrations:
        cls = classes[registration["code"]]
        prefix = registration["prefix"]
        for day in days:
            key = (registration["account"], registration["code"], day)
            clock, order_id = changes.get(key, (None, None))
            rows.append(make_row(registration, cls, day, prefix, clock, order_id,
                                 withdrawn.get(key)))
    for row in rows:
        if row["uid"] in uids:
            raise ValueError(f"two business rows share the UID {row['uid']}")
        uids.add(row["uid"])

    prefixes = {}
    for registration in registrations:      # both generations of a UID count as that class
        for prefix in (registration["old_prefix"], registration["prefix"]):
            known = prefixes.setdefault(prefix, registration["code"])
            if known != registration["code"]:
                raise ValueError(f"UID prefix {prefix!r} is used for both {known} and"
                                 f" {registration['code']}")

    digest = hashlib.sha256()
    for rel in sorted(set(files)):
        digest.update(rel.encode())
        digest.update(b"\0")
        with open(os.path.join(directory, rel), "rb") as handle:
            digest.update(handle.read())
        digest.update(b"\0")
    return dict(directory=os.path.abspath(directory), classes=[classes[c] for c in spec_classes],
                registrations=registrations, days=days, rows=rows, release=release,
                prefixes=prefixes, withdrawn=withdrawn,
                version=declared, digest=digest.hexdigest(),
                business_day=business_day(directory))


# --------------------------------------------------------------------------- #
# import
# --------------------------------------------------------------------------- #
def do_import(db, directory):
    plan = build_plan(directory)                      # every check happens before any write
    imported = plan["business_day"]
    known = {digest: version for version, digest in
             db.execute("select version,digest from service_import").fetchall()}
    latest = max(known.values(), default=0)
    if plan["digest"] in known:
        print(f'unchanged: this arrival is already registered as version {known[plan["digest"]]}'
              f' digest={plan["digest"][:8]}')
        return 0
    declared = plan["version"]
    if declared is not None and declared < latest:
        print(f'stale arrival: logical version {declared} is older than {latest}; ignored'
              f' digest={plan["digest"][:8]}')
        return 0
    if declared is not None and declared <= latest:
        raise ValueError(f'logical version {declared} is already registered with different content;'
                         f' bump version.txt instead of rewriting history')
    version = declared if declared is not None else latest + 1

    actions = {"added": 0, "changed": 0, "unchanged": 0}
    baseline = 1 if version > 1 else 0
    try:
        if not db.execute("select count(*) from service_history").fetchone()[0]:
            heritage = heritage_rows(db, plan)
            for row in heritage:                    # registrations that predate the intake
                store_row(db, row, baseline, imported)
            if heritage:
                db.execute("insert or ignore into service_import(version,digest,source,imported)"
                           " values(?,?,?,?)", (baseline, "baseline", "portal", imported))
                print(f'baseline: {len(heritage)} registration row(s) recorded at version {baseline}')
        for cls in plan["classes"]:
            wanted = dict(cls, version=version, imported=imported)
            store_meta(db, "service_class", ("code",), wanted,
                     ("code", "basis", "zone", "clock", "ref", "approval", "rank"), version, imported)
        for registration in plan["registrations"]:
            wanted = dict(registration, version=version, imported=imported)
            store_meta(db, "service_account", ("account", "code"), wanted,
                     ("account", "code", "channel", "joined", "old_prefix", "booking", "rank",
                      "prefix", "generation"), version, imported)
        for rank, day in enumerate(plan["days"]):
            store_meta(db, "service_day", ("day",), dict(day=day.isoformat(), rank=rank),
                     ("day", "rank"), version, imported)
        for row in plan["rows"]:
            action = store_row(db, row, version, imported)
            actions[action] += 1
            print(f'{row["account"]} {row["code"]} {row["day"]} {row["booking"]} '
                  f'{row["uid"]} {row["utc"]}'
                  + (f' order={row["order"]}' if row.get("order") else "")
                  + (f' reverted={row["reverted"]}' if row.get("reverted") else "") + f' {action}')
        for prefix, code in sorted(plan["prefixes"].items()):
            db.execute("insert or replace into service_prefix(prefix, code) values(?,?)", (prefix, code))
        mirror(db, plan["rows"], imported)
        db.execute("insert into service_import(version,digest,source,imported) values(?,?,?,?)",
                   (version, plan["digest"], plan["directory"], imported))
        db.commit()
    except Exception:
        db.rollback()
        raise
    print(f'version={version} digest={plan["digest"][:8]} source={plan["directory"]} '
          f'added={actions["added"]} changed={actions["changed"]} unchanged={actions["unchanged"]}')
    return 0


# --------------------------------------------------------------------------- #
# queries (database and explicit arguments only)
# --------------------------------------------------------------------------- #
def latest_version(db):
    return db.execute("select max(version) from service_import").fetchone()[0] or 0


def as_version(db, token):
    """A logical version number; an ISO business day means the last version up to that day."""
    if token is None:
        return latest_version(db)
    text = str(token).strip().lower()
    if text in ("latest", "now", "head"):
        return latest_version(db)
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    try:
        day = date.fromisoformat(text)
    except ValueError:
        raise ValueError(f"ASOF must be a logical version number or an ISO business day, got {token!r}")
    found = db.execute("select max(version) from service_import where imported<=?",
                       (day.isoformat(),)).fetchone()[0]
    return found or 0


def rows_as_of(db, account, asof):
    """The rows of ACCOUNT as they stood at logical version `asof`."""
    found = {}
    query = ("select account,code,day,booking,uid,utc,rank,version from service_history"
             " where account=? and version<=? order by version")
    for row in db.execute(query, (account, asof)):
        found[(row[1], row[2])] = row              # ordered by version: the newest wins
    ordered = sorted(found.values(), key=lambda row: (row[2], row[6], row[1]))
    return [dict(account=row[0], code=row[1], day=row[2], booking=row[3], uid=row[4], utc=row[5])
            for row in ordered]


def changed_between(db, account, since, until):
    """Rows that are new or different at `until` compared with `since`."""
    before = {(row["code"], row["day"]): row for row in rows_as_of(db, account, since)}
    return [row for row in rows_as_of(db, account, until)
            if before.get((row["code"], row["day"])) != row]


def batch_turn(batch):
    """The delivery turn a receipt batch came from; unnumbered batches sort first."""
    try:
        return int(batch.get("turn"))
    except (TypeError, ValueError):
        return 0


def receipt_state(batches):
    """What a channel holds: receipt batches applied in (turn, receipt) order."""
    if not isinstance(batches, list):
        raise ValueError("receipts must be a JSON array of batches")
    def order(batch):
        return (batch_turn(batch), str(batch.get("receipt") or ""))
    held = {}
    for batch in sorted(batches, key=order):
        rows = batch.get("rows")
        if rows is None:
            continue
        if not isinstance(rows, dict):
            raise ValueError(f'receipt batch {batch.get("receipt")!r} has no rows dictionary')
        for uid, row in rows.items():
            held[str(uid)] = row
    return held


def receipt_turns(batches):
    """The turns the given batches came from, oldest first."""
    if not isinstance(batches, list):
        return []
    return sorted({batch_turn(batch) for batch in batches if isinstance(batch, dict)})


def missing_rows(book_rows, held):
    """The invitations a channel should hold and does not, or holds differently."""
    out = []
    for row in book_rows:
        mine = held.get(row["uid"])
        if mine is None:
            out.append(dict(row, change="new", was=None))
            continue
        same = (instant(mine.get("utc"), f'receipt {row["uid"]}') ==
                instant(row["utc"], f'book {row["uid"]}')
                and str(mine.get("status") or "").upper() == "CONFIRMED")
        if not same:
            out.append(dict(row, change="changed", was=mine.get("utc")))
    # stable: chronological by day, and within a day the book's own class order
    out.sort(key=lambda row: row["day"])
    return out


def history(db, account=None):
    versions = []
    for version, digest, source, imported in db.execute(
            "select version,digest,source,imported from service_import order by version"):
        query = ("select account,code,day,booking,uid,utc,rank from service_history"
                 " where version=?")
        args = [version]
        if account is not None:
            query += " and account=?"
            args.append(account)
        rows = [dict(account=row[0], code=row[1], day=row[2], booking=row[3], uid=row[4], utc=row[5])
                for row in db.execute(query + " order by account,day,rank", args)]
        versions.append(dict(version=version, digest=digest, source=source,
                             imported=imported, rows=rows))
    return versions


INQUIRY_FIELDS = ("account", "code", "day")          # asof defaults to the latest version


def book_row(db, account, code, day, version):
    """The row of ACCOUNT/CODE/DAY as the book stood at `version`, or None."""
    for row in rows_as_of(db, account, version):
        if row["code"] == code and row["day"] == day:
            return row
    return None


def ledger_batches(ledger, account):
    """One mailbox's batches from a ledger file (mailbox -> array of batches)."""
    if not isinstance(ledger, dict):
        raise ValueError("ledger must map mailbox -> array of receipt batches")
    batches = ledger.get(account)
    if batches is None:
        return []
    if not isinstance(batches, list):
        raise ValueError(f"ledger entry for {account} is not an array of batches")
    for batch in batches:
        if not isinstance(batch, dict):
            raise ValueError(f"ledger entry for {account} holds something that is not a batch")
    return batches


def same_instant(left, right):
    """Both absent counts as the same; one absent never does."""
    if left is None or right is None:
        return left is None and right is None
    return instant(left, "due") == instant(right, "received")


def inquiry(db, questions, ledger):
    """逐笔答复：当时授权（due）与当时真实签收（received）是否一致。

    Each question names a mailbox, a class, an 原定业务日 and an ASOF.  The book
    at ASOF gives `due` and the UID the invitation was carrying then; the ledger
    batches up to ASOF, merged in (turn, receipt) order, give `received`.  Only
    that channel's own batches count and a batch that arrived after the question
    is invisible to it -- so temporary orders, their withdrawals and late
    redeliveries are reported as they stood at that moment, not as they look now.
    """
    if not isinstance(questions, list) or not questions:
        raise ValueError("questions must be a non-empty JSON array")
    if not isinstance(ledger, dict):
        raise ValueError("ledger must map mailbox -> array of receipt batches")
    answers = []
    for number, question in enumerate(questions, 1):
        if not isinstance(question, dict):
            raise ValueError(f"question {number} is not an object")
        missing = [field for field in INQUIRY_FIELDS if question.get(field) in (None, "")]
        if missing:
            raise ValueError(f"question {number} lacks {missing}")
        if "asof" not in question:
            question = dict(question, asof=None)
        account = str(question["account"]).strip()
        code = str(question["code"]).strip()
        day = str(question["day"]).strip()
        version = as_version(db, question["asof"])
        row = book_row(db, account, code, day, version)
        uid = row["uid"] if row else None
        due = row["utc"] if row else None
        up_to = [batch for batch in ledger_batches(ledger, account) if batch_turn(batch) <= version]
        held = receipt_state(up_to)
        mine = held.get(uid) if uid is not None else None
        received = (mine or {}).get("utc") if isinstance(mine, dict) else None
        answers.append(dict(question, uid=uid, due=due, received=received,
                           pending=not same_instant(due, received)))
    return answers


# --------------------------------------------------------------------------- #
# command line
# --------------------------------------------------------------------------- #
def main(argv=None):
    parser = argparse.ArgumentParser(description="Spring course intake and lookups.")
    sub = parser.add_subparsers(dest="action", required=True)
    one = sub.add_parser("import")
    one.add_argument("directory")
    two = sub.add_parser("view")
    two.add_argument("account")
    two.add_argument("asof", nargs="?")
    three = sub.add_parser("delta")
    three.add_argument("account")
    three.add_argument("asof")
    three.add_argument("receipts")
    three.add_argument("output")
    four = sub.add_parser("history")
    four.add_argument("questions")
    four.add_argument("ledger")
    four.add_argument("output")
    args = parser.parse_args(argv)
    db = ensure(sqlite3.connect(os.getenv("PORTAL_DB", "data/portal.sqlite")))
    try:
        if args.action == "import":
            return do_import(db, args.directory)
        if args.action == "view":
            rows = rows_as_of(db, args.account, as_version(db, args.asof))
            print(json.dumps(rows, ensure_ascii=False))
            return 0
        if args.action == "history":            # 追溯：当时授权 vs 当时签收
            answers = inquiry(db, load_json(args.questions), load_json(args.ledger))
            os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
            with open(args.output, "w", encoding="utf-8", newline="") as handle:
                json.dump(answers, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            pending = [answer for answer in answers if answer["pending"]]
            print(f"questions={len(answers)} pending={len(pending)} output={args.output}")
            for answer in pending:
                print(f'  {answer["account"]} {answer["code"]} {answer["day"]}'
                      f' asof={answer["asof"]} due={answer["due"]}'
                      f' received={answer["received"]}')
            return 0
        # delta: what the channel should hold and does not (this writes a package,
        # never a publication).
        version = as_version(db, args.asof)
        batches = load_json(args.receipts)
        held = receipt_state(batches)
        rows = missing_rows(rows_as_of(db, args.account, version), held)
        text = calendar_io.encode([dict(row, status="CONFIRMED") for row in rows])
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
        print(f'account={args.account} asof={version} held={len(held)}'
              f' to-send={len(rows)} output={args.output}')
        for row in rows:
            was = f' was {row["was"]}' if row["was"] else " (not received)"
            print(f'  {row["uid"]} {row["day"]} {row["code"]} {row["utc"]}{was}')
        late = [turn for turn in receipt_turns(batches) if turn > version]
        if late:
            print(f'note: receipts from turn(s) {late} are later than version {version}')
        if not rows:
            print(f'empty package: {args.account} already holds every invitation as of version {version}')
        return 0
    except (ValueError, OSError) as problem:
        print(f"service failed: {problem}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
