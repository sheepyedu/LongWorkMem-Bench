"""Tell a channel only what its own receipts say it is missing.

python3 project/notify.py CHANNEL OUTPUT --held RECEIPTS.json [--held ...] [--asof VERSION]

Each --held file is one channel's receipt history as the subscription service
returns it (a JSON array of batches, oldest first, each with `rows` of
{uid, utc, status}); several files are merged, later batches winning.  The book
is then asked what CHANNEL's invitations are at the logical version (default:
latest), and the two are differenced **per UID**:

  * a UID the channel does not hold at all     -> invite it,
  * a UID it holds at another instant or status -> correct it,
  * a UID it already holds unchanged            -> leave it alone.

So what goes out is exactly the change the customer has not signed for yet --
not the version delta, and not a resend of the whole course.  Rows the channel
holds that this book does not know (the old pilots, legacy invitations) are
reported and otherwise ignored.

OUTPUT is written as a CONFIRMED ICS ready for publishing; the last line names a
retry key for it, tagged with the sha256 of the very bytes written, so the same
package always gets the same key.  The database is opened read-only: notifying
prepares a package, it does not publish.
"""
import argparse
import hashlib
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import calendar_io
import service


def connect(path=None):
    """Read-only handle on the book."""
    path = os.path.abspath(path or os.getenv("PORTAL_DB", "data/portal.sqlite"))
    return sqlite3.connect(f"file:{path}?mode=ro", uri=True)


def held_state(paths):
    """Merge receipt histories into {uid: {uid, utc, status}}; later batches win.

    Several files are merged into one history and then applied in (turn, receipt)
    order, so splitting a channel's receipts over files cannot reorder them.
    """
    batches = []
    for path in paths:
        with open(path, encoding="utf-8") as handle:
            part = json.load(handle)
        if not isinstance(part, list):
            raise ValueError(f"{path} is not a receipt history")
        batches.extend(part)
    return service.receipt_state(batches)


def difference(book_rows, held):
    """-> (packages, already, foreign): what to send, what is settled, what is not ours."""
    packages = service.missing_rows(book_rows, held)
    settled = {row["uid"] for row in book_rows} - {row["uid"] for row in packages}
    already = [row for row in book_rows if row["uid"] in settled]
    foreign = sorted(uid for uid in held if uid not in {row["uid"] for row in book_rows})
    return packages, already, foreign


def build(channel, paths, db=None, asof=None):
    db = db or connect()
    version = service.as_version(db, asof)
    book_rows = service.rows_as_of(db, channel, version)
    held = held_state(paths)
    packages, already, foreign = difference(book_rows, held)
    rows = [dict(row, status="CONFIRMED") for row in packages]
    return dict(channel=channel, version=version, held=len(held), book=len(book_rows),
                packages=packages, already=[row["uid"] for row in already],
                foreign=sorted(foreign), rows=rows)


def package_text(rows):
    return calendar_io.encode(rows)


def key_for(channel, rows, digest):
    days = sorted({row["day"] for row in rows}) or ["00000000"]
    return f'{channel}-delta-{days[0].replace("-", "")}-{days[-1].replace("-", "")}-{digest}'


def main(argv=None):
    parser = argparse.ArgumentParser(description="Receipt-driven delta for one channel.")
    parser.add_argument("channel")
    parser.add_argument("output")
    parser.add_argument("--held", action="append", required=True,
                        help="a channel's receipt history JSON; repeat to merge batches")
    parser.add_argument("--asof", default=None)
    args = parser.parse_args(argv)
    db = connect()
    try:
        report = build(args.channel, args.held, db, args.asof)
    except (ValueError, OSError) as problem:
        print(f"notify failed: {problem}", file=sys.stderr)
        return 2
    finally:
        db.close()
    text = package_text(report["rows"])
    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)
    digest = hashlib.sha256(text.encode()).hexdigest()[:8]
    print(f'channel={args.channel} version={report["version"]} held={report["held"]}'
          f' book={report["book"]} to-send={len(report["rows"])}'
          f' already-held={len(report["already"])} foreign={len(report["foreign"])}'
          f' output={args.output}')
    for row in report["packages"]:
        was = f' was {row["was"]}' if row["was"] else " (not held at all)"
        print(f'  {row["uid"]} {row["day"]} {row["code"]} {row["utc"]}{was}')
    if report["foreign"]:
        print(f'  not ours (left alone): {" ".join(report["foreign"])}')
    if report["rows"]:
        print(f'key-suggestion={key_for(args.channel, report["rows"], digest)} sha256={digest}')
    else:
        print(f'nothing to send: {args.channel} already holds every invitation')
    return 0


if __name__ == "__main__":
    sys.exit(main())
