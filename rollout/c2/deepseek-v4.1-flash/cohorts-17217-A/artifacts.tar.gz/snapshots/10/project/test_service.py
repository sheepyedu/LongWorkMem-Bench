"""Tests for the spring course intake and lookups.

Run: python3 project/test_service.py
"""
import io
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import datetime
from zoneinfo import ZoneInfo

import portal
import service

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT = os.path.join(ROOT, "input")
SERVICE_TABLES = ("service_class", "service_account", "service_day", "service_row",
                  "service_history", "service_import")
EXPECTED = {
    "A": {"Q29": "14:05", "N84": None},
    "B": {"Q29": "15:10", "N84": None},
    "C": {"Q29": "16:15", "N84": None},
    "D": {"Q29": "17:20", "N84": None},
}


BASELINE = os.path.join(ROOT, "data", "portal.before-service.sqlite")


def seeded():
    """The portal as it stood before this arrival.

    The live data/portal.sqlite already carries the spring course at its logical
    version, so re-importing next to it would only ever be a resend.  The
    pre-arrival snapshot beside it keeps the first intake, the baseline version
    and the "portal gains the course" assertions meaningful run after run.
    """
    path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
    shutil.copyfile(BASELINE, path)
    return path, service.ensure(sqlite3.connect(path))


def read(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def arrival(version=2, schedule=None, roster=None, annex=None, annex41=None, clock="2026-03-30",
            migration=None, orders=None):
    """A copy of the delivered spring folder, with the pieces a test wants to bend."""
    directory = tempfile.mkdtemp()
    for week in ("week-41", "week-42"):
        os.makedirs(os.path.join(directory, "regional", "2025", week), exist_ok=True)
    for week, replacement in (("week-41", annex41), ("week-42", annex)):
        source = os.path.join(INPUT, "regional", "2025", week, "renewal.json")
        target = os.path.join(directory, "regional", "2025", week, "renewal.json")
        if replacement is not None:
            with open(target, "w", encoding="utf-8") as handle:
                json.dump(replacement, handle)
        else:
            shutil.copyfile(source, target)
    for name, content in (("schedule.json", schedule if schedule is not None
                           else read(os.path.join(INPUT, "schedule.json"))),
                          ("roster.json", roster if roster is not None
                           else read(os.path.join(INPUT, "roster.json")))):
        with open(os.path.join(directory, name), "w", encoding="utf-8") as handle:
            json.dump(content, handle)
    if orders is not None:
        os.makedirs(os.path.join(directory, "orders"), exist_ok=True)
        for name, document in orders.items():
            with open(os.path.join(directory, "orders", name), "w", encoding="utf-8") as handle:
                json.dump(document, handle)
    if migration is not None:
        with open(os.path.join(directory, "migration.json"), "w", encoding="utf-8") as handle:
            json.dump(migration, handle)
    with open(os.path.join(directory, "version.txt"), "w", encoding="utf-8") as handle:
        handle.write(str(version))
    with open(os.path.join(directory, "clock.txt"), "w", encoding="utf-8") as handle:
        handle.write(clock)
    return directory


def run_import(db, directory):
    out = io.StringIO()
    with redirect_stdout(out):
        code = service.do_import(db, directory)
    return code, out.getvalue()


def rows_of(db, account, asof=None):
    return service.rows_as_of(db, account, service.as_version(db, asof))


def receipts_of(db, account, version, turn=1):
    """A receipt history holding exactly what ACCOUNT held at `version`."""
    path = os.path.join(tempfile.mkdtemp(), f"receipts-{account}-{version}.json")
    rows = {row["uid"]: dict(uid=row["uid"], utc=row["utc"], status="CONFIRMED")
            for row in rows_of(db, account, version)}
    with open(path, "w", encoding="utf-8") as handle:
        json.dump([dict(turn=turn, receipt=f"held-{account}-{version}", rows=rows)], handle)
    return path


def uids_of(db, account, asof=None):
    """{(code, day): uid} for one account, as of a logical version."""
    return {(row["code"], row["day"]): row["uid"] for row in rows_of(db, account, asof)}


def release():
    return read(os.path.join(INPUT, "migration.json"))


def order(version=6, rows=None, **changes):
    document = dict(version=version,
                    rows=rows if rows is not None else
                    [dict(id="T-260", code="Q29", day="2026-03-09",
                          accounts=list("ABCD"), utc_clock="18:00")])
    document.update(changes)
    return document


def dump(path):
    db = sqlite3.connect(path)
    try:
        return {table: sorted(db.execute(f"select * from {table}").fetchall(),
                              key=lambda row: tuple("" if value is None else str(value) for value in row))
                for table in SERVICE_TABLES + ("events", "bookings", "series")}
    finally:
        db.close()


def ics_events(text):
    return [dict(line.split(":", 1) for line in body.strip().split("\r\n"))
            for body in re.findall(r"BEGIN:VEVENT\r\n(.*?)END:VEVENT\r\n", text, re.S)]


class Intake(unittest.TestCase):
    def setUp(self):
        self.path, self.db = seeded()
        self.dir = arrival()
        run_import(self.db, self.dir)

    def tearDown(self):
        self.db.close()

    def test_every_registration_and_day_is_registered(self):
        self.assertEqual(self.db.execute("select count(*) from service_row").fetchone()[0], 16)
        for account in ("A", "B", "C", "D"):
            rows = rows_of(self.db, account)
            self.assertEqual([(r["code"], r["day"]) for r in rows],
                             [("Q29", "2026-03-02"), ("N84", "2026-03-02"),
                              ("Q29", "2026-03-09"), ("N84", "2026-03-09")])

    def test_contract_fields_and_offset(self):
        for row in rows_of(self.db, "C"):
            self.assertEqual(list(row), ["account", "code", "day", "booking", "uid", "utc"])
            self.assertEqual(row["account"], "C")
            moment = datetime.fromisoformat(row["utc"])
            self.assertIsNotNone(moment.utcoffset())
            self.assertEqual(moment.utcoffset().total_seconds(), 0)
            self.assertEqual(row["uid"], f'{row["uid"].rsplit("-", 1)[0]}-{row["day"].replace("-", "")}')

    def test_q29_takes_each_accounts_signed_clock(self):
        for account, clocks in EXPECTED.items():
            for day in ("2026-03-02", "2026-03-09"):
                row = [r for r in rows_of(self.db, account) if r["code"] == "Q29" and r["day"] == day][0]
                self.assertEqual(row["utc"], f"{day}T{clocks['Q29']}:00+00:00")

    def test_n84_uses_the_venue_wall_clock_across_dst(self):
        zoned = {"2026-03-02": "2026-03-02T14:45:00+00:00",     # EST, UTC-5
                 "2026-03-09": "2026-03-09T13:45:00+00:00"}     # EDT, UTC-4
        for account in ("A", "B", "C", "D"):
            for day, want in zoned.items():
                row = [r for r in rows_of(self.db, account) if r["code"] == "N84" and r["day"] == day][0]
                self.assertEqual(row["utc"], want)
                local = datetime.fromisoformat(row["utc"]).astimezone(ZoneInfo("America/New_York"))
                self.assertEqual(local.strftime("%H:%M"), "09:45")

    def test_uids_and_bookings_come_from_the_roster(self):
        roster = {(entry["account"], entry["code"]): entry
                  for entry in read(os.path.join(INPUT, "roster.json"))}
        for (account, code), entry in roster.items():
            for row in [r for r in rows_of(self.db, account) if r["code"] == code]:
                self.assertEqual(row["booking"], entry["booking"])
                self.assertEqual(row["uid"], f'{entry["old_prefix"]}-{row["day"].replace("-", "")}')

    def test_existing_registrations_are_the_baseline_version(self):
        self.assertEqual(service.latest_version(self.db), 2)
        baseline = rows_of(self.db, "A", 1)
        self.assertEqual(baseline, [dict(account="A", code="Q29", day="2026-03-02",
                                         booking="BK-821", uid="invite-a-31-20260302",
                                         utc="2026-03-02T14:05:00+00:00")])
        self.assertEqual(rows_of(self.db, "A", 0), [])
        versions = [entry["version"] for entry in service.history(self.db, "A")]
        self.assertEqual(versions, [1, 2])

    def test_resending_the_same_arrival_changes_nothing(self):
        before = dump(self.path)
        code, text = run_import(self.db, self.dir)
        self.assertEqual(code, 0)
        self.assertIn("unchanged", text)
        self.assertEqual(dump(self.path), before)
        self.assertEqual(service.latest_version(self.db), 2)

    def test_the_portal_keeps_the_pilot_and_gains_the_course(self):
        db = service.portal.ensure_schema(sqlite3.connect(self.path))
        try:
            self.assertEqual(db.execute("select count(*) from series").fetchone()[0], 2)
            self.assertEqual(db.execute("select starts from events where uid='K17-20260306'").fetchone()[0],
                             "2026-03-06T15:00:00Z")
            for booking in ("BK-822", "BK-823", "BK-826", "BK-827"):
                self.assertIsNotNone(db.execute("select 1 from bookings where id=?", (booking,)).fetchone())
            for uid in ("invite-a-31-20260302", "invite-a-32-20260309"):
                self.assertIsNotNone(db.execute("select 1 from events where uid=?", (uid,)).fetchone())
            page = service.portal.route(db, "/invite/invite-c-32-20260309?tz=America/New_York")[1]
            self.assertIn("2026-03-09 09:45", page)
            listed = json.loads(service.portal.route(
                db, "/api/events?from=2026-03-09&to=2026-03-09&channel=D")[1])
            self.assertIn("invite-d-31-20260309", [row["uid"] for row in listed])
        finally:
            db.close()

    def test_delta_and_its_confirmed_ics(self):
        # the 03-02 Q29 row is the version-1 registration: unchanged, not re-notified
        changed = service.changed_between(self.db, "A", 1, 2)
        self.assertEqual([(row["code"], row["day"]) for row in changed],
                         [("N84", "2026-03-02"), ("Q29", "2026-03-09"), ("N84", "2026-03-09")])
        self.assertEqual(service.changed_between(self.db, "A", 2, 2), [])
        output = os.path.join(tempfile.mkdtemp(), "spring-a.ics")
        held = receipts_of(self.db, "A", 1)
        previous = os.environ.get("PORTAL_DB")
        os.environ["PORTAL_DB"] = self.path
        try:
            code = service.main(["delta", "A", "2", held, output])
        finally:
            if previous is None:
                del os.environ["PORTAL_DB"]
            else:
                os.environ["PORTAL_DB"] = previous
        self.assertEqual(code, 0)
        text = open(output, encoding="utf-8", newline="").read()
        events = ics_events(text)
        self.assertEqual([event["UID"] for event in events],
                         ["invite-a-32-20260302", "invite-a-31-20260309", "invite-a-32-20260309"])
        self.assertTrue(all(event["STATUS"] == "CONFIRMED" for event in events))
        self.assertTrue(text.startswith("BEGIN:VCALENDAR") and text.endswith("END:VCALENDAR\r\n"))

    def test_a_business_day_is_accepted_as_asof(self):
        self.assertEqual(rows_of(self.db, "B", "2026-03-30"), rows_of(self.db, "B", 2))

    def test_history_only_lists_the_versions_it_wrote(self):
        entries = service.history(self.db)
        self.assertEqual([entry["version"] for entry in entries], [1, 2])
        self.assertEqual(entries[0]["rows"][0]["account"], "A")
        # D's 03-02 N84 row is the version-1 registration, so version 2 wrote three
        self.assertEqual(len(service.history(self.db, "D")[1]["rows"]), 3)


class LaterArrivals(unittest.TestCase):
    def setUp(self):
        self.path, self.db = seeded()
        run_import(self.db, arrival())

    def tearDown(self):
        self.db.close()

    def extended_schedule(self):
        schedule = read(os.path.join(INPUT, "schedule.json"))
        schedule["days"] = schedule["days"] + ["2026-03-16"]
        return schedule

    def test_a_stale_logical_version_is_ignored(self):
        before = dump(self.path)
        code, text = run_import(self.db, arrival(version=1, schedule=self.extended_schedule()))
        self.assertEqual(code, 0)
        self.assertIn("stale", text)
        self.assertEqual(dump(self.path), before)

    def test_reusing_a_version_with_new_content_is_refused(self):
        before = dump(self.path)
        with self.assertRaises(ValueError):
            run_import(self.db, arrival(version=2, schedule=self.extended_schedule()))
        self.assertEqual(dump(self.path), before)

    def test_a_new_version_adds_without_dropping_earlier_rows(self):
        before = rows_of(self.db, "A", 2)
        code, _ = run_import(self.db, arrival(version=3, schedule=self.extended_schedule()))
        self.assertEqual(code, 0)
        self.assertEqual(service.latest_version(self.db), 3)
        self.assertEqual(rows_of(self.db, "A", 2), before)           # history is untouched
        later = rows_of(self.db, "A", 3)
        self.assertEqual(len(later), 6)
        added = [row for row in later if row["day"] == "2026-03-16"]
        self.assertEqual([(row["code"], row["booking"], row["uid"]) for row in added],
                         [("Q29", "BK-821", "invite-a-31-20260316"),
                          ("N84", "BK-822", "invite-a-32-20260316")])
        self.assertEqual(service.changed_between(self.db, "A", 2, 3), added)


class Identity(unittest.TestCase):
    """The identity release: joined vs cutover decides each registration's prefix."""
    EXPECTED = {
        "A": {"Q29": "invite-a-31", "N84": "n-n"},
        "B": {"Q29": "n-q", "N84": "invite-b-32"},
        "C": {"Q29": "invite-c-31", "N84": "s-n"},
        "D": {"Q29": "s-q", "N84": "invite-d-32"},
    }

    def setUp(self):
        self.path, self.db = seeded()
        run_import(self.db, arrival())                     # version 2, everyone under old_prefix
        self.before = dump(self.path)
        self.dir = arrival(version=3, migration=release())
        self.code, self.text = run_import(self.db, self.dir)

    def tearDown(self):
        self.db.close()

    def test_the_arrival_is_the_third_logical_version(self):
        self.assertEqual(self.code, 0, self.text)
        self.assertEqual(service.latest_version(self.db), 3)
        self.assertEqual(service.history(self.db, "A")[-1]["version"], 3)

    def test_only_the_registrations_from_the_cutover_are_renamed(self):
        for account, expected in self.EXPECTED.items():
            got = uids_of(self.db, account)
            self.assertEqual({(code, uid.rpartition("-")[0]) for (code, _), uid in got.items()},
                             set(expected.items()), account)
            self.assertTrue(all(uid.endswith(day.replace("-", "")) for (_, day), uid in got.items()))
            self.assertEqual({row["booking"] for row in rows_of(self.db, account)},
                             {row["booking"] for row in rows_of(self.db, account, 2)})  # 同一 booking

    def test_the_comparison_is_between_absolute_instants(self):
        early = service.instant("2026-01-31T18:59:59-05:00", "joined")     # 23:59:59Z
        on_it = service.instant("2026-02-01T01:00:00+01:00", "joined")     # 00:00:00Z
        cutover = self.db  # the release cutover is what the roster was judged against
        self.assertEqual((on_it - early).total_seconds(), 1.0)
        self.assertLess(early, on_it)
        self.assertEqual(service.identity_release(self.dir, [])["cutover"], on_it)
        self.assertEqual(uids_of(self.db, "B")[("Q29", "2026-03-02")], "n-q-20260302")
        self.assertEqual(uids_of(self.db, "B")[("N84", "2026-03-02")], "invite-b-32-20260302")

    def test_the_two_generations_of_a_channel_are_readable_at_once(self):
        page = lambda uid: portal.route(self.db, f"/invite/{uid}?tz=UTC")[1]
        self.assertIn("2026-03-02 15:10", page("invite-b-31-20260302"))   # 旧邀请照旧
        self.assertIn("2026-03-02 15:10", page("n-q-20260302"))           # 同一场, 新标识
        self.assertIn("2026-03-09 13:45", page("invite-a-32-20260309"))
        self.assertIn("2026-03-09 13:45", page("n-n-20260309"))
        self.assertIn("2026-03-09 15:10", page("n-q-20260309"))          # 次日也两代同在
        self.assertIn("2026-03-09 15:10", page("invite-b-31-20260309"))

    def test_the_old_invite_and_booking_mapping_survive(self):
        kept = dict(self.db.execute("select id, uid from bookings").fetchall())
        self.assertEqual(kept["BK-823"], "invite-b-31-20260302")   # 既有报名不被改名
        self.assertEqual(kept["BK-826"], "invite-c-32-20260302")
        row = self.db.execute("select starts from events where uid=?",
                              ("invite-b-31-20260302",)).fetchone()
        self.assertEqual(row[0], "2026-03-02T15:10:00Z")          # 已登记的第一周邀请还在
        self.assertEqual(self.db.execute("select count(*) from events").fetchone()[0], 28)

    def test_older_versions_still_answer_the_old_identifiers(self):
        for account, rows in (("A", 4), ("D", 4)):
            self.assertEqual(len(rows_of(self.db, account, 2)), rows)
        self.assertEqual(uids_of(self.db, "A", 2)[("N84", "2026-03-02")], "invite-a-32-20260302")
        self.assertEqual(uids_of(self.db, "A", 3)[("N84", "2026-03-02")], "n-n-20260302")
        self.assertEqual([row["version"] for row in service.history(self.db, "A")], [1, 2, 3])

    def test_the_delta_of_the_rename_is_one_new_uid_per_day(self):
        changed = service.changed_between(self.db, "A", 2, 3)
        self.assertEqual([(row["code"], row["day"], row["uid"]) for row in changed],
                         [("N84", "2026-03-02", "n-n-20260302"),
                          ("N84", "2026-03-09", "n-n-20260309")])
        out = os.path.join(tempfile.mkdtemp(), "a.ics")
        held = receipts_of(self.db, "A", 2)
        previous = os.environ.get("PORTAL_DB")
        os.environ["PORTAL_DB"] = self.path
        try:
            with redirect_stdout(io.StringIO()):
                service.main(["delta", "A", "3", held, out])
        finally:
            if previous is None:
                del os.environ["PORTAL_DB"]
            else:
                os.environ["PORTAL_DB"] = previous
        with open(out, encoding="utf-8", newline="") as handle:
            events = ics_events(handle.read())
        self.assertEqual([event["UID"] for event in events], ["n-n-20260302", "n-n-20260309"])
        self.assertEqual({event["STATUS"] for event in events}, {"CONFIRMED"})

    def test_a_migrated_uid_is_filed_under_its_business_day(self):
        self.db.execute("insert into events(uid, starts) values(?,?)",
                        ("s-n-20260310", "2026-03-09T20:00:00Z"))     # 原定日 03-10, UTC 日 03-09
        self.db.commit()
        rows = json.loads(portal.route(self.db, "/api/events?from=2026-03-10&to=2026-03-10")[1])
        self.assertIn("s-n-20260310", {row["uid"] for row in rows})

    def test_resending_the_release_changes_nothing(self):
        after = dump(self.path)
        code, text = run_import(self.db, self.dir)
        self.assertEqual(code, 0)
        self.assertIn("unchanged", text)
        self.assertEqual(dump(self.path), after)

    def test_a_late_arrival_of_the_previous_version_is_ignored(self):
        after = dump(self.path)
        roster = read(os.path.join(INPUT, "roster.json"))
        roster[0]["joined"] = "2026-01-30T00:00:00Z"        # 同版本号的另一份来件
        code, text = run_import(self.db, arrival(version=2, roster=roster))
        self.assertEqual(code, 0)
        self.assertIn("stale", text)
        self.assertEqual(dump(self.path), after)

    def test_the_prefix_table_keeps_both_generations_in_the_portal(self):
        pairs = dict(self.db.execute("select prefix, code from service_prefix").fetchall())
        self.assertEqual(pairs["n-q"], "Q29")
        self.assertEqual(pairs["invite-b-31"], "Q29")
        self.assertEqual(sorted(portal.filed_codes(self.db) & {"n-q", "s-n", "invite-a-31"}),
                         ["invite-a-31", "n-q", "s-n"])


class Issued(unittest.TestCase):
    """A temporary clock for one class on one service day."""
    def setUp(self):
        self.path, self.db = seeded()
        run_import(self.db, arrival())                                      # 版本 2
        run_import(self.db, arrival(version=3, migration=release()))         # 版本 3
        self.before = {account: rows_of(self.db, account) for account in "ABCD"}
        self.dir = arrival(version=6, migration=release(), orders={"6.json": order()})
        self.code, self.text = run_import(self.db, self.dir)

    def tearDown(self):
        self.db.close()

    def test_the_issued_clock_lands_on_the_named_day_only(self):
        self.assertEqual(self.code, 0, self.text)
        self.assertEqual(service.latest_version(self.db), 6)
        for account in "ABCD":
            moved = [row for row in rows_of(self.db, account) if row["day"] == "2026-03-09"
                     and row["code"] == "Q29"]
            self.assertEqual(len(moved), 1)
            self.assertEqual(moved[0]["utc"], "2026-03-09T18:00:00+00:00", account)

    def test_the_first_week_and_the_other_class_keep_their_clock(self):
        for account in "ABCD":
            now = {(row["code"], row["day"]): row for row in rows_of(self.db, account)}
            was = {(row["code"], row["day"]): row for row in self.before[account]}
            for key in (("Q29", "2026-03-02"), ("N84", "2026-03-02"), ("N84", "2026-03-09")):
                self.assertEqual(now[key], was[key], (account, key))
            self.assertEqual(now[("Q29", "2026-03-09")]["uid"], was[("Q29", "2026-03-09")]["uid"])

    def test_the_delta_is_the_one_invitation_that_moved(self):
        for account, booking in (("A", "BK-821"), ("D", "BK-827")):
            changed = service.changed_between(self.db, account, 3, 6)
            self.assertEqual([(row["code"], row["day"], row["uid"], row["utc"]) for row in changed],
                             [("Q29", "2026-03-09", changed[0]["uid"], "2026-03-09T18:00:00+00:00")])
            self.assertEqual(changed[0]["booking"], booking)

    def test_an_order_for_some_accounts_leaves_the_others_alone(self):
        self.db.close()
        path, db = seeded()
        run_import(db, arrival(version=3, migration=release()))
        partial = order(rows=[dict(id="T-261", code="Q29", day="2026-03-09",
                                   accounts=["A", "B"], utc_clock="18:00")])
        run_import(db, arrival(version=6, migration=release(), orders={"6.json": partial}))
        self.assertEqual({row["utc"] for row in rows_of(db, "A")
                          if row["code"] == "Q29" and row["day"] == "2026-03-09"},
                         {"2026-03-09T18:00:00+00:00"})
        self.assertEqual({row["utc"] for row in rows_of(db, "C")
                          if row["code"] == "Q29" and row["day"] == "2026-03-09"},
                         {"2026-03-09T16:15:00+00:00"})      # 附件钟点, 未被点名
        db.close()
        self.path, self.db = seeded()

    def test_the_newest_issuance_wins(self):
        self.db.close()
        path, db = seeded()
        run_import(db, arrival(version=3, migration=release()))
        run_import(db, arrival(version=6, migration=release(),
                              orders={"5.json": order(version=5, rows=[
                                          dict(id="T-259", code="Q29", day="2026-03-09",
                                               accounts=list("ABCD"), utc_clock="17:30")]),
                                      "6.json": order()}))
        self.assertEqual({row["utc"] for row in rows_of(db, "B")
                          if row["code"] == "Q29" and row["day"] == "2026-03-09"},
                         {"2026-03-09T18:00:00+00:00"})
        db.close()
        self.path, self.db = seeded()

    def test_resending_the_issuance_changes_nothing(self):
        after = dump(self.path)
        code, text = run_import(self.db, self.dir)
        self.assertEqual(code, 0)
        self.assertIn("unchanged", text)
        self.assertEqual(dump(self.path), after)


class Withdrawn(unittest.TestCase):
    """The committee takes its temporary clock back for some accounts only."""
    def setUp(self):
        self.path, self.db = seeded()
        run_import(self.db, arrival())                                       # 版本 2
        run_import(self.db, arrival(version=3, migration=release()))          # 版本 3
        self.contract = {account: rows_of(self.db, account) for account in "ABCD"}
        activation = {"6.json": order()}
        run_import(self.db, arrival(version=6, migration=release(), orders=activation))
        self.issued = {account: rows_of(self.db, account) for account in "ABCD"}
        withdrawal = {"7.json": dict(version=7, rows=[
            dict(id="W-264", target="T-260", day="2026-03-09", accounts=["B", "C", "D"])])}
        self.dir = arrival(version=7, migration=release(),
                           orders={**activation, **withdrawal})
        self.code, self.text = run_import(self.db, self.dir)

    def tearDown(self):
        self.db.close()

    def row(self, account, code, day):
        return [row for row in rows_of(self.db, account)
                if row["code"] == code and row["day"] == day][0]

    def test_only_the_named_accounts_go_back_to_the_contract(self):
        self.assertEqual(self.code, 0, self.text)
        self.assertEqual(service.latest_version(self.db), 7)
        self.assertEqual(self.row("A", "Q29", "2026-03-09")["utc"], "2026-03-09T18:00:00+00:00")
        for account in "BCD":
            self.assertEqual(self.row(account, "Q29", "2026-03-09")["utc"],
                             {row["code"] + row["day"]: row["utc"]
                              for row in self.contract[account]}["Q292026-03-09"], account)

    def test_the_contract_clock_is_the_one_that_comes_back(self):
        expected = {"B": "2026-03-09T15:10:00+00:00", "C": "2026-03-09T16:15:00+00:00",
                    "D": "2026-03-09T17:20:00+00:00"}
        for account, utc in expected.items():
            self.assertEqual(self.row(account, "Q29", "2026-03-09")["utc"], utc, account)

    def test_the_booking_and_the_identifier_survive_the_withdrawal(self):
        for account in "ABCD":
            now = {(row["code"], row["day"]): row for row in rows_of(self.db, account)}
            was = {(row["code"], row["day"]): row for row in self.contract[account]}
            for key in was:
                self.assertEqual(now[key]["uid"], was[key]["uid"], (account, key))
                self.assertEqual(now[key]["booking"], was[key]["booking"], (account, key))

    def test_the_rest_of_the_fortnight_is_untouched(self):
        for account in "ABCD":
            now = {(row["code"], row["day"]): row for row in rows_of(self.db, account)}
            was = {(row["code"], row["day"]): row for row in self.contract[account]}
            for key in (("Q29", "2026-03-02"), ("N84", "2026-03-02"), ("N84", "2026-03-09")):
                self.assertEqual(now[key], was[key], (account, key))

    def test_the_unnamed_account_keeps_the_temporary_clock(self):
        issued = [row for row in self.issued["A"]
                  if row["code"] == "Q29" and row["day"] == "2026-03-09"][0]
        self.assertEqual(issued["utc"], "2026-03-09T18:00:00+00:00")
        self.assertEqual(self.row("A", "Q29", "2026-03-09"), issued)          # 未被点名

    def test_the_package_for_the_unnamed_account_is_empty(self):
        held = receipts_of(self.db, "A", 6)                 # A signed for the 18:00 issuance
        out = os.path.join(tempfile.mkdtemp(), "plan-a.ics")
        previous = os.environ.get("PORTAL_DB")
        os.environ["PORTAL_DB"] = self.path
        try:
            with redirect_stdout(io.StringIO()) as said:
                code = service.main(["delta", "A", "7", held, out])
        finally:
            if previous is None:
                del os.environ["PORTAL_DB"]
            else:
                os.environ["PORTAL_DB"] = previous
        self.assertEqual(code, 0)
        self.assertIn("empty package", said.getvalue())
        with open(out, encoding="utf-8", newline="") as handle:
            text = handle.read()
        self.assertEqual(ics_events(text), [])
        self.assertTrue(text.startswith("BEGIN:VCALENDAR") and text.endswith("END:VCALENDAR\r\n"))

    def test_the_package_for_a_withdrawn_account_carries_the_contract_clock(self):
        for account, utc in (("B", "2026-03-09T15:10:00+00:00"),
                            ("C", "2026-03-09T16:15:00+00:00"),
                            ("D", "2026-03-09T17:20:00+00:00")):
            held = receipts_of(self.db, account, 6)         # they signed for 18:00
            out = os.path.join(tempfile.mkdtemp(), f"plan-{account}.ics")
            previous = os.environ.get("PORTAL_DB")
            os.environ["PORTAL_DB"] = self.path
            try:
                with redirect_stdout(io.StringIO()) as said:
                    code = service.main(["delta", account, "7", held, out])
            finally:
                if previous is None:
                    del os.environ["PORTAL_DB"]
                else:
                    os.environ["PORTAL_DB"] = previous
            self.assertEqual(code, 0)
            self.assertIn("to-send=1", said.getvalue())
            self.assertIn("was 2026-03-09T18:00:00+00:00", said.getvalue())
            with open(out, encoding="utf-8", newline="") as handle:
                events = ics_events(handle.read())
            self.assertEqual([event["UID"] for event in events],
                             [self.row(account, "Q29", "2026-03-09")["uid"]], account)
            with open(out, encoding="utf-8", newline="") as handle:
                text = handle.read()
            stamp = utc[:19].replace("-", "").replace(":", "") + "Z"        # 合同钟点, UTC
            self.assertIn(f"DTSTART:{stamp}", text)
            self.assertEqual(events[0]["STATUS"], "CONFIRMED")


class Refusals(unittest.TestCase):
    def setUp(self):
        self.path, self.db = seeded()

    def tearDown(self):
        self.db.close()

    def annex(self, **changes):
        annex = read(os.path.join(INPUT, "regional", "2025", "week-42", "renewal.json"))
        annex.update(changes)
        return annex

    def assert_refused(self, directory, fragment):
        before = dump(self.path)
        with self.assertRaises(ValueError) as caught:
            run_import(self.db, directory)
        self.assertIn(fragment, str(caught.exception))
        self.assertEqual(dump(self.path), before)                  # nothing was written

    def test_a_withdrawal_of_something_not_in_force_is_refused(self):
        self.assert_refused(arrival(version=7, migration=release(), orders={
            "7.json": dict(version=7, rows=[
                dict(id="W-264", target="T-260", day="2026-03-09", accounts=["B"])])}),
            "nothing by that name is in force")

    def test_a_withdrawal_without_accounts_is_refused(self):
        self.assert_refused(arrival(version=7, migration=release(), orders={
            "6.json": order(),
            "7.json": dict(version=7, rows=[
                dict(id="W-264", target="T-260", day="2026-03-09")])}),
            "without saying whose it is")

    def test_a_withdrawal_for_accounts_the_order_never_covered_is_refused(self):
        self.assert_refused(arrival(version=7, migration=release(), orders={
            "6.json": order(rows=[dict(id="T-260", code="Q29", day="2026-03-09",
                                       accounts=["A"], utc_clock="18:00")]),
            "7.json": dict(version=7, rows=[
                dict(id="W-264", target="T-260", day="2026-03-09", accounts=["B"])])}),
            "nothing by that name is in force")

    def test_expired_annex_is_not_an_authority(self):
        schedule = read(os.path.join(INPUT, "schedule.json"))
        schedule["classes"]["Q29"].update({"ref": "regional/2025/week-41/renewal.json",
                                           "approval": "RN-41"})
        self.assert_refused(arrival(schedule=schedule), "not signed")

    def test_annex_number_must_match_the_schedule(self):
        schedule = read(os.path.join(INPUT, "schedule.json"))
        schedule["classes"]["Q29"]["approval"] = "RN-41"
        self.assert_refused(arrival(schedule=schedule), "needs annex RN-41")

    def test_missing_attachment_is_refused(self):
        schedule = read(os.path.join(INPUT, "schedule.json"))
        schedule["classes"]["Q29"]["ref"] = "regional/2025/week-99/renewal.json"
        self.assert_refused(arrival(schedule=schedule), "not in")

    def test_annex_must_cover_every_account(self):
        annex = self.annex()
        del annex["utc_by_account"]["D"]
        self.assert_refused(arrival(annex=annex), "no UTC clock for ['D']")

    def test_roster_must_name_a_scheduled_class(self):
        roster = read(os.path.join(INPUT, "roster.json"))
        roster[0]["code"] = "X99"
        self.assert_refused(arrival(roster=roster), "schedule has")

    def bend_release(self, **changes):
        document = release()
        document.update(changes)
        return document

    def test_a_joined_moment_without_an_offset_is_refused(self):
        roster = read(os.path.join(INPUT, "roster.json"))
        roster[0]["joined"] = "2026-01-31T18:59:59"
        self.assert_refused(arrival(version=3, migration=release(), roster=roster),
                            "no UTC offset")

    def test_a_registration_from_the_cutover_needs_its_channel_prefix(self):
        document = self.bend_release()
        del document["prefixes"]["north"]["N84"]
        self.assert_refused(arrival(version=3, migration=document), "no prefix")

    def test_a_release_newer_than_the_arrival_is_refused(self):
        self.assert_refused(arrival(version=2, migration=release()), "version.txt says 2")

    def test_a_release_without_a_cutover_is_refused(self):
        document = self.bend_release()
        del document["cutover"]
        self.assert_refused(arrival(version=3, migration=document), "not an ISO instant")

    def test_one_prefix_cannot_serve_two_classes(self):
        document = self.bend_release()
        document["prefixes"]["north"]["N84"] = document["prefixes"]["north"]["Q29"]
        self.assert_refused(arrival(version=3, migration=document), "reuses one prefix")

    def test_an_order_for_a_day_the_schedule_lacks_is_refused(self):
        document = order(rows=[dict(id="T-262", code="Q29", day="2026-03-16",
                                   accounts=["A"], utc_clock="18:00")])
        self.assert_refused(arrival(version=6, migration=release(), orders={"6.json": document}),
                            "which the schedule does not have")

    def test_an_order_for_an_unregistered_account_is_refused(self):
        document = order(rows=[dict(id="T-263", code="Q29", day="2026-03-09",
                                   accounts=["A", "Z"], utc_clock="18:00")])
        self.assert_refused(arrival(version=6, migration=release(), orders={"6.json": document}),
                            "no Q29 registration")

    def test_an_order_for_an_unknown_class_is_refused(self):
        document = order(rows=[dict(id="T-264", code="X99", day="2026-03-09",
                                   accounts=["A"], utc_clock="18:00")])
        self.assert_refused(arrival(version=6, migration=release(), orders={"6.json": document}),
                            "schedule does not have")

    def test_an_order_issued_for_a_later_version_is_refused(self):
        document = order(version=9)
        self.assert_refused(arrival(version=6, migration=release(), orders={"6.json": document}),
                            "issued for logical version 9")

    def test_an_expired_order_is_refused(self):
        document = order(status="expired")
        self.assert_refused(arrival(version=6, migration=release(), orders={"6.json": document}),
                            "not signed")

    def test_an_order_without_a_clock_is_refused(self):
        document = order(rows=[dict(id="T-265", code="Q29", day="2026-03-09", accounts=["A"])])
        self.assert_refused(arrival(version=6, migration=release(), orders={"6.json": document}),
                            "gives no clock")

    def test_missing_schedule_is_refused(self):
        directory = tempfile.mkdtemp()
        self.assert_refused(directory, "needs schedule.json")


class CommandLine(unittest.TestCase):
    def test_import_then_view_through_the_cli(self):
        directory = arrival()
        path = os.path.join(tempfile.mkdtemp(), "portal.sqlite")
        shutil.copyfile(BASELINE, path)
        env = dict(os.environ, PORTAL_DB=path)
        run = lambda *args: subprocess.run([sys.executable, "project/service.py", *args],
                                           cwd=ROOT, env=env, capture_output=True, text=True)
        first = run("import", directory)
        self.assertEqual(first.returncode, 0, first.stderr)
        again = run("import", directory)
        self.assertEqual(again.returncode, 0, again.stderr)
        self.assertIn("unchanged", again.stdout)
        view = run("view", "D", "2")
        self.assertEqual(view.returncode, 0, view.stderr)
        rows = json.loads(view.stdout)
        self.assertEqual(len(rows), 4)
        self.assertEqual({row["uid"] for row in rows},
                         {"invite-d-31-20260302", "invite-d-32-20260302",
                          "invite-d-31-20260309", "invite-d-32-20260309"})
        self.assertEqual(run("view", "A", "not-a-version").returncode, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
