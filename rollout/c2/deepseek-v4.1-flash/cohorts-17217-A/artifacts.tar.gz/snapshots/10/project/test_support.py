"""Tests for the read-only support preview. Run: python3 project/test_support.py"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import support
import test_service

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VAULT = os.path.join(ROOT, "input", "vault", "index.json")
QUESTIONS = [dict(account=account, code="N84", day="2026-03-09", asof=4) for account in "ABCD"]


def london(utc):
    """An independent London label -- deliberately not the portal's own helper."""
    moment = datetime.fromisoformat(utc.replace("Z", "+00:00")).astimezone(ZoneInfo("Europe/London"))
    return moment.strftime("%Y-%m-%d %H:%M")


def arrived(db):
    """The book as it stands after the first send: version 2, then the release."""
    test_service.run_import(db, test_service.arrival())                      # 版本 2
    test_service.run_import(db, test_service.arrival(version=3,
                                                    migration=test_service.release()))


class Answers(unittest.TestCase):
    def setUp(self):
        self.path, self.db = test_service.seeded()
        arrived(self.db)

    def tearDown(self):
        self.db.close()

    def test_every_question_gets_one_answer_in_order(self):
        answers = support.preview(self.db, QUESTIONS)
        self.assertEqual([row["account"] for row in answers], list("ABCD"))
        self.assertEqual(len(answers), len(QUESTIONS))

    def test_the_question_keys_are_kept_and_uid_and_local_are_added(self):
        for question, answer in zip(QUESTIONS, support.preview(self.db, QUESTIONS)):
            self.assertEqual(list(answer), list(question) + ["uid", "local"])
            for key, value in question.items():
                self.assertEqual(answer[key], value)

    def test_the_uid_is_the_identity_each_registration_holds(self):
        held = {row["account"]: row["uid"] for row in support.preview(self.db, QUESTIONS)}
        self.assertEqual(held, {"A": "n-n-20260309", "B": "invite-b-32-20260309",
                                "C": "s-n-20260309", "D": "invite-d-32-20260309"})

    def test_the_second_service_day_is_gmt_in_london(self):
        for answer in support.preview(self.db, QUESTIONS):
            self.assertEqual(answer["local"], "2026-03-09 13:45")
        moment = datetime(2026, 3, 9, 13, 45, tzinfo=timezone.utc)
        self.assertEqual(moment.astimezone(ZoneInfo("Europe/London")).utcoffset().total_seconds(), 0)
        # 英国 2026-03-29 才换夏令时: 同一钟点那天才是 14:45
        later = datetime(2026, 3, 29, 13, 45, tzinfo=timezone.utc)
        self.assertEqual(later.astimezone(ZoneInfo("Europe/London")).strftime("%Y-%m-%d %H:%M"),
                         "2026-03-29 14:45")

    def test_asof_beyond_the_book_answers_with_the_newest_version(self):
        pairs = [(support.preview(self.db, [dict(QUESTIONS[0], asof=asof)])[0])
                 for asof in (3, 4, "now")]
        self.assertEqual([(row["uid"], row["local"]) for row in pairs],
                         [("n-n-20260309", "2026-03-09 13:45")] * 3)

    def test_an_older_asof_answers_with_the_identity_of_that_version(self):
        older = support.preview(self.db, [dict(QUESTIONS[0], asof=2)])[0]
        self.assertEqual(older["uid"], "invite-a-32-20260309")     # 换代前的标识
        self.assertEqual(older["local"], "2026-03-09 13:45")

    def test_the_answers_match_what_the_channels_signed_for(self):
        if not os.path.isfile(VAULT):
            self.skipTest("no vault index in this workspace")
        with open(VAULT, encoding="utf-8") as handle:
            index = json.load(handle)
        answers = {row["account"]: row for row in support.preview(self.db, QUESTIONS)}
        for account, row in answers.items():
            with open(os.path.join(ROOT, "input", index[account]), encoding="utf-8") as handle:
                batches = json.load(handle)
            held = {}
            for batch in batches:
                held.update(batch["rows"])
            self.assertIn(row["uid"], held, account)
            self.assertEqual(held[row["uid"]]["uid"], row["uid"])
            self.assertEqual(london(held[row["uid"]]["utc"]), row["local"], account)


class Refusals(unittest.TestCase):
    def setUp(self):
        self.path, self.db = test_service.seeded()
        arrived(self.db)

    def tearDown(self):
        self.db.close()

    def test_a_row_the_book_does_not_have_is_refused(self):
        with self.assertRaises(ValueError) as caught:
            support.preview(self.db, [dict(QUESTIONS[0], code="X99")])
        self.assertIn("no X99 on 2026-03-09", str(caught.exception))
        with self.assertRaises(ValueError):
            support.preview(self.db, [dict(QUESTIONS[0], day="2026-03-16")])

    def test_a_question_without_its_query_keys_is_refused(self):
        for field in support.QUESTION_FIELDS:
            question = dict(QUESTIONS[0])
            del question[field]
            with self.assertRaises(ValueError) as caught:
                support.preview(self.db, [question])
            self.assertIn(field, str(caught.exception))

    def test_the_book_is_opened_read_only(self):
        handle = support.connect(self.path)
        try:
            with self.assertRaises(sqlite3.OperationalError) as caught:
                handle.execute("insert into events(uid, starts) values('x','2026-03-09T00:00:00Z')")
            self.assertIn("readonly", str(caught.exception))
        finally:
            handle.close()

    def test_answering_writes_nothing(self):
        before = test_service.dump(self.path)
        support.preview(self.db, QUESTIONS)
        self.assertEqual(test_service.dump(self.path), before)


class CommandLine(unittest.TestCase):
    def setUp(self):
        self.path, self.db = test_service.seeded()
        arrived(self.db)
        self.db.close()
        self.out = os.path.join(tempfile.mkdtemp(), "preview.json")

    def test_the_array_lands_in_the_output_file(self):
        before = test_service.dump(self.path)
        env = dict(os.environ, PORTAL_DB=self.path)
        done = subprocess.run([sys.executable, "project/support.py", "input/support.json", self.out],
                              cwd=ROOT, env=env, capture_output=True, text=True)
        self.assertEqual(done.returncode, 0, done.stderr)
        with open(self.out, encoding="utf-8") as handle:
            answers = json.load(handle)
        self.assertEqual(len(answers), 4)
        self.assertEqual([row["local"] for row in answers], ["2026-03-09 13:45"] * 4)
        self.assertEqual(test_service.dump(self.path), before)

    def test_a_question_that_cannot_be_answered_exits_two(self):
        broken = os.path.join(tempfile.mkdtemp(), "questions.json")
        with open(broken, "w", encoding="utf-8") as handle:
            json.dump([dict(QUESTIONS[0], account="Z")], handle)
        env = dict(os.environ, PORTAL_DB=self.path)
        done = subprocess.run([sys.executable, "project/support.py", broken, self.out],
                              cwd=ROOT, env=env, capture_output=True, text=True)
        self.assertEqual(done.returncode, 2)
        self.assertIn("preview failed", done.stderr)
        self.assertFalse(os.path.exists(self.out))


if __name__ == "__main__":
    unittest.main(verbosity=2)
