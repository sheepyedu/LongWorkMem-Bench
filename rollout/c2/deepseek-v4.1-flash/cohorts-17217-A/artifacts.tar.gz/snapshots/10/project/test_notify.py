"""Tests for the receipt-driven delta. Run: python3 project/test_notify.py"""
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import notify
import service
import test_service

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VAULT = os.path.join(ROOT, "input", "vault")


def held_file(channel):
    return os.path.join(VAULT, f"{channel}-closing-04.json")


def write_held(rows):
    path = os.path.join(tempfile.mkdtemp(), "held.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump([{"turn": 4, "key": "test", "receipt": "T-1", "rows": rows}], handle)
    return path


class Delta(unittest.TestCase):
    def setUp(self):
        self.path, self.db = test_service.seeded()
        test_service.run_import(self.db, test_service.arrival())                        # 版本 2
        test_service.run_import(self.db, test_service.arrival(
            version=3, migration=test_service.release()))                               # 版本 3
        test_service.run_import(self.db, test_service.arrival(
            version=6, migration=test_service.release(),
            orders={"6.json": test_service.order()}))                                   # 版本 6

    def tearDown(self):
        self.db.close()

    def build(self, channel="A", held=None, asof=None):
        return notify.build(channel, [held or held_file(channel)], self.db, asof)

    def test_only_the_invitation_that_moved_is_packaged(self):
        report = self.build()
        self.assertEqual([(row["uid"], row["utc"], row["change"], row["was"])
                          for row in report["packages"]],
                         [("invite-a-31-20260309", "2026-03-09T18:00:00+00:00", "changed",
                           "2026-03-09T14:05:00Z")])
        self.assertEqual(sorted(report["already"]),
                         ["invite-a-31-20260302", "n-n-20260302", "n-n-20260309"])
        self.assertEqual(report["rows"][0]["status"], "CONFIRMED")

    def test_every_channel_gets_its_own_one_row_package(self):
        expected = {"A": "invite-a-31-20260309", "B": "n-q-20260309",
                    "C": "invite-c-31-20260309", "D": "s-q-20260309"}
        for channel, uid in expected.items():
            report = self.build(channel)
            self.assertEqual([row["uid"] for row in report["rows"]], [uid], channel)
            self.assertEqual(len(report["already"]), 3, channel)

    def test_an_invitation_the_channel_never_signed_for_is_invited(self):
        with open(held_file("A"), encoding="utf-8") as handle:
            batches = json.load(handle)
        rows = dict(batches[0]["rows"])
        del rows["n-n-20260302"]                       # 这一条它其实没签收
        report = self.build(held=write_held(rows))
        self.assertEqual([(row["uid"], row["change"]) for row in report["packages"]],
                         [("n-n-20260302", "new"), ("invite-a-31-20260309", "changed")])

    def test_rows_the_book_does_not_know_are_left_alone(self):
        with open(held_file("A"), encoding="utf-8") as handle:
            rows = dict(json.load(handle)[0]["rows"])
        rows["K17-20260306"] = {"uid": "K17-20260306", "utc": "2026-03-06T15:00:00Z",
                                "status": "CONFIRMED"}
        report = self.build(held=write_held(rows))
        self.assertEqual(report["foreign"], ["K17-20260306"])
        self.assertNotIn("K17-20260306", [row["uid"] for row in report["rows"]])

    def test_a_channel_that_already_holds_the_change_gets_nothing(self):
        report = self.build(asof=3)                     # 版本 3 就是客户手上那一批
        self.assertEqual(report["rows"], [])
        self.assertEqual(len(report["already"]), 4)

    def test_the_same_instant_in_another_spelling_is_not_a_change(self):
        with open(held_file("A"), encoding="utf-8") as handle:
            rows = dict(json.load(handle)[0]["rows"])
        rows["invite-a-31-20260309"]["utc"] = "2026-03-09T18:00:00+00:00"
        report = self.build(held=write_held(rows))
        self.assertEqual([row["uid"] for row in report["rows"]], [])
        self.assertEqual(len(report["already"]), 4)

    def test_the_package_is_one_confirmed_event(self):
        text = notify.package_text(self.build()["rows"])
        events = re.findall(r"BEGIN:VEVENT\r\n(.*?)END:VEVENT\r\n", text, re.S)
        self.assertEqual(len(events), 1)
        fields = dict(line.split(":", 1) for line in events[0].strip().split("\r\n"))
        self.assertEqual(fields["UID"], "invite-a-31-20260309")
        self.assertEqual(fields["DTSTART"], "20260309T180000Z")
        self.assertEqual(fields["STATUS"], "CONFIRMED")

    def test_answering_writes_nothing_to_the_book(self):
        before = test_service.dump(self.path)
        self.build()
        self.assertEqual(test_service.dump(self.path), before)

    def test_the_book_is_opened_read_only(self):
        handle = notify.connect(self.path)
        try:
            with self.assertRaises(sqlite3.OperationalError) as caught:
                handle.execute("delete from service_row")
            self.assertIn("readonly", str(caught.exception))
        finally:
            handle.close()


class CommandLine(unittest.TestCase):
    def setUp(self):
        self.path, self.db = test_service.seeded()
        test_service.run_import(self.db, test_service.arrival(version=3,
                                                             migration=test_service.release()))
        test_service.run_import(self.db, test_service.arrival(
            version=6, migration=test_service.release(),
            orders={"6.json": test_service.order()}))
        self.db.close()
        self.out = os.path.join(tempfile.mkdtemp(), "change-A.ics")

    def run_cli(self, *extra, held=None):
        env = dict(os.environ, PORTAL_DB=self.path)
        held = held or [held_file("A")]
        return subprocess.run([sys.executable, "project/notify.py", "A", self.out]
                              + [part for path in held for part in ("--held", path)] + list(extra),
                              cwd=ROOT, env=env, capture_output=True, text=True)

    def test_the_package_lands_with_a_key_tagged_by_its_own_bytes(self):
        done = self.run_cli()
        self.assertEqual(done.returncode, 0, done.stderr)
        with open(self.out, "rb") as handle:
            written = handle.read()
        key = re.search(r"key-suggestion=(\S+)", done.stdout).group(1)
        self.assertTrue(key.startswith("A-delta-20260309-20260309-"))
        self.assertTrue(key.endswith(hashlib.sha256(written).hexdigest()[:8]))
        self.assertIn(b"invite-a-31-20260309", written)
        self.assertNotIn(b"n-n-20260309", written)          # 没变的邀请不重发
        again = self.run_cli()
        self.assertEqual(re.search(r"key-suggestion=(\S+)", again.stdout).group(1), key)

    def test_several_receipt_files_are_merged(self):
        with open(held_file("A"), encoding="utf-8") as handle:
            rows = dict(json.load(handle)[0]["rows"])
        first = write_held({uid: rows[uid] for uid in ("invite-a-31-20260302", "n-n-20260302")})
        second = write_held({uid: rows[uid] for uid in ("invite-a-31-20260309", "n-n-20260309")})
        alone = self.run_cli(held=[first])
        self.assertIn("to-send=2", alone.stdout)            # 单看一份, 另外两条像没签收
        together = self.run_cli(held=[first, second])
        self.assertEqual(together.returncode, 0, together.stderr)
        self.assertIn("held=4", together.stdout)
        self.assertIn("to-send=1", together.stdout)         # 合起来只剩那条改时的

    def test_nothing_to_send_says_so(self):
        done = self.run_cli("--asof", "3")
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertIn("nothing to send", done.stdout)

    def test_a_missing_receipt_file_exits_two(self):
        done = self.run_cli(held=[os.path.join(tempfile.mkdtemp(), "absent.json")])
        self.assertEqual(done.returncode, 2)
        self.assertIn("notify failed", done.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
