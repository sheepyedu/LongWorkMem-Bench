# 6月5日（第5日）收件制度通知 + 通讯表

## 来件 inbox/06-05/通讯签收.txt
“HZ、NP、BA 的解释函发 code.review@office.test，其余解释函和所有维持函发 code.service@office.test，code 取对象客户代码小写。”

## 交 out/通讯.csv（案号,解释邮箱,维持邮箱）
J01 hz.review / hz.service      （对象 HZ-A）
J02 jl.service / jl.service     （JL-B，非 review 名单）
J03 np.review / np.service      （NP-B）
J04 hz.review / hz.service      （HZ-B）
J05 yc.service / yc.service     （YC-A）
J06 qh.service / qh.service     （QH-B）
J07 jl.service / jl.service     （JL-A）
J08 ba.review / ba.service      （BA-B）
J09 qh.service / qh.service     （QH-A）
J10 np.review / np.service      （NP-A）
J11 yc.service / yc.service     （YC-B）
J12 ba.review / ba.service      （BA-A）

## 地址核对
索引.csv 现行发布邮箱 = xx.service@office.test 六条，与脚本生成的 service 信箱一致；服务网点归口亦全部为 xx.service，未变更地址仍有效。
今日未发信（非通知动作日），未改席位。

## 今日柜面状态（与第4日一致，无新变动）
东港 7/8（J01 2、J02 4、J03 1）；西湾 7/7；南站 7/8（J07 4、J08 3、J09 0）；北仓 7/7。

## 未结
1. 第7日排期（只用第7日下班已知材料）；第8日预测沿用8日可查锁定与容量、采用第9日已知授权。
2. 第9日调度：东港/南站各空1席；8 案批文回选（到期日8 的 2011/2021/2041/2051/2071/2081/2101/2111 → 2010/2020/2040/2050/2070/2080/2100/2110）。
3. 第11日异议表用本表邮箱：需调整走解释邮箱，仅询证且开班即达目标走维持邮箱。
4. 上班遗留 4 件（L01–L04）仍未处理。
