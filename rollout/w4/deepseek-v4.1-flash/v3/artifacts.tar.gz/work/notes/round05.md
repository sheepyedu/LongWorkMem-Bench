# 6月5日 交接笔记

## 渠道签发.txt（今日起生效）
- HZ：新发布 hz.new@office.test｜旧件确认 hz.service@office.test｜勘误 hz.review@office.test
- JL：新发布 jl.new@office.test｜旧件确认 jl.service@office.test｜勘误 jl.review@office.test
- 其他四家（NP/YC/QH/BA）：三种职责均由原发布邮箱（xx.service@office.test）负责。
通讯页已按此更新（6 行齐全，HZ、JL 已改）。

## 夜班回条入档（收到日=5）
H10 确认（notes/留档/夜班客户回条-06-05.csv）。收到日晚于4日截点，不得回填“4日回条”列。

## 状态沿用
6/3 首批实占：东港6 西湾7 南站6 北仓6（余 2/2/1/2）；6/4 四封补办均签0，未新增占用。
