import collections, csv, json, pathlib, subprocess, tempfile
root=pathlib.Path('.')
terms=[]
for v in json.loads((root/'project/agreements/guarantee-manifest.json').read_text()):
    terms.extend(csv.DictReader((root/'project/agreements'/v['archive']).open()))
rows=[json.loads(s) for s in (root/'input/guarantees.jsonl').read_text().splitlines() if s.strip()]
expected={'decisions':[], 'posted':[], 'balance':[]}
for cut in (3,6,9):
    ledger={}; seen=set()
    for r in sorted(rows,key=lambda r:(r['day'],r['seq'])):
        if r['day']>cut or r['id'] in seen: continue
        seen.add(r['id']); key=(r['desk'],r['band'])
        active=None
        for w in sorted(terms,key=lambda w:int(w['start'])):
            if (w['desk'],w['band'])==key and int(w['start'])<=r['day']: active=w
        status='posted'
        if active is None or int(active['end'])<r['day']: status='expired'
        elif active['channel']!=r['channel']: status='channel'
        elif r['signer']!='panel-6': status='signature'
        elif ledger.get(key,0)+r['amount']>int(active['limit']): status='capacity'
        if status=='posted':
            ledger[key]=ledger.get(key,0)+r['amount']
            expected['posted'].append([cut,*key,r['id'],r['amount']])
        expected['decisions'].append([cut,r['id'],status])
    expected['balance'].extend([cut,*k,v] for k,v in ledger.items())
actual=json.loads((root/'out/guarantee.json').read_text())
for key in expected: assert sorted(expected[key])==sorted(actual[key]),key
with tempfile.TemporaryDirectory(dir='scratch') as d:
    p=pathlib.Path(d)
    (p/'guarantees.jsonl').write_bytes((root/'input/guarantees.jsonl').read_bytes())
    subprocess.run(['python3',str((root/'project/reserve.py').resolve()),str(p.resolve()),str((p/'result.json').resolve())],cwd='/tmp',check=True)
    assert (p/'result.json').read_bytes()==(root/'out/guarantee.json').read_bytes()
summary={str(cut):{'decisions':dict(collections.Counter(r[2] for r in actual['decisions'] if r[0]==cut)), 'balance_total':sum(r[3] for r in actual['balance'] if r[0]==cut)} for cut in (3,6,9)}
(root/'scratch/guarantee-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
