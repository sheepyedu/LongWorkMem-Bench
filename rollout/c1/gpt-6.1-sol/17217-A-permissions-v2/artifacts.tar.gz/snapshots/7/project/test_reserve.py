import unittest
from reserve import replay, load_terms


class ReserveTests(unittest.TestCase):
    def test_history_and_priority(self):
        windows = [dict(desk='d', band='b', start=1, end=10, channel='a', limit=10),
                   dict(desk='d', band='b', start=4, end=6, channel='b', limit=5)]
        def r(i, day, amount=1, channel='b', signer='s'):
            return dict(id=i, seq=int(i), day=day, desk='d', band='b',
                        amount=amount, channel=channel, signer=signer)
        rows = [r('1', 1, 6, 'a'), r('2', 3, 4, 'a'), r('3', 4),
                r('4', 5, channel='a', signer='bad'), r('5', 6, signer='bad'),
                r('6', 7, channel='a', signer='bad')]
        rows += [rows[0].copy()]
        result = replay(list(reversed(rows)), windows, 's')
        self.assertEqual(result['balance'], [[3, 'd', 'b', 10], [6, 'd', 'b', 10], [9, 'd', 'b', 10]])
        self.assertEqual([r[2] for r in result['decisions'] if r[0] == 9],
                         ['posted', 'posted', 'capacity', 'channel', 'signature', 'expired'])
        self.assertEqual(len(result['posted']), 6)

    def test_archive_and_boundaries(self):
        windows, signer = load_terms()
        self.assertEqual(signer, 'panel-6')
        self.assertEqual(len(windows), 26)
        rows = [dict(id=str(day), seq=day, day=day, desk='ops', band='blue',
                     channel='counter', signer=signer, amount=1) for day in (7, 8, 9)]
        result = replay(rows, windows, signer)
        self.assertEqual(result['decisions'], [[9, '7', 'posted'], [9, '8', 'posted'], [9, '9', 'expired']])
        rows[0]['desk'] = 'unknown'
        self.assertEqual(replay(rows[:1], windows, signer)['decisions'], [[9, '7', 'expired']])
