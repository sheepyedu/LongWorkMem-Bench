"""Independent guarantee ledger. Usage: reserve.py INPUT_DIR OUTPUT_JSON."""
import csv
import hashlib
import json
from pathlib import Path
import sys

AGREEMENTS = Path(__file__).resolve().parent / 'agreements'


def load_terms():
    manifest = json.loads((AGREEMENTS / 'guarantee-manifest.json').read_text())
    windows = []
    for version in manifest:
        raw = (AGREEMENTS / version['archive']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != version['version_sha256']:
            raise ValueError('Archived guarantee notice hash mismatch')
        for row in csv.DictReader(raw.decode('utf-8-sig').splitlines()):
            windows.append({**row, **{k: int(row[k]) for k in ('start', 'end', 'limit')}})
    auth = json.loads((AGREEMENTS / 'standing-authorizations.json').read_text())
    return windows, auth['cross_desk_transfer_revocation']['sole_issuer']


def replay(requests, windows, signer, cuts=(3, 6, 9)):
    result = dict(decisions=[], posted=[], balance=[])
    for cut in cuts:
        seen, balances = set(), {}
        for row in sorted((r for r in requests if r['day'] <= cut),
                          key=lambda r: (r['day'], r['seq'])):
            if row['id'] in seen:
                continue
            seen.add(row['id'])
            key = row['desk'], row['band']
            eligible = [w for w in windows if (w['desk'], w['band']) == key
                        and w['start'] <= row['day']]
            notice = max(eligible, key=lambda w: w['start'], default=None)
            if notice is None or row['day'] > notice['end']:
                status = 'expired'
            elif row['channel'] != notice['channel']:
                status = 'channel'
            elif row['signer'] != signer:
                status = 'signature'
            elif balances.get(key, 0) + row['amount'] > notice['limit']:
                status = 'capacity'
            else:
                status = 'posted'
                balances[key] = balances.get(key, 0) + row['amount']
                result['posted'].append([cut, *key, row['id'], row['amount']])
            result['decisions'].append([cut, row['id'], status])
        result['balance'].extend([cut, *key, value] for key, value in sorted(balances.items()))
    return result


def reserve(input_dir):
    windows, signer = load_terms()
    with (Path(input_dir) / 'guarantees.jsonl').open() as source:
        requests = [json.loads(line) for line in source if line.strip()]
    return replay(requests, windows, signer)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: python3 project/reserve.py INPUT_DIR OUTPUT_JSON')
    Path(sys.argv[2]).write_text(json.dumps(reserve(sys.argv[1]), ensure_ascii=False, indent=2) + '\n')
