"""Replay visible events from the supplied directory; no cross-plan mutable ledger."""
import json
import csv
import sys
from pathlib import Path
from collections import defaultdict


def settle(input_dir, plan):
    aliases = defaultdict(list)
    alias_file = Path(input_dir) / 'aliases.csv'
    if alias_file.exists():
        with alias_file.open(newline='') as stream:
            for row in csv.DictReader(stream):
                aliases[(row['tenant'], row['raw'])].append(
                    (int(row['start']), int(row['end']), row['canon']))
    events = {}
    for file in sorted((Path(input_dir) / 'packets').glob('*.jsonl')):
        for line in file.read_text().splitlines():
            if not line.strip():
                continue
            e = json.loads(line)
            if e['day'] > plan['day'] or e['seq'] > plan['lanes'].get(e['lane'], -1):
                continue
            if e['eid'] in events and events[e['eid']] != e:
                raise ValueError('Conflicting event: ' + e['eid'])
            events[e['eid']] = e
    accounts = {}
    audit = []
    usage = defaultdict(lambda: [0, 0])
    for e in sorted(events.values(), key=lambda e: (e['day'], e['order'])):
        matches = [canon for start, end, canon in aliases[(e['tenant'], e['ticket'])]
                   if start <= e['day'] <= end]
        if len(matches) > 1:
            raise ValueError('Overlapping aliases: ' + e['eid'])
        # One lookup only: canonical identifiers are not recursively resolved.
        key = (e['tenant'], matches[0] if matches else e['ticket'])
        units = e['units']
        if not isinstance(units, int) or units <= 0:
            raise ValueError('Invalid units: ' + e['eid'])
        if e['kind'] == 'credit':
            # Each indivisible unit retains its source ordinal and exact cost.
            lot = accounts.setdefault(key, [])
            for i in range(units):
                cost = (i + 1) * e['cents'] // units - i * e['cents'] // units
                lot.append((e['day'], e['order'], i, e['eid'], cost))
            lot.sort()
            audit.append([e['eid'], 'posted'])
        elif e['kind'] == 'use':
            lot = accounts.get(key, [])
            if len(lot) < units:
                audit.append([e['eid'], 'denied'])
                continue
            for _, _, _, source, cost in lot[:units]:
                row = usage[(e['eid'], source)]
                row[0] += 1
                row[1] += cost
            del lot[:units]
            audit.append([e['eid'], 'posted'])
        else:
            raise ValueError('Unsupported event kind: ' + e['kind'])
    lots = defaultdict(lambda: [0, 0])
    totals = defaultdict(int)
    for (tenant, ticket), lot in accounts.items():
        totals[tenant] += len(lot)
        for _, _, _, source, cost in lot:
            row = lots[(tenant, ticket, source)]
            row[0] += 1
            row[1] += cost
    return {
        'accounts': [[*key, len(lot)] for key, lot in sorted(accounts.items())],
        'audit': audit,
        'totals': [[key, value] for key, value in sorted(totals.items())],
        'lots': [[*key, *value] for key, value in sorted(lots.items())],
        'usage': [[*key, *value] for key, value in sorted(usage.items())],
    }


def main():
    input_dir, plan_file, output_file = sys.argv[1:]
    result = settle(input_dir, json.loads(Path(plan_file).read_text()))
    path = Path(output_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


if __name__ == '__main__':
    main()
