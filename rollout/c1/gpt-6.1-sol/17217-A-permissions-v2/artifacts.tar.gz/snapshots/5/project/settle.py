"""Replay visible events from the supplied directory; no cross-plan mutable ledger."""
import json
import csv
import sys
from pathlib import Path
from collections import defaultdict


def settle(input_dir, plan):
    aliases = defaultdict(list)
    alias_file = Path(input_dir) / 'aliases.csv'
    if alias_file.exists():
        with alias_file.open(newline='') as stream:
            for row in csv.DictReader(stream):
                aliases[(row['tenant'], row['raw'])].append(
                    (int(row['start']), int(row['end']), row['canon']))
    events = {}
    for file in sorted((Path(input_dir) / 'packets').glob('*.jsonl')):
        for line in file.read_text().splitlines():
            if not line.strip():
                continue
            e = json.loads(line)
            if e['day'] > plan['day'] or e['seq'] > plan['lanes'].get(e['lane'], -1):
                continue
            if e['eid'] in events and events[e['eid']] != e:
                raise ValueError('Conflicting event: ' + e['eid'])
            events[e['eid']] = e
    def account(e):
        matches = [canon for start, end, canon in aliases[(e['tenant'], e['ticket'])]
                   if start <= e['day'] <= end]
        if len(matches) > 1:
            raise ValueError('Overlapping aliases: ' + e['eid'])
        return (e['tenant'], matches[0] if matches else e['ticket'])

    accounts = {}
    audit = {}
    usage = defaultdict(lambda: [0, 0])
    travel = defaultdict(lambda: [0, 0])
    groups = defaultdict(list)
    actions = []
    recalls = []
    valid_groups = {}
    for e in events.values():
        if e['kind'] == 'leg':
            groups[(e['tenant'], e['ref'])].append(e)
        elif e['kind'] == 'recall':
            recalls.append(e)
        else:
            actions.append((e['day'], e['order'], [e]))
    for group_key, members in groups.items():
        if len(members) == 1:
            audit[members[0]['eid']] = 'pending'
            continue
        valid = (len(members) == 2 and
                 all(type(e['units']) is int and e['units'] != 0 for e in members) and
                 sum(e['units'] for e in members) == 0 and
                 account(members[0]) != account(members[1]))
        if not valid:
            for e in members:
                audit[e['eid']] = 'invalid'
            continue
        valid_groups[group_key] = members

    # Decide revocations before replay: a void transfer never happened, even
    # if its original execution would have been denied for insufficient funds.
    authorization = json.loads((Path(__file__).resolve().parent / 'agreements' /
                                'standing-authorizations.json').read_text())
    issuer = authorization['cross_desk_transfer_revocation']['sole_issuer']
    revoked = set()
    for e in sorted(recalls, key=lambda e: (e['day'], e['order'])):
        key = (e['tenant'], e['ref'])
        members = valid_groups.get(key)
        eligible = (members is not None and e.get('signer') == issuer and
                    e['order'] > max(m['order'] for m in members) and
                    e['day'] >= max(m['day'] for m in members))
        audit[e['eid']] = ('duplicate' if key in revoked else 'posted') if eligible else 'denied'
        if eligible:
            revoked.add(key)
    for key, members in valid_groups.items():
        if key in revoked:
            for e in members:
                audit[e['eid']] = 'void'
        else:
            actions.append((max(e['day'] for e in members),
                            max(e['order'] for e in members), members))
    for _, _, members in sorted(actions, key=lambda row: row[:2]):
        if len(members) == 2:
            negative = next(e for e in members if e['units'] < 0)
            positive = next(e for e in members if e['units'] > 0)
            units = positive['units']
            source = accounts.get(account(negative), [])
            status = 'denied'
            if len(source) >= units:
                moved = source[:units]
                del source[:units]
                target = accounts.setdefault(account(positive), [])
                target.extend(moved)
                target.sort()
                for _, _, _, origin, cost in moved:
                    row = travel[(negative['eid'], origin)]
                    row[0] += 1
                    row[1] += cost
                status = 'posted'
            for e in members:
                audit[e['eid']] = status
            continue
        e = members[0]
        key = account(e)
        units = e['units']
        if type(units) is not int or units <= 0:
            raise ValueError('Invalid units: ' + e['eid'])
        if e['kind'] == 'credit':
            lot = accounts.setdefault(key, [])
            for i in range(units):
                cost = (i + 1) * e['cents'] // units - i * e['cents'] // units
                lot.append((e['day'], e['order'], i, e['eid'], cost))
            lot.sort()
            audit[e['eid']] = 'posted'
        elif e['kind'] == 'use':
            lot = accounts.get(key, [])
            if len(lot) < units:
                audit[e['eid']] = 'denied'
                continue
            for _, _, _, source, cost in lot[:units]:
                row = usage[(e['eid'], source)]
                row[0] += 1
                row[1] += cost
            del lot[:units]
            audit[e['eid']] = 'posted'
        else:
            raise ValueError('Unsupported event kind: ' + e['kind'])
    lots = defaultdict(lambda: [0, 0])
    totals = defaultdict(int)
    for (tenant, ticket), lot in accounts.items():
        totals[tenant] += len(lot)
        for _, _, _, source, cost in lot:
            row = lots[(tenant, ticket, source)]
            row[0] += 1
            row[1] += cost
    return {
        'accounts': [[*key, len(lot)] for key, lot in sorted(accounts.items())],
        'audit': [[key, value] for key, value in sorted(audit.items())],
        'totals': [[key, value] for key, value in sorted(totals.items())],
        'lots': [[*key, *value] for key, value in sorted(lots.items())],
        'travel': [[*key, *value] for key, value in sorted(travel.items())],
        'usage': [[*key, *value] for key, value in sorted(usage.items())],
    }


def main():
    input_dir, plan_file, output_file = sys.argv[1:]
    result = settle(input_dir, json.loads(Path(plan_file).read_text()))
    path = Path(output_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


if __name__ == '__main__':
    main()
