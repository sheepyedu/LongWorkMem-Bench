import json
import tempfile
import unittest
from pathlib import Path
from settle import settle

class RecallTests(unittest.TestCase):
    def test_replay_and_authority(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); (root/'packets').mkdir()
            def e(eid, kind, order, ticket='a', units=0, day=1, **kw):
                return dict(eid=eid, tenant='t', kind=kind, order=order,
                            ticket=ticket, units=units, day=day, lane='e', seq=order, **kw)
            events = [e('c','credit',1,units=2,cents=5),
                      e('n','leg',2,units=-2,ref='r'),
                      e('p','leg',3,ticket='b',units=2,ref='r'),
                      e('u','use',4,units=2),
                      e('wrong','recall',5,ref='r',signer='other'),
                      e('yes','recall',6,ref='r',signer='panel-6'),
                      e('dup','recall',7,ref='r',signer='panel-6'),
                      e('missing','recall',8,ref='x',signer='panel-6'),
                      e('dn','leg',9,units=-9,ref='d'),
                      e('dp','leg',10,ticket='new',units=9,ref='d'),
                      e('rd','recall',11,ref='d',signer='panel-6'),
                      e('early','recall',12,day=0,ref='r',signer='panel-6')]
            (root/'packets/a.jsonl').write_text('\n'.join(map(json.dumps, events+[events[5]])))
            r = settle(root, {'day':1,'lanes':{'e':99}})
            self.assertEqual(dict(r['audit']),dict(c='posted', n='void',p='void',u='posted',wrong='denied',yes='posted',dup='duplicate',missing='denied',dn='void',dp='void',rd='posted',early='denied'))
            self.assertEqual(r['accounts'],[['t','a',0]])
            self.assertEqual(r['travel'],[])
            self.assertEqual(r['usage'],[['u','c',2,5]])
            before=settle(root, {'day':1,'lanes':{'e':5}})
            self.assertEqual(dict(before['audit'])['u'],'denied')
            self.assertEqual(before['travel'],[['n','c',2,5]])

if __name__ == '__main__': unittest.main()
