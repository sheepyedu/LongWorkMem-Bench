import json
import tempfile
import unittest
from pathlib import Path
from settle import settle

class TransferTests(unittest.TestCase):
    def test_groups_and_costs(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'packets').mkdir()
            def e(eid,ticket,units,order,kind='leg',**kw):
                return dict(eid=eid,tenant='t',ticket=ticket,units=units,day=1,
                            order=order,lane='e',seq=order,kind=kind,dept='t',**kw)
            events=[e('c','a',3,1,'credit',cents=5),
                    e('n','a',-2,2,ref='r'),e('p','b',2,4,ref='r'),
                    e('u','b',1,5,'use'),
                    e('wait','a',-1,6,ref='s'),
                    e('bad1','a',-1,7,ref='bad'),e('bad2','a',1,8,ref='bad'),
                    e('dn','a',-9,9,ref='denied'),e('dp','new',9,10,ref='denied'),
                    e('t1','a',-1,11,ref='three'),e('t2','b',1,12,ref='three'),e('t3','b',1,13,ref='three')]
            (root/'packets/a.jsonl').write_text('\n'.join(map(json.dumps,events+[events[1]])))
            r=settle(folder,{'day':1,'lanes':{'e':99}})
            self.assertEqual(r['travel'],[['n','c',2,3]])
            self.assertEqual(r['usage'],[['u','c',1,1]])
            self.assertEqual(r['lots'],[['t','a','c',1,2],['t','b','c',1,2]])
            self.assertEqual(r['accounts'],[['t','a',1],['t','b',1]])
            audit=dict(r['audit'])
            for key in ['bad1','bad2','t1','t2','t3']:self.assertEqual(audit[key],'invalid')
            for key in ['dn','dp']:self.assertEqual(audit[key],'denied')
            self.assertEqual(audit['wait'],'pending')
            limited=settle(folder,{'day':1,'lanes':{'e':3}})
            self.assertEqual(dict(limited['audit'])['n'],'pending')
            self.assertEqual(limited['travel'],[])

if __name__=='__main__':unittest.main()
