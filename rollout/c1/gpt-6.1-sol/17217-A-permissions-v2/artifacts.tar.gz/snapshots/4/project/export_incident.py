"""Export latest failed scheduler jobs, independently of settlement events."""
import json
import sys
from pathlib import Path


def export(source):
    latest = {}
    for line in Path(source).read_text().splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        key = (row['site'], row['job'])
        rank = (row['attempt'], row['stamp'])
        if key not in latest or rank > (latest[key]['attempt'], latest[key]['stamp']):
            latest[key] = row
        elif rank == (latest[key]['attempt'], latest[key]['stamp']) and row['result'] != latest[key]['result']:
            raise ValueError('Conflicting latest-state records: ' + repr(key))
    return [[site, job, row['attempt']] for (site, job), row in sorted(latest.items())
            if row['result'] == 'failed']


if __name__ == '__main__':
    source, destination = sys.argv[1:]
    result = export(source)
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
