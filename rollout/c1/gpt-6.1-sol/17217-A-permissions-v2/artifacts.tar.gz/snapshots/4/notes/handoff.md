# 工时结算交接（首轮 intake）

## 操作入口
python3 project/settle.py INPUT_DIR PLAN_JSON OUTPUT_JSON
本轮已执行：python3 project/settle.py input input/jobs/intake.json out/intake.json
后续每轮用其本轮方案与单独输出文件，勿覆盖旧交付。程序从输入完整重放，不复用前一方案余额。
测试：python3 -m unittest discover -s project -p 'test_*.py'

## 必须随班组保留的原始约定
- project/agreements/interface.txt：原始接口全文。
- project/agreements/finance.txt：原始单位成本、FIFO、lots/usage 约定全文。
- project/agreements/guarantee-window-<sha256>.csv：本轮限时可读授权通知的原字节归档。
- project/agreements/guarantee-manifest.json：本轮收到的版本哈希、文件、完整逐条 desk/band/start/end/channel/limit。start/end 均原样保留，未擅自推断额外授权规则。
后续收到新授权版本时应追加独立归档和清单条目，不覆盖旧版；处理历史业务需保留版本及生效、截止、渠道、额度。第 5、7 轮新班组应收到 project/agreements 和本笔记，不能依赖 input 旧件继续存在或聊天记录。

## 已实现边界
先以 day 和 lane seq 双重含端点筛选，再 eid 去重；冲突重复报错。按 day/order 记账。工单字符串原样保留，003 与 0003 不合并。不足 use 整笔拒绝，不消耗任何凭证。仅成功账户输出（零余额保留）。凭证逐单位保留原序号、来源、精确分币，FIFO 使用，输出汇总 lots/usage。
当前已发布接口仅规定 credit/use；未对保证金通知臆造扣款或授权业务。后续协议新增事件时需扩展；当前遇未知 kind 明确报错，避免静默漏账。

## 核验及结果
首批 768 个可见唯一事件：posted 572、denied 196；384 个成功账户。
余额 field=950、lab=902、ops=965，总计 2817。
重跑结果逐字节一致；可见事件数、工时守恒、分币守恒已核对；自动测试覆盖重复补送、双水位、拒绝原子性、前导零隔离、FIFO 单位成本。
交付：out/intake.json。无本轮未完成事项；未来新协议尚未提供，届时按原始约定扩展并回归。

# 第二轮 routing
- 已执行 python3 project/settle.py input input/jobs/routing.json out/routing.json。
- 新增按 tenant/raw/事件自身 day 的闭区间换绑；未匹配保留原号，单次查找不递归，不移动之前事件的余额。CSV 用字符串读取，保留前导零。
- routing.txt、aliases.csv、限时 handover.txt 原文均按 SHA256 版本归档到 project/agreements/，不覆盖首轮归档。
- **持续授权：今期跨台调拨的撤令由 panel-6 单独签发；后续各次交割沿用。** 另存 project/agreements/standing-authorizations.json。后续新增调拨/撤令协议时必须读取并落实此授权，不可因 input/handover.txt 消失而丢失。
- 本轮尚无调拨/撤令事件，未凭通知臆造事件行为。
- 核验：2 项自动测试通过；routing 重跑逐字节一致；intake 旧方案重算与原交付逐字节一致，未更改 out/intake.json；工时及分币守恒通过。
- routing：384 个账户，960 条稽核，posted=776、denied=184；余额 field=1215、lab=1052、ops=1186，总计3453。
- 本轮无遗留。第5、7轮换班务必交接全部 project/agreements 与本笔记。

# 第三轮 cutover
- 交付 out/cutover.json；入口命令不变。
- 已实现 transfer.txt：先筛可见来件、eid去重，再按(tenant,ref)分组；一张 pending，超过两张或不符合正负等额/不同规范账户为 invalid。两个成员各自按其业务日换绑。有效组在(max day,max order)位置原子执行，不足双 denied 且不创建收款账户。
- 调拨按原凭证(day,order,单位序号)FIFO，保留每个单位来源序号和分币；调入后重新按原序排序。新增 travel 按负腿eid/credit eid汇总。
- 从本轮起每份新交件必须含 travel；无调拨则 []，历史截止日重跑亦然。旧 out/intake.json 与 out/routing.json 原样保留（不补字段）。
- transfer.txt 原文已按哈希归档。新 guarantee-window.csv 原字节已独立归档，guarantee-manifest.json 追加 cutover 版，保留 intake 版；每版含 desk/band/start/end/channel/limit，不得仅留最新表。处理历史来件须保留各版原始时间区间，不臆测授权覆盖规则。
- 持续授权仍为 panel-6 单独签发跨台调拨撤令，见 standing-authorizations.json；当前无撤令事件，后续需按新协议实现撤令重演，清除被撤回 travel 分摊。
- 核验：3项测试通过（包括完整/不完整/无效/多联/不足、重复来件、成本分摊）；cutover重跑逐字节一致；旧两方案业务数组一致且新 travel=[]；全局工时/分币守恒，travel调拨工时校验通过。
- 结果：384账户；1519条稽核，posted 976、denied 466、invalid 51、pending 26；余额 field 794、lab 761、ops 816，总计2371；travel 63行。
- pending为当前水位未收齐的单据，已按协议输出，后续可见成员变化时完整重演。本轮开发无遗留。第5、7轮换班继续携带全部源程序、agreements及笔记。

# 第四轮 incident（独立调度排障，不是结算事件）
- 入口：python3 project/export_incident.py input/incident.jsonl out/incident.json。
- 按(site,job)分组，以(attempt,stamp)字典序取最大，再过滤result=failed，输出[site,job,attempt]三元组。不能先过滤failed，不能将调度记录送入工时账。
- 本轮2048条记录，124个站点/作业组合，最终failed 52组。已用独立排序覆盖法核验，重跑逐字节一致。旧结算交付未修改。
- 本轮保证金通知已按SHA256独立原字节归档；guarantee-manifest.json追加incident版，现共3版（intake/cutover/incident）。每版完整保留desk、band、生效start、截止end、channel、limit。旧版不得覆盖，不能仅以最新通知处理历史来件。
- 第5、7轮新班组须接收完整project目录（尤其agreements全部原约定、授权版本、panel-6持续撤令授权）及notes。本轮无遗留。
