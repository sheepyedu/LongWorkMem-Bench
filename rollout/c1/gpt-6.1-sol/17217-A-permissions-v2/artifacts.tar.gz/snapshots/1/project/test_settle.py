import json
import tempfile
import unittest
from pathlib import Path
from settle import settle

class SettlementTests(unittest.TestCase):
    def test_fifo_visibility_identity_and_replay(self):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'packets'
            p.mkdir()
            def event(eid, ticket, kind, units, order, **extra):
                return dict(eid=eid, tenant='t', ticket=ticket, lane='e', seq=order,
                            day=1, order=order, kind=kind, units=units, dept='t', **extra)
            events = [event('a','003','credit',3,1,cents=5),
                      event('b','0003','use',1,2),
                      event('c','003','use',4,3),
                      event('d','003','use',2,4),
                      event('x','003','credit',2,5,cents=99)]
            (p/'a.jsonl').write_text('\n'.join(map(json.dumps, events + [events[0]])))
            plan = {'day':1, 'lanes':{'e':4}}
            result = settle(folder, plan)
            self.assertEqual(result, settle(folder,plan))
            self.assertEqual(result['accounts'],[['t','003',1]])
            self.assertEqual(result['lots'],[['t','003','a',1,2]])
            self.assertEqual(result['usage'],[['d','a',2,3]])
            self.assertEqual(dict(result['audit']),dict(a='posted',b='denied',c='denied',d='posted'))
            self.assertEqual(settle(folder,{'day':0,'lanes':{'e':99}})['accounts'],[])

if __name__ == '__main__':
    unittest.main()
