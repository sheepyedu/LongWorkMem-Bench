# 工时结算交接（首轮 intake）

## 操作入口
python3 project/settle.py INPUT_DIR PLAN_JSON OUTPUT_JSON
本轮已执行：python3 project/settle.py input input/jobs/intake.json out/intake.json
后续每轮用其本轮方案与单独输出文件，勿覆盖旧交付。程序从输入完整重放，不复用前一方案余额。
测试：python3 -m unittest discover -s project -p 'test_*.py'

## 必须随班组保留的原始约定
- project/agreements/interface.txt：原始接口全文。
- project/agreements/finance.txt：原始单位成本、FIFO、lots/usage 约定全文。
- project/agreements/guarantee-window-<sha256>.csv：本轮限时可读授权通知的原字节归档。
- project/agreements/guarantee-manifest.json：本轮收到的版本哈希、文件、完整逐条 desk/band/start/end/channel/limit。start/end 均原样保留，未擅自推断额外授权规则。
后续收到新授权版本时应追加独立归档和清单条目，不覆盖旧版；处理历史业务需保留版本及生效、截止、渠道、额度。第 5、7 轮新班组应收到 project/agreements 和本笔记，不能依赖 input 旧件继续存在或聊天记录。

## 已实现边界
先以 day 和 lane seq 双重含端点筛选，再 eid 去重；冲突重复报错。按 day/order 记账。工单字符串原样保留，003 与 0003 不合并。不足 use 整笔拒绝，不消耗任何凭证。仅成功账户输出（零余额保留）。凭证逐单位保留原序号、来源、精确分币，FIFO 使用，输出汇总 lots/usage。
当前已发布接口仅规定 credit/use；未对保证金通知臆造扣款或授权业务。后续协议新增事件时需扩展；当前遇未知 kind 明确报错，避免静默漏账。

## 核验及结果
首批 768 个可见唯一事件：posted 572、denied 196；384 个成功账户。
余额 field=950、lab=902、ops=965，总计 2817。
重跑结果逐字节一致；可见事件数、工时守恒、分币守恒已核对；自动测试覆盖重复补送、双水位、拒绝原子性、前导零隔离、FIFO 单位成本。
交付：out/intake.json。无本轮未完成事项；未来新协议尚未提供，届时按原始约定扩展并回归。
