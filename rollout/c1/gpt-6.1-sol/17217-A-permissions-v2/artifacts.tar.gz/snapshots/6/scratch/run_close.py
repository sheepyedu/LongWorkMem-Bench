import json, hashlib, subprocess, collections
from pathlib import Path
old_names=['intake','routing','cutover']
hashes={n:hashlib.sha256(Path('out/'+n+'.json').read_bytes()).hexdigest() for n in old_names}
subprocess.run(['python3','-m','unittest','discover','-s','project','-p','test_*.py'],check=True)
all_events=[]
for f in Path('input/packets').glob('*.jsonl'):
 all_events.extend(json.loads(l) for l in f.read_text().splitlines() if l.strip())
reports=[]
for planfile in [Path('input/jobs/close.json')]+sorted(Path('input/jobs').glob('archive-*.json')):
 name=planfile.stem; output=Path('out')/(name+'.json')
 subprocess.run(['python3','project/settle.py','input',str(planfile),str(output)],check=True)
 repeat=Path('scratch')/(name+'-repeat.json')
 subprocess.run(['python3','project/settle.py','input',str(planfile),str(repeat)],check=True)
 assert output.read_bytes()==repeat.read_bytes()
 r=json.loads(output.read_text());p=json.loads(planfile.read_text())
 es={e['eid']:e for e in all_events if e['day']<=p['day'] and e['seq']<=p['lanes'].get(e['lane'],-1)}
 assert set(dict(r['audit']))==set(es)
 credits={e['eid']:(e['units'],e['cents']) for e in es.values() if e['kind']=='credit'}
 accounted=collections.defaultdict(lambda:[0,0])
 for t,a,c,u,v in r['lots']: accounted[c][0]+=u;accounted[c][1]+=v
 for use,c,u,v in r['usage']: accounted[c][0]+=u;accounted[c][1]+=v
 assert {k:tuple(v) for k,v in accounted.items()}==credits
 totals=collections.Counter()
 for t,a,u in r['accounts']:totals[t]+=u
 assert dict(totals)==dict(r['totals'])
 assert not ({x[0] for x in r['travel']} & {k for k,v in r['audit'] if v=='void'})
 reports.append(dict(plan=name,accounts=len(r['accounts']),audit=len(r['audit']),statuses=dict(collections.Counter(dict(r['audit']).values())),totals=r['totals'],travel=len(r['travel'])))
for name in old_names:
 target=Path('scratch')/(name+'-final-source.json')
 subprocess.run(['python3','project/settle.py','input','input/jobs/'+name+'.json',str(target)],check=True)
 old=json.loads(Path('out/'+name+'.json').read_text());new=json.loads(target.read_text())
 assert all(sorted(new[k])==sorted(v) for k,v in old.items()),name
 assert hashlib.sha256(Path('out/'+name+'.json').read_bytes()).hexdigest()==hashes[name]
Path('scratch/close-verification.json').write_text(json.dumps(dict(results=reports,sealed_sha256=hashes),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(reports,ensure_ascii=False,indent=2))
print('All checks passed; sealed original files unchanged.')
