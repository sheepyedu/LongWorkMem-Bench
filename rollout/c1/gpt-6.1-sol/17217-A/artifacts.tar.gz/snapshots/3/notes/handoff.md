# 工时结账交接（第 5、7 轮新班组必读）
入口：python3 project/settle.py INPUT_DIR PLAN_JSON OUTPUT_JSON
首批：python3 project/settle.py input input/jobs/intake.json out/intake.json
程序无跨方案余额缓存，每轮从原始 packets 重算。旧输出不得混合或覆盖；同方案复跑一致则保持文件不变，不同结果请使用新的输出路径。

## 必须随工作文件移交的原始约定
project/contracts/interface.txt、finance.txt 为原始全文；intake-plan.json 为首批方案。
project/contracts/guarantee-window-*.csv 为首批保证金通知原件（SHA256 内容寻址）。
project/contracts/versions/ 每次执行保留输入根目录所有 txt 及 guarantee-window.csv 的每个不同版本。不可清理旧版或仅保留最新版本。
保证金原件保留 desk、band、start、end、channel、limit 全部字段，不能把不同分组覆盖成一张当前表。未来历史来件须结合届时发布的协议解释生效及截止、渠道、额度，不能以最后收到的版本直接替代历史授权。本轮没有保证金记账或换绑协议，不能凭该表推断额外处置。后续新协议/事件种类须扩展程序后结算；未知种类会明确报错，不能静默忽略。

## 已实现的口径
双水位筛选后 eid 去重；冲突重复报错；按 day、order 处理。工单字符串原样保留，tenant 隔离。余额不足整笔拒绝；成功账户零余额保留。
成本逐原凭证单位按 floor 差值分配，FIFO 按原 day、order、单位序号；lots、usage 按约定键汇总。
当前只有 credit/use；尚无调拨或换绑协议，不自行设计。后续若引入调拨必须保留单位原始序号与成本。

## 首批核验
768 个可见唯一事件，posted 572、denied 196，384 个账户。
余额合计 field=950、lab=902、ops=965。
业务入口连续执行两次一致；独立余额重算与审计逐条一致；剩余单位守恒、总分币（剩余+耗用）守恒通过。
后续每轮仍需保留输入原始 packets、计划及交付，以便历史重跑；不能只交余额快照。

## routing 轮更新
交付 out/routing.json；入口保持不变。新增 aliases.csv 解析，按 tenant/raw 和事件自己的 day 匹配闭区间，单次映射不递归，未匹配保留原号。不重命名此前已记账余额。
原始 routing.txt、aliases.csv、routing-plan.json、handover.txt 已保存在 project/contracts；versions 归档已扩展为每轮保留所有根目录 txt/csv 的不同内容版本。
**后续持续有效的授权原文：今期跨台调拨的撤令由 panel-6 单独签发；后续各次交割沿用。** 该授权不是 credit/use 规则，本轮没有撤令事件；未来处理撤令务必执行此签发限制，不可因 input/handover.txt 消失而丢失。
核验：960 个可见唯一事件，posted 776、denied 184，384 个账户；余额 field=1215、lab=1052、ops=1186。独立按事件日映射的余额与审计重算一致，成本和单位守恒；业务入口复跑一致。project/test_routing.py 覆盖闭区间端点、阶段变化、未匹配、tenant 隔离、不递归和重复补送，通过。
旧 out/intake.json 未改写，SHA256=0d7269371d82057f3774cdf8f37112e6b09eda8561154e6b3dfae9f5528016d3。

## 第 3 轮 cutover 调拨上线
新增 transfer.txt 原约定见 project/contracts/transfer.txt，全部通知版本继续存于 contracts/versions/。本轮 guarantee-window.csv 已按 SHA256 新增版本，旧版仍保留；每版原件含 desk/band/start/end/channel/limit，不能覆盖旧版授权。
leg 按可见 (tenant,ref) 分组，独张 pending，多张或不合约 invalid；合约双张各按自己的业务日解析别名，在 (最大day,最大order) 原子入账。失败不建收款账户。FIFO 调拨保留原单位序号和成本；travel 以负腿 eid 汇总。
从本轮起新交付均有 travel，包括新跑的历史截止方案（无调拨为空数组）。既有 out/intake.json、out/routing.json 未改动。未来撤回需重演，不能保留撤回调拨的 travel；panel-6 单独签发撤令的原始 handover.txt 仍存 contracts，不可遗漏。
测试：python3 -m unittest discover -s project -p 'test*.py'；已覆盖换绑边界、非递归、租户隔离、双联可见性、原子时点、FIFO 成本、invalid/pending/denied、失败不建户。
