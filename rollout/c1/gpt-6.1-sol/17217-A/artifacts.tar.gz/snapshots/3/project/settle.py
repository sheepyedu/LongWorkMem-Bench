"""Stateless reconciliation; see contracts/ for preserved source agreements."""
import collections
import csv
import glob
import hashlib
from pathlib import Path
import json
import os
import sys


def settle(input_dir, plan):
    aliases = collections.defaultdict(list)
    alias_path = Path(input_dir) / 'aliases.csv'
    if alias_path.exists():
        with alias_path.open(encoding='utf-8', newline='') as source:
            for row in csv.DictReader(source):
                aliases[(row['tenant'], row['raw'])].append(
                    (int(row['start']), int(row['end']), row['canon']))

    def canonical(tenant, ticket, day):
        matches = [canon for start, end, canon in aliases[(tenant, ticket)]
                   if start <= day <= end]
        if len(matches) > 1:
            raise ValueError('Overlapping alias registration: ' + repr((tenant, ticket, day)))
        return matches[0] if matches else ticket

    events = {}
    for path in sorted(glob.glob(os.path.join(input_dir, 'packets', '*.jsonl'))):
        with open(path, encoding='utf-8') as source:
            for line in source:
                if not line.strip():
                    continue
                event = json.loads(line)
                if event['lane'] not in plan['lanes'] or event['seq'] > plan['lanes'][event['lane']] or event['day'] > plan['day']:
                    continue
                eid = event['eid']
                if eid in events and events[eid] != event:
                    raise ValueError('Conflicting visible eid: ' + eid)
                events[eid] = event
    def account(e):
        return (e['tenant'], canonical(e['tenant'], e['ticket'], e['day']))

    accounts = {}
    dispositions = {}
    usage = collections.defaultdict(lambda: [0, 0])
    travel = collections.defaultdict(lambda: [0, 0])
    groups = collections.defaultdict(list)
    actions = []
    for e in events.values():
        if e['kind'] == 'leg':
            groups[(e['tenant'], e['ref'])].append(e)
        else:
            actions.append((e['day'], e['order'], [e]))
    for members in groups.values():
        if len(members) == 1:
            dispositions[members[0]['eid']] = 'pending'
            continue
        valid = (len(members) == 2
                 and all(isinstance(e['units'], int) and not isinstance(e['units'], bool) for e in members)
                 and members[0]['units'] * members[1]['units'] < 0
                 and members[0]['units'] + members[1]['units'] == 0
                 and account(members[0]) != account(members[1]))
        if not valid:
            for e in members:
                dispositions[e['eid']] = 'invalid'
            continue
        actions.append((max(e['day'] for e in members),
                        max(e['order'] for e in members), members))

    def record(table, eid, units):
        for unit in units:
            agg = table[(eid, unit[3])]
            agg[0] += 1
            agg[1] += unit[4]

    for _, _, members in sorted(actions, key=lambda a: (a[0], a[1])):
        e = members[0]
        if e['kind'] == 'leg':
            negative = next(x for x in members if x['units'] < 0)
            positive = next(x for x in members if x['units'] > 0)
            source = accounts.get(account(negative), [])
            units = positive['units']
            if len(source) < units:
                status = 'denied'
            else:
                moved = source[:units]
                del source[:units]
                destination = accounts.setdefault(account(positive), [])
                destination.extend(moved)
                destination.sort()
                record(travel, negative['eid'], moved)
                status = 'posted'
            for member in members:
                dispositions[member['eid']] = status
            continue
        key = account(e)
        units = e['units']
        if not isinstance(units, int) or isinstance(units, bool) or units <= 0:
            raise ValueError('Invalid units: ' + e['eid'])
        if e['kind'] == 'credit':
            lot = accounts.setdefault(key, [])
            for i in range(units):
                cost = ((i + 1) * e['cents']) // units - (i * e['cents']) // units
                lot.append((e['day'], e['order'], i, e['eid'], cost))
            lot.sort()
            dispositions[e['eid']] = 'posted'
        elif e['kind'] == 'use':
            lot = accounts.get(key, [])
            if len(lot) < units:
                dispositions[e['eid']] = 'denied'
                continue
            record(usage, e['eid'], lot[:units])
            del lot[:units]
            dispositions[e['eid']] = 'posted'
        else:
            raise ValueError('Unsupported event kind: ' + e['kind'])
    lots = collections.defaultdict(lambda: [0, 0])
    totals = collections.defaultdict(int)
    for (tenant, ticket), lot in accounts.items():
        totals[tenant] += len(lot)
        for unit in lot:
            agg = lots[(tenant, ticket, unit[3])]
            agg[0] += 1
            agg[1] += unit[4]
    return {
        'accounts': [[*key, len(lot)] for key, lot in sorted(accounts.items())],
        'audit': [[eid, status] for eid, status in sorted(dispositions.items())],
        'totals': [[tenant, total] for tenant, total in sorted(totals.items())],
        'lots': [[*key, *value] for key, value in sorted(lots.items())],
        'travel': [[*key, *value] for key, value in sorted(travel.items())],
        'usage': [[*key, *value] for key, value in sorted(usage.items())],
    }


def main():
    input_dir, plan_path, output_path = sys.argv[1:]
    # Preserve every supplied revision verbatim, independently of business dates.
    archive = Path(__file__).resolve().parent / 'contracts' / 'versions'
    archive.mkdir(parents=True, exist_ok=True)
    sources = list(Path(input_dir).glob('*.txt')) + list(Path(input_dir).glob('*.csv'))
    for path in sources:
        raw = path.read_bytes()
        dest = archive / (path.name + '.' + hashlib.sha256(raw).hexdigest())
        if not dest.exists():
            dest.write_bytes(raw)
    with open(plan_path, encoding='utf-8') as source:
        result = settle(input_dir, json.load(source))
    # Never overwrite a different historical delivery.
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if os.path.exists(output_path):
        with open(output_path, encoding='utf-8') as source:
            if json.load(source) != result:
                raise ValueError('Refusing to replace a different delivery: ' + output_path)
        return
    with open(output_path, 'x', encoding='utf-8') as target:
        target.write(encoded)


if __name__ == '__main__':
    main()
