import json
import tempfile
import unittest
from pathlib import Path
from settle import settle

class TransferTest(unittest.TestCase):
    def test_atomic_visibility_fifo(self):
        with tempfile.TemporaryDirectory(dir='scratch') as tmp:
            p=Path(tmp);(p/'packets').mkdir()
            events=[]
            def add(eid, day, order, kind, ticket, units, **kw):
                events.append(dict(eid=eid,day=day,order=order,kind=kind,ticket=ticket,units=units,tenant='t',lane='e',seq=order,dept='t',**kw))
            add('c',1,1,'credit','A',3,cents=5)
            add('neg',2,2,'leg','A',-2,ref='r')
            add('u-before',2,3,'use','B',1)
            add('pos',3,4,'leg','B',2,ref='r')
            add('u-after',3,5,'use','B',1)
            add('bad1',4,6,'leg','A',-1,ref='bad')
            add('bad2',4,7,'leg','A',1,ref='bad')
            add('deny1',4,8,'leg','A',-2,ref='deny')
            add('deny2',4,9,'leg','C',2,ref='deny')
            add('pending',4,10,'leg','C',1,ref='pending')
            (p/'packets'/'a.jsonl').write_text('\n'.join(map(json.dumps,events)))
            r=settle(tmp,{'day':4,'lanes':{'e':10}})
            self.assertEqual(r['accounts'],[['t','A',1],['t','B',1]])
            self.assertEqual(r['travel'],[['neg','c',2,3]])
            self.assertEqual(r['usage'],[['u-after','c',1,1]])
            a=dict(r['audit'])
            for eid in ['bad1','bad2']:self.assertEqual(a[eid],'invalid')
            for eid in ['deny1','deny2','u-before']:self.assertEqual(a[eid],'denied')
            self.assertEqual(a['pending'],'pending')
            early=settle(tmp,{'day':2,'lanes':{'e':10}})
            self.assertEqual(dict(early['audit'])['neg'],'pending')
            self.assertEqual(early['travel'],[])
