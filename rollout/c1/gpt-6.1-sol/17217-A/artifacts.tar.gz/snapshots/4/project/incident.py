"""Independent scheduler incident export: attempt dominates stamp."""
import json
import sys


def export(source):
    latest = {}
    for line in source:
        if not line.strip():
            continue
        row = json.loads(line)
        key = (row['site'], row['job'])
        rank = (row['attempt'], row['stamp'])
        old = latest.get(key)
        if old is None or rank > (old['attempt'], old['stamp']):
            latest[key] = row
        elif rank == (old['attempt'], old['stamp']) and row['result'] != old['result']:
            raise ValueError('Conflicting state at identical attempt/stamp: ' + repr(key))
    return [[site, job, row['attempt']] for (site, job), row in sorted(latest.items())
            if row['result'] == 'failed']


if __name__ == '__main__':
    with open(sys.argv[1], encoding='utf-8') as source:
        result = export(source)
    with open(sys.argv[2], 'w', encoding='utf-8') as target:
        json.dump(result, target, ensure_ascii=False, indent=2)
        target.write('\n')
