"""Stateless reconciliation; see contracts/ for preserved source agreements."""
import collections
import glob
import hashlib
from pathlib import Path
import json
import os
import sys


def settle(input_dir, plan):
    events = {}
    for path in sorted(glob.glob(os.path.join(input_dir, 'packets', '*.jsonl'))):
        with open(path, encoding='utf-8') as source:
            for line in source:
                if not line.strip():
                    continue
                event = json.loads(line)
                if event['lane'] not in plan['lanes'] or event['seq'] > plan['lanes'][event['lane']] or event['day'] > plan['day']:
                    continue
                eid = event['eid']
                if eid in events and events[eid] != event:
                    raise ValueError('Conflicting visible eid: ' + eid)
                events[eid] = event
    accounts = {}
    audit = []
    usage = collections.defaultdict(lambda: [0, 0])
    for e in sorted(events.values(), key=lambda e: (e['day'], e['order'])):
        key = (e['tenant'], e['ticket'])
        units = e['units']
        if not isinstance(units, int) or isinstance(units, bool) or units <= 0:
            raise ValueError('Invalid units: ' + e['eid'])
        if e['kind'] == 'credit':
            # Individual units preserve original index, FIFO priority and exact cost.
            lot = accounts.setdefault(key, [])
            for i in range(units):
                cost = ((i + 1) * e['cents']) // units - (i * e['cents']) // units
                lot.append((e['day'], e['order'], i, e['eid'], cost))
            lot.sort()
            audit.append([e['eid'], 'posted'])
        elif e['kind'] == 'use':
            lot = accounts.get(key, [])
            if len(lot) < units:
                audit.append([e['eid'], 'denied'])
                continue
            for unit in lot[:units]:
                agg = usage[(e['eid'], unit[3])]
                agg[0] += 1
                agg[1] += unit[4]
            del lot[:units]
            audit.append([e['eid'], 'posted'])
        else:
            raise ValueError('Unsupported event kind: ' + e['kind'])
    lots = collections.defaultdict(lambda: [0, 0])
    totals = collections.defaultdict(int)
    for (tenant, ticket), lot in accounts.items():
        totals[tenant] += len(lot)
        for unit in lot:
            agg = lots[(tenant, ticket, unit[3])]
            agg[0] += 1
            agg[1] += unit[4]
    return {
        'accounts': [[*key, len(lot)] for key, lot in sorted(accounts.items())],
        'audit': audit,
        'totals': [[tenant, total] for tenant, total in sorted(totals.items())],
        'lots': [[*key, *value] for key, value in sorted(lots.items())],
        'usage': [[*key, *value] for key, value in sorted(usage.items())],
    }


def main():
    input_dir, plan_path, output_path = sys.argv[1:]
    # Preserve every supplied revision verbatim, independently of business dates.
    archive = Path(__file__).resolve().parent / 'contracts' / 'versions'
    archive.mkdir(parents=True, exist_ok=True)
    sources = list(Path(input_dir).glob('*.txt')) + list(Path(input_dir).glob('guarantee-window.csv'))
    for path in sources:
        raw = path.read_bytes()
        dest = archive / (path.name + '.' + hashlib.sha256(raw).hexdigest())
        if not dest.exists():
            dest.write_bytes(raw)
    with open(plan_path, encoding='utf-8') as source:
        result = settle(input_dir, json.load(source))
    # Never overwrite a different historical delivery.
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if os.path.exists(output_path):
        with open(output_path, encoding='utf-8') as source:
            if json.load(source) != result:
                raise ValueError('Refusing to replace a different delivery: ' + output_path)
        return
    with open(output_path, 'x', encoding='utf-8') as target:
        target.write(encoded)


if __name__ == '__main__':
    main()
