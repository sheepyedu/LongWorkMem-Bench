# 工时结账交接（第 5、7 轮新班组必读）
入口：python3 project/settle.py INPUT_DIR PLAN_JSON OUTPUT_JSON
首批：python3 project/settle.py input input/jobs/intake.json out/intake.json
程序无跨方案余额缓存，每轮从原始 packets 重算。旧输出不得混合或覆盖；同方案复跑一致则保持文件不变，不同结果请使用新的输出路径。

## 必须随工作文件移交的原始约定
project/contracts/interface.txt、finance.txt 为原始全文；intake-plan.json 为首批方案。
project/contracts/guarantee-window-*.csv 为首批保证金通知原件（SHA256 内容寻址）。
project/contracts/versions/ 每次执行保留输入根目录所有 txt 及 guarantee-window.csv 的每个不同版本。不可清理旧版或仅保留最新版本。
保证金原件保留 desk、band、start、end、channel、limit 全部字段，不能把不同分组覆盖成一张当前表。未来历史来件须结合届时发布的协议解释生效及截止、渠道、额度，不能以最后收到的版本直接替代历史授权。本轮没有保证金记账或换绑协议，不能凭该表推断额外处置。后续新协议/事件种类须扩展程序后结算；未知种类会明确报错，不能静默忽略。

## 已实现的口径
双水位筛选后 eid 去重；冲突重复报错；按 day、order 处理。工单字符串原样保留，tenant 隔离。余额不足整笔拒绝；成功账户零余额保留。
成本逐原凭证单位按 floor 差值分配，FIFO 按原 day、order、单位序号；lots、usage 按约定键汇总。
当前只有 credit/use；尚无调拨或换绑协议，不自行设计。后续若引入调拨必须保留单位原始序号与成本。

## 首批核验
768 个可见唯一事件，posted 572、denied 196，384 个账户。
余额合计 field=950、lab=902、ops=965。
业务入口连续执行两次一致；独立余额重算与审计逐条一致；剩余单位守恒、总分币（剩余+耗用）守恒通过。
后续每轮仍需保留输入原始 packets、计划及交付，以便历史重跑；不能只交余额快照。
