import json
import tempfile
import unittest
from pathlib import Path
from settle import settle


class RoutingTest(unittest.TestCase):
    def test_event_day_nonrecursive_and_tenant(self):
        with tempfile.TemporaryDirectory(dir='scratch') as tmp:
            p = Path(tmp)
            (p / 'packets').mkdir()
            (p / 'aliases.csv').write_text('tenant,raw,start,end,canon\nops,D,2,5,0003\nops,D,6,12,003\nops,003,1,12,X\n')
            events = []
            for i, (tenant, day) in enumerate([('ops', 1), ('ops', 2), ('ops', 5), ('ops', 6), ('ops', 12), ('ops', 13), ('lab', 6)], 1):
                events.append(dict(eid=str(i), tenant=tenant, ticket='D', lane='e', seq=i, day=day, order=i, kind='credit', units=1, cents=i, dept=tenant))
            # Exact resend must not create another credit.
            (p / 'packets' / 'a.jsonl').write_text('\n'.join(json.dumps(e) for e in events + events[:1]))
            r = settle(tmp, {'day': 13, 'lanes': {'e': 7}})
            self.assertEqual(r['accounts'], [['lab', 'D', 1], ['ops', '0003', 2], ['ops', '003', 2], ['ops', 'D', 2]])
            self.assertEqual(len(r['audit']), 7)
            early = settle(tmp, {'day': 5, 'lanes': {'e': 7}})
            self.assertEqual(early['accounts'], [['ops', '0003', 2], ['ops', 'D', 1]])


if __name__ == '__main__':
    unittest.main()
