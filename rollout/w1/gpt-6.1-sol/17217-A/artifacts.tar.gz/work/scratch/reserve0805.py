import csv,collections,re
from decimal import Decimal as D,InvalidOperation
from pathlib import Path
import json,shutil
def read(p):return list(csv.DictReader(open(p)))
jobs=json.load(open('notes/放行0805/planned.json'));receipts=['','M-11875087a4574288','D-0ff4558b7e3e4063','D-eff8a88736924ca2','M-bddceae4de4a46e6','M-dbfce99eecf04f7f','D-c8a4f63aec05492a']
with open('out/dispatch.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow('packet,review_draft,decision,recipient,receipt'.split(','))
 for j,receipt in zip(jobs,receipts):w.writerow([j['packet'],j['review_draft'],j['action'],j['recipient'] if j['action']!='HOLD' else '',receipt])
au={(r['project'],r['case']):r for r in read('notes/常2622.csv')}
yesterday=collections.defaultdict(list)
for r in read('out/reserve/2025-08-04.csv'):yesterday[r['office'],r['case']].append(r['target'])
def prior(key):
 vals=yesterday[key]
 if len(vals)!=1:return D(0)
 try:
  v=D(vals[0])
  return v if v.is_finite() and v>=0 and v==v.quantize(D('.01')) else D(0)
 except (InvalidOperation,ValueError):return D(0)
count=collections.Counter();total=change=D(0)
with open('out/reserve/2025-08-05.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow('office,case,project,desk,authority,decision,target,change'.split(','));seen=set()
 for r in read('input/资金运营/争议清册/2025-08-05.csv'):
  key=r['office'],r['case'];assert key not in seen;seen.add(key)
  p=r['project']
  if p=='共享':p='乙' if r['worked']>='2025-07-16' else '甲'
  a=au[p,r['kind']];ok=D(r['amount'])<=D(a['limit']);v=D(r['amount']) if ok else D(0);delta=v-prior(key)
  decision='BOOK' if ok else 'HOLD';count[decision]+=1;total+=v;change+=delta
  w.writerow([*key,p,a['desk'],a['authority'],decision,format(v,'.2f'),format(delta,'.2f')])
print('reserve',dict(count),'target',total,'change',change)
for p in ['out/settlement.csv','out/dispatch.csv','out/reserve/2025-08-04.csv','out/reserve/2025-08-05.csv','input/资金运营/签报流水.csv','input/资金运营/早班直联流水.csv','input/资金运营/晨间卡务签件.csv','inbox/OPS-0805.eml','inbox/AP-0805.eml']:
 shutil.copyfile(p,'notes/放行0805/'+Path(p).name)
# 核验截止归档：历史附件不改写，不补发
shutil.copytree('out/verify','notes/放行0805/verify',dirs_exist_ok=True);shutil.copyfile('out/verify_index.csv','notes/放行0805/verify_index.csv')
Path('notes/放行0805/结果说明.txt').write_text('封单2025-08-05 09:00。FIN第2版财务放行缺同版内控签发，HOLD。JA第2版放行，沿原JA-D草稿收件人及原附件投递。YI第2版财务换岗RELIEF，按当日邮箱重拟，待签。B01原包可足额照发，新增余额另拟-extra待批；B02原包照发；B03新增到账及E03生效卡务导致原包需整包撤下，现额-replace重拟待批。所有原附件保留原字节。dispatch.csv真实回执和草稿号已登记。\n8月5日争议预留：临时代办到期，两库均按常2622，停8228到期恢复。change逐库逐件扣8月4日实际申报中唯一、有效、非负分币target；缺件、重复及无效额按0，不覆盖昨日。\n三次核验窗口实际附件及累计真实回执已归档，未补发旧函。六月首询两封附件混有两库数据，已在7月续核依补救条款prior留空分库发出；历史越库披露仍需内控跟进，原件如实保留。\n')
