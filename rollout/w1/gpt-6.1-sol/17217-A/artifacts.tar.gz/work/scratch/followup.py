import csv,collections
from decimal import Decimal as D
def read(p):return list(csv.DictReader(open(p)))
auth={(r['project'],r['case']):r for r in read('notes/常2622.csv')}
counts=collections.Counter();total=D(0)
with open('out/reserve/2025-07-08.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow('office,case,project,desk,authority,decision,target,change'.split(','))
 for r in read('input/资金运营/争议清册/2025-07-08.csv'):
  project=r['project']
  if project=='共享':project='乙' if r['worked']>='2025-07-16' else '甲'
  a=auth[project,r['kind']];desk=a['desk'];authority=a['authority'];limit=D(a['limit'])
  if project=='乙' and r['kind']=='待清':desk='岗2943';authority='代8337';limit=D(150)
  amount=D(r['amount']);ok=amount<=limit;target=amount if ok else D(0);decision='BOOK' if ok else 'HOLD';counts[decision]+=1;total+=target
  w.writerow([r['office'],r['case'],project,desk,authority,decision,format(target,'.2f'),format(target,'.2f')])
print('reserve',dict(counts),'total',total)
# 审核实际首询附件：前函混入其他库区，故不符合“只附本库区”的有效首询条件，本次补救 prior 留空。
answers={}
for r in read('input/核验往来/供应商补件回函.csv'):
 if r['status']=='签发' and r['effective']<='2025-07-08':
  k=(r['site'],r['id'])
  if k not in answers or int(r['revision'])>int(answers[k]['revision']):answers[k]=r
for site in ['江北','西港']:
 original={r['id']:r for r in read('out/verify/首询-'+site+'.csv') if r['site']==site}
 with open('out/verify/续核-'+site+'.csv','w',newline='') as f:
  w=csv.writer(f);w.writerow(['prior','site','id','po','line'])
  for id,r in original.items():
   if answers.get((site,id),{}).get('action','继续')=='继续':w.writerow(['',site,id,r['po'],r['line']])
