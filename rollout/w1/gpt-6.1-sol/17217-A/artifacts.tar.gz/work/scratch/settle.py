import csv,collections,json,openpyxl
from decimal import Decimal as D
from pathlib import Path
def read(p):return list(csv.DictReader(open(p)))
def sheet(p,s):
 v=list(openpyxl.load_workbook(p,data_only=True)[s].values);return [dict(zip(v[0],r)) for r in v[1:]]
def write(p,h,rs):
 with open(p,'w',newline='') as f:w=csv.writer(f);w.writerow(h.split(','));w.writerows(rs)
cut='2025-08-04 17:00';day='2025-08-04'
accounts=sheet('input/资金运营/运营主数据.xlsx','代付账户');channels={r['employee']:r['channel'] for r in sheet('input/资金运营/支付直联.xlsx','分行通道')}
legacy={r['legacy']:r['employee'] for r in read('input/资金运营/旧系统迁移索引.csv') if r['approval']=='签发'}
for r in accounts:
 if r['approval']=='签发':legacy[r['account']]=r['employee']
latest={}
for r in read('input/资金运营/垫付直联流水.csv'):
 if r['approval']=='确认' and r['stamp']<=cut:
  k=r['bank'],r['ref']
  if k not in latest or int(r['revision'])>int(latest[k]['revision']):latest[k]=r
paid=collections.defaultdict(D);reserved=collections.defaultdict(D)
for k,r in latest.items():
 if r['kind']=='付款' and r['period']=='2025-07':
  e=legacy[r['account']]
  if r['state']=='到账':paid[e]+=D(r['amount'])
  elif r['state']=='在途':reserved[e]+=D(r['amount'])
 if r['kind']=='退回' and r['state']=='到账':
  old=latest.get((r['bank'],r['original']))
  if old and old['kind']=='付款' and old['period']=='2025-07' and old['state']=='到账':paid[legacy[old['account']]]-=D(r['amount'])
gross=collections.defaultdict(D);pay=read('out/pay.csv')
for r in pay:gross[r['employee']]+=D(r['bonus'])
current={}
for r in accounts:
 if r['approval']=='签发' and r['effective']<=day:
  e=r['employee']
  if e not in current or (r['effective'],int(r['revision']))>(current[e]['effective'],int(current[e]['revision'])):current[e]=r
settlement=[];packages=collections.defaultdict(list)
for e,g in sorted(gross.items()):
 a=current[e];v=max(D(0),g-paid[e]-reserved[e]) if a['state']=='正常' else D(0)
 settlement.append([e,channels[e],a['account'],g,paid[e],reserved[e],v])
 if v>0:packages[channels[e]].append([a['account'],v])
write('out/settlement.csv','employee,channel,account,gross,paid,reserved,payable',settlement)
for b in ['B01','B02','B03']:write('out/dispatch/'+b+'.csv','account,bonus',packages[b])
for p,name in [('甲','jia'),('乙','yi')]:
 rr=[r for r in pay if r['project']==p];write('out/dispatch/'+name+'.csv','project,period,hours,bonus',[[p,'2025-07',sum(D(r['hours']) for r in rr),sum(D(r['bonus']) for r in rr)]])
slots={}
for r in sheet('input/资金运营/运营主数据.xlsx','岗位邮箱登记'):
 if r['approval']=='签发' and r['valid_from']<=day<=r['valid_to']:
  k=r['slot']
  if k not in slots or int(r['revision'])>int(slots[k]['revision']):slots[k]=r

for r in sheet('input/资金运营/支付直联.xlsx','资金岗'):slots[r['channel']]={'mailbox':r['mailbox']}
jobs=[]
for r in read('input/资金运营/送审工单.csv'):
 slot='JA-D' if r['slot']=='JA' else r['slot'];jobs.append({**r,'recipient':slots[slot]['mailbox'],'subject':'/'.join(r[k] for k in ['batch','packet','purpose'])})
json.dump(jobs,open('notes/送审0804/jobs.json','w'),ensure_ascii=False,indent=2)
# 独立本轮预留，停办优先，办理日权限与实际工作日归属分开
au={(r['project'],r['case']):r for r in read('notes/常2622.csv')};out=[];counts=collections.Counter()
for r in read('input/资金运营/争议清册/2025-08-04.csv'):
 p=r['project']
 if p=='共享':p='乙' if r['worked']>='2025-07-16' else '甲'
 a=au[p,r['kind']];desk=a['desk'];authority=a['authority'];limit=D(a['limit'])
 if r['office']=='南港' and p=='乙' and r['kind']=='待清':desk='岗2943';authority='代8337';limit=D(150)
 ok=D(r['amount'])<=limit
 if r['vendor']=='栩新':desk='IC-01';authority='停8228';ok=False
 target=D(r['amount']) if ok else D(0);counts['BOOK' if ok else 'HOLD']+=1
 out.append([r['office'],r['case'],p,desk,authority,'BOOK' if ok else 'HOLD',format(target,'.2f'),format(target,'.2f')])
write('out/reserve/2025-08-04.csv','office,case,project,desk,authority,decision,target,change',out)
print('reserve',dict(counts));print(json.dumps(jobs,ensure_ascii=False))
