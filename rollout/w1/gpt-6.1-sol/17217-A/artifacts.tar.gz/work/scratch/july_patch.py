s=open('scratch/close.py').read().replace("cut='2025-06-30'","cut='2025-07-08'")
s=s.replace("rows('input/财务共享/流转/0630/应付归集.xlsx','认领')","rows('notes/六月留档/流转/0630/应付归集.xlsx','认领')+rows('input/财务共享/流转/0708/应付归集.xlsx','认领')")
s=s.replace("rows('input/财务共享/流转/0630/'+file,sheet)","rows('notes/六月留档/流转/0630/'+file,sheet)+rows('input/财务共享/流转/0708/'+file,sheet)")
s=s.replace("open('out/frozen/erp-events.json','w')","open('notes/七月留档/erp-events.json','w')")
s=s.replace("rows('input/财务共享/寄售/0630/复核移交.xlsx',sheet)","rows('notes/六月留档/寄售/0630/复核移交.xlsx',sheet)+rows('input/财务共享/寄售/0708/复核移交.xlsx',sheet)")
pos=s.index('current=[]')
s=s[:pos]+'''# 售后只用六月冻结凭证和原分摊
june=json.load(open('out/frozen/erp-events.json'))
orig={(r['source'],r['site'],r['event']):r for r in june}
notices={}
for r in csv.DictReader(open('input/财务共享/售后/冲抵通知.csv')):
 if r['posted']<=cut and r['signed']<=cut and r['status'] in ['核准','撤回']:
  key=(r['site'],r['id'])
  if key not in notices or int(r['revision'])>int(notices[key]['revision']):notices[key]=r
support=[]
for r in notices.values():
 if r['status']=='撤回':continue
 old=orig[r['source'],r['site'],r['origin']];assert old['status']!='撤销'
 aa=old['allocations'];remaining=rnd(D(old['booked_value'])*D(r['discount_bps'])/10000)
 for i,a in enumerate(aa):
  k=tuple(a['target']);n=v=D(0)
  if r['source']=='receipt':
   factor=D(old['booked_value'])/D(str(old['qty']))
   n=-D(r['return_qty'])*factor
  else:
   part=remaining if i==len(aa)-1 else rnd(D(a['value'])*D(r['discount_bps'])/10000)
   remaining-=part;v=-part
  totals[k][0]+=n;totals[k][1]+=v
  support.append([r['site'],r['id'],r['source'],r['origin'],old['revision'],*k,n,v])
write('out/credit_support.csv','site,id,source,origin,original_revision,target_site,po,line,net_change,invoice_change',support)
''' +s[pos:]
s+='''
old={ (r['site'],r['po'],int(r['line'])):r for r in csv.DictReader(open('out/frozen/2025-06.csv'))}
bridge=[]
for r in current:
 k=tuple(r[:3]);o=old[k];n=r[5]-D(o['net']);v=r[6]-D(o['invoiced_amount'])
 if n or v:bridge.append([*k,n,v])
write('out/bridge.csv','site,po,line,net_change,invoice_change',bridge)
def routes(events):
 return {(r['site'],r['source'],r['event']):'|'.join(sorted(set('/'.join(map(str,a['target'])) if tuple(a['target']) in O else 'PENDING' for a in r['allocations']))) for r in events if r['status']!='撤销'}
before=routes(june);after=routes(ledger)
def cons_routes(rs):
 out={}
 for r in rs:
  site,batch,bill,status,tickets=r
  targets=set()
  if status=='BOOKED':
   for t in T[site,batch]:
    if t[3] in tickets.split('|'):targets.add('/'.join(map(str,[site,t[4],t[5]])))
  out[site,'invoice',bill]='|'.join(sorted(targets)) if targets else 'PENDING'
 return out
before.update(cons_routes(list(csv.reader(open('out/frozen/consignment-06.csv')))[1:]));after.update(cons_routes(cons))
write('out/routing_changes.csv','site,source,id,before,after',[[*k,before[k],after[k]] for k in sorted(before.keys() & after.keys()) if before[k]!=after[k]])
'''
open('scratch/july.py','w').write(s)
