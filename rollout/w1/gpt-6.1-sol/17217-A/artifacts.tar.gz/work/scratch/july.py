import openpyxl,csv,itertools,collections,json
from decimal import Decimal as D, ROUND_HALF_UP
from pathlib import Path
cut='2025-07-08'
def rnd(v):return v.quantize(D('.01'),rounding=ROUND_HALF_UP)
def rows(p,s):
 v=list(openpyxl.load_workbook(p,data_only=True)[s].values);return [dict(zip(v[0],r)) for r in v[1:]]
def write(p,cols,rs):
 with open(p,'w',newline='') as f:
  w=csv.writer(f);w.writerow(cols.split(','));w.writerows(rs)
b='notes/六月留档/流转/0626/'
orders=rows(b+'订货与基础资料.xlsx','订单'); packs=rows(b+'订货与基础资料.xlsx','包装');rates=rows(b+'订货与基础资料.xlsx','汇率')
O={(r['site'],r['po'],r['line']):r for r in orders}; totals={k:[D(0),D(0)] for k in O};un=[]; ledger=[]
claims=collections.defaultdict(list)
for r in rows('notes/六月留档/流转/0630/应付归集.xlsx','认领')+rows('input/财务共享/流转/0708/应付归集.xlsx','认领'):
 if r['signed']<=cut and r['decision']!='提议':claims[r['source'],r['site'],r['event']].append(r)
for source,file,sheet in [('receipt','仓库签收.xlsx','仓储'),('invoice','应付归集.xlsx','发票')]:
 latest={}
 for r in rows(b+file,sheet)+rows('notes/六月留档/流转/0630/'+file,sheet)+rows('input/财务共享/流转/0708/'+file,sheet):
  if r['posted']<=cut and r['approved']<=cut:
   key=(r['site'],r['event'])
   if key not in latest or r['revision']>latest[key]['revision']:latest[key]=r
 for r in latest.values():
  k=(r['site'],r['po'],r['line']);r=dict(r);r['source']=source
  if r['status']=='撤销':ledger.append(r);continue
  if source=='invoice':
   rate=D(1) if r['currency']=='CNY' else D(str(max([x for x in rates if x['currency']==r['currency'] and x['effective']<=r['posted']],key=lambda x:x['effective'])['cny']))
   val=rnd(D(str(r['amount']))*rate)
  else:
   factor=D(1)
   if r['unit']!='件' and k in O:factor=D(str(max([x for x in packs if x['sku']==O[k]['sku'] and x['unit']==r['unit'] and x['effective']<=r['posted']],key=lambda x:x['effective'])['factor']))
   val=D(str(r['qty']))*factor
  r['booked_value']=str(val);r['target']='/'.join(map(str,k)) if k in O else 'PENDING';ledger.append(r)
  cc=claims[source,r['site'],r['event']]
  cc=[c for c in cc if c['revision']==max(x['revision'] for x in cc)] if cc else []
  targets=[(k,10000)]
  if cc and cc[0]['decision']=='核准':targets=[((c['target_site'],c['po'],c['line']),c['bps']) for c in sorted(cc,key=lambda c:int(c['part']))]
  allocations=[];remaining=val
  for j,(target,bps) in enumerate(targets):
   part=remaining if j==len(targets)-1 else rnd(val*D(str(bps))/10000);remaining-=part
   allocations.append({'target':list(target),'value':str(part)})
   if target in O:totals[target][source=='invoice']+=part
  r['allocations']=allocations
  r['target']='|'.join(sorted('/'.join(map(str,t)) for t,bp in targets))
  if any(t not in O for t,bp in targets):un.append([r['site'],source,r['event'],r['po'],r['line']])
json.dump(ledger,open('notes/七月留档/erp-events.json','w'),ensure_ascii=False,indent=2)
def paper(file,kind):
 s=openpyxl.load_workbook('notes/六月留档/寄售/0626/'+file).active; out=[];site=batch=None
 for row in list(s)[3:]:
  v=[c.value for c in row]
  if v[1]:site=v[1]
  if v[2]:batch=v[2]
  if v[0]!=kind:continue
  out.append((site,batch,v,row[-1].comment))
 return out
T=collections.defaultdict(list);B=collections.defaultdict(list)
for site,batch,v,c in paper('消耗联.xlsx','领用'):T[site,batch].append(v)
for site,batch,v,c in paper('对账联.xlsx','结算'):B[site,batch].append((v,c))
corrections={};changes={}
for sheet,keys,dest in [('数字勘误',['site','batch','bill'],corrections),('签注变更',['site','batch','bill','ticket'],changes)]:
 for r in rows('notes/六月留档/寄售/0630/复核移交.xlsx',sheet)+rows('input/财务共享/寄售/0708/复核移交.xlsx',sheet):
  if r['status']=='签发' and r['signed']<=cut:
   k=tuple(r[x] for x in keys)
   if k not in dest or r['revision']>dest[k]['revision']:dest[k]=r
cons=[]
for group,bills in B.items():
 ts=T[group];candidates=[]
 for v,c in bills:
  v=list(v)
  fix=corrections.get((*group,v[3]))
  if fix:v[6]=fix['total_qty'];v[7]=fix['total_amount']
  poss=[];req=set();ex=set()
  if c and c.author=='应付复核岗':
   for line in c.text.splitlines():
    bits=line.split('／')
    if len(bits)==3 and bits[0]<=cut:
     (req if bits[1]=='指定' else ex).add(bits[2])
  for key,ch in changes.items():
   if key[:3]==(*group,v[3]):
    req.discard(key[3]);ex.discard(key[3])
    if ch['action']=='指定':req.add(key[3])
    elif ch['action']=='排除':ex.add(key[3])
  for inds in itertools.combinations(range(len(ts)),int(v[5])):
   names={ts[i][3] for i in inds}
   if req<=names and not ex&names and sum(D(str(ts[i][6])) for i in inds)==D(str(v[6])) and sum(D(str(ts[i][7])) for i in inds)==D(str(v[7])):poss.append(frozenset(inds))
  candidates.append(poss)
 seen=[set() for _ in bills];count=[0]
 def solve(left,used,picked):
  if not left:
   if len(used)==len(ts):
    count[0]+=1
    for j,p in picked.items():seen[j].add(p)
   return
  j=min(left,key=lambda j:sum(not(p&used) for p in candidates[j]))
  for p in candidates[j]:
   if not p&used:solve(left-{j},used|p,{**picked,j:p})
 solve(set(range(len(bills))),frozenset(),{})
 for j,(v,c) in enumerate(bills):
  status='CONFLICT' if not count[0] else 'BOOKED' if len(seen[j])==1 else 'MULTIPLE';names=[]
  if status=='BOOKED':
   for i in next(iter(seen[j])):
    t=ts[i];names.append(t[3]);k=(group[0],t[4],t[5]);totals[k][0]+=D(str(t[6]));totals[k][1]+=D(str(t[7]))
  else:un.append([group[0],'invoice',v[3],group[1],v[4]])
  cons.append([*group,v[3],status,'|'.join(sorted(names))])
write('out/consignment.csv','site,batch,bill,status,tickets',cons)
# 售后只用六月冻结凭证和原分摊
june=json.load(open('out/frozen/erp-events.json'))
orig={(r['source'],r['site'],r['event']):r for r in june}
notices={}
for r in csv.DictReader(open('input/财务共享/售后/冲抵通知.csv')):
 if r['posted']<=cut and r['signed']<=cut and r['status'] in ['核准','撤回']:
  key=(r['site'],r['id'])
  if key not in notices or int(r['revision'])>int(notices[key]['revision']):notices[key]=r
support=[]
for r in notices.values():
 if r['status']=='撤回':continue
 old=orig[r['source'],r['site'],r['origin']];assert old['status']!='撤销'
 aa=old['allocations'];remaining=rnd(D(old['booked_value'])*D(r['discount_bps'])/10000)
 for i,a in enumerate(aa):
  k=tuple(a['target']);n=v=D(0)
  if r['source']=='receipt':
   factor=D(old['booked_value'])/D(str(old['qty']))
   n=-D(r['return_qty'])*factor
  else:
   part=remaining if i==len(aa)-1 else rnd(D(a['value'])*D(r['discount_bps'])/10000)
   remaining-=part;v=-part
  totals[k][0]+=n;totals[k][1]+=v
  support.append([r['site'],r['id'],r['source'],r['origin'],old['revision'],*k,n,v])
write('out/credit_support.csv','site,id,source,origin,original_revision,target_site,po,line,net_change,invoice_change',support)
current=[]
for k,r in O.items():
 n,a=totals[k];q=n-D(str(r['ordered']));diff=rnd(a-n*D(str(r['unit_price'])));flags=('Q' if q else '')+('A' if diff else '')
 current.append([*k,r['project'],r['ordered'],n,a,q,diff,flags])
write('out/current.csv','site,po,line,project,ordered,net,invoiced_amount,qty_diff,amount_diff,flags',current)
write('out/unclaimed.csv','site,source,id,po,line',un)
meeting=[];priority=[]
for p in ['甲','乙','丙']:
 rr=[r for r in current if r[3]==p];ee=[r for r in rr if r[-1]]
 meeting.append([p,len(rr),len(ee),sum(bool(r[7]) for r in rr),sum(bool(r[8]) for r in rr),sum(abs(r[8]) for r in rr)])
 for rank,r in enumerate(sorted(ee,key=lambda r:(-abs(r[8]),-abs(r[7]),r[0],r[1],int(r[2])))[:3],1):priority.append([p,rank,*r[:3],r[-1]])
write('out/meeting.csv','project,total_lines,exception_lines,qty_lines,amount_lines,exposure',meeting)
write('out/priority.csv','project,rank,site,po,line,flags',priority)
print('current',len(current),'unclaimed',len(un),'consignment',collections.Counter(r[3] for r in cons))

old={ (r['site'],r['po'],int(r['line'])):r for r in csv.DictReader(open('out/frozen/2025-06.csv'))}
bridge=[]
for r in current:
 k=tuple(r[:3]);o=old[k];n=r[5]-D(o['net']);v=r[6]-D(o['invoiced_amount'])
 if n or v:bridge.append([*k,n,v])
write('out/bridge.csv','site,po,line,net_change,invoice_change',bridge)
def routes(events):
 return {(r['site'],r['source'],r['event']):'|'.join(sorted(set('/'.join(map(str,a['target'])) if tuple(a['target']) in O else 'PENDING' for a in r['allocations']))) for r in events if r['status']!='撤销'}
before=routes(june);after=routes(ledger)
def cons_routes(rs):
 out={}
 for r in rs:
  site,batch,bill,status,tickets=r
  targets=set()
  if status=='BOOKED':
   for t in T[site,batch]:
    if t[3] in tickets.split('|'):targets.add('/'.join(map(str,[site,t[4],t[5]])))
  out[site,'invoice',bill]='|'.join(sorted(targets)) if targets else 'PENDING'
 return out
before.update(cons_routes(list(csv.reader(open('out/frozen/consignment-06.csv')))[1:]));after.update(cons_routes(cons))
write('out/routing_changes.csv','site,source,id,before,after',[[*k,before[k],after[k]] for k in sorted(before.keys() & after.keys()) if before[k]!=after[k]])
