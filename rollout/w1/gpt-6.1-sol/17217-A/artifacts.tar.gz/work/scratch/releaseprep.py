s=open('scratch/settle.py').read();s=s[:s.index("write('out/settlement.csv'")]+"write('out/settlement.csv','employee,channel,account,gross,paid,reserved,payable',settlement)\n"
s=s.replace("cut='2025-08-04 17:00';day='2025-08-04'","cut='2025-08-05 09:00';day='2025-08-05'")
s=s.replace("channels={", "channels={",1)
s=s.replace("legacy={", "\nfor r in read('input/资金运营/晨间卡务签件.csv'):\n r['revision']=100;accounts.append(r)\nlegacy={",1)
s=s.replace("read('input/资金运营/垫付直联流水.csv'):","read('input/资金运营/垫付直联流水.csv')+read('input/资金运营/早班直联流水.csv'):")
s=s.replace("r['effective']<=day","r['effective']<=cut")
exec(s)
jobs=json.load(open('notes/送审0804/drafts.json'));planned=[]
for job in jobs:
 packet=job['packet'];action='HOLD';recipient=job['recipient'];attachment=job['attachment'];subject=job['subject']
 if packet in ['B01','B02','B03']:
  old={r['account']:D(r['bonus']) for r in read(attachment)};now={a:v for a,v in packages[packet]}
  if not now:action='HOLD'
  elif any(now.get(a,D(0))<v for a,v in old.items()):
   action='REDRAFT';attachment=attachment.replace('.csv','-replace.csv');subject+='/重拟待批';write(attachment,'account,bonus',sorted(now.items()))
  else:
   action='SEND';extra={a:v-old.get(a,D(0)) for a,v in now.items() if v>old.get(a,D(0))}
   if extra:
    ep=attachment.replace('.csv','-extra.csv');write(ep,'account,bonus',sorted(extra.items()));planned.append({**job,'action':'TOPUP','attachment':ep,'subject':subject+'/补发待批'})
 else:
  signs=[r for r in read('input/资金运营/签报流水.csv') if r['batch']==job['batch'] and r['packet']==packet and r['desk']=='财务' and r['approval']=='签发' and r['effective']<=cut]
  if signs:
   sig=max(signs,key=lambda r:int(r['revision']));valid=True
   if packet=='FIN':valid=any(r['batch']==sig['batch'] and r['packet']==packet and r['revision']==sig['revision'] and r['desk']=='内控' and r['approval']=='签发' and r['action']==sig['action'] and r['effective']<=cut for r in read('input/资金运营/签报流水.csv'))
   if valid:
    if sig['action']=='放行':action='SEND'
    elif sig['action']=='换岗':
     action='REDRAFT'
     slots=[r for r in sheet('input/资金运营/运营主数据.xlsx','岗位邮箱登记') if r['slot']==sig['slot'] and r['approval']=='签发' and r['valid_from']<=day<=r['valid_to']]
     recipient=max(slots,key=lambda r:int(r['revision']))['mailbox']
 planned.append({**job,'action':action,'recipient':recipient,'attachment':attachment,'subject':subject})
json.dump(planned,open('notes/放行0805/planned.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(planned,ensure_ascii=False))
