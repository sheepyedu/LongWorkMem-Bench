import csv,collections
from fractions import Fraction as F
from decimal import Decimal as D,ROUND_DOWN
import openpyxl
from openpyxl.styles import Font,PatternFill
from openpyxl.workbook.properties import CalcProperties
def read(p):return list(csv.DictReader(open(p)))
def write(p,head,rs):
 with open(p,'w',newline='') as f:w=csv.writer(f);w.writerow(head.split(','));w.writerows(rs)
sigs=collections.defaultdict(set)
for r in read('input/财务会签/调班联签流水.csv'):
 if r['decision']=='签发' and r['signed']<='2025-08-03 18:00':sigs[r['site'],r['ticket'],int(r['revision'])].add(r['authority'])
print('roles',set(x for v in sigs.values() for x in v))
trans={}
for r in read('input/人事值班/追溯调班登记.csv'):
 k=r['site'],r['ticket'];v=int(r['revision'])
 if {'财务','人事'}<=sigs[k+(v,)]:
  if k not in trans or v>int(trans[k]['revision']):trans[k]=r
trans={k:r for k,r in trans.items() if r['decision']=='改派'}
write('out/time_transfers.csv','site,ticket,revision,destination,percent',[[r[x] for x in ['site','ticket','revision','destination','percent']] for k,r in sorted(trans.items())])
latest={}
for r in read('input/工时中心/主账.csv')+read('input/工时中心/补正.csv'):
 if r['decision'] in ['已核','作废'] and r['posted']<='2025-08-03 18:00':
  k=r['site'],r['ticket']
  if k not in latest or int(r['revision'])>int(latest[k]['revision']):latest[k]=r
index=read('out/frozen/payroll-index.csv');home={r['employee']:r['home'] for r in read('input/薪酬制度/人员台账.csv')};duties=read('input/人事值班/签批派班.csv');hours=collections.defaultdict(F);review=[];audit=[]
for k,r in latest.items():
 if r['decision']=='作废' or not '2025-07-01'<=r['worked']<='2025-07-31':continue
 matches=[x for x in index if x['site']==r['site'] and x['badge']==r['badge'] and x['valid_from']<=r['worked']<=x['valid_to']];assert len(matches)==1
 x=matches[0];e=x['employee'];h=F(r['units'])*(F(1,60) if r['unit']=='MIN' else 1)*F(x['rate']);p=r['project']
 if p=='共享':
  p=home[e]
  if e=='E07':p='乙' if r['worked']>='2025-07-16' else '甲'
  for d in duties:
   if d['employee']==e and d['from']<=r['worked']<=d['to']:p=d['project']
 portions=[(p,h)]
 if k in trans:
  t=trans[k];m=h*F(t['percent'])/100;portions=[(p,h-m),(t['destination'],m)]
 if any(p=='待查' and h>0 for p,h in portions):review.append(k)
 for p,h in portions:
  if h>0:hours[p,e]+=h
 audit.append([*k,e,r['worked'],str(h),str(portions)])
write('out/time_review.csv','site,ticket',sorted(review))
prior={}
for r in read('input/财务会签/六月激励结转.csv'):
 if r['decision']=='签发' and r['signed']<='2025-06-30 18:00':
  k=r['project'],r['employee']
  if k not in prior or int(r['revision'])>int(prior[k]['revision']):prior[k]=r
pools={r['project']:F(r['pool']) for r in read('out/released.csv')};caps={(r['project'],r['employee']):F(r['cap']) for r in read('input/财务会签/个人合同上限.csv')}
def cum(h):return min(h,F(40))+max(h-40,0)*F(3,2)
result=[]
for p,pool in pools.items():
 hh={e:h for (pp,e),h in hours.items() if pp==p and h>0};weights={e:cum(h+F(prior.get((p,e),{}).get('prior_hours','0')))-cum(F(prior.get((p,e),{}).get('prior_hours','0'))) for e,h in hh.items()}
 def allocate(es,amount):
  den=sum(weights[e] for e in es);out={e:F((amount*weights[e]/den*100).__floor__(),100) for e in es};winner=min(es,key=lambda e:(-weights[e],e));out[winner]+=amount-sum(out.values());return out
 money=allocate(list(hh),pool)
 for e in hh:
  if (p,e) in caps and (pool*weights[e]/sum(weights.values())>=caps[p,e] or money[e]>caps[p,e]):money=allocate([x for x in hh if x!=e],pool-caps[p,e]);money[e]=caps[p,e];break
 for e in sorted(hh):result.append([p,e,float(hh[e]),float(money[e])])
write('out/pay.csv','project,employee,hours,bonus',[[p,e,format(h,'.12g'),format(b,'.2f')] for p,e,h,b in result])
w=openpyxl.Workbook();ps=w.active;ps.title='Pools';ps.append(['project','pool','total_bonus','difference']);pay=w.create_sheet('Pay');pay.append(['project','employee','hours','bonus','prior_hours','cap','increment_weight','raw_share','normal_floor','normal_bonus','cap_trigger','redistribution_weight','final_floor'])
for p,pool in pools.items():ps.append([p,float(pool),f'=SUMIF(Pay!A2:A{len(result)+1},A{ps.max_row+1},Pay!D2:D{len(result)+1})',f'=ROUND(B{ps.max_row+1}-C{ps.max_row+1},2)'])
N=len(result)+1
for i,(p,e,h,bonus) in enumerate(result,2):
 pr=float(F(prior.get((p,e),{}).get('prior_hours','0')));cap=float(caps[p,e]) if (p,e) in caps else None
 pay.append([p,e,h,None,pr,cap])
 # project rows contiguous, employees ascending => MATCH picks smallest employee in a tie
 inds=[j for j,r in enumerate(result,2) if r[0]==p];lo=min(inds);hi=max(inds);pi=list(pools).index(p)+2;pool=f'Pools!$B${pi}'
 W=f'$G${lo}:$G${hi}';floors=f'$I${lo}:$I${hi}';normalwinner=f'MATCH(MAX({W}),{W},0)+{lo}-1'
 pay.cell(i,7,f'=MIN(C{i}+E{i},40)+MAX(C{i}+E{i}-40,0)*1.5-MIN(E{i},40)-MAX(E{i}-40,0)*1.5')
 pay.cell(i,8,f'={pool}*G{i}/SUM({W})')
 pay.cell(i,9,f'=ROUNDDOWN(H{i},2)')
 pay.cell(i,10,f'=I{i}+IF(ROW()={normalwinner},ROUND({pool}-SUM({floors}),2),0)')
 pay.cell(i,11,f'=IF(ISNUMBER(F{i}),IF(OR(H{i}>=F{i},J{i}>F{i}),1,0),0)')
 pay.cell(i,12,f'=IF(K{i}=1,0,G{i})')
 capsum=f'SUMPRODUCT($F${lo}:$F${hi},$K${lo}:$K${hi})';RW=f'$L${lo}:$L${hi}';RF=f'$M${lo}:$M${hi}'
 pay.cell(i,13,f'=IF(K{i}=1,F{i},ROUNDDOWN(({pool}-{capsum})*L{i}/SUM({RW}),2))')
 pay.cell(i,4,f'=IF(SUM($K${lo}:$K${hi})=0,J{i},M{i}+IF(AND(K{i}=0,ROW()=MATCH(MAX({RW}),{RW},0)+{lo}-1),ROUND({pool}-SUM({RF}),2),0))')
for sh in w:
 sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
 for c in sh[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='254B68')
 for col in sh.columns:sh.column_dimensions[col[0].column_letter].width=20
 for row in sh.iter_rows(min_row=2):
  for c in row:
   if c.column>=3:c.number_format='0.00'
for col in ['E','F','G','H','I','J','K','L','M']:pay.column_dimensions[col].hidden=True
w.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True)
w.save('out/bonus.xlsx')
print('pay rows',len(result),'review',len(review),'transfers',len(trans))
