p='scratch/close.py'
s=open(p).read().replace("b='input/财务共享/流转/0626/'","b='notes/六月留档/流转/0626/'")
s=s.replace("for r in rows(b+file,sheet):","for r in rows(b+file,sheet)+rows('input/财务共享/流转/0630/'+file,sheet):")
s=s.replace("for source,file,sheet in",'''claims=collections.defaultdict(list)
for r in rows('input/财务共享/流转/0630/应付归集.xlsx','认领'):
 if r['signed']<=cut and r['decision']!='提议':claims[r['source'],r['site'],r['event']].append(r)
for source,file,sheet in''')
s=s.replace("if k not in O:un.append([r['site'],source,r['event'],r['po'],r['line']])\n  else:totals[k][source=='invoice']+=val",'''cc=claims[source,r['site'],r['event']]
  cc=[c for c in cc if c['revision']==max(x['revision'] for x in cc)] if cc else []
  targets=[(k,10000)]
  if cc and cc[0]['decision']=='核准':targets=[((c['target_site'],c['po'],c['line']),c['bps']) for c in sorted(cc,key=lambda c:int(c['part']))]
  allocations=[];remaining=val
  for j,(target,bps) in enumerate(targets):
   part=remaining if j==len(targets)-1 else rnd(val*D(str(bps))/10000);remaining-=part
   allocations.append({'target':list(target),'value':str(part)})
   if target in O:totals[target][source=='invoice']+=part
  r['allocations']=allocations
  r['target']='|'.join(sorted('/'.join(map(str,t)) for t,bp in targets))
  if any(t not in O for t,bp in targets):un.append([r['site'],source,r['event'],r['po'],r['line']])''')
s=s.replace("'input/财务共享/寄售/0626/'","'notes/六月留档/寄售/0626/'")
s=s.replace("cons=[]",'''corrections={};changes={}
for sheet,keys,dest in [('数字勘误',['site','batch','bill'],corrections),('签注变更',['site','batch','bill','ticket'],changes)]:
 for r in rows('input/财务共享/寄售/0630/复核移交.xlsx',sheet):
  if r['status']=='签发' and r['signed']<=cut:
   k=tuple(r[x] for x in keys)
   if k not in dest or r['revision']>dest[k]['revision']:dest[k]=r
cons=[]''')
s=s.replace("poss=[];req=set();ex=set()","v=list(v)\n  fix=corrections.get((*group,v[3]))\n  if fix:v[6]=fix['total_qty'];v[7]=fix['total_amount']\n  poss=[];req=set();ex=set()")
s=s.replace("for inds in itertools.combinations",'''for key,ch in changes.items():
   if key[:3]==(*group,v[3]):
    req.discard(key[3]);ex.discard(key[3])
    if ch['action']=='指定':req.add(key[3])
    elif ch['action']=='排除':ex.add(key[3])
  for inds in itertools.combinations''')
open(p,'w').write(s)
